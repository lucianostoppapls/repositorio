# Sazonalidade

Este programa tem como objetivo prover uma interface simples para atualização da tabela ```DimSeasonality``` do banco ```StoneDwv0```. Ao fazer um upload do excel na interface, este programa:

1. Deleta arquivos de mesmo nome na pasta upload
2. Salva o arquivo na pasta upload
3. Lê e cria uma tabela no ```StoneDwv0``` de staging com as primeiras colunas da pimeira planilha do excel (ele espera receber um excel como os exemplos da pasta download)
4. Roda uma das query localizada na pasta app/template/querys desse projeto(.sql), para atualizar a tabela fim.

## Executando localmente

Para trabalhar com este projeto, você deve ter o Docker instalado no seu computador. No Ubuntu:

```sudo apt install docker```

Alimentar as variáveis de ambiente  ```USERNAME```, ```PASSWORD```, ```HOST```, ```PORT``` e ```FLASK_CONFIG```. Seja passando por parametro para o docker através do comando ```docker run --env USERNAME=example --env HOST=localhost...``` ou criando um arquivo com extenção .env e atribuindo seu nome no parametro ```--env-file```, ```docker run docker run --env-file example.env```. A variável FLASK_CONFIG deve ser atribuida o valor ```FLASK_CONFIG=production```para montar a connection string através das variáveis.

```

Crie a imagem docker:

```docker build -t sazonalidade .```

Crie um container com o comando abaixo, passando como parametro o nome do arquivo de variáveis de ambiente:

```docker run --restart=always  -d --env-file=dockenv.env -p 5000:5000 sazonalidade```

Após a execução do comando acima será levantado um servidor web escutando a porta 5000

Se precisar destruir o container:

```docker rm $(docker stop $(docker ps -a -q --filter ancestor=sazonalidade --format="{{.ID}}"))```
