from flask_wtf import FlaskForm
from flask_wtf.file import FileRequired, FileAllowed, FileField
from wtforms import SelectField, SubmitField


class UploadForm(FlaskForm):
    option = SelectField(
        "Tipo",
        choices=[
            ("tpv", "TPV"),
            ("credenciamento", "Credenciamentos"),
            ("outras", "Outras Receitas Digital"),
            ("rav", "RAV"),
            ("tpv_credito", "TPV Crédito"),
            ("dx_auto_spot", "DX Auto e Spot"),
            ("tpv_antecipado_auto_spot", "TPV antecipado auto e Spot"),
        ],
    )
    excel = FileField(
        "File",
        validators=[FileRequired(), FileAllowed(["xlsxb", "xlsx"], "Excel only")],
    )
    submit = SubmitField("Enviar")
