from . import seasonality
from .. import db
from .forms import UploadForm
from datetime import datetime
from flask import current_app
from flask import render_template, url_for, flash
from werkzeug.utils import secure_filename
import json, pandas, os


def update_dim_seasonality_tpv(json_file):

    temp_table_name = (
        f"sazonalidade_staging_tpv_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}"
    )
    try:
        with db.engine.begin() as conn:
            conn.execute(
                f"""
                SET NOCOUNT ON;
                IF OBJECT_ID('Stonedwv0.airflow_staging.{temp_table_name}') IS NOT NULL
                    DROP TABLE Stonedwv0.airflow_staging.{temp_table_name};
                CREATE TABLE Stonedwv0.airflow_staging.{temp_table_name} (
                    Fulldate datetime,
                    SalesStructurenamelevel1 varchar(50),
                    SalesStructurenamelevel2 varchar(50),
                    Seasonality float
            );
            """
            )
    except Exception as err:
        return "Erro ao criar a tabela temporária no DW. Tente novamente."

    try:
        with db.engine.begin() as conn:
            for row in json_file:
                # check if the dictnary not contain None values
                for key, value in row.items():
                    if value is None:
                        return f"Ha valores em branco na coluna {key}"

                conn.execute(
                    f"""
                        SET NOCOUNT ON;
                        INSERT INTO Stonedwv0.airflow_staging.{temp_table_name} (Fulldate, SalesStructurenamelevel1, SalesStructurenamelevel2, Seasonality)
                        VALUES('{row["Data"]}','{row["Canal"]}','{row["SubCanal"]}','{row["Sazonalidade"]}');
                    """
                )
    except Exception as err:
        return "Erro ao inserir dados na tabela temporária. Certifique-se de que a ordem das colunas está como no exemplo. Caso sim, tente novamente mais tarde."

    try:
        with db.engine.begin() as conn:
            sql = render_template(
                "querys/transfer_seasonality_tpv.sql", temp_table_name=temp_table_name
            )
            conn.execute(sql)
            conn.execute(f"DROP TABLE Stonedwv0.airflow_staging.{temp_table_name}")
    except Exception as err:
        return err

    return "Tabela atualizada com sucesso!"


def update_dim_seasonality_rav(json_file):
    temp_table_name = (
        f"sazonalidade_staging_rav_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}"
    )
    try:
        with db.engine.begin() as conn:
            conn.execute(
                f"""
                SET NOCOUNT ON;
                IF OBJECT_ID('Stonedwv0.airflow_staging.{temp_table_name}') IS NOT NULL
                    DROP TABLE Stonedwv0.airflow_staging.{temp_table_name};
                CREATE TABLE Stonedwv0.airflow_staging.{temp_table_name} (
                    Fulldate datetime,
                    SalesStructurenamelevel1 varchar(50),
                    SalesStructurenamelevel2 varchar(50),
                    SeasonalityAuto float,
                    SeasonalitySpot float
                );
            """
            )
    except:
        return "Erro ao criar a tabela temporária no DW. Tente novamente."
    try:
        with db.engine.begin() as conn:
            for row in json_file:
                # check if the dictnary not contain None values
                for key, value in row.items():
                    if value is None:
                        return f"Ha valores em branco na coluna {key}"
                conn.execute(
                    f"""
                    SET NOCOUNT ON;
                    INSERT INTO Stonedwv0.airflow_staging.{temp_table_name} (Fulldate, SalesStructurenamelevel1, SalesStructurenamelevel2, SeasonalityAuto, SeasonalitySpot)
                    VALUES('{row["Data"]}','{row["Canal"]}','{row["SubCanal"]}','{row["Sazonalidade Automática"]}','{row["Sazonalidade Pontual"]}');
                """
                )
    except Exception as err:
        return f"Erro ao inserir dados na tabela temporária. Certifique-se de que a ordem das colunas está como no exemplo. Caso sim, tente novamente mais tarde."

    try:
        with db.engine.begin() as conn:
            sql = render_template(
                "querys/transfer_seasonality_rav.sql", temp_table_name=temp_table_name
            )
            conn.execute(sql)
            conn.execute(
                f"""
                SET NOCOUNT ON;
                DROP TABLE Stonedwv0.airflow_staging.{temp_table_name}
            """
            )
    except Exception as err:
        return err

    return "Tabela atualizada com sucesso!"


def update_dim_seasonality_new_clients(json_file):
    temp_table_name = f"sazonalidade_staging_new_clients_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}"
    try:
        with db.engine.begin() as conn:
            conn.execute(
                f"""
                SET NOCOUNT ON;
                IF OBJECT_ID('Stonedwv0.airflow_staging.{temp_table_name}') IS NOT NULL
                    DROP TABLE Stonedwv0.airflow_staging.{temp_table_name};
                CREATE TABLE Stonedwv0.airflow_staging.{temp_table_name} (
                    Fulldate datetime,
                    SalesStructurenamelevel1 varchar(50),
                    SalesStructurenamelevel2 varchar(50),
                    Seasonality float
                );
            """
            )
    except Exception as e:
        return f"Erro ao criar a tabela temporária no DW. Tente novamente."

    try:
        with db.engine.begin() as conn:
            for row in json_file:
                # check if the dictnary not contain None values
                for key, value in row.items():
                    if value is None:
                        return f"Ha valores em branco na coluna {key}"
                conn.execute(
                    f"""
                    SET NOCOUNT ON;
                    INSERT INTO 
                    Stonedwv0.airflow_staging.{temp_table_name} 
                        (Fulldate, SalesStructurenamelevel1, SalesStructurenamelevel2, Seasonality)
                    VALUES('{row["Data"]}','{row["Canal"]}','{row["SubCanal"]}','{row["Sazonalidade"]}');
                """
                )
    except:
        return "Erro ao inserir dados na tabela temporária. Certifique-se de que a ordem das colunas está como no exemplo. Caso sim, tente novamente mais tarde."

    try:
        with db.engine.begin() as conn:
            sql = render_template(
                "querys/transfer_seasonality_new_clients.sql",
                temp_table_name=temp_table_name,
            )
            conn.execute(sql)
            conn.execute(
                f"""
                SET NOCOUNT ON;
                DROP TABLE Stonedwv0.airflow_staging.{temp_table_name}
            """
            )
    except Exception as err:
        return f"Erro de inserção no banco de dados."
    return "Tabela atualizada com sucesso!"


def update_dim_seasonality_other_revenues_digital(json_file):
    temp_table_name = f"sazonalidade_staging_other_revenues_digital_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}"
    try:
        with db.engine.begin() as conn:
            conn.execute(
                f"""
                SET NOCOUNT ON;
                IF OBJECT_ID('Stonedwv0.airflow_staging.{temp_table_name}') IS NOT NULL
                    DROP TABLE Stonedwv0.airflow_staging.{temp_table_name};
                CREATE TABLE Stonedwv0.airflow_staging.{temp_table_name} (
                    Fulldate datetime,
                    SalesStructurenamelevel1 varchar(50),
                    SalesStructurenamelevel2 varchar(50),
                    OtherRevenues float
                );
            """
            )
    except:
        return "Erro ao criar a tabela temporária no DW. Tente novamente."

    try:
        with db.engine.begin() as conn:
            for row in json_file:
                # check if the dictnary not contain None values
                for key, value in row.items():
                    if value is None:
                        return f"Ha valores em branco na coluna {key}"
                conn.execute(
                    f"""
                    SET NOCOUNT ON;
                    INSERT INTO Stonedwv0.airflow_staging.{temp_table_name} (Fulldate, SalesStructurenamelevel1, SalesStructurenamelevel2, OtherRevenues)
                    VALUES('{row["Data"]}','{row["Canal"]}','{row["SubCanal"]}','{row["OutrasReceitas"]}');
                """
                )
    except Exception as err:
        return f"Erro ao inserir dados na tabela temporária. Certifique-se de que a ordem das colunas está como no exemplo. Caso sim, tente novamente mais tarde."

    try:
        with db.engine.begin() as conn:
            sql = render_template(
                "querys/transfer_seasonality_otherrevenuesdigital.sql",
                temp_table_name=temp_table_name,
            )
            conn.execute(sql)
            conn.execute(
                f"""
                SET NOCOUNT ON;
                DROP TABLE Stonedwv0.airflow_staging.{temp_table_name}
            """
            )
    except Exception as err:
        return err

    return "Tabela atualizada com sucesso!"


def update_dim_seasonality_credit(json_file):
    temp_table_name = (
        f"sazonalidade_staging_credit_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}"
    )
    try:
        with db.engine.begin() as conn:
            conn.execute(
                f"""
                SET NOCOUNT ON;
                IF OBJECT_ID('Stonedwv0.airflow_staging.{temp_table_name}') IS NOT NULL
                    DROP TABLE Stonedwv0.airflow_staging.{temp_table_name};
                CREATE TABLE Stonedwv0.airflow_staging.{temp_table_name} (
                    Fulldate datetime,
                    SalesStructurenamelevel1 varchar(50),
                    SalesStructurenamelevel2 varchar(50),
                    TPVCreditSeasonality float
                );
            """
            )
    except Exception as err:
        return f"Erro ao criar a tabela temporária no DW. Tente novamente."

    try:
        with db.engine.begin() as conn:
            for row in json_file:
                # check if the dictnary not contain None values
                for key, value in row.items():
                    if value is None:
                        return f"Ha valores em branco na coluna {key}"
                conn.execute(
                    f"""
                    SET NOCOUNT ON;
                    INSERT INTO Stonedwv0.airflow_staging.{temp_table_name} (Fulldate, SalesStructurenamelevel1, SalesStructurenamelevel2, TPVCreditSeasonality)
                    VALUES('{row["Data"]}','{row["Canal"]}','{row["SubCanal"]}','{row["TPVCreditSeasonality"]}');
                """
                )
    except Exception as err:
        return f"Erro ao inserir dados na tabela temporária. Certifique-se de que a ordem das colunas está como no exemplo. Caso sim, tente novamente mais tarde."

    try:
        with db.engine.begin() as conn:
            sql = render_template(
                "querys/transfer_seasonality_credit.sql",
                temp_table_name=temp_table_name,
            )
            conn.execute(sql)
            conn.execute(
                f"""
                SET NOCOUNT ON;
                DROP TABLE Stonedwv0.airflow_staging.{temp_table_name}
            """
            )
    except Exception as err:
        return err

    return "Tabela atualizada com sucesso!"


def update_dim_seasonality_dx_auto_spot(json_file):
    temp_table_name = f"sazonalidade_staging_dx_auto_spot_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}"
    try:
        with db.engine.begin() as conn:
            conn.execute(
                f"""
                SET NOCOUNT ON;
                IF OBJECT_ID('Stonedwv0.airflow_staging.{temp_table_name}') IS NOT NULL
                    DROP TABLE Stonedwv0.airflow_staging.{temp_table_name};
                CREATE TABLE Stonedwv0.airflow_staging.{temp_table_name} (
                    Fulldate datetime,
                    SalesStructurenamelevel1 varchar(50),
                    SalesStructurenamelevel2 varchar(50),
                    AutoDXSeasonality float,
                    SpotDXSeasonality float
                );
            """
            )
    except:
        return "Erro ao criar a tabela temporária no DW. Tente novamente."

    try:
        with db.engine.begin() as conn:
            for row in json_file:
                # check if the dictnary not contain None values
                for key, value in row.items():
                    if value is None:
                        return f"Ha valores em branco na coluna {key}"
                conn.execute(
                    f"""
                    SET NOCOUNT ON;
                    INSERT INTO Stonedwv0.airflow_staging.{temp_table_name} (Fulldate, SalesStructurenamelevel1, SalesStructurenamelevel2, AutoDXSeasonality, SpotDXSeasonality)
                    VALUES('{row["Data"]}','{row["Canal"]}','{row["SubCanal"]}','{row["DX Auto"]}','{row["DX Spot"]}');
                """
                )
    except Exception as err:
        return f"Erro ao inserir dados na tabela temporária. Certifique-se de que a ordem das colunas está como no exemplo. Caso sim, tente novamente mais tarde."

    try:
        with db.engine.begin() as conn:
            sql = render_template(
                "querys/transfer_seasonality_dx.sql", temp_table_name=temp_table_name
            )
            conn.execute(sql)
            conn.execute(
                f"""
                SET NOCOUNT ON;
                DROP TABLE Stonedwv0.airflow_staging.{temp_table_name}
            """
            )
    except Exception as err:
        return err

    return "Tabela atualizada com sucesso!"


def update_dim_seasonality_gross_auto_spot(json_file):
    temp_table_name = f"sazonalidade_staging_gross_auto_spot_{datetime.now().strftime('%m_%d_%Y_%H_%M_%S')}"
    try:
        with db.engine.begin() as conn:
            conn.execute(
                f"""
                SET NOCOUNT ON;
                IF OBJECT_ID('Stonedwv0.airflow_staging.{temp_table_name}') IS NOT NULL
                    DROP TABLE Stonedwv0.airflow_staging.{temp_table_name};
                CREATE TABLE Stonedwv0.airflow_staging.{temp_table_name} (
                    Fulldate datetime,
                    SalesStructurenamelevel1 varchar(50),
                    SalesStructurenamelevel2 varchar(50),
                    GrossValueAutoSeasonality float,
                    GrossValueSpotSeasonality float
                );
            """
            )
    except:
        return "Erro ao criar a tabela temporária no DW. Tente novamente."

    try:
        with db.engine.begin() as conn:
            for row in json_file:
                # check if the dictnary not contain None values
                for key, value in row.items():
                    if value is None:
                        return f"Ha valores em branco na coluna {key}"
                conn.execute(
                    f"""
                    SET NOCOUNT ON;
                    INSERT INTO Stonedwv0.airflow_staging.{temp_table_name} (Fulldate, SalesStructurenamelevel1, SalesStructurenamelevel2, GrossValueAutoSeasonality, GrossValueSpotSeasonality)
                    VALUES('{row["Data"]}','{row["Canal"]}','{row["SubCanal"]}','{row["TPV Antecipado Auto"]}','{row["TPV Antecipado Spot"]}');
                """
                )
    except Exception as err:
        return f"Erro ao inserir dados na tabela temporária. Certifique-se de que a ordem das colunas está como no exemplo. Caso sim, tente novamente mais tarde."

    try:
        with db.engine.begin() as conn:
            sql = render_template(
                "querys/transfer_seasonality_tpv_antecipado.sql",
                temp_table_name=temp_table_name,
            )
            conn.execute(sql)
            conn.execute(
                f"""
                SET NOCOUNT ON;
                DROP TABLE Stonedwv0.airflow_staging.{temp_table_name}
            """
            )
    except Exception as err:
        return err

    return "Tabela atualizada com sucesso!"


@seasonality.route("/", methods=["GET", "POST"])
def index():
    form = UploadForm()
    if form.validate_on_submit():
        f = form.excel.data
        filename = secure_filename(f.filename)
        try:
            path = ("./upload/%s") % (filename)
            os.remove(path)
        except:
            pass
        f.save(os.path.join("app/static/upload", filename))
        json_file = json.loads(
            pandas.read_excel(os.path.join("app/static/upload", filename)).to_json(
                orient="records", date_format="iso"
            )
        )
        if form.option.data == "tpv":
            flash(update_dim_seasonality_tpv(json_file))
        elif form.option.data == "rav":
            flash(update_dim_seasonality_rav(json_file))
        elif form.option.data == "credenciamento":
            flash(update_dim_seasonality_new_clients(json_file))
        elif form.option.data == "tpv_credito":
            flash(update_dim_seasonality_credit(json_file))
        elif form.option.data == "dx_auto_spot":
            flash(update_dim_seasonality_dx_auto_spot(json_file))
        elif form.option.data == "tpv_antecipado_auto_spot":
            flash(update_dim_seasonality_gross_auto_spot(json_file))
        elif form.option.data == "outras":
            flash(update_dim_seasonality_other_revenues_digital(json_file))
    return render_template("seasonality.html", form=form)
