from flask import Blueprint

seasonality = Blueprint("seasonality", __name__)
from . import views, forms
