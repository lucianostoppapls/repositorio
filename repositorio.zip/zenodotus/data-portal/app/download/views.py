from . import download_blueprint
from flask import send_from_directory, render_template


@download_blueprint.route("/<file>", methods=["GET"])
def download(file):
    if file not in (
        [
            "tpv",
            "rav",
            "credenciamentos",
            "outrasreceitasdigital",
            "dx_auto_spot",
            "tpv_antecipado_auto_spot",
            "tpv_credito",
        ]
    ):
        return render_template("404.html")

    return send_from_directory(
        directory="./static", filename=f"{file}_exemplo.xlsx", as_attachment=True
    )
