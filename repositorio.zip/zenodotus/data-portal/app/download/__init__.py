from flask import Blueprint

download_blueprint = Blueprint("download", __name__)
from . import views
