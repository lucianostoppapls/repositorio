USE StoneDwv0

IF OBJECT_ID('tempdb..#SAZ_CREDIT') IS NOT NULL
    DROP TABLE #SAZ_CREDIT

SELECT REPLACE(CAST(b.Fulldate AS DATE),'-','') Datekey
		,a.SalesStructurenamelevel1
		,a.SalesStructurenamelevel2
		,SUM(a.TPVCreditSeasonality) [TPVCreditSeasonality]
		INTO #SAZ_CREDIT
FROM [StoneDWv0].[airflow_staging].[{{temp_table_name}}] a
JOIN [StoneDWv0].[airflow_staging].[{{temp_table_name}}] b
	on a.Fulldate<=b.Fulldate
		and a.SalesStructurenamelevel1 = b.SalesStructurenamelevel1
		and a.SalesStructurenamelevel2 = b.SalesStructurenamelevel2
GROUP BY b.Fulldate
		,a.SalesStructurenamelevel1
		,a.SalesStructurenamelevel2

UPDATE A
	SET
		A.[TPVCreditSeasonality] = B.[TPVCreditSeasonality]
FROM [StoneDWv0].[dbo].[DimSeasonality] A
JOIN #SAZ_CREDIT B
	ON A.Datekey = B.Datekey
	AND A.SalesStructureNameLevel1 = B.SalesStructurenamelevel1
	AND A.SalesStructureNameLevel2 = B.SalesStructurenamelevel2

INSERT INTO [StoneDWv0].[dbo].[DimSeasonality] (
		[DateKey]
		,[SalesStructureNameLevel1]
		,[SalesStructureNameLevel2]
		,[TPVCreditSeasonality]
)
SELECT [DateKey]
		,[SalesStructureNameLevel1]
		,[SalesStructureNameLevel2]
		,[TPVCreditSeasonality]
FROM #SAZ_CREDIT A
WHERE NOT EXISTS(
	SELECT TOP 1 1
	FROM [StoneDWv0].[dbo].[DimSeasonality] B
	WHERE A.Datekey = B.Datekey
	AND A.SalesStructurenamelevel1 = B.SalesStructureNameLevel1
	AND A.SalesStructurenamelevel2 = B.SalesStructureNameLevel2
)
