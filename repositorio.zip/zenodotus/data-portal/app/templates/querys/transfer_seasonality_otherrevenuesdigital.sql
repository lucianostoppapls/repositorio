USE StoneDwv0
SET NOCOUNT ON

IF OBJECT_ID('tempdb..#SAZ_OTHERREVENUESDIGITAL') IS NOT NULL
    DROP TABLE #SAZ_OTHERREVENUESDIGITAL

SELECT REPLACE(CAST(b.Fulldate AS DATE),'-','') Datekey
		,a.SalesStructurenamelevel1
		,a.SalesStructurenamelevel2
		,SUM(a.OtherRevenues) [LinearSeasonality]
		INTO #SAZ_OTHERREVENUESDIGITAL
FROM StoneDWv0..DimDate dt
LEFT JOIN [StoneDWv0].[airflow_staging].[{{temp_table_name}}] a ON dt.FullDate = a.Fulldate
JOIN [StoneDWv0].[airflow_staging].[{{temp_table_name}}] b ON a.Fulldate<=b.Fulldate
															AND a.SalesStructurenamelevel1 = b.SalesStructurenamelevel1
															AND a.SalesStructurenamelevel2 = b.SalesStructurenamelevel2
WHERE EOMONTH(a.Fulldate) = EOMONTH(dt.FullDate)
GROUP BY REPLACE(CAST(b.Fulldate AS DATE),'-','')
		,a.SalesStructurenamelevel1
		,a.SalesStructurenamelevel2

UPDATE A
	SET
		A.[LinearSeasonality] = B.[LinearSeasonality]
FROM [StoneDWv0].[dbo].[DimSeasonality] A
JOIN #SAZ_OTHERREVENUESDIGITAL B ON A.Datekey = B.Datekey
	AND A.SalesStructureNameLevel1 = B.SalesStructurenamelevel1
	AND A.SalesStructureNameLevel2 = B.SalesStructurenamelevel2

INSERT INTO [StoneDWv0].[dbo].[DimSeasonality] (
		[DateKey]
		,[SalesStructureNameLevel1]
		,[SalesStructureNameLevel2]
		,[LinearSeasonality]
)
SELECT [DateKey]
		,[SalesStructureNameLevel1]
		,[SalesStructureNameLevel2]
		,[LinearSeasonality]
FROM #SAZ_OTHERREVENUESDIGITAL A
WHERE NOT EXISTS(
	SELECT TOP 1 1
	FROM [StoneDWv0].[dbo].[DimSeasonality] B
	WHERE A.Datekey = B.Datekey
	AND A.SalesStructurenamelevel1 = B.SalesStructureNameLevel1
	AND A.SalesStructurenamelevel2 = B.SalesStructureNameLevel2
)
