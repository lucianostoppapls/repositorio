import os
import sqlalchemy

basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = "hard secret string"

    SECRET = os.getenv("SECRET") or "my secret key"
    TEMPLATES_AUTO_RELOAD = os.getenv("TEMPLATES_AUTO_RELOAD") or True

    @staticmethod
    def init_app(app):
        pass


class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = os.getenv("TEST_DATABASE_URL")


class ProductionConfig(Config):

    SQLALCHEMY_DATABASE_URI = sqlalchemy.engine.url.URL(
        "mssql+pyodbc",
        username=os.getenv("USERNAME"),
        password=(os.getenv("PASSWORD") or "").replace('"', ""),
        host=os.getenv("HOST"),
        port=os.getenv("PORT"),
        database=os.getenv("DATABASE") or "Stonedwv0",
        query=dict(
            driver=os.getenv("DRIVER") or "ODBC Driver 17 for SQL Server",
            Trusted_Connection="no",
        ),
    )

    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER") or "static/upload"


config = {
    "testing": TestingConfig,
    "production": ProductionConfig,
    "default": TestingConfig,
}
