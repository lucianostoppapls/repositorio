from airflow import configuration as conf
from airflow import DAG
from airflow.operators.latest_only import LatestOnlyOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from datetime import datetime, timedelta
from mssql_utils import MssqlToGCSExtractOperator
from plugins.gcp_utils import GCSToPostgresOperator
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts


dag = DAG(
    dag_id="_legacy__reports_churn",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 17, 0),
    default_args={
        "autocommit": True,
        "retries": 4,
        "retry_delay": timedelta(minutes=15),
        "google_cloud_storage_conn_id": "gcp_mis",
        "salesforce_conn_id": "datalake_from_sop_salesforce",
        "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
        "gcs_bucket_name": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
        "mssql_conn_id": "bw_azure",
        "on_failure_callback": PagerDutyAlerts.failure_incident,
        "on_success_callback": PagerDutyAlerts.resolve_incident,
    },
)

ds = "{{ds}}"
with dag:

    only_latest_load = LatestOnlyOperator(task_id="only_latest")

    unload_task = MssqlToGCSExtractOperator(
        task_id="unload_mssql_churn_report",
        mssql_database="StoneDwv0",
        sql_query="select * from StoneDWv0.kpi.VwChurnReport",
        gcs_file_name=f"airflow-files/_legacy/reports/churn_report_{ds}.csv",
        pool="bw_azure",
    )

    truncate_postgres_task = PostgresOperator(
        task_id="truncate_postgres_churn_report",
        postgres_conn_id="heroku",
        autocommit=True,
        sql="""
            truncate table churn_report
        """,
    )

    load_postgres_task = GCSToPostgresOperator(
        task_id="load_postgres_churn_report",
        dest_table="churn_report",
        gcs_file=f"airflow/reports/churn_report_{ds}.csv",
        postgres_conn_id="heroku",
    )

    only_latest_load >> unload_task >> truncate_postgres_task >> load_postgres_task
