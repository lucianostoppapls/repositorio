from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args, transfer_tasks


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_contact_v2",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 6, 0),
    default_args=default_args,
)

transfer_tasks(
    dag=dag,
    repo_name="salesforce",
    table="DimContact",
    database="StoneDWv0",
    prod_schema="dbo",
    column_types={
        "[contactkey]": "[nvarchar](18) not null",
        "[birthdate]": "[varchar](8) null",
        "[fax]": "[varchar](40) null",
        "[phone]": "[varchar](40) null",
        "[contactresponsibility]": "[varchar](30) null",
        "[createddate]": "[varchar](8) null",
        "[isdeleted]": "[bit] null",
        "[department]": "[varchar](80) null",
        "[hasoptedoutofemail]": "[bit] null",
        "[lastmodifieddate]": "[varchar](8) null",
        "[lastupdatedat]": "[varchar](8) null",
        "[email]": "[varchar] (1000) null",
    },
    date_column="LastUpdatedAt",
    external_dag_id="_legacy__salesforce_dim_account_v3",
)
