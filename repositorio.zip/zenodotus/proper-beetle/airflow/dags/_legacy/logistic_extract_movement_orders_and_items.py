from airflow import DAG
from _legacy.airflow_utils import make_backfill_dags, with_dags
from _legacy.logistic_extract import default_args, transfer_tasks_upsert
from datetime import datetime, timedelta


recents, backfill = make_backfill_dags(
    task_id="_legacy__logistic_extract_movement_orders_and_items",
    version=1,
    recents_start_date=datetime(2020, 4, 26, 3, 20),
    backfill_expected_start_date=datetime(2014, 1, 1),
    recents_schedule_interval=timedelta(days=1),
    dag_factory=lambda **kwargs: DAG(**kwargs),
    default_args=default_args,
)

for dag in with_dags(recents, backfill):
    transfer_tasks_upsert(
        dag=dag,
        table="tbstonef_om_logistica",
        dest_schema="stone",
        database="StoneCoODS",
        column_types={
            "contractor": "nvarchar(100) NULL",
            "arrival_date": "datetime NULL",
            "transit_date": "datetime NULL",
            "destination": "nvarchar(200) NULL",
            "failure_reason": "nvarchar(200) NULL",
            "invoice_code": "nvarchar(200) NULL",
            "order_number": "int NOT NULL",
            "observation": "nvarchar(max) NULL",
            "origin": "nvarchar(100) NULL",
            "quantity_request": "int NULL",
            "reference_code": "nvarchar(100) NULL",
            "status": "nvarchar(100) NULL",
            "type": "nvarchar(100) NULL",
            "model": "nvarchar(200) NULL",
            "quantity_request_item": "int NULL",
            "created_date": "datetime NULL",
            "last_modified_date": "datetime NULL",
        },
        date_column="last_modified_date",
    )
