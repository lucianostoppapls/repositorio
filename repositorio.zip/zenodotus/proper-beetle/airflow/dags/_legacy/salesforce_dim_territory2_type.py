from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args, transfer_tasks


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_territory2_type_v2",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 6, 0),
    default_args=default_args,
)

transfer_tasks(
    dag=dag,
    repo_name="salesforce",
    table="DimTerritory2Type",
    database="StoneDWv0",
    column_types={
        "[Territory2TypeKey]": "[nvarchar](18) NOT NULL",
        "[CreatedDate]": "[varchar](8) NULL",
        "[IsDeleted]": "[bit] NOT NULL",
        "[Description]": "[nvarchar](255) NULL",
        "[LastModifiedDate]": "[varchar](8) NULL",
        "[MasterLabel]": "[nvarchar](80) NULL",
    },
    prod_schema="dbo",
    date_column="LastUpdatedAt",
)
