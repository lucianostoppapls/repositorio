from mssql_utils import MsSqlOperatorPYODBC
from airflow import DAG
from datetime import datetime, timedelta

dag = DAG(
    dag_id="_legacy__reports_fpa_top_line",
    schedule_interval="0 0 9 * *",
    start_date=datetime(2020, 4, 26, 0, 0),
    default_args={
        "autocommit": True,
        "retries": 4,
        "retry_delay": timedelta(minutes=15),
    },
)

with dag:
    tpv_by_card_brand = MsSqlOperatorPYODBC(
        task_id="tpv_by_card_brand",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/tpv_by_card_brand.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv_by_installments = MsSqlOperatorPYODBC(
        task_id="tpv_by_installments",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/tpv_by_installments.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    active_clients = MsSqlOperatorPYODBC(
        task_id="active_clients",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/active_clients.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    net_new_clients = MsSqlOperatorPYODBC(
        task_id="net_new_clients",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/net_new_clients.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    revenue_retention_cohorts = MsSqlOperatorPYODBC(
        task_id="revenue_retention_cohorts",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/revenue_retention_cohorts.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv_retention_cohorts = MsSqlOperatorPYODBC(
        task_id="tpv_retention_cohorts",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/tpv_retention_cohorts.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    average_tpv_net_new_clients = MsSqlOperatorPYODBC(
        task_id="average_tpv_net_new_clients",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/average_tpv_net_new_clients.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    average_tpv_total_clients = MsSqlOperatorPYODBC(
        task_id="average_tpv_total_clients",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/average_tpv_total_clients.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    churn_ec = MsSqlOperatorPYODBC(
        task_id="churn_ec",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/churn_ec.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    churn_tpv = MsSqlOperatorPYODBC(
        task_id="churn_tpv",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/churn_tpv.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    average_rent_per_pos = MsSqlOperatorPYODBC(
        task_id="average_rent_per_pos",
        database="StoneDwv0",
        sql="/reports/fpa_top_line/average_rent_per_pos.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    (
        tpv_by_card_brand
        >> tpv_by_installments
        >> active_clients
        >> net_new_clients
        >> revenue_retention_cohorts
        >> tpv_retention_cohorts
        >> average_tpv_net_new_clients
        >> average_tpv_total_clients
        >> churn_ec
        >> churn_tpv
        >> average_rent_per_pos
    )
