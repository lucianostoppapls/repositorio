from collections import namedtuple
from datetime import timedelta, datetime
from math import ceil
import pandas as pd


BackfillDags = namedtuple("BackfillDags", ["recents", "backfill"])


def with_dags(*dags):
    for dag in dags:
        if dag is None:
            break
        else:
            with dag:
                yield dag


def make_backfill_dags(
    task_id,
    version,
    recents_start_date,
    dag_factory,
    recents_schedule_interval=timedelta(days=1),
    backfill_expected_start_date=datetime(2012, 1, 1),
    backfill_schedule_interval=timedelta(days=30),
    backfill_enabled=False,
    **kwargs,
):

    # We change the naming convension for dags. However, it's necessary
    # to preserve the naming scheme for older dags, so we make it so that
    # dags with start date after the date below adopt the new convension, and dags
    # with start date before adopt the previous convension.
    #
    # Also, there is a change in how the start date of the backfill dag is calculated,
    # in order to make sure the start and end dates fits an exact multiplier of times
    # the backfill interval.
    if recents_start_date >= datetime(2018, 12, 17):
        # The new naming convension writes the version before
        # the specification of the type of dag (i.e. backfill or
        # recents). The effect is that, when you sort the dag ids
        # alphabetically, the two dags related to the same version
        # will be one right next to the other.
        recents_dag_id = f"{task_id}_v{version}_recents"
        backfill_dag_id = f"{task_id}_v{version}_backfill"

        # We want to make sure the backfill finishes executing at the same time
        # the recents task starts, so we change the start date accordingly
        total_interval = recents_start_date - backfill_expected_start_date
        num_windows = ceil(
            total_interval.total_seconds() / backfill_schedule_interval.total_seconds()
        )
        backfill_start_date = (
            recents_start_date - num_windows * backfill_schedule_interval
        )
    else:
        # Here we adopt the older convension in order to avoid conflicts.
        recents_dag_id = f"{task_id}_recents_v{version}"
        backfill_dag_id = f"{task_id}_backfill_v{version}"

        # In order not to break older dags, we keep the old behavior
        backfill_start_date = backfill_expected_start_date

    if backfill_enabled:
        recents_dag = dag_factory(
            dag_id=recents_dag_id,
            start_date=recents_start_date,
            schedule_interval=recents_schedule_interval,
            **kwargs,
        )

        backfill_dag = dag_factory(
            dag_id=backfill_dag_id,
            start_date=backfill_start_date,
            end_date=recents_start_date,
            schedule_interval=backfill_schedule_interval,
            **kwargs,
        )

        return BackfillDags(recents=recents_dag, backfill=backfill_dag)
    else:
        recents_dag = dag_factory(
            dag_id=recents_dag_id,
            start_date=recents_start_date,
            schedule_interval=recents_schedule_interval,
            **kwargs,
        )

        return BackfillDags(recents=recents_dag, backfill=None)


def with_callable(operator, argument="python_callable", **kwargs):
    def decorator(python_callable):
        kwargs[argument] = python_callable
        return operator(**kwargs)

    return decorator


def datalake_csv_metadata_builder(filename, context):
    df = pd.read_csv(filename, dtype="str")
    df["airflow_metadata__execution_date"] = context["execution_date"].strftime(
        "%Y-%m-%dT%H:%M:%S"
    )
    df["airflow_metadata__extraction_date"] = datetime.utcnow().strftime(
        "%Y-%m-%dT%H:%M:%S"
    )
    df.to_csv(filename, index=False)


def datalake_metadata_extender(converted_metadata):
    execution_date = {
        "name": "airflow_metadata__execution_date",
        "type": "timestamp",
        "mode": "",
        "description": "",
    }

    extraction_date = {
        "name": "airflow_metadata__extraction_date",
        "type": "timestamp",
        "mode": "",
        "description": "",
    }

    return converted_metadata.extend([execution_date, extraction_date])


def datalake_csv_sensitive_fields_mask_remover(filename, sensitive_field_list):
    df = pd.read_csv(filename)

    for sensitive_field in sensitive_field_list:  # REVISAR remover máscaras e quais?
        df[sensitive_field] = [
            x.lstrip("+-").rstrip("aAbBcC") for x in df[sensitive_field]
        ]

    df.to_csv(filename, index=False)
