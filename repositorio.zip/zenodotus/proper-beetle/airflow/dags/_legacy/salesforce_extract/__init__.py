from airflow import configuration as conf
from airflow.operators.dummy import DummyOperator
from airflow.operators.python import ShortCircuitOperator
from datetime import timedelta
from mssql_utils import (
    CreatePrefixTableMsSqlOperator,
    DropPrefixTableMsSqlOperator,
    GCSToMssqlExtractOperator,
    MsSqlOperatorPYODBC,
)
from salesforce_utils import SalesforceToGCSOperator
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts


default_args = {
    "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "google_cloud_storage_conn_id": "gcp_mis",
    "mssql_conn_id": "bw_azure",
    "salesforce_conn_id": "salesforce",
    "depends_on_past": False,
    "retries": 4,
    "retry_delay": timedelta(minutes=15),
    "autocommit": True,
    "on_failure_callback": PagerDutyAlerts.failure_incident,
    "on_success_callback": PagerDutyAlerts.resolve_incident,
}


def transfer_tasks(
    dag,
    table,
    database,
    date_column,
    column_types,
    prod_schema="dbo",
    log_schema="airflow_staging",
    primary_key="Id",
):
    def data_checker(**kwargs):
        ti = kwargs["ti"]
        return ti.xcom_pull(task_ids=f"unload_{table}")

    def caster(column_name, datatype):
        if datatype in ("[date]", "[datetime]"):
            return f"CAST(REPLACE({column_name},'+0000', '') as {datatype})"
        elif datatype[:9] == "[numeric]":
            return f"CAST(CAST({column_name} as FLOAT) as {datatype})"
        else:
            return f"CAST({column_name} as {datatype})"

    date_nodash = "{{ macros.date.format_nodash(execution_date) }}"
    gcs_file = f"airflow-files/_legacy/salesforce_extract/{table}-{{{{ts}}}}.csv"
    source_sql = f"salesforce_extract/source_{table}.sql"
    column_name_list = ",\n".join(column_types.keys())
    select_list = ",\n".join(
        [caster(key, value) for key, value in column_types.items()]
    )

    with dag:
        check_completion = DummyOperator(task_id="dag_init")

        unload_task = SalesforceToGCSOperator(
            task_id=f"unload_{table}",
            sql=source_sql,
            gcs_file=gcs_file,
            include_deleted=True,
        )

        check_data = ShortCircuitOperator(
            task_id="check_data", provide_context=True, python_callable=data_checker
        )

        create_temp_table_task_azure = CreatePrefixTableMsSqlOperator(
            task_id="create_temp_table_azure",
            schema=log_schema,
            database="StoneCoODS",
            table_prefix=table,
            column_types={key: "nvarchar(max)" for key in column_types},
            mssql_conn_id="bw_azure",
        )

        transfer_task_azure = GCSToMssqlExtractOperator(
            task_id=f"load_{table}_azure",
            source_file=gcs_file,
            database=database,
            dest_schema="{{ ti.xcom_pull('create_temp_table_azure').split('.')[0] }}",
            table_name="{{ ti.xcom_pull('create_temp_table_azure').split('.')[1] }}",
            pool="bw_azure",
            gcs_data_delete=False,
        )

        upsert_task_azure = MsSqlOperatorPYODBC(
            task_id=f"upsert_{table}_azure",
            database=database,
            pool="bw_azure",
            sql=f"""
                BEGIN;

                    DELETE prod_schema FROM {prod_schema}.{table} prod_schema
                    INNER JOIN {log_schema}.{table}_{date_nodash} ON prod_schema.{primary_key} = {log_schema}.{table}_{date_nodash}.{primary_key};

                    INSERT INTO {prod_schema}.{table} ({column_name_list})
                        SELECT
                            {select_list}
                    FROM {log_schema}.{table}_{date_nodash};

                END;
            """,
            mssql_conn_id="bw_azure",
        )

        drop_temp_table_task_azure = DropPrefixTableMsSqlOperator(
            task_id="drop_temp_table_azure",
            pool="bw_azure",
            database="StoneCoODS",
            schema=log_schema,
            table_prefix=table,
            mssql_conn_id="bw_azure",
        )

        complete_task = DummyOperator(task_id="dag_complete")

    (
        check_completion
        >> unload_task
        >> check_data
        >> create_temp_table_task_azure
        >> transfer_task_azure
        >> upsert_task_azure
        >> drop_temp_table_task_azure
        >> complete_task
    )
