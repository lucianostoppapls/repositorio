SELECT
    createdbyid,
    createddate,
    field,
    id,
    isdeleted,
    leadid,
    newvalue,
    oldvalue
FROM
    leadhistory
WHERE
    createddate >= {{ execution_date.strftime('%Y-%m-%dT%H:%M:%SZ') }} AND
    createddate < {{ next_execution_date.strftime('%Y-%m-%dT%H:%M:%SZ') }}
