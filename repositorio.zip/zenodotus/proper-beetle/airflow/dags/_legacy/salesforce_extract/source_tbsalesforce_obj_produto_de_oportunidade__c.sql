SELECT
    aluguel__c,
    ativo_stone__c,
    createdbyid,
    createddate,
    dias_de_insecao__c,
    gateway__c,
    id,
    isdeleted,
    lastmodifiedbyid,
    lastmodifieddate,
    lastreferenceddate,
    lastvieweddate,
    meio_de_captura__c,
    name,
    oportunidade_relacionada__c,
    origem_instala__c,
    quantidade__c,
    recordtypeid,
    systemmodstamp,
    tecnologia__c,
    url__c
FROM
    produto_de_oportunidade__c
WHERE
    systemmodstamp >= {{ execution_date.strftime('%Y-%m-%dT%H:%M:%SZ') }} AND
    systemmodstamp < {{ next_execution_date.strftime('%Y-%m-%dT%H:%M:%SZ') }}
