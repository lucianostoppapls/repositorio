SELECT
    amount,
    closedate,
    createdbyid,
    createddate,
    expectedrevenue,
    forecastcategory,
    id,
    isdeleted,
    opportunityid,
    probability,
    stagename,
    systemmodstamp
FROM
    opportunityhistory
WHERE
    systemmodstamp >= {{ execution_date.strftime('%Y-%m-%dT%H:%M:%SZ') }} AND
    systemmodstamp < {{ next_execution_date.strftime('%Y-%m-%dT%H:%M:%SZ') }}
