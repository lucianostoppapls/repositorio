from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args, transfer_tasks


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_product_opportunity_v2",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 6, 0),
    default_args=default_args,
)

transfer_tasks(
    dag=dag,
    repo_name="salesforce",
    table="DimProductOpportunity",
    database="StoneDWv0",
    column_types={
        "[ProductOpportunityKey]": "[nvarchar](18) NOT NULL",
        "[Rent]": "[real] NULL",
        "[IsActiveStone]": "[bit] NULL",
        "[CreatedDate]": "[varchar](8) NULL",
        "[IsDeleted]": "[bit] NULL",
        "[ExemptionDays]": "[real] NULL",
        "[Gateway]": "[nvarchar](255) NULL",
        "[Name]": "[nvarchar](80) NULL",
        "[LastModifiedDate]": "[varchar](8) NULL",
        "[LastViewedDate]": "[varchar](8) NULL",
        "[CaptureMeans]": "[nvarchar](255) NULL",
        "[RelatedOpportunity]": "[nvarchar](18) NULL",
        "[InstallationOrigins]": "[bit] NULL",
        "[Amount]": "[real] NULL",
        "[Tecnology]": "[nvarchar](255) NULL",
        "[URL]": "[nvarchar](255) NULL",
    },
    prod_schema="dbo",
    date_column="LastUpdatedAt",
)
