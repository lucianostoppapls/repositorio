from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.utils.decorators import apply_defaults


class UpdateDeletionsOperator(PostgresOperator):
    @apply_defaults
    def __init__(self, table, schema, date_column, *args, **kwargs):
        kwargs.update(
            params={"table": table, "schema": schema, "date_column": date_column},
            sql="""
                UPDATE {{ params.schema }}.{{ params.table }}
                SET  isdeleted = true,
                    SystemModstamp = b._metadata_updated_at,
                    _metadata_updated_at = b._metadata_updated_at
                FROM {{ params.schema }}.{{ params.table }}_deleted b
                INNER JOIN {{ params.schema }}.{{ params.table }} a ON b._metadata_salesforce_id = a.id
                WHERE b.{{ params.date_column }} >= a.{{ params.date_column }}
                """,
        )
        super().__init__(*args, **kwargs)


class DeleteFromTableOperator(PostgresOperator):
    @apply_defaults
    def __init__(self, table, schema, date_column, *args, **kwargs):
        kwargs.update(
            params={"table": table, "schema": schema, "date_column": date_column},
            sql="""
                DELETE FROM {{ params.schema }}.{{ params.table }}
                WHERE {{ params.date_column }} < '{{ next_execution_date.isoformat() }}'
                """,
        )
        super().__init__(*args, **kwargs)
