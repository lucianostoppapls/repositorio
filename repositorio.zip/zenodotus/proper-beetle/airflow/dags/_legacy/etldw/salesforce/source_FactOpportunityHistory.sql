SELECT Id as `OpportunityHistoryKey`
, REPLACE(CAST(CloseDate AS STRING),'-','') as `CloseDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, IFNULL(OpportunityId,'0') as `OpportunityKey`
, IFNULL(Probability, 0)  as `Probability`
, IFNULL(StageName, 'N/D')  as `StageName`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') AS `CreatedDate`
, REPLACE(CAST(EXTRACT(date from SystemModstamp at time zone 'America/Sao_Paulo') AS STRING),'-','') AS `SystemModstamp`
FROM dataplatform-prd.sop_salesforce.opportunityhistory
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
