INSERT INTO [dbo].[DimSalesStructure] ( [SalesStructureNameLevel1]
, [SalesStructureNameLevel2]
, [SalesStructureNameLevel3]
, [SalesStructureNameLevel4]
, [SalesStructureNameLevel5]
, [SalesStructureNameLevel6]
, [LastUpdatedAt])

SELECT A.[SalesStructureNameLevel1]
, A.[SalesStructureNameLevel2]
, A.[SalesStructureNameLevel3]
, A.[SalesStructureNameLevel4]
, A.[SalesStructureNameLevel5]
, A.[SalesStructureNameLevel6]
,'{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimSalesStructure] B WHERE B.[SalesStructureNameLevel1] = A.[SalesStructureNameLevel1]
AND B.[SalesStructureNameLevel2] = A.[SalesStructureNameLevel2]
AND B.[SalesStructureNameLevel3] = A.[SalesStructureNameLevel3]
AND B.[SalesStructureNameLevel4] = A.[SalesStructureNameLevel4]
AND B.[SalesStructureNameLevel5] = A.[SalesStructureNameLevel5]
AND B.[SalesStructureNameLevel6] = A.[SalesStructureNameLevel6])
