SELECT Id as `AccountContactRelationKey`
, IFNULL(AccountId, '0') as `AccountKey`
, ContactId as `ContactKey`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, REPLACE(CAST(EndDate AS STRING),'-','') as `EndDate`
, REPLACE(CAST(StartDate AS STRING),'-','') as `StartDate`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
FROM dataplatform-prd.sop_salesforce.accountcontactrelation
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
