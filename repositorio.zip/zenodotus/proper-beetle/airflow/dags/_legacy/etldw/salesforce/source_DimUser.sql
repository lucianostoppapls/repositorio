SELECT Id as `UserKey`
, IFNULL(AccountId, '0')  as `AccountKey`
, CAST(IFNULL(IsActive,FALSE) AS INT64) as `IsActive`
, IFNULL(Cargo__c, 'N/D') as `Responsibility`
, IFNULL(MobilePhone, 'N/D') as `MobilePhone`
, IFNULL(City, 'N/D') as `City`
, IFNULL(ContactId,'0') as `ContactKey`
, IFNULL(Country, 'N/D') as `Country`
, IFNULL(Department, 'N/D') as `Department`
, IFNULL(Email, 'N/D') as `Email`
, IFNULL(EmployeeNumber, 'N/D') as `EmployeeNumber`
, IFNULL(FirstName, 'N/D')  as `FirstName`
, IFNULL(Name, 'N/D') as `Name`
, IFNULL(LastName, 'N/D') as `LastName`
, IFNULL(Latitude, 0) as `Latitude`
, IFNULL(Longitude, 0) as `Longitude`
, IFNULL(ManagerId, '0')  as `ManagerKey`
, IFNULL(Nome_e_Polo__c, 'N/D') as `NameAndPolo`
, IFNULL(Phone, 'N/D') as `Phone`
, IFNULL(Polo__c, 'N/D') as `Polo`
, IFNULL(ProfileId,'0') as `ProfileKey`
, IFNULL(FederationIdentifier, 'N/D') as `FederationIdentifier`
, IFNULL(State, 'N/D') as `State`
, IFNULL(Street, 'N/D') as `Street`
, IFNULL(Title, 'N/D') as `Title`
, IFNULL(UserType, 'N/D') as `UserType`
, IFNULL(Username, 'N/D') as `Username`
, IFNULL(PostalCode, 'N/D') as `PostalCode`
, IFNULL(Division, 'N/D') as `Division`
, IFNULL(Dias_de_Firma__c,0) as `BusinessDays`
, IFNULL(Dias_Uteis__c,0) as `WorkingDays`
, IFNULL(DU_30_dias__c,0) as `WorkingDaysLastThirtyDays`
, IFNULL(DU_M_s_Atual__c,0) as `WorkingDaysCurrentMonth`
, IFNULL(DU_M_s_Passado__c,0) as `WorkingDaysLastMonth`
, REPLACE(CAST(Data_de_Criacao__c AS STRING),'-','') as `CreatedDate`
, REPLACE(CAST(EXTRACT(date from LastLoginDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastLoginDate`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, REPLACE(CAST(EXTRACT(date from LastViewedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastViewedDate`
, IFNULL(UserRoleId, '0') as `UserRoleKey`
, IFNULL(CompanyName, '0') as `CompanyName`
, REPLACE(CAST(Data_de_entrada_no_time_comercial__c AS STRING),'-','') as `HiringDate`
, CASE WHEN IFNULL(ferias__c, FALSE)  = FALSE THEN 0 ELSE 1 END as `Vacation` 
FROM dataplatform-prd.sop_salesforce.user
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
