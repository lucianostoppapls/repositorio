SELECT Id as `TaskRelationKey`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, CAST(IFNULL(IsWhat,FALSE) AS INT64) as `IsWhat`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, IFNULL(RelationId,'0') as `RelationKey`
, IFNULL(TaskId,'0') as `TaskKey`
FROM dataplatform-prd.sop_salesforce.taskrelation
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
