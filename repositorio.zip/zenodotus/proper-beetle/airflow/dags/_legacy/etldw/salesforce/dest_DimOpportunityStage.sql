INSERT INTO [dbo].[DimOpportunityStage] ([OpportunityStageKey]
, [IsClosed]
, [CreatedDate]
, [Description]
, [IsActive]
, [LastModifiedDate]
, [LastUpdatedAt])

SELECT A.[OpportunityStageKey]
, A.[IsClosed]
, A.[CreatedDate]
, A.[Description]
, A.[IsActive]
, A.[LastModifiedDate]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimOpportunityStage] B WHERE A.[OpportunityStageKey] = B.[OpportunityStageKey])

UPDATE C
SET C.[IsClosed] = D.[IsClosed]
, C.[CreatedDate] = D.[CreatedDate]
, C.[Description] = D.[Description]
, C.[IsActive] = D.[IsActive]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[DimOpportunityStage] C ON C.[OpportunityStageKey] = D.[OpportunityStageKey]
