INSERT INTO [dbo].[DimFlagStatus] ([FlagStatusKey]
, [Flag]
, [StatusDate]
, [IsDeleted]
, [LastModifiedDate]
, [LastViewedDate]
, [Status]
, [Name]
, [ClientAlternateKey]
, [LastUpdatedAt])

SELECT A.[FlagStatusKey]
, A.[Flag]
, A.[StatusDate]
, A.[IsDeleted]
, A.[LastModifiedDate]
, A.[LastViewedDate]
, A.[Status]
, A.[Name]
, A.[ClientAlternateKey]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimFlagStatus] B WHERE A.[FlagStatusKey] = B.[FlagStatusKey])

UPDATE C
SET C.[Flag] = D.[Flag]
, C.[StatusDate] = D.[StatusDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[LastViewedDate] = D.[LastViewedDate]
, C.[Status] = D.[Status]
, C.[Name] = D.[Name]
, C.[ClientAlternateKey] = D.[ClientAlternateKey]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[DimFlagStatus] C ON C.[FlagStatusKey] = D.[FlagStatusKey]
