SELECT Id as `EventRelationKey`
, IFNULL(AccountId,'0') as `AccountKey`
, IFNULL(CreatedById, 'N/D') as `CreatedByKey`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `CreatedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, IFNULL(EventId, '0') as `EventKey`
, CAST(IFNULL(IsParent,FALSE) AS INT64) as `IsParent`
, CAST(IFNULL(IsWhat,FALSE) AS INT64) as `IsWhat`
, IFNULL(RelationId, 'N/D') as `RelationKey`
, IFNULL(Response, 'N/D') as `Response`
, REPLACE(CAST(EXTRACT(date from RespondedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `RespondedDate`
, IFNULL(Status, 'N/D') as `Status`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
FROM dataplatform-prd.sop_salesforce.eventrelation
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
