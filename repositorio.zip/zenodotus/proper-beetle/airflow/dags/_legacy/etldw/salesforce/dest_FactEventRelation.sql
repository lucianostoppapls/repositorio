INSERT INTO [dbo].[FactEventRelation] ([EventRelationKey]
, [AccountKey]
, [CreatedByKey]
, [CreatedDate]
, [IsDeleted]
, [EventKey]
, [IsParent]
, [IsWhat]
, [RelationKey]
, [Response]
, [RespondedDate]
, [Status]
, [LastModifiedDate]
, [LastUpdatedAt])

SELECT A.[EventRelationKey]
, A.[AccountKey]
, A.[CreatedByKey]
, A.[CreatedDate]
, A.[IsDeleted]
, A.[EventKey]
, A.[IsParent]
, A.[IsWhat]
, A.[RelationKey]
, A.[Response]
, A.[RespondedDate]
, A.[Status]
, A.[LastModifiedDate]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[FactEventRelation] B WHERE A.[EventRelationKey] = B.[EventRelationKey])
AND EXISTS (SELECT TOP 1 1 FROM [dbo].[FactEvent] E WHERE ISNULL(A.[EventKey],'0') = E.[EventKey])

UPDATE C
SET C.[AccountKey] = D.[AccountKey]
, C.[CreatedByKey] = D.[CreatedByKey]
, C.[CreatedDate] = D.[CreatedDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[EventKey] = D.[EventKey]
, C.[IsParent] = D.[IsParent]
, C.[IsWhat] = D.[IsWhat]
, C.[RelationKey] = D.[RelationKey]
, C.[Response] = D.[Response]
, C.[RespondedDate] = D.[RespondedDate]
, C.[Status] = D.[Status]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[FactEventRelation] C ON C.[EventRelationKey] = D.[EventRelationKey]
WHERE EXISTS (SELECT TOP 1 1 FROM [dbo].[FactEvent] F WHERE ISNULL(D.[EventKey],'0') = F.[EventKey])
