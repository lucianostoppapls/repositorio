INSERT INTO [dbo].[FactAccountContactRelation] ([AccountContactRelationKey]
, [AccountKey]
, [ContactKey]
, [IsDeleted]
, [EndDate]
, [StartDate]
, [LastModifiedDate]
, [LastUpdatedAt])

SELECT A.[AccountContactRelationKey]
, A.[AccountKey]
, A.[ContactKey]
, A.[IsDeleted]
, A.[EndDate]
, A.[StartDate]
, A.[LastModifiedDate]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[FactAccountContactRelation] B WHERE A.[AccountContactRelationKey] = B.[AccountContactRelationKey])
AND EXISTS (SELECT TOP 1 1 FROM [dbo].[DimAccount] E WHERE ISNULL(A.[AccountKey],'0') = E.[AccountKey])

UPDATE C
SET C.[AccountKey] = D.[AccountKey]
, C.[ContactKey] = D.[ContactKey]
, C.[IsDeleted] = D.[IsDeleted]
, C.[EndDate] = D.[EndDate]
, C.[StartDate] = D.[StartDate]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[FactAccountContactRelation] C ON C.[AccountContactRelationKey] = D.[AccountContactRelationKey]
WHERE EXISTS (SELECT TOP 1 1 FROM [dbo].[DimAccount] F WHERE ISNULL(D.[AccountKey],'0') = F.[AccountKey])
