SELECT Id as `ProductOpportunityKey`
, IFNULL(Aluguel__c,0) as `Rent`
, CAST(IFNULL(Ativo_Stone__c,FALSE) AS INT64) as `IsActiveStone`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `CreatedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, IFNULL(Dias_de_Insecao__c,0)  as `ExemptionDays`
, IFNULL(Gateway__c,'N/D')  as `Gateway`
, IFNULL(Name,'N/D')  as `Name`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, REPLACE(CAST(EXTRACT(date from LastViewedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastViewedDate`
, IFNULL(Meio_de_Captura__c,'N/D')  as `CaptureMeans`
, IFNULL(Oportunidade_Relacionada__c,'N/D')  as `RelatedOpportunity`
, CAST(IFNULL(Origem_Instala__c,FALSE) AS INT64) as `InstallationOrigins`
, IFNULL(Quantidade__c,0)  as `Amount`
, IFNULL(Tecnologia__c,'N/D')  as `Tecnology`
, IFNULL(Url__c,'N/D') as `URL`
FROM dataplatform-prd.sop_salesforce.produto_de_oportunidade__c
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
