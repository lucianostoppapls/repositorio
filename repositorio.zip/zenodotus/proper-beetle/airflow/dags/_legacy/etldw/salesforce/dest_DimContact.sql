INSERT INTO [dbo].[DimContact] ([ContactKey]
, [Birthdate]
, [Fax]
, [Phone]
, [ContactResponsibility]
, [CreatedDate]
, [IsDeleted]
, [Department]
, [HasOptedOutOfEmail]
, [LastModifiedDate]
, [LastUpdatedAt]
, [Email])

SELECT A.[ContactKey]
, A.[Birthdate]
, A.[Fax]
, A.[Phone]
, A.[ContactResponsibility]
, A.[CreatedDate]
, A.[IsDeleted]
, A.[Department]
, A.[HasOptedOutOfEmail]
, A.[LastModifiedDate]
, '{{ ds_nodash }}'
, A.[Email]
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimContact] B WHERE A.[ContactKey] = B.[ContactKey])

UPDATE C
SET C.[Birthdate] = D.[Birthdate]
, C.[Fax] = D.[Fax]
, C.[Phone] = D.[Phone]
, C.[ContactResponsibility] = D.[ContactResponsibility]
, C.[CreatedDate] = D.[CreatedDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[Department] = D.[Department]
, C.[HasOptedOutOfEmail] = D.[HasOptedOutOfEmail]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
, C.[Email] = D.[Email]
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[DimContact] C ON C.[ContactKey] = D.[ContactKey]
