INSERT INTO [dbo].[DimTerritory2Model] ([Territory2ModelKey]
, [IsDeleted]
, [Name]
, [LastModifiedDate]
, [LastUpdatedAt])

SELECT A.[Territory2ModelKey]
, A.[IsDeleted]
, A.[Name]
, A.[LastModifiedDate]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimTerritory2Model] B WHERE A.[Territory2ModelKey] = B.[Territory2ModelKey])

UPDATE C
SET C.[IsDeleted] = D.[IsDeleted]
, C.[Name] = D.[Name]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[DimTerritory2Model] C ON C.[Territory2ModelKey] = D.[Territory2ModelKey]
