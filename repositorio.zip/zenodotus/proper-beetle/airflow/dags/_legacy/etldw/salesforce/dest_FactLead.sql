INSERT INTO [dbo].[FactLead] ( [LeadKey]
, [IsConverted]
, [ConvertedDate]
, [ConvertedOpportunityId]
, [CreatedDate]
, [IsDeleted]
, [LeadSource]
, [Status]
, [OwnerKey]
, [LastUpdatedAt]
, [ExpectedTPV])

SELECT A.[LeadKey]
, A.[IsConverted]
, A.[ConvertedDate]
, A.[ConvertedOpportunityId]
, A.[CreatedDate]
, A.[IsDeleted]
, A.[LeadSource]
, A.[Status]
, A.[OwnerKey]
, '{{ ds_nodash }}'
, A.[ExpectedTPV]
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[FactLead] B WHERE A.[LeadKey] = B.[LeadKey])

UPDATE C
SET C.[IsConverted] = D.[IsConverted]
, C.[ConvertedDate] = D.[ConvertedDate]
, C.[ConvertedOpportunityId] = D.[ConvertedOpportunityId]
, C.[CreatedDate] = D.[CreatedDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[LeadSource] = D.[LeadSource]
, C.[Status] = D.[Status]
, C.[OwnerKey] = D.[OwnerKey]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
, C.[ExpectedTPV] = D.[ExpectedTPV]
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[FactLead] C ON D.[LeadKey] = C.[LeadKey]
