INSERT INTO [dbo].[FactTaskRelation] ([TaskRelationKey]
, [IsDeleted]
, [IsWhat]
, [LastModifiedDate]
, [RelationKey]
, [TaskKey]
, [LastUpdatedAt])

SELECT A.[TaskRelationKey]
, A.[IsDeleted]
, A.[IsWhat]
, A.[LastModifiedDate]
, A.[RelationKey]
, A.[TaskKey]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[FactTaskRelation] B WHERE A.[TaskRelationKey] = B.[TaskRelationKey])
AND EXISTS (SELECT TOP 1 1 FROM [dbo].[FactTask] E WHERE ISNULL(A.[TaskKey],'0') = E.[TaskKey])

UPDATE C
SET C.[IsDeleted] = D.[IsDeleted]
, C.[IsWhat] = D.[IsWhat]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[RelationKey] = D.[RelationKey]
, C.[TaskKey] = D.[TaskKey]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[FactTaskRelation] C ON C.[TaskRelationKey] = D.[TaskRelationKey]
WHERE EXISTS (SELECT TOP 1 1 FROM [dbo].[FactTask] F WHERE ISNULL(D.[TaskKey],'0') = F.[TaskKey])
