SELECT Id as `TerritorySettingsKey`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `CreatedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, IFNULL(Name, 'N/D') as `Name`
, IFNULL(Query_Limit__c,'0') as `QueryLimit`
FROM dataplatform-prd.sop_salesforce.territorysettings__c
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
