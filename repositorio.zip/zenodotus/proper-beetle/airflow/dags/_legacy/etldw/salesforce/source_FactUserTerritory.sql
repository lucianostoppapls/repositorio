SELECT ID as `UserTerritoryKey`
, IFNULL(UserId, '0') as `UserKey`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, IFNULL(RoleInTerritory2, 'N/D')  as `RoleInTerritory2`
, IFNULL(Territory2Id, '0') as `Territory2Key`
FROM dataplatform-prd.sop_salesforce.userterritory2association
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
