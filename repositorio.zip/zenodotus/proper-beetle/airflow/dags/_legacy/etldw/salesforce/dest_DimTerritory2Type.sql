INSERT INTO [dbo].[DimTerritory2Type] ([Territory2TypeKey]
, [CreatedDate]
, [IsDeleted]
, [Description]
, [LastModifiedDate]
, [MasterLabel]
, [LastUpdatedAt])

SELECT A.[Territory2TypeKey]
, A.[CreatedDate]
, A.[IsDeleted]
, A.[Description]
, A.[LastModifiedDate]
, A.[MasterLabel]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimTerritory2Type] B WHERE A.[Territory2TypeKey] = B.[Territory2TypeKey])

UPDATE C
SET C.[CreatedDate] = D.[CreatedDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[Description] = D.[Description]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[MasterLabel] = D.[MasterLabel]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[DimTerritory2Type] C ON C.[Territory2TypeKey] = D.[Territory2TypeKey]
