SELECT  Id as `UserTerritory2AssociationKey`
, UserId as `UserKey`
, Territory2Id as `Territory2Key`
, CAST(IFNULL(IsActive,FALSE) AS INT64) as `IsActive`
, IFNULL(RoleInTerritory2, 'N/D') as `RoleInTerritory2`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, LastModifiedById as `LastModifiedByKey`
, REPLACE(CAST(EXTRACT(date from SystemModstamp at time zone 'America/Sao_Paulo') AS STRING),'-','') as `SystemModstamp`
FROM dataplatform-prd.sop_salesforce.userterritory2association
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
