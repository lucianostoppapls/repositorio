INSERT INTO [dbo].[DimTerritorySettings] ([TerritorySettingsKey]
, [CreatedDate]
, [IsDeleted]
, [LastModifiedDate]
, [Name]
, [QueryLimit]
, [LastUpdatedAt])

SELECT A.[TerritorySettingsKey]
, A.[CreatedDate]
, A.[IsDeleted]
, A.[LastModifiedDate]
, A.[Name]
, A.[QueryLimit]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimTerritorySettings] B WHERE A.[TerritorySettingsKey] = B.[TerritorySettingsKey])

UPDATE C
SET C.[CreatedDate] = D.[CreatedDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[Name] = D.[Name]
, C.[QueryLimit] = D.[QueryLimit]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[DimTerritorySettings] C ON C.[TerritorySettingsKey] = D.[TerritorySettingsKey]
