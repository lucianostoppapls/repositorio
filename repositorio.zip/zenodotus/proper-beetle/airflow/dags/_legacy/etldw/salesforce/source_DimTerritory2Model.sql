SELECT Id as `Territory2ModelKey`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, IFNULL(Name, 'N/D')  as `Name`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
FROM dataplatform-prd.sop_salesforce.territory2model
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
