SELECT Id as `VendorTargetKey`
, IFNULL(OwnerId, '0')as `OwnerKey`
, IFNULL(OwnerEmail__c, 'N/D') as `OwnerEmail`
, IFNULL(OwnerName__c, 'N/D') as `OwnerName`
, IFNULL(PoloName__c, 'N/D') as `PoloName`
, IFNULL(DistritoName__c, 'N/D') as `DistrictName`
, IFNULL(CRED_ATI_PROJETADO__c,0) as `TargetATIAccreditations`
, IFNULL(CRED_AUTO_PROJETADO__c,0) as `TargetAutoAccreditations`
, CONCAT(SUBSTR(REPLACE(CAST(DT_REF__c AS STRING),'-',''), 1, 6), '01') as `ReferenceDate`
, IFNULL(REC_ALU_PROJETADO__c,0) as `TargetRent`
, IFNULL(REC_MDR_PROJETADO__c,0) as `TargetDIA`
, IFNULL(TPV_PROJETADO__c,0) as `TargetTPV`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
FROM dataplatform-prd.sop_salesforce.meta_do_vendedor__c
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
