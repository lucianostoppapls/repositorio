SELECT DISTINCT `Id` AS `AccountStatusKey`
,IFNULL(`OwnerId`, '0') AS `OwnerKey`
,CAST(IFNULL(IsDeleted,FALSE) AS INT64) AS `IsDeleted`
,IFNULL(`Name`, 'N/D') AS `Name`
,CONCAT(SUBSTR(REPLACE(CAST(EXTRACT(date from `CreatedDate` at time zone 'America/Sao_Paulo') AS STRING),'-',''), 1, 6), '01') AS `CreatedDate`
,IFNULL(`CreatedById`, '0') AS `CreatedById`
,CONCAT(SUBSTR(REPLACE(CAST(EXTRACT(date from `LastModifiedDate` at time zone 'America/Sao_Paulo') AS STRING),'-',''), 1, 6), '01') AS `LastModifiedDate`
,IFNULL(`Account__c`, '0') AS `AccountKey`
,IFNULL(`Type__c`, '0') AS `Type`
,IFNULL(`Stonecode__c`, '0') AS `ClientAlternateKey`
FROM dataplatform-prd.sop_salesforce.account_status__c
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
