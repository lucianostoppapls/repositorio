INSERT INTO [dbo].[DimAccountStatus] ([AccountStatusKey]
                                ,[OwnerKey]
                                ,[IsDeleted]
                                ,[Name]
                                ,[CreatedDate]
                                ,[CreatedById]
                                ,[LastModifiedDate]
                                ,[AccountKey]
                                ,[Type]
                                ,[ClientAlternateKey]
                                ,[LastUpdatedAt])

SELECT [AccountStatusKey]
        , A.[OwnerKey]
        , A.[IsDeleted]
        , A.[Name]
        , A.[CreatedDate]
        , A.[CreatedById]
        , A.[LastModifiedDate]
        , A.[AccountKey]
        , A.[Type]
        , A.[ClientAlternateKey]
        , '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1
                    FROM [dbo].[DimAccountStatus] B
                    WHERE A.[AccountStatusKey] = B.[AccountStatusKey])

UPDATE B
SET B.[OwnerKey] = A.[OwnerKey]
        , B.[IsDeleted] = A.[IsDeleted]
        , B.[Name] = A.[Name]
        , B.[CreatedDate] = A.[CreatedDate]
        , B.[CreatedById] = A.[CreatedById]
        , B.[LastModifiedDate] = A.[LastModifiedDate]
        , B.[AccountKey] = A.[AccountKey]
        , B.[Type] = A.[Type]
        , B.[ClientAlternateKey] = A.[ClientAlternateKey]
        , B.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
    INNER JOIN [dbo].[DimAccountStatus] B
        ON A.[AccountStatusKey] = B.[AccountStatusKey]
