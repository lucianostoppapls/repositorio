SELECT DISTINCT 
`Id` as `AccountKey`
, CAST(IFNULL(NULLIF(REGEXP_REPLACE(stonecode__C,'[^0-9]',''),''), '1') AS INT64) as `ClientAlternateKey`
, IFNULL(`Percent_Credito__c`, 0)	as `PercentCredit`
, IFNULL(`Percent_Credito_2_a_6x__c`, 0)  as `PercentCredit2to6`
, IFNULL(`Percent_Credito_7_a_12x__c`, 0) as `PercentCredit7to12`
, IFNULL(`Percent_Debito__c`, 0) as `PercentDebit`
, IFNULL(`Elo__c`, 0) as `Elo`
, IFNULL(`Hiper__c`, 0) as `Hiper`
, IFNULL(`Master__c`, 0) as `Master`
, IFNULL(`Visa__c`, 0) as `Visa`
, IFNULL(`Name`, 'N/D') as `Name`
, IFNULL(`Phone`, 'N/D') as `Phone`
, IFNULL(`Site`, 'N/D') as `Site`
, IFNULL(`mcc__c`, 'DEFAULT') as `mcc__c`
, CAST(IFNULL(Aceita_Hiper__c,FALSE) AS INT64) as `AcceptsHiper`
, IFNULL(`acquirer__c`, 'N/D') as `Acquirer`
, IFNULL(`AnnualRevenue`, 0) as `AnnualRevenue`
, IFNULL(`BillingCity`, 'N/D') as `BillingCity`
, IFNULL(`BillingCountry`, 'N/D') as `BillingCountry`
, IFNULL(`BillingGeocodeAccuracy`, 'N/D') as `BillingGeocodeAccuracy`
, cast(cast(IFNULL(`BillingLatitude`, 0) as NUMERIC) AS string)  as `BillingLatitude`
, cast(cast(IFNULL(`BillingLongitude`, 0) as NUMERIC) AS string) as `BillingLongitude`
, IFNULL(`BillingState`, 'N/D') as `BillingState`
, IFNULL(`BillingStreet`, 'N/D') as `BillingStreet`
, IFNULL(`BillingPostalCode`, 'N/D') as `BillingPostalCode`
, IFNULL(`Cadeia__c`, 'N/D') as `Chain`
, IFNULL(`sales_channel_name__c`, 'N/D') as `SalesChannelName`
, CAST(IFNULL(Cliente_Elavon__c,FALSE) AS INT64) as `ElavonClient`
, IFNULL(`Cliente_Tombado__c`, 'N/D') as `Migrated`
, IFNULL(`CNPJ_Limpo__c`, 'N/D')  as `ClientCNPJorCPF`
, REPLACE(SUBSTR(CAST(Data_de_credenciamento__c AS STRING),1,10),'-','') as `CreatedDate`
, REPLACE(SUBSTR(CAST(Data_de_inicio_do_Contrato__c AS STRING),1,10),'-','') as `ContractCommissionDate`
, CASE WHEN length(`affiliation_date__c`) = 10 AND `affiliation_date__c` LIKE '%/%'
	THEN REPLACE(CAST(CONCAT(SUBSTR(`affiliation_date__c`, -4), '-', SUBSTR(SUBSTR(`affiliation_date__c`, -7), 1, 2), '-', SUBSTR(`affiliation_date__c`, 1, 2)) AS STRING), '-', '')
	WHEN `affiliation_date__c` LIKE '%T%Z%'
	THEN REPLACE(CAST((SUBSTR(`affiliation_date__c`, 1, 10)) AS STRING),'-','')
	WHEN `affiliation_date__c` LIKE '%T%' THEN REPLACE(CAST((SUBSTR(`affiliation_date__c`, 1, 10)) AS STRING),'-','')
	WHEN `affiliation_date__c` LIKE '%-%'
	THEN REPLACE(CAST((`affiliation_date__c`) AS STRING) ,'-','')
	WHEN length(`affiliation_date__c`) = 8
	THEN REPLACE(CAST(CONCAT(SUBSTR(`affiliation_date__c`, -4), '-', SUBSTR(SUBSTR(`affiliation_date__c`, -6), 1, 2), '-', SUBSTR(`affiliation_date__c`, 1, 2)) AS STRING),'-','')
  ELSE NULL END as `AffiliationDate`
, REPLACE(SUBSTR(CAST(Data_fim_do_Contrato__c AS STRING),1,10),'-','') as `ContractFinalDate`
, IFNULL(`Elavon__c`, '0') as `Elavon`
, IFNULL(`account_mail__c`, 'N/D') as `AccountMail`
, IFNULL(`Email_Owner_Carteira__c`, 'N/D') as `EmailOwnerStructure`
, IFNULL(`Estado__c`, 'N/D') as `State`
, IFNULL(`Faturamento_Total_em_Cart_o__c`, 0) as `TotalCardBilling`
, IFNULL(`fraud_tools__c`, 'N/D') as `FraudTools`
, IFNULL(`Forca_da_Venda__c`, 'N/D') as `SalesForce`
, IFNULL(`Garantia__c`, 0) as `Warranty`
, IFNULL(`Gestor_da_Conta__c`, 'N/D') as `AccountManager`
, IFNULL(`GrupoCampanhas__c`, 'N/D') as `CampaignGroup`
, IFNULL(`Ilha_de_Atendimento__c`, 'N/D') as `ServiceIsland`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, REPLACE(CAST(EXTRACT(date from LastViewedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastViewedDate`
, IFNULL(`Melhor_meio_de_contato__c`, 'N/D') as `BestMeansContact`
, IFNULL(`merchant_id__c`, 0) as `MerchantKey`
, IFNULL(`Modelo_Elo__c`, 0) as `EloModel`
, IFNULL(`N_o_Atender_Ilha_Vip__c`, '0') as `NotAnswerVipIsland`
, CAST(IFNULL(nao_fazer_venda_ativa__c,FALSE) AS INT64) as `NotActiveSelling`
, CAST(IFNULL(Nao_negociar_taxa__c,FALSE) AS INT64) as `NotNegotiateFee`
, CAST(IFNULL(nao_oferecer_rav_automatico__c,FALSE) AS INT64)  as `NotOfferAutomaticRAV`
, IFNULL(`Nome_da_Cadeia__c`, 'N/D')  as `ChainName`
, IFNULL(`sales_partner_name__c`, 'N/D') as `SalesPartnerName`
, CAST(IFNULL(rav_oferecer_rav_automatico__c,FALSE) AS INT64) as `OfferAutomaticRAV`
, IFNULL(`outras_adquirentes__c`,	'N/D') as `OtherPurchasers`
, 'N/D' as `PartnerStone`
, IFNULL(`ParentId`, 'N/D') as `ParentKey`
, IFNULL(`rav_periodicidade_de_liquidacao__c`, 'N/D') as `RAVSettlementPeriodicity`
, IFNULL(`Polo__c`, 'N/D') as `Polo`
, CAST(IFNULL(possui_outra_adquirente__c,FALSE) AS INT64) as `HasAnotherPurchasers`
, CAST(IFNULL(rav_possui_rav_automatico__c,FALSE) AS INT64) as `RAVHasAnAutomaticRAV`
, IFNULL(`RAV_Agenda_Total__c`, 0) as `RAVTotalSchedule`
, REPLACE(CAST(EXTRACT(date from RAV_Data_da_Simulacao__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `RAVSimulationDate`
, IFNULL(`RAV_Prazo__c`, 'N/D') as `RAVDeadline`
, IFNULL(`RAV_Taxa_Cadastrada__c`, 0) as `RAVRegisteredRate`
, IFNULL(`RAV_Taxa_Simulada__c`, 0) as `RAVSimulatedRate`
, IFNULL(`RAV_Valor_Liquido__c`, 0) as `RAVNetValue`
, IFNULL(`legal_name__c`, 'N/D') as `LegalName`
, IFNULL(`Route__c`, 'N/D') as `Route`
, IFNULL(`balance_due__c`, 0) as `BalanceDue`
, IFNULL(`balance_receivables__c`, 0) as `BalanceReceivables`
, IFNULL(`balance_total__c`, 0) as `TotalBalance`
, IFNULL(`Segmenta_o__c`, 'N/D') as `Segmentation`
, CAST(IFNULL(is_seller__c,FALSE) AS INT64) as `IsSeller`
, IFNULL(`ShippingCity`, 'N/D') as `ShippingCity`
, IFNULL(`ShippingCountry`, 'N/D') as `ShippingCountry`
, IFNULL(`ShippingGeocodeAccuracy`, 'N/D') as `ShippingGeocodeAccuracy`
, cast(cast(IFNULL(`ShippingLatitude`, 0) as NUMERIC) AS string) as `ShippingLatitude`
, cast(cast(IFNULL(`ShippingLongitude`, 0) as NUMERIC) AS string) as `ShippingLongitude`
, IFNULL(`ShippingState`, 'N/D') as `ShippingState`
, IFNULL(`ShippingStreet`, 'N/D') as `ShippingStreet`
, IFNULL(`ShippingPostalCode`, 'N/D') as `ShippingPostalCode`
, IFNULL(`Status_Churn__c`, 'N/D') as `ChurnStatus`
, IFNULL(`status_name__c`, 'N/D') as `StatusName`
, IFNULL(`rav_taxa_de_antecipacao__c`, 0) as `RAVAnticipationFee`
, IFNULL(`Tem_contrato_com_a_Stone__c`, 'N/D') as `HasContractWithStone`
, IFNULL(`Ticket_M_dio_Cr_dito_2_a_6x__c`, 0) as `AverageTicketCredit2to6`
, IFNULL(`Ticket_M_dio_Cr_dito_7_a_12x__c`, 0) as `AverageTicketCredit7to12`
, IFNULL(`Ticket_M_dio_Cr_dito_Vista__c`, 0) as `AverageTicketCredit`
, IFNULL(`Ticket_Medio_Debito__c`, 0) as `AverageTicketDebit`
, IFNULL(`account_type__c`, 'N/D') as `AccountType`
, IFNULL(`Total_de_m_quinas_no_balc_o__c`, 0) as `TotalMachines`
, IFNULL(`tpv_m0__c`, 0) as `TPVCurrentMonth`
, IFNULL(`sales_person_name__c`, 'N/D') as `SalesPersonName`
, IFNULL(`Volume_comprometido_com_Stone__c`, 0) as `CommittedVolumeStone`
, IFNULL(`Website`, 'N/D') as `Website`
, IFNULL(`Canal_Carteira__c`, 'N/D') as `Canal_Carteira__c`
, IFNULL(`SubCanal_Carteira__c`, 'N/D') as `SubCanal_Carteira__c`
, IFNULL(`Grupo1_Carteira__c`, '-') as `Grupo1_Carteira__c`
, IFNULL(`Grupo2_Carteira__c`, '-') as `Grupo2_Carteira__c`
, IFNULL(`Grupo3_Carteira__c`,'-') as `Grupo3_Carteira__c`
, IFNULL(`Migracao__c`, 0) as `Migration`
, IFNULL(`ExpectedTPV__c`, 0) as `ExpectedTPV`
, IFNULL(`Quantidade_de_Lojas__c`, 0) as `StoreQuantity`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) AS `IsDeleted`
, IFNULL(subscription_plan_name__c,'N/D') AS `PlanName`
, IFNULL((case when upper(subscription_plan_id__c) = 'SEM REGISTRO' then '9' else subscription_plan_id__c end),'9') AS `PlanKey`
, Descancelado_pelo_user__c AS `RetractedUserKey`
, REPLACE(SUBSTR(CAST(Data_descancelamento__c AS STRING),1,10),'-','') AS `RetractedDateKey`
, IFNULL(`Stage_Name__c`, 'N/D') as `StageName`
, `Stage_Priority__c` as `StagePriority`
, IFNULL(`Stage_Description__c`, 'N/D') as `StageDescription`
, IFNULL(`Stage_Group__c`, 'N/D') as `StageGroup`
, IFNULL(`status_banking__c`, 'N/D') as `StatusBanking`
, IFNULL(`recordtypeid`, 'N/D') as `Recordtypeid`
, IFNULL(`Estrategia_Digital__c`, 'N/D') as `DigitalStrategy`
FROM dataplatform-prd.sop_salesforce.account
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}' AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
