SELECT Id as `FlagStatusKey`
, IFNULL(Bandeira__c, 'N/D') as `Flag`
, REPLACE(CAST(Status_date__c AS STRING),'-','') as `StatusDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, REPLACE(CAST(EXTRACT(date from LastViewedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastViewedDate`
, IFNULL(Status__c, 'N/D') as `Status`
, IFNULL(Name, 'N/D') as `Name`
, IFNULL(Stonecode__c, 'N/D') as `ClientAlternateKey`
FROM dataplatform-prd.sop_salesforce.status_bandeira__c
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
