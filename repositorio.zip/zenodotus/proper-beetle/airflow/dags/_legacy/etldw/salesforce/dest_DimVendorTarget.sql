INSERT INTO [dbo].[DimVendorTarget] ([VendorTargetKey]
, [OwnerKey]
, [OwnerEmail]
, [OwnerName]
, [PoloName]
, [DistrictName]
, [TargetATIAccreditations]
, [TargetAutoAccreditations]
, [ReferenceDate]
, [TargetRent]
, [TargetDIA]
, [TargetTPV]
, [LastModifiedDate]
, [IsDeleted]
, [LastUpdatedAt])

SELECT A.[VendorTargetKey]
, A.[OwnerKey]
, A.[OwnerEmail]
, A.[OwnerName]
, A.[PoloName]
, A.[DistrictName]
, A.[TargetATIAccreditations]
, A.[TargetAutoAccreditations]
, A.[ReferenceDate]
, A.[TargetRent]
, A.[TargetDIA]
, A.[TargetTPV]
, A.[LastModifiedDate]
, A.[IsDeleted]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimVendorTarget] B WHERE A.[VendorTargetKey] = B.[VendorTargetKey])
AND EXISTS (SELECT TOP 1 1 FROM [dbo].[DimUser] E WHERE ISNULL(A.[OwnerKey],'0') = E.[UserKey])

UPDATE C
SET C.[OwnerKey] = D.[OwnerKey]
, C.[OwnerEmail] = D.[OwnerEmail]
, C.[OwnerName] = D.[OwnerName]
, C.[PoloName] = D.[PoloName]
, C.[DistrictName] = D.[DistrictName]
, C.[TargetATIAccreditations] = D.[TargetATIAccreditations]
, C.[TargetAutoAccreditations] = D.[TargetAutoAccreditations]
, C.[ReferenceDate] = D.[ReferenceDate]
, C.[TargetRent] = D.[TargetRent]
, C.[TargetDIA] = D.[TargetDIA]
, C.[TargetTPV] = D.[TargetTPV]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[DimVendorTarget] C ON C.[VendorTargetKey] = D.[VendorTargetKey]
WHERE EXISTS (SELECT TOP 1 1 FROM [dbo].[DimUser] F WHERE ISNULL(D.[OwnerKey],'0') = F.[UserKey])
