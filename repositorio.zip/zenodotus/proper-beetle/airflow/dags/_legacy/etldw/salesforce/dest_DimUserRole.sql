INSERT INTO [dbo].[DimUserRole] ([UserRoleKey]
, [LastModifiedDate]
, [Name]
, [ParentRoleKey]
, [LastUpdatedAt])

SELECT A.[UserRoleKey]
, A.[LastModifiedDate]
, A.[Name]
, A.[ParentRoleKey]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimUserRole] B  WHERE A.[UserRoleKey] = B.[UserRoleKey])

UPDATE C
SET C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[Name] = D.[Name]
, C.[ParentRoleKey] = D.[ParentRoleKey]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[DimUserRole] C ON D.[UserRoleKey] = C.[UserRoleKey]
