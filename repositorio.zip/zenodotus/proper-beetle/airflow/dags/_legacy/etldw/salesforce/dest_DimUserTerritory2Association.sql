INSERT INTO [dbo].[DimUserTerritory2Association] ([UserTerritory2AssociationKey]
, [UserKey]
, [Territory2Key]
, [IsActive]
, [RoleInTerritory2]
, [LastModifiedDate]
, [LastModifiedByKey]
, [SystemModstamp]
, [LastUpdatedAt])

SELECT A.[UserTerritory2AssociationKey]
, A.[UserKey]
, A.[Territory2Key]
, A.[IsActive]
, A.[RoleInTerritory2]
, A.[LastModifiedDate]
, A.[LastModifiedByKey]
, A.[SystemModstamp]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimUserTerritory2Association] B WHERE A.[UserTerritory2AssociationKey] = B.[UserTerritory2AssociationKey])

UPDATE C
SET C.[UserKey] = D.[UserKey]
, C.[Territory2Key] = D.[Territory2Key]
, C.[IsActive] = D.[IsActive]
, C.[RoleInTerritory2] = D.[RoleInTerritory2]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[LastModifiedByKey] = D.[LastModifiedByKey]
, C.[SystemModstamp] = D.[SystemModstamp]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[DimUserTerritory2Association] C ON D.[UserTerritory2AssociationKey] = C.[UserTerritory2AssociationKey]
