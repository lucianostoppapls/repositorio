SELECT Id as `LeadHistoryKey`
, IFNULL(Field, 'N/D') as `Field`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING) ,'-','') as `CreatedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, IFNULL(LeadId, 'N/D') as `LeadKey`
, IFNULL(NewValue, 'N/D') as `NewValue`
, IFNULL(OldValue, 'N/D') as `OldValue`
FROM dataplatform-prd.sop_salesforce.leadhistory
WHERE EXTRACT(datetime from CreatedDate at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from CreatedDate at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
