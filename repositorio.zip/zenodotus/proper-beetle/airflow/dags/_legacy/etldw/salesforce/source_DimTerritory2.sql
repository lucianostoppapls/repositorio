SELECT Id as `Territory2Key`
, IFNULL(Name, 'N/D') as `Name`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, IFNULL(ParentTerritory2Id, '0') as `ParentTerritory2Key`
, IFNULL(Territory2ModelId, '0') as `Territory2ModelKey`
, IFNULL(Territory2TypeId, '0') as `Territory2TypeKey`
, CAST(IFNULL(Ativo__c,FALSE) AS INT64) as `Active`
, CAST(IFNULL(Apuracao_Ativa__c,FALSE) AS INT64) as `PaymentActive`
FROM dataplatform-prd.sop_salesforce.territory2
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
