SELECT `Id` as `OpportunityKey`
, IFNULL(`Leads__c`, 0) as `Leads`
, IFNULL(`AccountId`, 'N/D') as `AccountKey`
, CAST(IFNULL(Antecipa_com_a_concorr_ncia__c,FALSE) AS INT64) as `AnticipatesCompetition`
, CAST(IFNULL(Antecipacao__c,FALSE) AS INT64) as `Anticipation`
, CAST(IFNULL(Antifraude__c,FALSE) AS INT64) as `Antifraud`
, IFNULL(`Area_m2__c`, 0) as `AreaM2`
, CAST(IFNULL(Atestado_de_Validade__c,FALSE) AS INT64) as `ValidityCertificate`
, CAST(IFNULL(Aumentar_limite_de_credito__c,FALSE) AS INT64) as `IncreaseCreditLimit`
, CAST(IFNULL(Aumento_do_prazo__c,FALSE) AS INT64) as `TermIncrease`
, IFNULL(`Bairro__c`, 'N/D') as `Neighborhood`
, IFNULL(`Banco__c`, 'N/D') as `Bank`
, IFNULL(`CEP__c`, 'N/D') as `ZipCode`
, IFNULL(`Cidade__c`, 'N/D') as `City`
, REPLACE(SUBSTR(CAST(CloseDate AS STRING),1,10),'-','') as `Closeddate`
, CAST(IFNULL(Isclosed,FALSE) AS INT64) as `Isclosed`
, IFNULL(`Com_quem_o_lead_antecipa__c`, 'N/D') as `WithWhomTheLeadAnticipates`
, IFNULL(`Como_conheceu_a_Stone__c`, '0') as `HowMeetStone`
, IFNULL(`Complemento__c`, 'N/D') as `Complement`
, CAST(IFNULL(Conciliacao_Equals__c,FALSE) AS INT64) as `ConciliationEquals`
, IFNULL(`CPF_do_Socio__c`, 'N/D') as `PartnerCpf`
, IFNULL(`CNPJ__c`, 'N/D') as `ClientCNPJorCPF`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `Createddate`
, CAST(IFNULL(Credenciado__c,FALSE) AS INT64) as `Accredited`
, CAST(IFNULL(Credito_Via_Bancos_Parceiros__c,FALSE) AS INT64) as `PartnerBankCredit`
, REPLACE(SUBSTR(CAST(Data_de_Credenciamento__c AS STRING),1,10),'-','') as `AccreditationDate`
, REPLACE(SUBSTR(CAST(Data_de_Nascimento_do_Socio__c AS STRING),1,10),'-','') as `MemberDateBirth`
, CAST(IFNULL(Isdeleted,FALSE) AS INT64) as `Isdeleted`
, IFNULL(`Dias_Debito__c`, 'N/D') as `DaysDebit`
, IFNULL(`Digito_da_Agencia__c`, 'N/D') as `AgencyDigest`
, IFNULL(`Digito_da_Conta__c`, 'N/D') as `AccountDigit`
, IFNULL(`Email_da_Conta__c`, 'N/D') as `AccountsEmail`
, IFNULL(`Email__c`, 'N/D') as `Email`
, IFNULL(`Email_do_Socio__c`, 'N/D') as `PartnerEmail`
, IFNULL(`Encadeamento__c`, 'N/D') as `Thread`
, IFNULL(`Estado__c`, 'N/D') as `State`
, IFNULL(`Faixa_Etaria_do_Tomador_de_Decisao__c`, 'N/D') as `DecisionRangeOfTheDecisionMaker`
, CAST(IFNULL(FIDC__c,FALSE) AS INT64) as `FIDC`
, CAST(IFNULL(Flip__c,FALSE) AS INT64) as `Flip`
, CAST(IFNULL(Foi_indicado_por_um_cliente__c,FALSE) AS INT64) as `WasIndicatedByACustomer`
, CAST(IFNULL(Garantia_Fornecedor__c,FALSE) AS INT64) as `SupplierWarranty`
, IFNULL(`Horario_de_Entrega_Final__c`, 'N/D') as `FinalDeliverySchedule`
, IFNULL(`Horario_de_Entrega_Inicial__c`, 'N/D') as `InitialDeliverySchedule`
, IFNULL(`Horario_de_funcionamento__c`, 'N/D') as `HoursOfOperation`
, IFNULL(`Identificador_de_Pricing_del__c`, 'N/D') as `PricingIdentifier`
, IFNULL(`Indicado_Por__c`, 'N/D') as `IndicatedBy`
, CAST(IFNULL(Integracao_RP_Equals__c,FALSE) AS INT64) as `RPEqualsIntegration`
, CAST(IFNULL(Ja_tem_Alelo__c,FALSE) AS INT64) as `AlreadyAlelo`
, IFNULL(`Justificativa_de_Perda__c`, 'N/D') as `JustificationLoss`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, REPLACE(CAST(EXTRACT(date from LastViewedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastViewedDate`
, IFNULL(`Latitude__c`, 'N/D') as `Latitude`
, IFNULL(`Longitude__c`, 'N/D') as `Longitude`
, IFNULL(`MCC__c`, 'N/D') as `MCCKey`
, IFNULL(CAST(`Mcc_Infoplex__c` as STRING), 'N/D') as `MCCInfoplex`
, IFNULL(`Meio_de_Captura__c`, 'N/D') as `CaptureMedium`
, IFNULL(`Migracao__c`, 0) as `Migration`
, IFNULL(`Name`, 'N/D') as `Name`
, IFNULL(`Nome_do_Socio__c`, 'N/D') as `MemberName`
, IFNULL(`Nome_da_pessoa_do_primeiro_contato__c`, 'N/D') as `FirstContactPerson`
, IFNULL(`Numero__c`, 'N/D') as `Number`
, IFNULL(`Numero_da_Agencia__c`, 'N/D') as `AgencyNumber`
, IFNULL(`Numero_da_Conta__c`, 'N/D') as `AccountNumber`
, IFNULL(`N_mero_de_tentativas__c`, 'N/D') as `NumberAttempts`
, IFNULL(`Numero_maximo_de_refeicoes_por_dia__c`, 0) as `MaximumNumberMealsPerDay`
, IFNULL(`O_Lead_antecipa__c`, 'N/D') as `LeadAnticipates`
, IFNULL(`O_Lead_parcela__c`, 'N/D') as `LeadPlot`
, IFNULL(`Origem__c`, 'N/D') as `Source`
, IFNULL(`OwnerId`, 'N/D') as `OwnerKey`
, CAST(IFNULL(Pagamento_na_Matriz__c,FALSE) AS INT64) as `MatrixPayment`
, IFNULL(`Pais__c`, 'N/D') as `Country`
, IFNULL(`Periodicidade__c`, 0) as `Frequency`
, IFNULL(`Polo__c`, 'N/D') as `Polo`
, IFNULL(CAST(`Produtos__c` AS STRING), 'N/D') as `Products`
, IFNULL(`Qual_bandeira_travada__c`, 'N/D') as `WhatFlagIsCaught`
, IFNULL(`Qual_Modelo_de_Parceria__c`, 'N/D') as `WhichPartnershipModel`
, IFNULL(`Raz_o_Social__c`, 'N/D') as `SocialReason`
, CAST(IFNULL(Rebate__c,FALSE) AS INT64) as `Rebate`
, IFNULL(`Receita_Net_MDR_esperada__c`, 0) as `ExpectedDIANetRevenue`
, IFNULL(`Receita_RAV_esperada__c`, 0) as `ExpectedRAVRevenue`
, IFNULL(`Rua__c`, 'N/D') as `Street`
, CAST(IFNULL(Split_de_Pagamento__c,FALSE) AS INT64) as `PaymentSplit`
, IFNULL(`StageName`, 'N/D') as `StageName`
, IFNULL(`StoneCode__c`, '1') as `ClientAlternateKey`
, IFNULL(`Tecnologia__c`, 'N/D') as `Technology`
, CAST(IFNULL(TEF_Cappta__c,FALSE) AS INT64) as `TEFCappta`
, IFNULL(`Telefone__c`, 'N/D') as `Telephone`
, IFNULL(`Telefone_do_Socio__c`, 'N/D') as `MemberPhone`
, CAST(IFNULL(Tem_Wi_fi__c,FALSE) AS INT64) as `IsThereWiFi`
, IFNULL(`Termometro__c`, 'N/D') as `Thermometer`
, IFNULL(`Territory2Id`, '0') as `Territory2Key`
, IFNULL(`Tipo_de_Alimentacao__c`, 'N/D') as `TypeOfFood`
, IFNULL(`Tipo_de_Conta__c`, 'N/D') as `AccountType`
, IFNULL(`Tipo_de_Lead__c`, 'N/D') as `LeadType`
, IFNULL(`Tipo_de_Oportunidade__c`, 'N/D') as `TypeOfOpportunity`
, IFNULL(`Tipo_de_Refeicao__c`, 'N/D') as `TypeOfMeal`
, IFNULL(`TPV_Estimado__c`, 0) as `TPVEstimate`
, CAST(IFNULL(Valido__c,FALSE) AS INT64) as `Valid`
, CAST(IFNULL(IsWon,FALSE) AS INT64)  as `IsWon`
, IFNULL(`Qualificador__c`, 'N/D') as `Qualificator`
, IFNULL(`CreatedById`, 'N/D') as `UserKey`
, IFNULL(`Migracao__c`, 0) as `ExpectedMigration`
, IFNULL(`ExpectedTPV__c`, 0) as `ExpectedTPV`
, IFNULL(`Numero_de_Lojas__c`,0) as `StoreQuantity`
, CASE
      WHEN `Recordtypeid` = '01241000001UQvAAAW' THEN 'Stone Mais'
      WHEN `Recordtypeid` = '0121L000001cmf7QAA' THEN 'Stone Expansão'
      WHEN `Recordtypeid` = '0121L000001cmf2QAA' THEN 'Stone Livre'
      ELSE 'N/D'
  END as `StonePlan`
FROM dataplatform-prd.sop_salesforce.opportunity
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
