INSERT INTO [dbo].[DimTerritory2] ([Territory2Key]
, [Name]
, [LastModifiedDate]
, [ParentTerritory2Key]
, [Territory2ModelKey]
, [Territory2TypeKey]
, [Active]
, [PaymentActive]
, [LastUpdatedAt])

SELECT A.[Territory2Key]
, A.[Name]
, A.[LastModifiedDate]
, A.[ParentTerritory2Key]
, A.[Territory2ModelKey]
, A.[Territory2TypeKey]
, A.[Active]
, A.[PaymentActive]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[DimTerritory2] B WHERE A.[Territory2Key] = B.[Territory2Key])

UPDATE C
SET C.[Name] = D.[Name]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[ParentTerritory2Key] = D.[ParentTerritory2Key]
, C.[Territory2ModelKey] = D.[Territory2ModelKey]
, C.[Territory2TypeKey] = D.[Territory2TypeKey]
, C.[Active] = D.[Active]
, C.[PaymentActive] = D.[PaymentActive]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D INNER JOIN [dbo].[DimTerritory2] C ON C.[Territory2Key] = D.[Territory2Key]
