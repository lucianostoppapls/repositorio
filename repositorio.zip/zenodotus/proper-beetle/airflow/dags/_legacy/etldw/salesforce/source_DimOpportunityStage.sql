SELECT Id as `OpportunityStageKey`
, CAST(IFNULL(IsClosed,FALSE) AS INT64) as `IsClosed`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `CreatedDate`
, IFNULL(Description, 'N/D')  as `Description`
, CAST(IFNULL(IsActive,FALSE) AS INT64) as `IsActive`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
FROM dataplatform-prd.sop_salesforce.opportunitystage
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
