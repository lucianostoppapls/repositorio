SELECT IFNULL(`AccountId`, '0') as `AccountKey`
	 , IFNULL(`AssetId`, 'N/D') as `AssetKey`
	 , IFNULL(`BIN__c`, 'N/D') as `BIN`
	 , IFNULL(`BusinessHoursId`, 'N/D') as `BusinessHoursKey`
	 , IFNULL(`CaseNumber`, 'N/D') as `CaseNumber`
	 , IFNULL(`Status_da_Reclama_o__c`, 'N/D') as `CaseStatus`
	 , REPLACE(CAST(EXTRACT(date from ClosedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `ClosedDate`
	 , IFNULL(`ContactId`, '0') as `ContactKey`
	 , IFNULL(`CPF_MEI__c`, 'N/D') as `CPFMEI`
	 , IFNULL(`CreatedById`, 'N/D') as `CreatedByKey`
	 , REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `CreatedDate`
	 , IFNULL(`Description`, 'N/D') as `Description`
	 , IFNULL(`EntitlementId`, 'N/D') as `EntitlementKey`
	 , IFNULL(`GCI__c`, 'N/D') as `GCI`
	 , IFNULL(`Id`, 'N/D') as `CaseKey`
	 , CAST(IFNULL(IsClosed,FALSE) AS INT64) as `IsClosed`
	 , CAST(IFNULL(IsClosedOnCreate,FALSE) AS INT64) as `IsClosedOnCreate`
	 , CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
	 , CAST(IFNULL(IsEscalated,FALSE) AS INT64) as `IsEscalated`
	 , CAST(IFNULL(IsStopped,FALSE) AS INT64) as `IsStopped`
	 , IFNULL(`LastModifiedById`, 'N/D') as `LastModifiedByKey`
	 , REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
	 , REPLACE(CAST(EXTRACT(date from LastReferencedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastReferencedDate`
	 , REPLACE(CAST(EXTRACT(date from LastViewedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastViewedDate`
	 , IFNULL(`lntcms__EngineeringReqNumber__c`, 'N/D') as `lntcmsEngineeringReqNumber`
	 , IFNULL(`lntcms__Product__c`, 'N/D') as `lntcmsProduct`
	 , IFNULL(`MID__c`, 'N/D') as `MID`
	 , IFNULL(`MilestoneStatus`, 'N/D') as `MilestoneStatus`
	 , IFNULL(`NSU__c`, 'N/D') as `NSU`
	 , IFNULL(`Origin__c`, 'N/D') as `Origin`
	 , IFNULL(`OwnerId`, 'N/D') as `OwnerKey`
	 , IFNULL(`ParentId`, 'N/D') as `ParentKey`
	 , IFNULL(`Priority`, 'N/D') as `Priority`
	 , IFNULL(`ProductId`, 'N/D') as `ProductKey`
	 , IFNULL(`Reason`, 'N/D') as `Reason`
	 , IFNULL(`RecordTypeId`, 'N/D') as `RecordTypeKey`
	 , IFNULL(`SLA__c`, 0) as `SLA`
	 , REPLACE(CAST(EXTRACT(date from SlaExitDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `SlaExitDate`
	 , REPLACE(CAST(EXTRACT(date from SlaStartDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `SlaStartDate`
	 , IFNULL(`SourceId`, 'N/D') as `SourceKey`
	 , IFNULL(`Status`, 'N/D') as `Status`
	 , REPLACE(CAST(EXTRACT(date from StopStartDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `StopStartDate`
	 , IFNULL(`Subject`, 'N/D') as `Subject`
	 , IFNULL(`SuppliedCompany`, 'N/D') as `SuppliedCompany`
	 , IFNULL(`SuppliedEmail`, 'N/D') as `SuppliedEmail`
	 , IFNULL(`SuppliedName`, 'N/D') as `SuppliedName`
	 , IFNULL(`SuppliedPhone`, 'N/D') as `SuppliedPhone`
	 , REPLACE(CAST(EXTRACT(date from SystemModstamp at time zone 'America/Sao_Paulo') AS STRING),'-','') as `SystemModstamp`
	 , IFNULL(`textover__c`, 'N/D') as `TextOver`
	 , IFNULL(`Type`, 'N/D') as `Type`
	 , IFNULL(`URLsrc__c`, 'N/D') as `URLsrc`
	 , IFNULL(`Erro_Comercial_Parceiro__c`, 'N/D') as `CommercialErrorPartner`
	 , IFNULL(`Anexos__c`, 'N/D') as `Attachments`
	 , IFNULL(`Email_ouvidoria__c`, 'N/D') as `OmbudsmansEmail`
	 , IFNULL(`Nome_ouvidoria__c`, 'N/D') as `OmbudsmansName`
	 , IFNULL(`Qual_Bandeira_Produto__c`, 'N/D') as `WhichProductFlag`
	 , CAST(IFNULL(Reverti__c,FALSE) AS INT64) as `Reversed`
	 , CAST(IFNULL(Retirada_de_Equipamentos__c,FALSE) AS INT64) as `EquipmentWithdrawal`
	 , IFNULL(`Assunto_Expansao__c`, 'N/D') as `SubjectExpansion`
	 , CAST(IFNULL(Alerta_Risco__c,FALSE) AS INT64) as `AlertRisk`
	 , CAST(IFNULL(Reclame_Aqui_Mencionado__c,FALSE) AS INT64) as `ClaimHereMentioned`
	 , IFNULL(`Operadora_do_Chip__c`, 'N/D') as `ChipOperator`
	 , REPLACE(CAST(EXTRACT(date from Retornar_Cliente__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `ReturnCustomer`
	 , CAST(IFNULL(Ame_Aqui__c,FALSE) AS INT64) as `AmeAqui`
	 , IFNULL(`Ordem_de_Servico__c`, 'N/D') as `ServiceOrder`
	 , REPLACE(CAST(EXTRACT(date from Data_do_Evento__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `EventDate`
	 , IFNULL(`Qntd_de_POS__c`, 0) as `POSAmount`
	 , REPLACE(CAST(Data_de_Termino__c AS STRING),'-','') as `EndDate`
	 , IFNULL(`Tema_Help_Fin__c`, 'N/D') as `TopicHelpFin`
	 , IFNULL(`Categoria_Expansao__c`, 'N/D') as `CategoryExpansion`
	 , IFNULL(`Tema_Help_TI__c`, 'N/D') as `ITHelpTopic`
	 , REPLACE(CAST(EXTRACT(date from SlaExitDatelog__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `SLAExitDateLog`
	 , IFNULL(`SLA_dias_uteis__c`, 0) as `SLAWorkingDays`
	 , IFNULL(`Texto__c`, 'N/D') as `Text`
	 , IFNULL(`Tema_Risco__c`, 'N/D') as `TopicRisk`
	 , IFNULL(`Imagem_Status__c`, 'N/D') as `ImageStatus`
	 , IFNULL(`Saldo_em_aberto__c`, 0) as `OutstandingBalance`
	 , IFNULL(`Pesquisa_de_Satisfa_o__c`, 'N/D') as `SatisfactionSurvey`
	 , IFNULL(`Regra_do_Cliente__c`, 'N/D') as `CustomerRule`
	 , IFNULL(`Area_Resolvedora__c`, 'N/D') as `ResolvingArea`
	 , CAST(IFNULL(Gerou_OP__c,FALSE) AS INT64) as `GeneratedOP`
	 , IFNULL(`Tema_WC__c`, 'N/D') as `WCTheme`
	 , IFNULL(`Categoria_WC__c`, 'N/D') as `CategoryWC`
	 , IFNULL(`Assunto_WC__c`, 'N/D') as `SubjectWC`
	 , IFNULL(`Tema_Trading__c`, 'N/D') as `TradingTheme`
	 , IFNULL(`Categoria_Trading__c`, 'N/D') as `CategoryTrading`
	 , IFNULL(`Assunto_Trading__c`, 'N/D') as `SubjectTrading`
	 , IFNULL(`Tema_Logistica__c`, 'N/D') as `ThemeLogistics`
	 , IFNULL(`Valor_da_OP__c`, 0) as `OPValue`
	 , IFNULL(`Precisa_de_OP__c`, 'N/D') as `OPNeed`
	 , IFNULL(`Respons_vel_pelo_custo_da_OP__c`, 'N/D') as `CostOPResponsible`
	 , IFNULL(`Valor_Bruto_Antecipado__c`, 0) as `AdvanceGrossAmount`
	 , IFNULL(`Quantidade_de_Stone_Codes__c`, 0) as `ClientAlternateKeyQuantity`
	 , IFNULL(`ExternalID__c`, 0) as `ExternalKey`
	 , IFNULL(`Id_Reclame_Aqui__c`, 'N/D') as `ReclameAquiKey`
	 , IFNULL(`Tema_Saldo_em_Aberto__c`, 'N/D') as `OpenBalanceTheme`
	 , IFNULL(`Motivo_ReclameAqui__c`, 'N/D') as `ReclameAquiReason`
	 , IFNULL(`Categoria_Saldo_em_Aberto__c`, 'N/D') as `OpenBalanceCategory`
	 , IFNULL(`Assunto_Saldo_em_Aberto__c`, 'N/D') as `SubjectBalanceOpen`
	 , IFNULL(`Categoria_Autorizador__c`, 'N/D') as `AuthorizationCategory`
	 , CAST(IFNULL(Caso_nao_respondido__c,FALSE) AS INT64) as `UnansweredCase`
	 , IFNULL(`Tipo_de_erro_da_conta__c`, 'N/D') as `AccounterrorType`
	 , IFNULL(`Voltaria_a_fazer_neg_cio__c`, 'N/D') as `WouldDoBusinessAgain`
	 , IFNULL(`Entende_que_o_problema_foi_resolvido__c`, 'N/D') as `ResolvedProblem`
	 , IFNULL(`Nota_ReclameAqui__c`, 0) as `ReclameAquiNote`
	 , CAST(IFNULL(Caso_redirecionado__c,FALSE) AS INT64) as `RedirectCase`
	 , IFNULL(`Autosservi_o_Oferecido_del__c`, 'N/D') as `SelfServiceOffered`
	 , IFNULL(`Taxa_Automatica__c`, 0) as `AutomaticRate`
	 , CAST(IFNULL(Comercial_ISO__c,FALSE) AS INT64) as `CommercialISO`
	 , IFNULL(`Tema_Banops__c`, 'N/D') as `BanopsTheme`
	 , IFNULL(`Categoria_Banops__c`, 'N/D') as `BanopsCategory`
	 , IFNULL(`Assunto_Banops__c`, 'N/D') as `BanopsSubject`
	 , IFNULL(`Taxa_Pontual__c`, 0) as `PunctualRate`
	 , IFNULL(`Qual_problema_aconteceu_CIP__c`, 'N/D') as `ProblemCIP`
	 , IFNULL(`Problema_habilitacao__c`, 'N/D') as `EnablingProblem`
	 , IFNULL(`Dados_Glias__c`, 'N/D') as `GliasContactInfo`
	 , IFNULL(`Canal__c`, 'N/D') as `Channel`
	 , CAST(IFNULL(Inserir_dados_de_lead__c,FALSE) AS INT64) as `EnterLeadData`
	 , IFNULL(`Tema_RAV__c`, 'N/D') as `RAVTheme`
	 , IFNULL(`Categoria_Logistica__c`, 'N/D') as `LogisticsCategory`
	 , IFNULL(`Assunto_Logistica__c`, 'N/D') as `LogisticsSubject`
	 , REPLACE(CAST(EXTRACT(date from SolveDate__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `SolveDate`
	 , IFNULL(`PSCComentarios__c`, 'N/D') as `PSCComments`
	 , IFNULL(`Transferi__c`, 'N/D') as `Transferred`
	 , IFNULL(`Stonecode_antecipados__c`, 0) as `ClientAlternateKeyAnticipated`
	 , REPLACE(CAST(EXTRACT(date from ZClosedDate__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `ZClosedDate`
	 , REPLACE(CAST(EXTRACT(date from ZCreatedDate__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `ZCreatedDate`
	 , REPLACE(CAST(EXTRACT(date from PendingDate__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `PendingDate`
	 , IFNULL(`Categoria_RAV__c`, 'N/D') as `RAVCategory`
	 , IFNULL(`Erro__c`, 'N/D') as `Error`
	 , IFNULL(`Taxa_Spot__c`, 0) as `SpotRate`
	 , IFNULL(`A_OS_foi_tratada__c`, 'N/D') as `OSTreated`
	 , IFNULL(`Problema_Logistica__c`, 'N/D') as `LogisticProblem`
	 , IFNULL(`PSCMeiodecaptura__c`, 'N/D') as `PSCCaptureMedium`
	 , REPLACE(CAST(EXTRACT(date from PSCDataHoradaResposta__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `PSCdateResponse`
	 , IFNULL(`Previs_o_correta_S_N__c`, 'N/D') as `CorrectForecast`
	 , IFNULL(`Status_Verifica_o_de_Seguran_a__c`, 'N/D') as `StatusChecksSecurity`
	 , IFNULL(`Solicitante__c`, 'N/D') as `Requester`
	 , IFNULL(`Requisitar_visita_t_cnica__c`, 'N/D') as `RequestTechnicalVisit`
	 , IFNULL(`Tema_CBK__c`, 'N/D') as `CBKTheme`
	 , IFNULL(`Categoria_CBK__c`, 'N/D') as `CBKCategory`
	 , IFNULL(`Assunto_CBK__c`, 'N/D') as `CBKSubject`
	 , IFNULL(`Tema_Campanhas__c`, 'N/D') as `CampaignsTheme`
	 , IFNULL(`TRC__c`, 'N/D') as `TRC`
	 , IFNULL(`CRC__c`, 'N/D') as `CRC`
	 , IFNULL(`ARC__c`, 'N/D') as `ARC`
	 , REPLACE(CAST(Data_da_Transa_o__c AS STRING),'-','') as `TransactionDate`
	 , IFNULL(`Email_Gambiarra__c`, 'N/D') as `AdjustmentEmail`
	 , IFNULL(`Stonecode_provisorio__c`, 'N/D') as `ClientAlternateKeyProvisional`
	 , IFNULL(`Virou__c`, 'N/D') as `Turned`
	 , IFNULL(`Agente_do_Erro__c`, 'N/D') as `ErrorAgent`
	 , IFNULL(`Stonecode_MID_do_erro__c`, 'N/D') as `ClientAlternateKeyErrorMKey`
	 , IFNULL(`Serial_POS__c`, 'N/D') as `SerialPOS`
	 , IFNULL(`Versao_App__c`, 'N/D') as `Appversion`
	 , IFNULL(`Tarifas__c`, 'N/D') as `Rates`
	 , IFNULL(`Duvidas_Tarifas__c`, 'N/D') as `DoubtsRates`
	 , IFNULL(`Dados_Cadastrais__c`, 'N/D') as `RegistrationData`
	 , IFNULL(`Features_do_Portal__c`, 'N/D') as `PortalFeatures`
	 , IFNULL(`Duvidas_RAV__c`, 'N/D') as `ViewForumPosts`
	 , IFNULL(`Tema_Integracoes__c`, 'N/D') as `ThemeIntegration`
	 , IFNULL(`Tema_COF__c`, 'N/D') as `COFTopic`
	 , IFNULL(`Categoria_COF__c`, 'N/D') as `COFCategory`
	 , IFNULL(`Erro_gerador_da_OP__c`, 'N/D') as `OPGeneratorError`
	 , IFNULL(`Tarifa_Renegociada__c`, 'N/D') as `RenegotiatedRate`
	 , IFNULL(`Categoria_Risco__c`, 'N/D') as `CategoryRisk`
	 , IFNULL(`N_mero_do_Telefone_do_Cliente__c`, 'N/D') as `CustomersPhoneNumber`
	 , IFNULL(`Assunto_Risco__c`, 'N/D') as `SubjectRisk`
	 , IFNULL(`Duvidas_Antifraude__c`, 'N/D') as `AntifraudDoubts`
	 , IFNULL(`Resultado_da_Analise__c`, 'N/D') as `AnalysisResult`
	 , IFNULL(`Tema_Elavon__c`, 'N/D') as `ElavonTheme`
	 , IFNULL(`Categoria_Elavon__c`, 'N/D') as `ElavonCategory`
	 , IFNULL(`Assunto_Elavon__c`, 'N/D') as `ElavonSubject`
	 , IFNULL(`Tema_RT__c`, 'N/D') as `RTTopic`
	 , IFNULL(`Categoria_RT__c`, 'N/D') as `RTCategory`
	 , IFNULL(`Assunto_RT__c`, 'N/D') as `RTSubject`
	 , IFNULL(`Cancelamento_Nao_Realizado_Motivos__c`, 'N/D') as `CancellationNotRealizedReasons`
	 , IFNULL(`Categoria_Help_Fin__c`, 'N/D') as `HelpFinCategory`
	 , IFNULL(`Assunto_Help_Fin__c`, 'N/D') as `HelpFinSubject`
	 , IFNULL(`Categoria_Integra_es__c`, 'N/D') as `IntegrationsCategory`
	 , IFNULL(`N_o_virou_autom_tica__c`, 'N/D') as `NotTurnedAutomatic`
	 , IFNULL(`Incidente_Relacionado__c`, 'N/D') as `RelatedIncident`
	 , IFNULL(`Problema__c`, 'N/D') as `Problem`
	 , IFNULL(`Renegociacao__c`, 'N/D') as `Renegotiation`
	 , IFNULL(`Valor_total_da_venda__c`, 0) as `SaleTotalValue`
	 , IFNULL(`C_digo_de_Autoriza_o__c`, 'N/D') as `AuthorizationCode`
	 , IFNULL(`Tipo_de_Venda__c`, 'N/D') as `SaleType`
	 , IFNULL(`Email_para_carta_de_cancelamento__c`, 'N/D') as `EmailCancellationlLetter`
	 , IFNULL(`Valor_a_cancelar__c`, 0) as `CancelAmount`
	 , IFNULL(`Tema_Help_Produtos__c`, 'N/D') as `HelpTopicProducts`
	 , IFNULL(`Assunto_Help_Produtos__c`, 'N/D') as `HelpProductsSubject`
	 , IFNULL(`Categoria1_Help_Produtos__c`, 'N/D') as `HelpProductsCategory1`
	 , IFNULL(`Tema_Tombamento__c`, 'N/D') as `TumbingTheme`
	 , IFNULL(`Categoria_Tombamento__c`, 'N/D') as `TumbingCategory`
	 , IFNULL(`Modalidade__c`, 'N/D') as `Modality`
	 , IFNULL(`Origem__c`, 'N/D') as `Source`
	 , IFNULL(`Assunto_Tombamento__c`, 'N/D') as `TippingSubject`
	 , IFNULL(`Reclama_es_Duopolio__c`, 'N/D') as `DuopolyClaims`
	 , IFNULL(`Adquirente_Ilha_Vip__c`, 'N/D') as `VipIslandAcquirer`
	 , IFNULL(`Tema_Ilha_VIP__c`, 'N/D') as `VIPIslandTheme`
	 , IFNULL(`Categoria_Ilha_VIP__c`, 'N/D') as `VIPIslandCategory`
	 , IFNULL(`Assunto_Ilha_VIP__c`, 'N/D') as `VIPIslandSubject`
	 , IFNULL(`Profile_Case__c`, 'N/D') as `ProfileCase`
	 , IFNULL(`cancelamentomail__c`, 'N/D') as `EmailCancellation`
	 , IFNULL(`Caso_do_erro__c`, 'N/D') as `ErrorCase`
	 , IFNULL(`Lead_Vinculado_del__c`, 'N/D') as `LinkedLead`
	 , IFNULL(`Profile_do_criador_do_caso__c`, 'N/D') as `ProfileCaseCreator`
	 , IFNULL(`Emissor__c`, 'N/D') as `Issuer`
	 , IFNULL(`Gerou_reajuste__c`, 'N/D') as `GeneratedReset`
	 , IFNULL(`Valor_do_Ajuste_del__c`, 'N/D') as `SettingValue`
	 , IFNULL(`ItCliente__c`, 0) as `ItClient`
	 , IFNULL(`Modelo_do_Equipamento__c`, 'N/D') as `EquipmentModel`
	 , IFNULL(`Tipo_de_Erro__c`, 'N/D') as `ErrorType`
	 , CAST(IFNULL(Vira_vira__c,FALSE) AS INT64) as `ViraVira`
	 , IFNULL(`Canal_de_contato__c`, 'N/D') as `ContactChannel`
	 , CAST(IFNULL(Potencial_venda_ativa__c,FALSE) AS INT64) as `PotentialActiveSale`
	 , IFNULL(`Tema_Ativacao__c`, 'N/D') as `ActivationTheme`
	 , IFNULL(`Categoria_Ativacao__c`, 'N/D') as `ActivationCategory`
	 , IFNULL(`Assunto_Ativacao__c`, 'N/D') as `ActivationSubject`
	 , CAST(IFNULL(Robo_de_Cancelamento_Falhou__c,FALSE) AS INT64) as `CancellationTheftFailed`
	 , IFNULL(`Tema_Caca__c`, 'N/D') as `CacaTheme`
	 , IFNULL(`Tema_Franquias__c`, 'N/D') as `FranchisesTheme`
	 , IFNULL(`Categoria_Franquias__c`, 'N/D') as `FranchisesCategory`
	 , IFNULL(`Tema_Campanhas_Tomb__c`, 'N/D') as `CampaignsTombTheme`
	 , IFNULL(`Tipo_do_Tombamento__c`, 'N/D') as `TumbingType`
	 , IFNULL(`Tema_Ouvidoria__c`, 'N/D') as `OmbudsmanTopic`
	 , IFNULL(`Categoria_Ouvidoria__c`, 'N/D') as `OmbudsmanCategory`
	 , IFNULL(`Assunto_Ouvidoria__c`, 'N/D') as `OmbudsmanSubject`
	 , IFNULL(`Tipo_do_caso__c`, 'N/D') as `CaseType`
	 , IFNULL(`Duvida_Integracoes__c`, 'N/D') as `PrivacyPolicy`
	 , IFNULL(`Erro_Integracoes__c`, 'N/D') as `ErrorIntegrations`
	 , IFNULL(`Assunto_Help_TI__c`, 'N/D') as `SubjectHelpIT`
	 , IFNULL(`Codigo_de_Erro__c`, 'N/D') as `ErrorCode`
	 , IFNULL(`Arvore_concatenada_RC__c`, 'N/D') as `ConcatenatedRCtree`
	 , CAST(IFNULL(Falta_Informacoes__c,FALSE) AS INT64) as `MissingInformations`
	 , IFNULL(`Tema_RC__c`, 'N/D') as `RCTheme`
	 , IFNULL(`Categoria_RC__c`, 'N/D') as `RCCategory`
	 , IFNULL(`Assunto_RC__c`, 'N/D') as `RCSubject`
	 , IFNULL(`Arvore_Concatenada_RT__c`, 'N/D') as `ConcatenatedTreeRT`
	 , IFNULL(`Arvore_Concatenada_Help_Fin__c`, 'N/D') as `ConcatenatedTreeHelpEnd`
	 , IFNULL(`Arvore_Concatenada_Help_Ti__c`, 'N/D') as `ConcatenatedTreeHelpTi`
	 , IFNULL(`Arvore_Concatenada_Help_Produtos__c`, 'N/D') as `ConcatenatedTreeHelpProducts`
	 , CAST(IFNULL(Solucionei_pelo_Portal__c,FALSE) AS INT64) as `SolvedPortal`
	 , IFNULL(`Origem_Erro_S_A__c`, 'N/D') as `OriginErrorSA`
	 , CAST(IFNULL(Classificacao_Errada__c,FALSE) AS INT64) as `WrongClassification`
	 , IFNULL(`Duvidas_POS__c`, 'N/D') as `POSDoubt`
	 , IFNULL(`Duvidas_Tombamento__c`, 'N/D') as `TippingDoubts`
	 , IFNULL(`Tema_Risco_Prevencao__c`, 'N/D') as `RiskPreventionTheme`
	 , IFNULL(`Categoria_Risco_Prevencao__c`, 'N/D') as `RiskPreventionCategory`
	 , IFNULL(`Assunto_Risco_Prevencao__c`, 'N/D') as `RiskPreventionSubject`
	 , IFNULL(`Motivo_Desabilitacao__c`, 'N/D') as `ReasonDisable`
	 , IFNULL(`Qualidade_da_demanda__c`, 'N/D') as `DemandQuality`
	 , IFNULL(`Tema_Juridico__c`, 'N/D') as `LegalTopic`
	 , IFNULL(`Categoria_Juridico__c`, 'N/D') as `LegalCategory`
	 , IFNULL(`D_vidas_Pagamentos__c`, 'N/D') as `PaymentsDoubt`
	 , IFNULL(`Motivo_Nivel_3__c`, 'N/D') as `ReasonLevel3`
	 , IFNULL(`Descricao_Ouvidoria__c`, 'N/D') as `DescriptionOmbudsman`
	 , IFNULL(`Arvore_Concatenada_Ilha_Vip__c`, 'N/D') as `VipIslandConcatenatedTree`
	 , IFNULL(`Nome_da_Lista__c`, 'N/D') as `ListName`
	 , IFNULL(`Conversao_de_contato__c`, 'N/D') as `ContactConversation`
	 , IFNULL(`Motivo_do_contato__c`, 'N/D') as `ContactReason`
	 , IFNULL(`Detalhes_do_motivo__c`, 'N/D') as `ReasonDetail`
	 , IFNULL(`Recorrencia__c`, 'N/D') as `Recurrence`
	 , CAST(IFNULL(Canal_Portal__c,FALSE) AS INT64) as `PortalChannel`
	 , IFNULL(`Status_na_carteira__c`, 'N/D') as `StatusStructure`
	 , IFNULL(`Bandeira__c`, 'N/D') as `Flag`
	 , IFNULL(`Motivo_Cancelamento__c`, 'N/D') as `ReasonCancellation`
	 , IFNULL(`Duvidas_Bandeiras__c`, 'N/D') as `DoubtFlags`
	 , IFNULL(`Portal_Cancelado__c`, 'N/D') as `CanceledPortal`
	 , IFNULL(`Tema_Help_Fin_Elavon__c`, 'N/D') as `HelpFinElavonTopic`
	 , IFNULL(`Categoria_Help_Fin_Elavon__c`, 'N/D') as `HelpFinElavonCategory`
	 , IFNULL(`Assunto_Help_Fin_Elavon__c`, 'N/D') as `HelpEndElavonTopic`
	 , IFNULL(`rea_Causadora__c`, 'N/D') as `RealCause`
	 , IFNULL(`Tipo_de_Tombamento__c`, 'N/D') as `TippingType`
	 , IFNULL(`Particularidades__c`, 'N/D') as `SpecialFeatures`
	 , IFNULL(`Criterio__c`, 'N/D') as `Criterion`
	 , REPLACE(CAST(EXTRACT(date from Data_e_Hora_Ligacao__c at time zone 'America/Sao_Paulo') AS STRING),'-','') as `CallDate`
	 , IFNULL(`Bandeira_RI__c`, 'N/D') as `RIFlag`
FROM dataplatform-prd.sop_salesforce.case
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
