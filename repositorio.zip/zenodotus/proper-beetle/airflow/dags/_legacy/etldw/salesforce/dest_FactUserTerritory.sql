INSERT INTO [dbo].[FactUserTerritory] ([UserTerritoryKey]
, [UserKey]
, [LastModifiedDate]
, [RoleInTerritory2]
, [Territory2Key]
, [LastUpdatedAt])

SELECT A.[UserTerritoryKey]
, A.[UserKey]
, A.[LastModifiedDate]
, A.[RoleInTerritory2]
, A.[Territory2Key]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[FactUserTerritory] B  WHERE A.[UserTerritoryKey] = B.[UserTerritoryKey])
      AND EXISTS (SELECT TOP 1 1 FROM [dbo].[DimUser] E WHERE ISNULL(A.[UserKey],'0') = E.[UserKey])

UPDATE C
SET C.[UserKey] = D.[UserKey] [UserKey]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[RoleInTerritory2] = D.[RoleInTerritory2]
, C.[Territory2Key] = D.[Territory2Key]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[FactUserTerritory] C ON C.[UserTerritoryKey] = D.[UserTerritoryKey]
WHERE EXISTS (SELECT TOP 1 1 FROM [dbo].[DimUser] F WHERE ISNULL(D.[UserKey],'0') = F.[UserKey])
