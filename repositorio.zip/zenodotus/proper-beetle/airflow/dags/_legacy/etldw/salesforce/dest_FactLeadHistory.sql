INSERT INTO [dbo].[FactLeadHistory] ([LeadHistoryKey]
, [Field]
, [CreatedDate]
, [IsDeleted]
, [LeadKey]
, [NewValue]
, [OldValue]
, [LastUpdatedAt])

SELECT A.[LeadHistoryKey]
, A.[Field]
, A.[CreatedDate]
, A.[IsDeleted]
, A.[LeadKey]
, A.[NewValue]
, A.[OldValue]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[FactLeadHistory] B WHERE A.[LeadHistoryKey] = B.[LeadHistoryKey])

UPDATE C
SET C.[Field] = D.[Field]
, C.[CreatedDate] = D.[CreatedDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[LeadKey] = D.[LeadKey]
, C.[NewValue] = D.[NewValue]
, C.[OldValue] = D.[OldValue]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[FactLeadHistory] C ON D.[LeadHistoryKey] = C.[LeadHistoryKey]
