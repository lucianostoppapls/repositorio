INSERT INTO [dbo].[FactOpportunityHistory] ([OpportunityHistoryKey]
, [CloseDate]
, [IsDeleted]
, [OpportunityKey]
, [Probability]
, [StageName]
, [LastUpdatedAt]
, [CreatedDate]
, [SystemModstamp])

SELECT A.[OpportunityHistoryKey]
, A.[CloseDate]
, A.[IsDeleted]
, A.[OpportunityKey]
, A.[Probability]
, A.[StageName]
, '{{ ds_nodash }}'
, A.[CreatedDate]
, A.[SystemModstamp]
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[FactOpportunityHistory] B WHERE A.[OpportunityHistoryKey] = B.[OpportunityHistoryKey])
AND EXISTS (SELECT TOP 1 1 FROM [dbo].[DimOpportunity] E WHERE ISNULL(A.[OpportunityKey],'0') = E.[OpportunityKey])

UPDATE C
SET C.[CloseDate] = D.[CloseDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[OpportunityKey] = D.[OpportunityKey]
, C.[Probability] = D.[Probability]
, C.[StageName] = D.[StageName]
, C.[LastUpdatedAt]= '{{ ds_nodash }}'
, C.[CreatedDate] = D.[CreatedDate]
, C.[SystemModstamp] = D.[SystemModstamp]
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[FactOpportunityHistory] C ON C.[OpportunityHistoryKey] = D.[OpportunityHistoryKey]
WHERE EXISTS (SELECT TOP 1 1 FROM [dbo].[DimOpportunity] F WHERE ISNULL(D.[OpportunityKey],'0') = F.[OpportunityKey])
