SELECT Id as `ContactKey`
, REPLACE(CAST(BirthDate AS STRING),'-','') as `Birthdate`
, IFNULL(Fax, '0') as `Fax`
, IFNULL(Phone, '0') as `Phone`
, IFNULL(Cargo_do_contato__c, 'N/D') as `ContactResponsibility`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING) ,'-','') as `CreatedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, IFNULL(Department, 'N/D') as `Department`
, CAST(IFNULL(HasOptedOutOfEmail,FALSE) AS INT64) as `HasOptedOutOfEmail`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, IFNULL(Email, 'N/D') AS `Email`
FROM dataplatform-prd.sop_salesforce.contact
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
