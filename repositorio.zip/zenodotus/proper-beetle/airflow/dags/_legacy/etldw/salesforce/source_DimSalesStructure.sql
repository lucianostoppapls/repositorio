WITH TB AS (SELECT IFNULL(Canal__c, 'N/D') as `SalesStructureNameLevel1`
, IFNULL(Subcanal__c, 'N/D') as `SalesStructureNameLevel2`
, IFNULL(Grupo_1__c, '-') as `SalesStructureNameLevel3`
, IFNULL(Grupo_2__c, '-') as `SalesStructureNameLevel4`
, IFNULL(Grupo_3__c, '-') as `SalesStructureNameLevel5`
, IFNULL(Grupo_3__c, '-') as `SalesStructureNameLevel6`
FROM dataplatform-prd.sop_salesforce.metas__c
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
UNION DISTINCT
SELECT IFNULL(`Canal_Carteira__c`, 'N/D') as `SalesStructureNameLevel1`
, IFNULL(`SubCanal_Carteira__c`, 'N/D') as `SalesStructureNameLevel2`
, IFNULL(`Grupo1_Carteira__c`, '-') as `SalesStructureNameLevel3`
, IFNULL(`Grupo2_Carteira__c`, '-') as `SalesStructureNameLevel4`
, IFNULL(`Grupo3_Carteira__c`, '-') as `SalesStructureNameLevel5`
, IFNULL(`Grupo3_Carteira__c`, '-') as `SalesStructureNameLevel6`
FROM dataplatform-prd.sop_salesforce.account
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}')
SELECT *
FROM TB
GROUP BY `SalesStructureNameLevel1`
, `SalesStructureNameLevel2`
, `SalesStructureNameLevel3`
, `SalesStructureNameLevel4`
, `SalesStructureNameLevel5`
, `SalesStructureNameLevel6`
