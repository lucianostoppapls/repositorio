SELECT `Id`  as `Territory2TypeKey`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `CreatedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, IFNULL(`Description`,'N/D')  as `Description`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, IFNULL(`MasterLabel`, 'N/D') as `MasterLabel`
FROM dataplatform-prd.sop_salesforce.territory2type
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
