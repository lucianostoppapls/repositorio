SELECT Id as `LeadKey`
, CAST(IFNULL(IsConverted,FALSE) AS INT64) as `IsConverted`
, REPLACE(CAST(ConvertedDate AS STRING),'-','') as `ConvertedDate`
, IFNULL(ConvertedOpportunityId, 'N/D') as `ConvertedOpportunityId`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `CreatedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, IFNULL(LeadSource, 'N/D') as `LeadSource`
, IFNULL(Status, 'N/D') as `Status`
, IFNULL(OwnerId, 'N/D') as `OwnerKey`
, TPV_Estimado__c as `ExpectedTPV`
FROM dataplatform-prd.sop_salesforce.lead
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
