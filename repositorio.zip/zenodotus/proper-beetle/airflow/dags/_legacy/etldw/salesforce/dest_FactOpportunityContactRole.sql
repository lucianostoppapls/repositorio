INSERT INTO [dbo].[FactOpportunityContactRole] ([OpportunityContactRoleKey]
, [OpportunityKey]
, [ContactKey]
, [OpportunityContactRole]
, [LastModifiedDate]
, [IsDeleted]
, [LastUpdatedAt])

SELECT A.[OpportunityContactRoleKey]
, A.[OpportunityKey]
, A.[ContactKey]
, A.[OpportunityContactRole]
, A.[LastModifiedDate]
, A.[IsDeleted]
, '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} A
WHERE NOT EXISTS (SELECT TOP 1 1 FROM [dbo].[FactOpportunityContactRole] B WHERE A.[OpportunityContactRoleKey] = B.[OpportunityContactRoleKey])
AND EXISTS (SELECT TOP 1 1 FROM [dbo].[DimOpportunity] E WHERE ISNULL(A.[OpportunityKey],'0') = E.[OpportunityKey])
AND EXISTS (SELECT TOP 1 1 FROM [dbo].[DimContact] G WHERE ISNULL(A.[ContactKey],'0') = G.[ContactKey])

UPDATE C
SET C.[OpportunityKey] = D.[OpportunityKey]
, C.[ContactKey] = D.[ContactKey]
, C.[OpportunityContactRole] = D.[OpportunityContactRole]
, C.[LastModifiedDate] = D.[LastModifiedDate]
, C.[IsDeleted] = D.[IsDeleted]
, C.[LastUpdatedAt] = '{{ ds_nodash }}'
FROM {{ ti.xcom_pull('create_table') }} D
INNER JOIN [dbo].[FactOpportunityContactRole] C ON C.[OpportunityContactRoleKey] = D.[OpportunityContactRoleKey]
WHERE EXISTS (SELECT TOP 1 1 FROM [dbo].[DimOpportunity] F WHERE ISNULL(D.[OpportunityKey],'0') = F.[OpportunityKey])
AND EXISTS (SELECT TOP 1 1 FROM [dbo].[DimContact] H WHERE ISNULL(A.[ContactKey],'0') = H.[ContactKey])
