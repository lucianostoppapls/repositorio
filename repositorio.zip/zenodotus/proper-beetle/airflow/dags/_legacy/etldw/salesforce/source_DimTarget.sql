SELECT DISTINCT Id as `TargetKey`
, IFNULL(OwnerId,'0') as `OwnerKey`
, CONCAT(SUBSTR(REPLACE(CAST(DT_REF__c AS STRING),'-',''), 1, 6), '01') as `ReferenceDate`
, IFNULL(Credenciamentos_Meta__c,0) as `AccreditationsTarget`
, IFNULL(Base_Ativa_Meta__c,0) as `ActiveBaseTarget`
, IFNULL(Receita_MDR_Meta__c,0) as `DIATarget`
, IFNULL(TPV_Total_Meta__c,0) as `TotalTPVTarget`
, IFNULL(Margem_Meta__c,0) as `MarginTarget`
, IFNULL(Receita_RAV_Meta__c,0) as `RAVRevenueTarget`
, IFNULL(TPV_Credito_Meta__c,0) as `TPVCreditTarget`
, IFNULL(Outras_Receitas_Meta__c,0) as `OtherRevenuesTarget`
, IFNULL(Net_MDR_Meta__c,0) as `NetDIATarget`
, IFNULL(Receita_MDR_M0_Meta__c,0) as `DIAM0Target`
, IFNULL(TPV_M0_Meta__c,0) as `TPVM0Target`
, IFNULL(Reativados_Meta__c,0) as `ReactivatedTarget`
, IFNULL(Clientes_Churn_Meta__c,0) as `ChurnClientsTarget`
, IFNULL(TPV_Churn_Meta__c,0) as `TPVChurnTarget`
, IFNULL(TPV_Base_Meta__c,0) as `TPVBaseTarget`
, IFNULL(DX_Meta__c,0) as `DXTarget`
, IFNULL(Base_Ativa_M_1_Meta__c,0) as `ActiveBaseM1Target`
, IFNULL(Base_Ativa_Cadeia_Meta__c,0) as `BaseActiveChainTarget`
, IFNULL(Credenciamentos_Cadeia_Meta__c,0) as `AccreditationsChainTarget`
, IFNULL(Funil_Mineracao_Meta__c,0) as `MiningFunnelTarget`
, IFNULL(Funil_Negociacao_Meta__c,0) as `NegotiationFunnelTarget`
, IFNULL(Funil_Qualificacao_Meta__c,0) as `QualificationFunnelTarget`
, IFNULL(Receita_MDR_Hunter_Meta__c,0) as `DIAHunterTarget`
, IFNULL(TPV_Antecipado_Meta__c,0) as `AtecipatedTPVTarget`
, IFNULL(TPV_Hunter_Meta__c,0) as `HunterTPVTarget`
, IFNULL(TPV_Total_M_1_Meta__c,0) as `TotalTPVM1Target`
, IFNULL(Headcount_Meta__c,0) as `HeadcountTarget`
, IFNULL(Receita_Total_Meta__c,0) as `TotalRevenueTarget`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, IFNULL(Ativacao_Meta__c,0) as `ActivationTarget`
, IFNULL(Credenciamentos_Ativos_Meta__c,0) as `ActiveAccreditationsTarget`
, IFNULL(DX_Auto_Meta__c,0) as `AutoDXTarget`
, IFNULL(DX_Spot_Meta__c,0) as `SpotDXTarget`
, IFNULL(Funil_Onboarding_Meta__c,0) as `OnboardingFunnelTarget`
, IFNULL(Funil_Qualificado_Meta__c,0) as `QualifiedFunnelTarget`
, IFNULL(HC_M0_Meta__c,0) as `HCM0Target`
, IFNULL(HC_M1_Meta__c,0) as `HCM1Target`
, IFNULL(HC_M2_Meta__c,0) as `HCM2Target`
, IFNULL(Receita_Antifraude_Pagarme_Meta__c,0) as `PagarmeAntifraudRevenueTarget`
, IFNULL(Receita_Boleto_Pagarme_Meta__c,0) as `PagarmeBoletoRevenueTarget`
, IFNULL(Receita_Boleto_Stone_Meta__c,0) as `StoneBoletoRevenueTarget`
, IFNULL(Receita_Gateway_Mundipagg_Meta__c,0) as `MundipaggGatewayRevenueTarget`
, IFNULL(Receita_Gateway_Pagarme_Meta__c,0) as `PagarmeGatewayRevenueTarget`
, IFNULL(Receita_RAV_Auto_Meta__c,0) as `RAVAutoTarget`
, IFNULL(Receita_RAV_Hunter_Meta__c,0) as `RAVHunterTarget`
, IFNULL(Receita_RAV_Spot_Meta__c,0) as `RAVSpotTarget`
, IFNULL(TPV_Antecipado_Auto_Meta__c,0) as `GrossValueAutoTarget`
, IFNULL(TPV_Antecipado_Spot_Meta__c,0) as `GrossValueSpotTarget`
, IFNULL(`Canal__c`,'N/D') as `Canal__c`
, IFNULL(`Subcanal__c`,'N/D') as `Subcanal__c`
, IFNULL(`Grupo_1__c`, '-') as `Grupo_1__c`
, IFNULL(`Grupo_2__c`, '-') as `Grupo_2__c`
, IFNULL(`Grupo_3__c`, '-') as `Grupo_3__c`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, IFNULL(tpv_cluster_meta__c,0) as `TPVClusterTarget`
, IFNULL(HC_M9_Meta__c,0) as `HCM9Target`
, IFNULL(Receita_Mensalidade_Meta__c,0) as `RecurrentRevenueTarget`
, IFNULL(Migracao_Meta_M0__c,0) as `MigrationM0Target`
, IFNULL(HC_M3_M5_Meta__c,0) as `HCM3toM5Target`
, IFNULL(HC_M6_M8_Meta__c,0) as `HCM6toM8Target`
, 0 as `MigrationM1Target`
, IFNULL(Clientes_RAV_Automatico_Meta__c,0) as `RAVAutoAccreditationsTarget`
, IFNULL(Demais_Receitas_Meta__c,0) as `MinorRevenueTarget`
, IFNULL(Churn_Receita_Meta__c,0) as `ChurnRevenueTarget`
, IFNULL(Receita_Total_M_1_Meta__c,0) as `TotalRevenueM1Target`
, IFNULL(TPV_Total_Pagarme_Meta__c,0) as `TotalTPVPagarme`
, IFNULL(Receita_Nova_Meta__c,0) as `RevenueNewTarget`
, IFNULL(TPV_Digital_Meta__c,0) as `DigitalTPVTarget`
FROM dataplatform-prd.sop_salesforce.metas__c
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
AND `Grupo_3__c` <> 'NULL'
