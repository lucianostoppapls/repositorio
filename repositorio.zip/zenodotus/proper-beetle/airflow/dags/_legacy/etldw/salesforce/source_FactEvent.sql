SELECT Id as `EventKey`
, IFNULL(AccountId,'0') as `AccountKey`
, CAST(IFNULL(IsAllDayEvent,FALSE) AS INT64) as `IsAllDayEvent`
, CAST(IFNULL(IsArchived,FALSE) AS INT64) as `IsArchived`
, IFNULL(OwnerId, 'N/D') as `OwnerKey`
, IFNULL(Contato_com_o_RC__c, 'N/D') as `ContactRC`
, CAST(IFNULL(IsRecurrence,FALSE) AS INT64) as `IsRecurrence`
, REPLACE(CAST(EXTRACT(date from CreatedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `CreatedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
, REPLACE(CAST(ActivityDate AS STRING),'-','') as `ActivityDate`
, IFNULL(DurationInMinutes,0) as `DurationInMinutes`
, IFNULL(GroupEventType, 'N/D') as `GroupEventType`
, CAST(IFNULL(IsChild,FALSE) AS INT64) as `IsChild`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, IFNULL(`Location`, 'N/D') as `Location`
, IFNULL(Li__c, 'N/D') as `Li`
, IFNULL(Objetivo__c, 'N/D') as `Objective`
, IFNULL(RecurrenceActivityId, 'N/D') as `RecurrenceActivityKey`
, IFNULL(RecurrenceInstance, 'N/D') as `RecurrenceInstance`
, IFNULL(RecurrenceInterval,0) as `RecurrenceInterval`
, IFNULL(RecurrenceType, 'N/D') as `RecurrenceType`
, IFNULL(Resultado_da_Visita__c, 'N/D') as `VisitResult`
, IFNULL(TPV_M_1__c,0) as `TPVM1`
FROM dataplatform-prd.sop_salesforce.event
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
