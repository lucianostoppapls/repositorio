SELECT IFNULL(Id, 'N/D') as `UserRoleKey`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, IFNULL(Name, 'N/D') as `Name`
, IFNULL(ParentRoleId, 'N/D') as `ParentRoleKey`
FROM dataplatform-prd.sop_salesforce.userrole
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
