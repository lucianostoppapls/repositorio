SELECT Id as `OpportunityContactRoleKey`
, IFNULL(OpportunityId, '0') as `OpportunityKey`
, ContactId as `ContactKey`
, IFNULL(ROLE, 'N/D') as `OpportunityContactRole`
, REPLACE(CAST(EXTRACT(date from LastModifiedDate at time zone 'America/Sao_Paulo') AS STRING),'-','') as `LastModifiedDate`
, CAST(IFNULL(IsDeleted,FALSE) AS INT64) as `IsDeleted`
FROM dataplatform-prd.sop_salesforce.opportunitycontactrole
WHERE EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') >= '{{ ds }}'
AND EXTRACT(datetime from SystemModstamp at time zone 'America/Sao_Paulo') < '{{ next_ds }}'
