use stonecoods

select
	5 as [companykey]
	, a.[customerkey]
	, case
		when [creditcardbrand] = 'aura' then 15
		when [creditcardbrand] = 'credz' then 13
		when [creditcardbrand] = 'visa' then 1
		when [creditcardbrand] = 'vr' then 6
		when [creditcardbrand] = 'sodexo' then 5
		when [creditcardbrand] = 'mastercard' then 2
		when [creditcardbrand] = 'paqueta' then 10
		when [creditcardbrand] = 'pernambucanas' then 14
		when [creditcardbrand] = 'discover' then 12
		when [creditcardbrand] = 'elo' then 4
		when [creditcardbrand] = 'amex' then 11
		when [creditcardbrand] = 'diners' then 8
		when [creditcardbrand] = 'havan' then 16
		when [creditcardbrand] = 'jcb' then 17
		when [creditcardbrand] = 'hipercard' then 3
		else 9
	end [flagkey]
	, case
		when transactiontype = 'boleto' then 4
		when transactiontype = 'creditcard' then 2
		else 9
	end [productkey]
	, case
		when installmentcount = '7 a 12 parcelas' then 4
		when installmentcount = 'à vista' then 2
		when installmentcount = '2 a 6 parcelas' then 3
		when installmentcount = 'acima de 12 parcelas' then 5
		else 9
	end [installmentkey]
	, sum(capturedtransactionscount) [transactions]
	, sum(capturedtpv) [tpv]
	, 0 as [mdr]
	, 0 as [interchange]
	, 0 as [assessment]
	, 0 as [dia]
	, case
		when acquirer = 'itau' then 26
		when acquirer = 'santander' then 28
		when acquirer = 'bradesco' then 4
		when acquirer = 'redecard' then 27
		when acquirer = 'getnet' then 12
		when acquirer = 'bin' then 6
		when acquirer = 'havan' then 14
		when acquirer = 'stone' then 1
		when acquirer = 'conductor' then 8
		when acquirer = 'sodexo' then 20
		when acquirer = 'credsystem' then 22
		when acquirer = 'vr' then 21
		when acquirer = 'simulator' then 19
		when acquirer = 'aura' then 5
		when acquirer = 'banco do brasil' then 23
		when acquirer = 'elavon' then 11
		when acquirer = 'citibank' then 24
		when acquirer = 'global payments' then 13
		when acquirer = 'hsbc' then 25
		when acquirer = 'cielo' then 2
		when acquirer = 'pagarme' then 17
		else 9
	end [acquirerkey]
	, 2 as [typekey]
	, ck.[closer_id]
	, replace(a.[captureddate], '-', '') as [transactiondate]
	, null as [nm_bandeira]
	, null as [id_registro]
	, null as [nm_empresa]
	, null as [type]
	, null as [stonecode]
from
	[mundi].[tbmundif_tpv] a
left join (
	select
		mc.[customerkey]
		, isnull(mc.[closername], 'mundi') as [closer_name]
		, mc2.[closer_id]
	from
		[mundi].[tbmundid_client] mc
	left join (
		select distinct
			concat('mundi_',row_number() over(order by [closername])) as [closer_id]
			, isnull([closername], 'mundi') as [closer_name]
		from
			[mundi].[tbmundid_client] mc 
		group by
			[closername]
	) mc2 on isnull(mc.[closername], 'mundi') = mc2.[closer_name]
) ck on ck.[customerkey] = a.[customerkey]
where
	eomonth('{{ ds }}') = eomonth(a.[captureddate])
	and cast(a.[captureddate] as date) < '{{ next_ds }}'
group by
	a.[customerkey]
	, case
		when [creditcardbrand] = 'aura' then 15
		when [creditcardbrand] = 'credz' then 13
		when [creditcardbrand] = 'visa' then 1
		when [creditcardbrand] = 'vr' then 6
		when [creditcardbrand] = 'sodexo' then 5
		when [creditcardbrand] = 'mastercard' then 2
		when [creditcardbrand] = 'paqueta' then 10
		when [creditcardbrand] = 'pernambucanas' then 14
		when [creditcardbrand] = 'discover' then 12
		when [creditcardbrand] = 'elo' then 4
		when [creditcardbrand] = 'amex' then 11
		when [creditcardbrand] = 'diners' then 8
		when [creditcardbrand] = 'havan' then 16
		when [creditcardbrand] = 'jcb' then 17
		when [creditcardbrand] = 'hipercard' then 3
		else 9
	end
	, case
		when transactiontype = 'boleto' then 4
		when transactiontype = 'creditcard' then 2
		else 9
	end
	, case
		when installmentcount = '7 a 12 parcelas' then 4
		when installmentcount = 'à vista' then 2
		when installmentcount = '2 a 6 parcelas' then 3
		when installmentcount = 'acima de 12 parcelas' then 5
		else 9
	end
	, case
		when acquirer = 'itau' then 26
		when acquirer = 'santander' then 28
		when acquirer = 'bradesco' then 4
		when acquirer = 'redecard' then 27
		when acquirer = 'getnet' then 12
		when acquirer = 'bin' then 6
		when acquirer = 'havan' then 14
		when acquirer = 'stone' then 1
		when acquirer = 'conductor' then 8
		when acquirer = 'sodexo' then 20
		when acquirer = 'credsystem' then 22
		when acquirer = 'vr' then 21
		when acquirer = 'simulator' then 19
		when acquirer = 'aura' then 5
		when acquirer = 'banco do brasil' then 23
		when acquirer = 'elavon' then 11
		when acquirer = 'citibank' then 24
		when acquirer = 'global payments' then 13
		when acquirer = 'hsbc' then 25
		when acquirer = 'cielo' then 2
		when acquirer = 'pagarme' then 17
		else 9
	end
	, ck.[closer_id]
	, replace(a.[captureddate], '-', '')
