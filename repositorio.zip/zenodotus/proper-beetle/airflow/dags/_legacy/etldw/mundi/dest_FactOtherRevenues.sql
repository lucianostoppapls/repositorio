use stonedwv0

delete from [stonedwv0].[dbo].[factotherrevenues]
where companykey in (5) and eomonth(convert(date,convert(char(8),[datekey]))) = eomonth('{{ ds }}')

insert into [stonedwv0].[dbo].[factotherrevenues] (
    [companykey]
    , [datekey]
    , [vendorkey]
    , [revenue]
    , [revenuetypekey]
    , [quantity]
    , [affiliationkey]
)

select
    5
    , a.[revenuedate]
    , c.[vendorkey]
    , sum([grossrevenue])
    , isnull(r.[revenuetypekey], 9)
    , 1
    , b.[affiliationkey]
from
    {{ ti.xcom_pull('create_table') }} a
left join
    [stonedwv0].[dbo].[dimrevenuetype] r on a.[revenueservicetype] = r.[revenuetypename]
inner join
    [dbo].[dimaffiliation] b on b.[clientalternatekey] = a.[customerkey]
inner join (
    select
        [vendoralternatekeymundi]
        , max([vendorkey]) as [vendorkey]
    from
        [dbo].[dimvendor]
    where
        [vendoralternatekeymundi] is not null
    group by
        [vendoralternatekeymundi]
) c on isnull(a.[closer_id],'mundi_1') = isnull(c.[vendoralternatekeymundi],'mundi_001')
group by
    a.[revenuedate]
    , c.[vendorkey]
    , isnull(r.[revenuetypekey], 9)
    , b.[affiliationkey]

truncate table {{ ti.xcom_pull('create_table') }}
