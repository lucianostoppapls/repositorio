use stonedwv0

delete
from
    [stonedwv0].[dbo].[facttpv]
where
    companykey in (5)
    and eomonth(convert(date,convert(char(8),[transactiondate]))) = eomonth('{{ ds }}')

insert into [dbo].[facttpv] (
    [companykey]
    , [flagkey]
    , [productkey]
    , [installmentkey]
    , [vendorkey]
    , [transactiondate]
    , [transactions]
    , [tpv]
    , [mdr]
    , [interchange]
    , [assessment]
    , [dia]
    , [acquirerkey]
    , [typekey]
    , [affiliationkey]
)

select
    a.[companykey]
    , a.[flagkey]
    , a.[productkey]
    , a.[installmentkey]
    , isnull(c.[vendorkey], 1)
    , a.[transactiondate]
    , a.[transactions]
    , a.[tpv]
    , a.[mdr]
    , a.[interchange]
    , a.[assessment]
    , a.[dia]
    , a.[acquirerkey]
    , a.[typekey]
    , isnull(b.[affiliationkey], 1)
from
    {{ ti.xcom_pull('create_table') }} a
left join
    [dbo].[dimaffiliation] b on b.[clientalternatekey] = a.[customerkey]
left join (
    select
        vendoralternatekeymundi
        , max(vendorkey) as [vendorkey]
    from
        [dbo].[dimvendor]
    where
        [vendoralternatekeymundi] is not null
    group by
        [vendoralternatekeymundi]
) c on isnull(a.[closer_id],'mundi_1') = isnull(c.[vendoralternatekeymundi],'mundi_001')

truncate table
    {{ ti.xcom_pull('create_table') }}
