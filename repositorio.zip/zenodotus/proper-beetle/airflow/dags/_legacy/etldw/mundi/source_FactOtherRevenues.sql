use stonecoods

select
    replace(a.[revenuedate], '-', '') as [revenuedate]
    , vendor.[closer_id] as [closer_id]
    , sum(a.[grossrevenue]) as [grossrevenue]
    , a.[revenueservicetype] as [revenueservicetype]
    , a.[customerkey]
    , null [date]
    , null [company_id]
    , null [revenue]
    , null [type]
    , null [unitamount]
    , null [vl_mdr]
    , null [vl_ic]
    , null [nr_transacoes]
    , null [dt_transacao]
    , null [stonecode]
    , null [nm_produto]
    , null [nm_empresa]
    , null [id_registro]
from
    [mundi].[tbmundif_revenue] a
left join (
    select mc.[customerkey]
    , isnull(mc.[closername], 'mundi') as [closer_name]
    , mc2.[closer_id]
    from
        [mundi].[tbmundid_client] mc
    left join (
        select distinct
            concat('mundi_',row_number() over(order by [closername])) as [closer_id]
            , isnull([closername], 'mundi') as [closer_name]
        from
            [mundi].[tbmundid_client] mc 
        group by
            [closername]
    ) mc2 on isnull(mc.[closername], 'mundi') = mc2.[closer_name]
) vendor on vendor.[customerkey] = a.[customerkey]
where
    eomonth(a.[revenuedate]) = eomonth('{{ ds }}')
    and cast([revenuedate] as date) < '{{ next_ds }}'
group by
    replace(a.[revenuedate], '-', '')
    , vendor.[closer_id]
    , a.[revenueservicetype]
    , a.[customerkey]
