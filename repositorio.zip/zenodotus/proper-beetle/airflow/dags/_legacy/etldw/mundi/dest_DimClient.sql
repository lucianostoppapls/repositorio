use stonedwv0

if object_id('tempdb..#dimclient_mundi_client_date') is not null
	drop table #dimclient_mundi_client_date

select a.[createdate]
	, a.[ds_canal]
	, a.[nm_subcanal]
	, a.[ds_grupo1]
	, a.[ds_grupo2]
	, a.[ds_grupo3]
	, a.[ds_grupo4]
	, a.[clientcnpjorcpf]
	, b.[clientalternatekeymundi]
into #dimclient_mundi_client_date
from (select min(createdate) [createdate]
		, [ds_canal]
		, [nm_subcanal]
		, [ds_grupo1]
		, [ds_grupo2]
		, [ds_grupo3]
		, [ds_grupo4]
		, [clientcnpjorcpf]
	from (select * from {{ ti.xcom_pull('create_table') }} where companykey = 5) c
	group by [ds_canal]
		, [nm_subcanal]
		, [ds_grupo1]
		, [ds_grupo2]
		, [ds_grupo3]
		, [ds_grupo4]
		, [clientcnpjorcpf]) a
	join (select [createdate]
		, min(clientalternatekeymundi) [clientalternatekeymundi]
		, [ds_canal]
		, [nm_subcanal]
		, [ds_grupo1]
		, [ds_grupo2]
		, [ds_grupo3]
		, [ds_grupo4]
		, [clientcnpjorcpf]
		from (select * from {{ ti.xcom_pull('create_table') }} where companykey = 5) d
		group by [createdate]
			, [ds_canal]
			, [nm_subcanal]
			, [ds_grupo1]
			, [ds_grupo2]
			, [ds_grupo3]
			, [ds_grupo4]
			, [clientcnpjorcpf]) b
			ON a.clientcnpjorcpf = b.clientcnpjorcpf
				AND a.ds_canal = B.ds_canal
				AND a.nm_subcanal = b.nm_subcanal
				AND a.ds_grupo1 = b.ds_grupo1
				AND a.ds_grupo2 = b.ds_grupo2
				AND a.ds_grupo3 = b.ds_grupo3
				AND a.ds_grupo4 = b.ds_grupo4
				AND a.createdate = b.createdate
group by a.[createdate]
	, a.[ds_canal]
	, a.[nm_subcanal]
	, a.[ds_grupo1]
	, a.[ds_grupo2]
	, a.[ds_grupo3]
	, a.[ds_grupo4]
	, a.[clientcnpjorcpf]
	, b.[clientalternatekeymundi]


update [dbo].[dimclient]
set clientstatuskey = 1
where companykey = 5

if object_id('tempdb..#dim_client_mundi_alteracoesdimclient') is not null
	drop table #dim_client_mundi_alteracoesdimclient;

select distinct
	a.[clientkey]
	, b.[clientalternatekeymundi]
	, c.[salesstructurekey]
	, isnull(t.[geographykey],1) geographykey
	, b.[clientlegalname]
	, b.[createdate]
	, b.[clientcnpjorcpf]
	, isnull(v.[vendorkey], 1) vendorkey
	, a.[clientstatuskey]
	, case
		when len(b.[clientcnpjorcpf]) <= 11 then 'PF'
		when isnumeric(right(b.[clientlegalname], 11)) = 1 then 'MEI'
		else 'PJ'
	end AS [clientcnpjorcpfclassification]
into #dim_client_mundi_alteracoesdimclient
	from [dbo].[dimclient]   a
	inner join (select * from {{ ti.xcom_pull('create_table') }} where companykey = 5) b on a.[clientalternatekeymundi] = b.[clientalternatekeymundi]
	inner join [dbo].[dimsalesstructure] c on b.[ds_canal] = c.[salesstructurenamelevel1]
		and b.[nm_subcanal] = c.[salesstructurenamelevel2]
		and b.[ds_grupo1] = c.[salesstructurenamelevel3]
		and b.[ds_grupo2] = c.[salesstructurenamelevel4]
		and b.[ds_grupo3] = c.[salesstructurenamelevel5]
		and b.[ds_grupo4] = c.[salesstructurenamelevel6]
	left join (select vendoralternatekeymundi, max(vendorkey) as vendorkey
		from dbo.[dimvendor]
		where vendoralternatekeymundi is not null
		group by vendoralternatekeymundi) v on b.[closer_id] = isnull(v.[vendoralternatekeymundi],'mundi_1')
	left join [dbo].[dimgeography] t on t.[geographykey] = isnull([stonedwv0].[dbo].fc_regexp_003(b.[zipcode],'^0-9'),1)
where (c.[salesstructurekey] <> a.[salesstructurekey]
	or b.[clientlegalname] <> a.[clientname]
	or isnull(t.[geographykey],1) <> isnull(a.[geographykey],1)
	or b.[clientlegalname] <> a.[clientlegalname]
	or b.[createdate] <> a.[createdate]
	or b.[clientcnpjorcpf]<> a.[clientcnpjorcpf]
	or v.[vendorkey] <> a.[vendorkey]
	or case
       	when len(b.[clientcnpjorcpf]) <= 11 then 'PF'
		when isnumeric(right(b.[clientlegalname], 11)) = 1 then 'MEI'
		else 'PJ'
	end <> a.[clientcnpjorcpfclassification])
	or a.[clientstatuskey] <> 1

update a
set
	a.[salesstructurekey] = b.[salesstructurekey]
	, a.[clientname] = b.[clientlegalname]
	, a.[geographykey] = b.[geographykey]
	, a.[clientlegalname]	= b.[clientlegalname]
	, a.[createdate] = b.[createdate]
	, a.[clientcnpjorcpf] = b.[clientcnpjorcpf]
	, a.[vendorkey] = b.[vendorkey]
	, a.[clientstatuskey] = 1
	, a.[clientcnpjorcpfclassification] = b.[clientcnpjorcpfclassification]
from [dbo].[dimclient]   a
inner join #dim_client_mundi_alteracoesdimclient b on a.clientkey = b.clientkey

-- update clientes com data menor

update a
set clientstatuskey = 7
from [dbo].[dimclient] a
join (select [clientcnpjorcpf], [salesstructurekey], [clientkey]
	from [dbo].[dimclient] a
	where not exists (select top 1 1
		from #dimclient_mundi_client_date b
		where a.[clientalternatekeymundi] = b.[clientalternatekeymundi])
	group by clientcnpjorcpf, salesstructurekey, clientkey) b
on a.clientkey = b.clientkey
where companykey = 5

-- update conceito cnpj/canal

declare @cont int = (select sum(qtd)
	from (select count(*) as [qtd], [clientcnpjorcpf], [salesstructurekey], max(clientkey) as [clientkey]
		from [dbo].[dimclient]
		where 
			[companykey] in (5)
			and ([clientstatuskey] <> 7 or [clientstatuskey] is null)
		group by [clientcnpjorcpf], [salesstructurekey]
		having count(*) > 1) a )

while @cont > 0

begin

update a
set clientstatuskey = 7
from [dbo].[dimclient] a
	join (select count(*) as [qtd], [clientcnpjorcpf], [salesstructurekey], max(clientkey) as [clientkey]
		from [dbo].[dimclient]
		where [companykey] in (5)
			and ([clientstatuskey] <> 7 or [clientstatuskey] is null)
		group by [clientcnpjorcpf], [salesstructurekey]
		having count(*) > 1) b on a.clientkey = b.clientkey

set @cont = (select sum(qtd)
	from (select count(*) as [qtd], [clientcnpjorcpf], [salesstructurekey], max(clientkey) as [clientkey]
		from [dbo].[dimclient]
		where [companykey] in (5)
			and ([clientstatuskey] <> 7 or [clientstatuskey] is null)
		group by [clientcnpjorcpf], [salesstructurekey]
		having count(*) > 1) a )

end



insert into [stonedwv0].[dbo].[dimclient] ([clientcnpjorcpf]
	, [clientname]
	, [geographykey]
	, [clientparentkey]
	, [clientlegalname]
	, [clientalternatekeymundi]
	, [salesstructurekey]
	, [createdate]
	, [migrationdate]
	, [migrated]
	, [mcckey]
	, [companykey]
	, [chainname]
	, [clientstatuskey]
	, [vendorkey]
	, [originregisterkey]
	, [clientcnpjorcpfclassification])

select a.[clientcnpjorcpf]
	, a.[clientlegalname]
	, isnull(b.[geographykey], 1)
	, null
	, a.[clientlegalname]
	, a.[clientalternatekeymundi]
	, c.[salesstructurekey]
	, a.[createdate]
	, a.[createdate]
	, 0
	, null
	, a.[companykey]
	, null
	, 1
	, isnull(v.[vendorkey], 1)
	, 19 as [originregisterkey]
	, case
		when len(a.[clientcnpjorcpf]) <= 11 then 'PF'
		when isnumeric(right(a.[clientlegalname], 11)) = 1 then 'MEI'
		else 'PJ'
	end AS [clientcnpjorcpfclassification]
from #dimclient_mundi_client_date cc
inner join (select * from {{ ti.xcom_pull('create_table') }} where companykey = 5) a on cc.[clientalternatekeymundi] = a.[clientalternatekeymundi]
left join [dbo].[dimgeography] b on b.[geographykey] = isnull([stonedwv0].[dbo].fc_regexp_003(a.[zipcode], '^0-9'), 1)
inner join [dbo].[dimsalesstructure] c on
	a.[ds_canal] = c.[salesstructurenamelevel1]
	and a.[nm_subcanal] = c.[salesstructurenamelevel2]
	and a.[ds_grupo1] = c.[salesstructurenamelevel3]
	and a.[ds_grupo2] = c.[salesstructurenamelevel4]
	and a.[ds_grupo3] = c.[salesstructurenamelevel5]
	and a.[ds_grupo4] = c.[salesstructurenamelevel6]
left join (select [vendoralternatekeymundi], max([vendorkey]) as [vendorkey]
	from [dbo].[dimvendor]
	where [vendoralternatekeymundi] is not null
	group by [vendoralternatekeymundi]) v on a.[closer_id] = isnull(v.[vendoralternatekeymundi], 'mundi_1')
where not exists (select top 1 1 from [stonedwv0].[dbo].[dimclient] d 
	where a.[clientcnpjorcpf] = d.[clientcnpjorcpf]
		and a.[companykey] = d.[companykey]
		and c.[salesstructurekey] = d.[salesstructurekey]
		and ([clientstatuskey] is null or [clientstatuskey] <> 7))
