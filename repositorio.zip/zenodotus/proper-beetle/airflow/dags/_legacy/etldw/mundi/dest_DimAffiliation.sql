use stonedwv0

if object_id('tempdb..#alteracoesdimaffiliation') is not null
	drop table #alteracoesdimaffiliation;

select b.[clientalternatekeymundi]
	, c.[salesstructurekey]
	, isnull(t.[geographykey], 1) [geographykey]
	, replace(ltrim(rtrim(replace(replace(b.[clientlegalname], char(9), ''), char(32), ''))), '"', '') [clientlegalname]
	, b.[createdate]
	, b.[clientcnpjorcpf]
	, isnull(max(v.[vendorkey]), 1) vendorkey
	, i.[clientkey]
into #alteracoesdimaffiliation
from [dbo].[dimaffiliation] a
inner join (select * from {{ ti.xcom_pull('create_table') }}  where [companykey] = 5) b on a.[clientalternatekey] = b.[clientalternatekeymundi]
inner join [dbo].[dimsalesstructure] c on b.[ds_canal] = c.[salesstructurenamelevel1]
	and b.[nm_subcanal] = c.[salesstructurenamelevel2]
	and b.[ds_grupo1] = c.[salesstructurenamelevel3]
	and b.[ds_grupo2] = c.[salesstructurenamelevel4]
	and b.[ds_grupo3] = c.[salesstructurenamelevel5]
	and b.[ds_grupo4] = c.[salesstructurenamelevel6]
left join [dbo].[dimgeography] t on t.[geographykey] = isnull([stonedwv0].[dbo].fc_regexp_003(b.[zipcode],'^0-9'), 1)
inner join [stonedwv0].[dbo].[dimvendor] v on isnull(b.[closer_id], 'mundi') = (isnull(v.[vendoralternatekeymundi],'mundi_001'))
inner join (select distinct [clientcnpjorcpf]
		, [salesstructurekey]
		, [companykey]
		, [clientkey]
	from [dbo].[dimclient]
	where ([clientstatuskey] <> 7 or [clientstatuskey] is null) and [companykey] in (5)) i on b.[clientcnpjorcpf]  = i.[clientcnpjorcpf]
		and c.[salesstructurekey] = i.[salesstructurekey]
		and a.[companykey] = i.[companykey]
where a.[salesstructurekey] <> c.[salesstructurekey]
	or replace(ltrim(rtrim(replace(replace(b.[clientlegalname], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(a.[clientname], char(9), ''), char(32), ''))), '"', '')
	or isnull(t.[geographykey],1) <> isnull(a.[geographykey],1)
	or replace(ltrim(rtrim(replace(replace(b.[clientlegalname], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
	or b.[createdate] <> a.[createdate]
	or b.[clientcnpjorcpf] <> a.[clientcnpjorcpf]
	or v.[vendorkey] <> a.[vendorkey]
	or i.[clientkey] <> a.[clientkey]
group by b.[clientalternatekeymundi]
	, c.[salesstructurekey]
	, isnull(t.[geographykey], 1)
	, replace(ltrim(rtrim(replace(replace(b.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
	, replace(ltrim(rtrim(replace(replace(b.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
	, b.[createdate]
	, b.[clientcnpjorcpf]
	, i.[clientkey]


-- update dimaffiliation

update a
set a.[salesstructurekey] = b.[salesstructurekey]
	, a.[clientname] = b.[clientlegalname]
	, a.[geographykey] = b.[geographykey]
	, a.[clientlegalname]	= b.[clientlegalname]
	, a.[createdate] = b.[createdate]
	, a.[clientcnpjorcpf] = b.[clientcnpjorcpf]
	, a.[vendorkey] = b.[vendorkey]
	, a.[clientkey] = b.[clientkey]
from [dbo].[dimaffiliation] a
join #alteracoesdimaffiliation b on a.[clientalternatekey] = b.[clientalternatekeymundi]

-- insert dimaffiliation

insert into [stonedwv0].[dbo].[dimaffiliation] ([clientcnpjorcpf]
	, [clientname]
	, [geographykey]
	, [clientlegalname]
	, [clientalternatekey]
	, [salesstructurekey]
	, [createdate]
	, [migrationdate]
	, [migrated]
	, [mcckey]
	, [companykey]
	, [chainname]
	, [clientstatuskey]
	, [vendorkey]
	, [clientkey]
	, [originregisterkey])

select a.[clientcnpjorcpf]
	, replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
	, isnull(b.[geographykey], 1)
	, replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
	, a.[clientalternatekeymundi]
	, c.[salesstructurekey]
	, a.[createdate]
	, a.[createdate]
	, 0
	, null
	, 5
	, null
	, 1
	, min(v.[vendorkey])
	, min(e.[clientkey])
	, 19
from (select * from {{ ti.xcom_pull('create_table') }}  where [companykey] = 5) a
left join [dbo].[dimgeography] b on b.[geographykey] = isnull([stonedwv0].[dbo].fc_regexp_003(a.[zipcode],'^0-9'), 1)
inner join [dbo].[dimsalesstructure] c on a.[ds_canal] = c.[salesstructurenamelevel1]
	and a.[nm_subcanal] = c.[salesstructurenamelevel2]
	and a.[ds_grupo1] = c.[salesstructurenamelevel3]
	and a.[ds_grupo2] = c.[salesstructurenamelevel4]
	and a.[ds_grupo3] = c.[salesstructurenamelevel5]
	and a.[ds_grupo4] = c.[salesstructurenamelevel6]
inner join [stonedwv0].[dbo].[dimvendor] v on isnull(a.[closer_id], 'mundi') = (isnull(v.[vendoralternatekeymundi],'mundi_001'))
inner join [stonedwv0].[dbo].[dimclient] e  on a.[clientcnpjorcpf] = e.[clientcnpjorcpf]
	and a.[companykey] = e.[companykey]
	and c.[salesstructurekey] = e.[salesstructurekey]
	and (e.[clientstatuskey] <> 7 or e.[clientstatuskey] is null)
where not exists (select top (1) 1 from [stonedwv0].[dbo].[dimaffiliation] d  where a.[clientalternatekeymundi] = d.[clientalternatekey]) and a.[clientcnpjorcpf] is not null
group by a.[clientcnpjorcpf]
	, replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
	, isnull(b.[geographykey], 1)
	, replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
	, a.[clientalternatekeymundi]
	, c.[salesstructurekey]
	, a.[createdate]
