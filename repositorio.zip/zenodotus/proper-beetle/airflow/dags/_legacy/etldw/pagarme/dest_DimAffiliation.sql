use stonedwv0

if object_id('tempdb..#alteracoesdimaffiliation') is not null
	drop table #alteracoesdimaffiliation;

select distinct
	c.[salesstructurekey]
	, b.[clientalternatekeypagarme]
	, b.[clientcnpjorcpf]
	, b.[clientname]
	, b.[createdate]
	, isnull(b.[mcckey], 0) as [mcckey]
	, b.[clientlegalname]
	, b.[companykey]
	, i.[clientkey]
into #alteracoesdimaffiliation
from [dbo].[dimaffiliation] a
inner join (select * from {{ ti.xcom_pull('create_table') }}  where [companykey] = 3) b on a.[clientalternatekey] = b.[clientalternatekeypagarme]
inner join [dbo].[dimsalesstructure] c on
	b.[ds_canal] = c.[salesstructurenamelevel1]
	and b.[nm_subcanal] = c.[salesstructurenamelevel2]
	and b.[ds_grupo1] = c.[salesstructurenamelevel3]
	and b.[ds_grupo2] = c.[salesstructurenamelevel4]
	and b.[ds_grupo3] = c.[salesstructurenamelevel5]
	and b.[ds_grupo4] = c.[salesstructurenamelevel6]
inner join (
	select distinct
		[clientcnpjorcpf]
		, [salesstructurekey]
		, [companykey]
		, [clientkey]
	from [dbo].[dimclient]
	where (clientstatuskey <> 7 or clientstatuskey is null) and companykey in (3,4)
) i on
		isnull(b.[clientcnpjorcpf], 1) = isnull(i.[clientcnpjorcpf], 1)
		and c.[salesstructurekey] = i.[salesstructurekey]
		and a.[companykey] = i.[companykey]
where
	a.[salesstructurekey] <> c.[salesstructurekey]
	or isnull(a.[clientcnpjorcpf], 1) <> isnull(b.[clientcnpjorcpf], 1)
	or replace(ltrim(rtrim(replace(replace(a.[clientname], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(b.[clientname], char(9), ''), char(32), ''))), '"', '')
	or isnull(convert(varchar, a.[createdate]), '') <> b.[createdate]
	or a.[mcckey] <> b.[mcckey]
	or replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(b.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
	or i.[clientkey] <> a.[clientkey]

-- update dimaffiliation

update a
set a.[salesstructurekey] = b.[salesstructurekey]
	, a.[clientname] = left(b.[clientname], 300)
	, a.[clientlegalname]	= left(b.[clientlegalname], 300)
	, a.[createdate] = b.[createdate]
	, a.[clientcnpjorcpf] = b.[clientcnpjorcpf]
	, a.[mcckey] = isnull(c.[mcckey], 0)
	, a.[clientkey] = b.[clientkey]
from [dbo].[dimaffiliation] a
inner join
	#alteracoesdimaffiliation b on a.[clientalternatekey] = b.[clientalternatekeypagarme]
left join
	[dbo].[dimmcc] c on b.mcckey = c.mcckey

-- insert dimaffiliation

insert into [stonedwv0].[dbo].[dimaffiliation] (
	[clientcnpjorcpf]
	, [clientname]
	, [geographykey]
	, [clientlegalname]
	, [clientalternatekey]
	, [salesstructurekey]
	, [createdate]
	, [migrationdate]
	, [migrated]
	, [mcckey]
	, [companykey]
	, [chainname]
	, [clientstatuskey]
	, [vendorkey]
	, [clientkey]
	, [originregisterkey]
)

	select
		a.[clientcnpjorcpf]
		, left(replace(ltrim(rtrim(replace(replace(a.[clientname], char(9), ''), char(32), ''))), '"', ''), 300)
		, isnull(b.[geographykey], 1)
		, left(replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', ''), 300)
		, a.[clientalternatekeypagarme]
		, c.[salesstructurekey]
		, a.[createdate]
		, a.[createdate]
		, 0
		, isnull(m.[mcckey], 0)
		, 3
		, null
		, s.[clientstatuskey]
		, max(v.[vendorkey])
		, e.[clientkey]
		, 19
	from
		(select * from {{ ti.xcom_pull('create_table') }}  where [companykey] = 3) a
	left join
		[dbo].[dimgeography] b on b.[geographykey] = isnull([stonedwv0].[dbo].fc_regexp_003(a.[zipcode],'^0-9'), 1)
	inner join
		[dbo].[dimsalesstructure] c on
			a.[ds_canal] = c.[salesstructurenamelevel1]
			and a.[nm_subcanal] = c.[salesstructurenamelevel2]
			and a.[ds_grupo1] = c.[salesstructurenamelevel3]
			and a.[ds_grupo2] = c.[salesstructurenamelevel4]
			and a.[ds_grupo3] = c.[salesstructurenamelevel5]
			and a.[ds_grupo4] = c.[salesstructurenamelevel6]
	left join
		[dbo].[dimclientstatus] s on a.[status] = s.[clientstatusdesc]
	inner join
		[stonedwv0].[dbo].[dimvendor] v on v.[vendoralternatekeypagarme] = left(isnull(a.[closer_id],'pagarme_001'), 99)
	inner join
		[stonedwv0].[dbo].[dimclient] e  on
			isnull(a.[clientcnpjorcpf], 1) = isnull(e.[clientcnpjorcpf], 1)
			and a.[companykey] = e.[companykey]
			and c.[salesstructurekey] = e.[salesstructurekey]
			and (e.[clientstatuskey] <> 7 or e.[clientstatuskey] is null)
	left join
		[dbo].[dimmcc] m on a.mcckey = m.mcckey
	where not exists (select top (1) 1 from [stonedwv0].[dbo].[dimaffiliation] d where convert(varchar,a.[clientalternatekeypagarme]) = d.[clientalternatekey])
	group by
		a.[clientcnpjorcpf]
		, left(replace(ltrim(rtrim(replace(replace(a.[clientname], char(9), ''), char(32), ''))), '"', ''), 300)
		, isnull(b.[geographykey], 1)
		, left(replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', ''), 300)
		, a.[clientalternatekeypagarme]
		, c.[salesstructurekey]
		, a.[createdate]
		, a.[createdate]
		, isnull(m.[mcckey], 0)
		, s.[clientstatuskey]
		, e.[clientkey]
