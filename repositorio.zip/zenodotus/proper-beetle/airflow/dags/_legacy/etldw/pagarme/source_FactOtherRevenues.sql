use stonecoods

if object_id('tempdb..#other_revenues') is not null
    drop table #other_revenues;

--receita boleto
select
    convert(date,a.[date]) as [date]
    , a.[company_id]
    , sum(isnull([boleto_fee], 0)) as [revenue]
    , 21 as [type]
    , sum(a.[transaction_count]) as [unitamount]
into
    #other_revenues
from
    [pagarme].[revenues] a
where
    convert(date, a.[date]) < '{{ next_ds }}'
    and eomonth(a.[date]) = eomonth('{{ ds }}')
    and [boleto_tpv] <> 0
group by
    convert(date,a.[date])
    , a.[company_id]

union

--receita mdr outras adquirentes
select
    convert(date,a.[date]) as [date]
    , a.[company_id]
    , sum(isnull([credit_card_fee], 0)) + sum(isnull([debit_card_fee], 0)) - sum(isnull([credit_card_cost], 0)) - sum(isnull([debit_card_cost], 0)) as [revenue]
    , 31 as [type]
    , sum(a.[transaction_count]) as [unitamount]
from
    [pagarme].[revenues] a
where
    convert(date,a.[date]) < '{{ next_ds }}'
    and [tpv] <> 0
    and eomonth(a.[date]) = eomonth('{{ ds }}')
    and [origin_receivable] in ('cielo', 'rede', 'cielo/rede')
group by
    convert(date,a.[date])
    , a.[company_id]

union

--receita gateway
select
    convert(date,a.[date]) as [date]
    , a.[company_id]
    , sum(isnull([gateway_fee], 0)) as [revenue]
    , 26 as [type]
    , sum(a.[transaction_count]) as [unitamount]
from
    [pagarme].[revenues] a
where
    convert(date,a.[date]) < '{{ next_ds }}'
    and [gateway_fee] <> 0
    and eomonth(a.[date]) = eomonth('{{ ds }}')
group by
    convert(date,a.[date])
    , a.[company_id]

union

--transferência
select
    convert(date,a.[date]) as [date]
    , a.[company_id]
    , sum(isnull([transfer_fee], 0)) as [revenue]
    , 28 as [type]
    , sum(isnull([transfer_count],0)) as [unitamount]
from
    [pagarme].[revenues] a
where
    convert(date,a.[date]) < '{{ next_ds }}'
    and [transfer_fee] <> 0
    and eomonth(a.[date]) = eomonth('{{ ds }}')
group by
    convert(date,a.[date])
    , a.[company_id]


select
    a.[date]
    , a.[company_id]
    , a.[revenue]
    , a.[type]
    , a.[unitamount]
    , vendor.[closer_id] as [closer_id]
    , null as [revenuedate]
    , null as [grossrevenue]
    , null as [revenueservicetype]
    , null as [customerkey]
    , null as [vl_mdr]
    , null as [vl_ic]
    , null as [nr_transacoes]
    , null as [dt_transacao]
    , null as [stonecode]
    , null as [nm_produto]
    , null as [nm_empresa]
    , null as [id_registro]
from
    #other_revenues a
left join (
    select
        [company_id]
        , max((isnull(closer_id,'pagarme_001'))) as [closer_id]
    from
        [pagarme].[companies]
    group by
        [company_id]
) as vendor on vendor.[company_id] = a.[company_id]
