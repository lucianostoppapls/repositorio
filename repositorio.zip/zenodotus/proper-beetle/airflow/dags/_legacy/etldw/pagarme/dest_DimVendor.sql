use stonedwv0

-- carrega #tempvendor

if object_id('tempdb..#tempvendor') is not null
	drop table #tempvendor;

select a.[vendorkey]
into #tempvendor
from [stonedwv0].[dbo].[dimvendor] a 
where exists (select top(1) 1 from (select * from {{ ti.xcom_pull('create_table') }} where companykey = 3) b
inner join [stonedwv0].[dbo].[dimsalesstructure] c  on c.[salesstructurekey] = a.[salesstructurekey]
and b.[closer_id] = a.[vendoralternatekeypagarme]
where replace(ltrim(rtrim(replace(replace(b.[closer_name], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(a.[vendorname], char(9), ''), char(32), ''))), '"', ''))

-- insert dimvendorhist

insert into [stonedwv0].[dbo].[dimvendorhist] ([vendorkey]
, [parentvendorkey]
, [cpf]
, [salesstructurekey]
, [vendorname]
, [vendornickname]
, [hiredate]
, [birthdate]
, [loginid]
, [emailaddress]
, [phone]
, [gender]
, [enddate]
, [vendoralternatekey])

select [vendorkey]
, [parentvendorkey]
, [cpf]
, [salesstructurekey]
, [vendorname]
, [vendornickname]
, [hiredate]
, [birthdate]
, [loginid]
, [emailaddress]
, [phone]
, [gender]
, cast(getdate() as date)
, [vendoralternatekey]
from [stonedwv0].[dbo].[dimvendor] 
where [vendorkey] in (select vendorkey from #tempvendor)

-- update dimvendor

update d
set d.[salesstructurekey] = c.[salesstructurekey]
, d.[vendorname] = a.[closer_name]
, d.[vendornickname] = 'pagar.me'
, d.[emailaddress] = null
from [stonedwv0].[dbo].[dimvendor] d 
inner join (select * from {{ ti.xcom_pull('create_table') }} where companykey = 3) a  on a.closer_id = d.vendoralternatekeypagarme
inner join [stonedwv0].[dbo].[dimsalesstructure] c  on a.[closer_name] = c.[salesstructurenamelevel4]
where d.[vendorkey] in (select [vendorkey] from #tempvendor)

-- carga inicial

declare @pagarmestructureid int
set  @pagarmestructureid = (select [salesstructurekey] from [stonedwv0].[dbo].[dimsalesstructure] where [salesstructurenamelevel1] = 'digital'
and [salesstructurenamelevel2] = 'pagar.me'
and [salesstructurenamelevel3] = 'pagar.me'
and [salesstructurenamelevel4] = 'pagar.me'
and [salesstructurenamelevel5] = 'pagar.me'
and [salesstructurenamelevel6] = 'pagar.me')

if (@pagarmestructureid = null)

begin

insert into [stonedwv0].[dbo].[dimsalesstructure] ([salesstructurenamelevel1]
, [salesstructurenamelevel2]
, [salesstructurenamelevel3]
, [salesstructurenamelevel4]
, [salesstructurenamelevel5]
, [salesstructurenamelevel6])
values ('digital', 'pagar.me','pagar.me','pagar.me','pagar.me','pagar.me')

end

-- insert dimvendor

insert into [stonedwv0].[dbo].[dimvendor] ([salesstructurekey]
, [vendorname]
, [vendornickname]
, [emailaddress]
, [vendoralternatekeypagarme])

select @pagarmestructureid
, a.[closer_name]
, a.[closer_name]
, null
, a.[closer_id]
from (select * from {{ ti.xcom_pull('create_table') }} where companykey = 3) a
where not exists (select top(1) 1 from [stonedwv0].[dbo].[dimvendor] b  where a.[closer_id] = b.[vendoralternatekeypagarme])
