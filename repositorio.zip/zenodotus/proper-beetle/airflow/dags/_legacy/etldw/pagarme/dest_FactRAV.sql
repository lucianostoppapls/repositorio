use stonedwv0

delete from [stonedwv0].[dbo].[factrav]
where companykey = 3 and eomonth(convert(date,convert(char(8),[contractdate]))) = eomonth('{{ ds }}')

insert into [dbo].[factrav] (
    [companykey]
    , [ravtypekey]
    , [vendorkey]
    , [contractdate]
    , [grossvalue]
    , [netvalue]
    , [revenue]
    , [duration]
    , [warranty]
    , [flagkey]
    , [productkey]
    , [durationwd]
    , [clienttypekey]
    , [affiliationkey]
)

select
    rav.[companykey]
    , rav.[ravtypekey]
    , a.[vendorkey]
    , replace(convert(date, rav.[dt_contract]), '-', '')
    , rav.[vl_bruto]
    , rav.[vl_liquido]
    , rav.[vl_receita]
    , rav.[vl_duration]
    , null
    , rav.[flagkey]
    , 2
    , [stonedwv0].[dbo].fc_workingdays(dateadd(day, round(isnull(rav.[duration_numerator]/nullif(rav.[total_anticipated_amount], 0), 0), 0), c.[fulldate]), c.[fulldate])
    , 5
    , d.[affiliationkey]
from 
    (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 3) rav
inner join (
    select
        vendoralternatekeypagarme
        , max(vendorkey) as [vendorkey]
    from
        [dbo].[dimvendor]
    where
        vendoralternatekeypagarme is not null
    group by vendoralternatekeypagarme
) a on a.[vendoralternatekeypagarme] = isnull(rav.[closer_id],'pagarme_001')
inner join
    [dbo].[dimdate] c  on rav.[dt_contract] = c.[fulldate]
inner join
    [dbo].[dimaffiliation] d on d.[clientalternatekey] = isnull(rav.[company_id], -1)
