use stonecoods

if object_id('tempdb..#revenues') is not null
	drop table #revenues;

--crédito
select
	replace(convert(date,a.[date]), '-', '') as [transaction_date]
	, a.[company_id]
	, origin_receivable
	, sum(credit_card_tpv) as [tpv]
	, sum(case when origin_receivable='stone' then credit_card_fee else 0 end) as [mdr]
	, sum(
		case
			when origin_receivable='stone' then stone_credit_card_interchange
			when origin_receivable in ('cielo','rede','cielo/rede') then 0
			else credit_card_cost
		end
	) as [interchange]
	, sum(case when origin_receivable='stone' then stone_credit_card_assessment else 0 end) as [assessment]
	, sum(transaction_count) as [transaction_count]
	, 2 [product]
into
	#revenues
from
	[pagarme].[revenues] a
where
	eomonth(a.[date]) = eomonth('{{ ds }}')
	and convert(date,a.[date]) < '{{ next_ds }}'
	and ([credit_card_tpv] <> 0 or [credit_card_fee] <> 0 or [stone_credit_card_interchange] <> 0)
group by
	replace(convert(date,a.[date]), '-', '')
	, a.[company_id]
	, [origin_receivable]

union

--débito
select
	replace(convert(date,a.[date]), '-', '') as [transaction_date]
	, a.[company_id]
	, origin_receivable
	, sum(debit_card_tpv) as [tpv]
	, sum(case when origin_receivable='stone' then debit_card_fee else 0 end) as [mdr]
	, sum(
		case
			when origin_receivable='stone' then stone_debit_card_interchange
			when origin_receivable in ('cielo','rede','cielo/rede') then 0
			else debit_card_cost
		end
	) as [interchange]
	, sum(case when origin_receivable='stone' then stone_debit_card_assessment else 0 end) as [assessment]
	, sum(transaction_count) as [transaction_count]
	, 1 as [product]
from
	[pagarme].[revenues] a
where
	eomonth(a.[date]) = eomonth('{{ ds }}')
	and convert(date,a.[date]) < '{{ next_ds }}'
	and ([debit_card_tpv] <> 0 or [debit_card_fee] <> 0 or [stone_debit_card_interchange] <> 0)
group by
	replace(convert(date,a.[date]), '-', '')
	, a.[company_id]
	, [origin_receivable]

union

--boleto
select
	convert(date,a.[date]) as [transaction_date]
	, a.[company_id]
	, origin_receivable
	, sum(boleto_tpv) as [tpv]
	, sum(0) as [mdr]
	, sum(0) as [interchange]
	, sum(0) as [assessment]
	, sum(transaction_count) as transaction_count
	, 4 as [product]
from
	 [pagarme].[revenues] a
where
	eomonth(a.[date]) = eomonth('{{ ds }}')
	and convert(date,a.[date]) < '{{ next_ds }}'
	and [boleto_tpv] <> 0
group by
	convert(date,a.[date])
	, a.[company_id]
	, origin_receivable


select
	3 as [companykey]
	, null as [customerkey]
	, 9 as [flagkey]
	, g.[product] as [productkey]
	, 9 as [installmentkey]
	, vendor.[closer_id] as [closer_id]
	, replace(g.[transaction_date], '-', '') as [transactiondate]
	, sum(isnull(g.[transaction_count],0)) as [transactions]
	, sum(isnull(g.[tpv],0)) as [tpv]
	, sum(isnull(g.[mdr],0)) as [mdr]
	, sum(isnull(g.[interchange],0)) as [interchange]
	, sum(isnull(g.[assessment],0)) as [assessment]
	, null as [dia]
	, case
		when g.[origin_receivable] like '%stone%' then 1
		when g.[origin_receivable] like '%cielo%' then 2
		when g.[origin_receivable] like '%rede%' then 3
		when g.[origin_receivable] like '%bradesco%' then 4
		else 9
	end as [acquirerkey]
	, case
		when g.[origin_receivable] = 'stone' then 1
		when g.[origin_receivable] like '%gateway%' then 2
		else 9
	end as [typekey]
	, g.[company_id] as [stonecode]
	, null as [nm_bandeira]
	, null as [id_registro]
	, null as [nm_empresa]
	, null as [type]
from
	#revenues g
inner join (
	select
		[company_id],
		max((isnull(closer_id,'pagarme_001'))) as [closer_id]
	from
		[pagarme].[companies]
	group by
		[company_id]
) as vendor on vendor.[company_id] = g.[company_id]
group by
	product
	, vendor.[closer_id]
	, transaction_date
	, case
		when g.[origin_receivable] like '%stone%' then 1
		when g.[origin_receivable] like '%cielo%' then 2
		when g.[origin_receivable] like '%rede%' then 3
		when g.[origin_receivable] like '%bradesco%' then 4
		else 9
	end
	, case
		when g.[origin_receivable] = 'stone' then 1
		when g.[origin_receivable] like '%gateway%' then 2
		else 9
	end
	, g.[company_id]
