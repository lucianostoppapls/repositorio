use stonedwv0

if object_id('tempdb..#dimclient_pagarme_client_date') is not null
    drop table #dimclient_pagarme_client_date

select a.[createdate]
    , a.[ds_canal]
    , a.[nm_subcanal]
    , a.[ds_grupo1]
    , a.[ds_grupo2]
    , a.[ds_grupo3]
    , a.[ds_grupo4]
    , a.[clientcnpjorcpf]
    , b.[clientalternatekeypagarme]
into #dimclient_pagarme_client_date
from (select isnull(min([createdate]), '20170101') as [createdate]
        , [ds_canal]
        , [nm_subcanal]
        , [ds_grupo1]
        , [ds_grupo2]
        , [ds_grupo3]
        , [ds_grupo4]
        , [clientcnpjorcpf]
    from (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 3) c
    group by [ds_canal]
        , [nm_subcanal]
        , [ds_grupo1]
        , [ds_grupo2]
        , [ds_grupo3]
        , [ds_grupo4]
        , [clientcnpjorcpf]) a
inner join (select isnull([createdate], '20170101') as [createdate]
        , min(clientalternatekeypagarme) as [clientalternatekeypagarme]
        , [ds_canal]
        , [nm_subcanal]
        , [ds_grupo1]
        , [ds_grupo2]
        , [ds_grupo3]
        , [ds_grupo4]
        , [clientcnpjorcpf]
    from (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 3) d
    group by isnull([createdate], '20170101')
        , [ds_canal]
        , [nm_subcanal]
        , [ds_grupo1]
        , [ds_grupo2]
        , [ds_grupo3]
        , [ds_grupo4]
        , [clientcnpjorcpf]) b on a.clientcnpjorcpf = b.clientcnpjorcpf
            and a.ds_canal = b.ds_canal
            and a.nm_subcanal = b.nm_subcanal
            and a.ds_grupo1 = b.ds_grupo1
            and a.ds_grupo2 = b.ds_grupo2
            and a.ds_grupo3 = b.ds_grupo3
            and a.ds_grupo4 = b.ds_grupo4
            and a.[createdate] = b.[createdate]
group by a.[createdate]
    , a.[ds_canal]
    , a.[nm_subcanal]
    , a.[ds_grupo1]
    , a.[ds_grupo2]
    , a.[ds_grupo3]
    , a.[ds_grupo4]
    , a.[clientcnpjorcpf]
    , b.[clientalternatekeypagarme]

update [dbo].[dimclient]
set clientstatuskey = 1
where companykey = 3

if object_id('tempdb..#dimclient_pagarme_alteracoesdimclient') is not null
    drop table #dimclient_pagarme_alteracoesdimclient;

select distinct a.[clientkey] as [clientkey]
    , c.[salesstructurekey] as [salesstructurekey]
    , isnull(t.[geographykey], 1) [geographykey]
    , b.[clientalternatekeypagarme] as [clientalternatekeypagarme]
    , b.[clientcnpjorcpf] as [clientcnpjorcpf]
    , replace(ltrim(rtrim(replace(replace(b.[clientname], char(9), ''), char(32), ''))), '"', '') as [clientname]
    , b.[createdate] as [createdate]
    , isnull(b.[mcckey], 0) as [mcckey]
    , replace(ltrim(rtrim(replace(replace(b.[clientlegalname], char(9), ''), char(32), ''))), '"', '') as [clientlegalname]
    , v.[vendorkey] as [vendorkey]
    , s.[clientstatuskey] as [clientstatuskey]
    , case
        when len(b.[clientcnpjorcpf]) <= 11 then 'PF'
        when isnumeric(right(replace(ltrim(rtrim(replace(replace(b.[clientlegalname], char(9), ''), char(32), ''))), '"', ''), 11)) = 1 then 'MEI'
        else 'PJ'
    end AS [clientcnpjorcpfclassification]
into #dimclient_pagarme_alteracoesdimclient
from [dbo].[dimclient] a
inner join (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 3) b on a.[clientalternatekeypagarme] = b.[clientalternatekeypagarme]
inner join [dbo].[dimsalesstructure] c on b.[ds_canal] = c.[salesstructurenamelevel1]
    and b.[nm_subcanal] = c.[salesstructurenamelevel2]
    and b.[ds_grupo1] = c.[salesstructurenamelevel3]
    and b.[ds_grupo2] = c.[salesstructurenamelevel4]
    and b.[ds_grupo3] = c.[salesstructurenamelevel5]
    and b.[ds_grupo4] = c.[salesstructurenamelevel6]
inner join (select vendoralternatekeypagarme, max(vendorkey) as [vendorkey]
    from [dbo].[dimvendor]
    where vendoralternatekeypagarme is not null
    group by vendoralternatekeypagarme) v on v.[vendoralternatekeypagarme] = left(isnull(b.[closer_id],'pagarme_001'),99)
left join [dbo].[dimclientstatus] s on b.[status] = s.[clientstatusdesc]
left join dbo.[dimgeography] t on t.[geographykey] = isnull([stonedwv0].[dbo].fc_regexp_003(b.[zipcode],'^0-9'),1)
where a.[salesstructurekey] <> c.[salesstructurekey]
    or convert(varchar,a.[geographykey]) <> isnull(t.[geographykey],1)
    or a.[clientcnpjorcpf] <> b.[clientcnpjorcpf]
    or replace(ltrim(rtrim(replace(replace(a.[clientname], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(b.[clientname], char(9), ''), char(32), ''))), '"', '')
    or isnull(convert(varchar, a.[createdate]), '') <> b.[createdate]
    or a.[mcckey] <> b.[mcckey]
    or replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(b.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
    or a.[vendorkey] <> v.[vendorkey]
    or a.[clientstatuskey] <> s.[clientstatuskey]

update a
set a.[salesstructurekey] = b.[salesstructurekey]
    , a.[clientname] = left(b.[clientname], 300)
    , a.[geographykey] = b.[geographykey]
    , a.[clientlegalname]	= left(b.[clientlegalname], 300)
    , a.[createdate] = b.[createdate]
    , a.[clientcnpjorcpf] = b.[clientcnpjorcpf]
    , a.[vendorkey] = b.[vendorkey]
    , a.[mcckey] = isnull(c.[mcckey], 0)
    , a.[clientstatuskey] = b.[clientstatuskey]
    , a.[clientcnpjorcpfclassification] = b.[clientcnpjorcpfclassification]
from
    [dbo].[dimclient] a
inner join
    #dimclient_pagarme_alteracoesdimclient b on a.[clientkey] = b.[clientkey]
left join
    [dbo].[dimmcc] c on b.mcckey = c.mcckey

-- update clientes com data menor

update a
set clientstatuskey = 7
from [dbo].[dimclient] a
join (select clientcnpjorcpf, salesstructurekey, clientkey
    from [dbo].[dimclient] a
    where not exists (select top 1 1
        FROM #dimclient_pagarme_client_date b
        where a.clientalternatekeypagarme = b.clientalternatekeypagarme)
    group by clientcnpjorcpf, salesstructurekey, clientkey) b on a.clientkey = b.clientkey
where companykey = 3


-- update conceito cnpj/canal

declare @cont int = (select sum(qtd)
    from (select count(*) qtd, clientcnpjorcpf, salesstructurekey, max(clientkey) clientkey
        from [dbo].[dimclient]
        where companykey in (3,4) and clientstatuskey <> 7
        group by clientcnpjorcpf, salesstructurekey
        having count(*) > 1) a )

while @cont > 0

begin

update a
set clientstatuskey = 7
from [dbo].[dimclient]   a
    join (select count(*) qtd, clientcnpjorcpf, salesstructurekey, max(clientkey) clientkey
        from [dbo].[dimclient]
        where companykey in (3,4) and clientstatuskey <> 7
        group by clientcnpjorcpf, salesstructurekey
        having count(*) > 1) b
        on a.[clientkey] = b.[clientkey]

set @cont = (select sum(qtd)
    from (select count(*) qtd, clientcnpjorcpf, salesstructurekey, max(clientkey) clientkey
        from [dbo].[dimclient]
        where companykey in (3,4) and clientstatuskey <> 7
        group by clientcnpjorcpf, salesstructurekey
        having count(*) > 1) a )

end


insert into [stonedwv0].[dbo].[dimclient] ([clientcnpjorcpf]
    ,[clientname]
    ,[geographykey]
    ,[clientparentkey]
    ,[clientlegalname]
    ,[clientalternatekeypagarme]
    ,[salesstructurekey]
    ,[createdate]
    ,[migrationdate]
    ,[migrated]
    ,[mcckey]
    ,[companykey]
    ,[chainname]
    ,[clientstatuskey]
    ,[vendorkey]
    ,[originregisterkey]
    ,[clientcnpjorcpfclassification])

select a.[clientcnpjorcpf]
    , left(replace(ltrim(rtrim(replace(replace(a.[clientname], char(9), ''), char(32), ''))), '"', ''), 300)
    , isnull(b.[geographykey],1)
    , null
    , left(replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', ''), 300)
    , a.[clientalternatekeypagarme]
    , c.[salesstructurekey]
    , a.[createdate]
    , a.[createdate]
    , 0
    , isnull(m.[mcckey], 0)
    , a.[companykey]
    , null
    , s.[clientstatuskey]
    , isnull(v.[vendorkey], 1)
    , 19
    , case
        when len(a.[clientcnpjorcpf]) <= 11 then 'PF'
        when isnumeric(right(replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', ''), 11)) = 1 then 'MEI'
        else 'PJ'
    end AS clientcnpjorcpfclassification
from #dimclient_pagarme_client_date cc
inner join (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 3) as a on cc.[clientalternatekeypagarme] = a.[clientalternatekeypagarme]
left join [dbo].[dimgeography] b on b.[geographykey] = isnull([stonedwv0].[dbo].fc_regexp_003(a.[zipcode],'^0-9'),1)
inner join [dbo].[dimsalesstructure] c on a.[ds_canal] = c.[salesstructurenamelevel1]
    and a.[nm_subcanal] = c.[salesstructurenamelevel2]
    and a.[ds_grupo1] = c.[salesstructurenamelevel3]
    and a.[ds_grupo2] = c.[salesstructurenamelevel4]
    and a.[ds_grupo3] = c.[salesstructurenamelevel5]
    and a.[ds_grupo4] = c.[salesstructurenamelevel6]
left join [dbo].[dimclientstatus] s on a.[status] = s.[clientstatusdesc]
inner join (select vendoralternatekeypagarme, max(vendorkey) as vendorkey
    from [dbo].[dimvendor]
    where vendoralternatekeypagarme is not null
    group by vendoralternatekeypagarme) v on v.[vendoralternatekeypagarme] = left(isnull(a.[closer_id],'pagarme_001'),99)
left join
    [dbo].[dimmcc] m on a.mcckey = m.mcckey
where not exists (
    select top (1) 1
    from
        [stonedwv0].[dbo].[dimclient]   d 
    where
        isnull(a.[clientcnpjorcpf], 1) = isnull(d.[clientcnpjorcpf], 1)
        and a.[companykey] = d.[companykey]
        and c.[salesstructurekey] = d.[salesstructurekey]
        and ([clientstatuskey] <> 7 or [clientstatuskey] is null)
)
