use stonedwv0

delete 
from 
    [stonedwv0].[dbo].[facttpv]
where 
    companykey = 3 
    and eomonth(convert(date,convert(char(8),[transactiondate]))) = eomonth('{{ ds }}')

insert into [dbo].[facttpv] (
    [companykey]
    , [flagkey]
    , [productkey]
    , [installmentkey]
    , [vendorkey]
    , [transactiondate]
    , [transactions]
    , [tpv]
    , [mdr]
    , [interchange]
    , [assessment]
    , [acquirerkey]
    , [typekey]
    , [affiliationkey]
)

select 
    a.[companykey]
    , a.[flagkey]
    , a.[productkey]
    , a.[installmentkey]
    , isnull(c.[vendorkey], 1)
    , a.[transactiondate]
    , a.[transactions]
    , a.[tpv]
    , a.[mdr]
    , a.[interchange]
    , a.[assessment]
    , a.[acquirerkey]
    , a.[typekey]
    , isnull(d.[affiliationkey], 1)
from 
    {{ ti.xcom_pull('create_table') }} a
left join (
    select 
        vendoralternatekeypagarme
        , max(vendorkey) as [vendorkey]
    from 
        [stonedwv0].[dbo].[dimvendor]
    where 
        vendoralternatekeypagarme is not null
    group by 
        vendoralternatekeypagarme
) c on c.[vendoralternatekeypagarme] = isnull(a.[closer_id],'pagarme_001')
left join 
    [dbo].[dimaffiliation] d on d.[clientalternatekey] = isnull(a.[stonecode], -1)

--update ic e ass
update e
set 
    e.[tpv] = isnull((e.[tpv]/nullif([tpv_weight],0))*f.[tpv],0)
    , e.[interchange] = isnull((e.[interchange]/nullif([interchange_weight],0))*f.[interchange],0)
    , e.[assessment] = isnull((e.[assessment]/nullif([assessment_weight],0))*f.[assessment],0)
from 
    [dbo].[facttpv] e
inner join (
    select a.[transactiondate]
    , c.[fulldate]
    , sum(a.[tpv]) tpv
    , sum(isnull(a.[interchange],0)) interchange
    , sum(isnull(a.[assessment],0)) assessment
    from 
        [dbo].[facttpv] a
    inner join 
        [dbo].[dimdate] c on a.[transactiondate] = c.[datekey]
    inner join 
        [dbo].[dimaffiliation] d on a.[affiliationkey] = d.[affiliationkey]
    where 
        eomonth(c.[fulldate]) = eomonth('{{ ds }}') 
        and d.[clientkey] = 3626
    group by 
        a.[transactiondate]
        , c.[fulldate]
) f on e.[transactiondate] = f.[transactiondate]
inner join 
    [dbo].[dimdate] g on e.[transactiondate] = g.[datekey]
inner join 
    {{ ti.xcom_pull('create_support_table') }} h on g.[fulldate] = h.[transactiondate]
where 
    e.[companykey] = 3 
    and eomonth(g.[fulldate]) = eomonth('{{ ds }}') 
    and e.[typekey] = 1 
    and e.[acquirerkey] = 1

--update dia
update m
set 
    m.[dia] = isnull(m.[mdr],0) - isnull(m.[interchange],0) - isnull(m.[assessment],0)
from 
    [dbo].[facttpv]  m
inner join 
    [dbo].[dimdate] n on m.[transactiondate] = n.[datekey]
where 
    m.[companykey] = 3 
    and eomonth(n.[fulldate]) = eomonth('{{ ds }}')
