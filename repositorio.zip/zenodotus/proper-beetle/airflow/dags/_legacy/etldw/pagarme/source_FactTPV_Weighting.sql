use stonecoods

select
    convert(date,a.[date]) as [transactiondate]
    , sum(tpv) as [tpv_weight]
    , isnull(sum(isnull(stone_credit_card_interchange,0)) + sum(isnull(stone_debit_card_interchange,0)),0) as [interchange_weight]
    , isnull(sum(isnull(stone_credit_card_assessment,0)) + sum(isnull(stone_debit_card_assessment,0)),0) as [assessment_weight]
from
    [pagarme].[revenues] a
inner join (
    select distinct
        company_id
    from
        [pagarme].[companies]
) b on a.[company_id] = b.[company_id]
where
    eomonth([date]) = eomonth('{{ ds }}')
    and convert(date,[date]) < '{{ next_ds }}'
    and [origin_receivable] = 'stone'
group by
    convert(date,a.[date])
