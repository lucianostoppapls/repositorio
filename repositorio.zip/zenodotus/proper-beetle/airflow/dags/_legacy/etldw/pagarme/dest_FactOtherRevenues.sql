use stonedwv0

delete from [stonedwv0].[dbo].[factotherrevenues]
where companykey = 3 and eomonth(convert(date,convert(char(8),[datekey]))) = eomonth('{{ ds }}')

insert into [stonedwv0].[dbo].[factotherrevenues] (
    [datekey]
    , [vendorkey]
    , [revenue]
    , [revenuetypekey]
    , [quantity]
    , [companykey]
    , [affiliationkey]
)

select
    b.[datekey]
    , isnull(d.[vendorkey], 1)
    , sum(a.[revenue])
    , a.[type]
    , sum(a.[unitamount])
    , 3
    , isnull(e.[affiliationkey], 1)
from
    {{ ti.xcom_pull('create_table') }} a
inner join
    [stonedwv0].[dbo].[dimdate] b  on a.[date] = b.[fulldate]
inner join (
    select
        vendoralternatekeypagarme
        , max(vendorkey) as [vendorkey]
    from
        [dbo].[dimvendor]
    where
        vendoralternatekeypagarme is not null
    group by
        vendoralternatekeypagarme
) d on d.[vendoralternatekeypagarme] = isnull(a.[closer_id],'pagarme_001')
inner join
    [dbo].[dimaffiliation] e on e.[clientalternatekey] = isnull(a.[company_id], -1)
group by
    b.[datekey]
    , d.[vendorkey]
    , a.[type]
    , e.[affiliationkey]

truncate table {{ ti.xcom_pull('create_table') }}
