from mssql_utils import (
    CreatePrefixTableMsSqlOperator,
    DropPrefixTableMsSqlOperator,
    MsSqlOperatorPYODBC,
)
from airflow.operators.dummy import DummyOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from _legacy.etldw.mssql_utils import CleanTableOperator
from _legacy.etldw.redshift_utils import (
    UpdateDeletionsOperator,
    DeleteFromTableOperator,
)
from datetime import timedelta
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts
from airflow import configuration as conf
from plugins.gcp_utils import BigqueryToGCSOperator
from plugins.mssql_utils import GCSToMssqlExtractOperator


default_args = {
    "postgres_conn_id": "datarock",
    "aws_conn_id": "databalde",
    "dest_bucket": "databalde",
    "mssql_conn_id": "bw_azure",
    "depends_on_past": False,
    "retries": 4,
    "retry_delay": timedelta(minutes=15),
    "autocommit": True,
    "salesforce_conn_id": "salesforce",
    "google_cloud_storage_conn_id": "gcp_mis",
    "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "gcs_bucket_name": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "on_failure_callback": PagerDutyAlerts.failure_incident,
    "on_success_callback": PagerDutyAlerts.resolve_incident,
}


def transfer_tasks(
    dag,
    repo_name,
    table,
    database,
    prod_schema,
    date_column,
    column_types,
    log_schema="airflow_staging",
    external_dag_id=None,
):

    ds = "{{ ds }}"
    gcs_file = f"airflow-files/_legacy/{repo_name}/{table}-{ds}.csv"
    source_sql = f"etldw/{repo_name}/source_{table}.sql"
    dest_sql = f"etldw/{repo_name}/dest_{table}.sql"
    prod_table = f"{prod_schema}.{table}"

    with dag:

        if external_dag_id is not None:
            check_completion = ExternalTaskSensor(
                task_id="dag_init",
                external_dag_id=external_dag_id,
                external_task_id=None,
                allowed_states=["success"],
                mode="reschedule",
                poke_interval=60,
                check_existence=True,
            )
        else:
            check_completion = DummyOperator(task_id="dag_init")

        unload_task = BigqueryToGCSOperator(
            task_id=f"unload_{table}",
            source_conn_id="gcp_mis_datalake",
            dest_conn_id="gcp_mis",
            gcs_bucket=conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
            gcs_file=gcs_file,
            sql=source_sql,
        )

        create_temp_table_task = CreatePrefixTableMsSqlOperator(
            task_id="create_table",
            schema=log_schema,
            database="StoneDWv0",
            table_prefix=table,
            column_types=column_types,
            mssql_conn_id="bw_azure",
        )

        transfer_task = GCSToMssqlExtractOperator(
            task_id=f"load_{table}",
            database=database,
            dest_schema="{{ ti.xcom_pull('create_table').split('.')[0] }}",
            table_name="{{ ti.xcom_pull('create_table').split('.')[1] }}",
            source_file=gcs_file,
            truncate=False,
            gcs_data_delete=False,
            pool="bw_azure",
            mssql_conn_id="bw_azure",
            source_bucket=conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
            google_cloud_storage_conn_id="gcp_mis",
        )

        clean_task = CleanTableOperator(
            task_id=f"clean_{table}",
            table=prod_table,
            database=database,
            date_column=date_column,
            pool="bw_azure",
            mssql_conn_id="bw_azure",
        )

        write_task = MsSqlOperatorPYODBC(
            task_id=f"write_{table}",
            database=database,
            sql=dest_sql,
            pool="bw_azure",
            mssql_conn_id="bw_azure",
        )

        drop_temp_table_task = DropPrefixTableMsSqlOperator(
            task_id="drop_table",
            pool="bw_azure",
            database="StoneDWv0",
            schema=log_schema,
            table_prefix=table,
            mssql_conn_id="bw_azure",
        )

        complete_task = DummyOperator(task_id="dag_complete")

    (
        check_completion
        >> unload_task
        >> create_temp_table_task
        >> transfer_task
        >> clean_task
        >> write_task
        >> drop_temp_table_task
        >> complete_task
    )


def treat_deletions(dag, table, schema, date_column):

    with dag:

        update_task = UpdateDeletionsOperator(
            task_id=f"update_{table}",
            table=table,
            schema=schema,
            date_column=date_column,
            pool="datarock",
        )

        delete_task = DeleteFromTableOperator(
            task_id=f"delete_{table}_deleted",
            table=table + "_deleted",
            schema=schema,
            date_column=date_column,
            pool="datarock",
        )

    update_task >> delete_task
