use stonedwv0

delete from [stonedwv0].[dbo].[factheadcount]
where [datekey] = '{{ ds_nodash }}'

--insere o headcount diário

insert into [stonedwv0].[dbo].[factheadcount]

select
    '{{ ds_nodash }}'
    , null
    , a.[userkey]
    , a.[userrolekey]
    , a.[isactive]
    , min([salesstructurekey])
from
    [stonedwv0].[dbo].[dimuser] a
inner join
    [dbo].[dimuserrole] b on a.[userrolekey] = b.[userrolekey]
inner join (
    select c.[salesstructurekey]
    , [salesstructurenamelevel1]
    , [salesstructurenamelevel2]
    , [salesstructurenamelevel3]
    , [salesstructurenamelevel4]
    , [salesstructurenamelevel5]
    , [salesstructurenamelevel6]
    from
        [stonedwv0].[dbo].[dimclient] b
    inner join
        [stonedwv0].[dbo].dimsalesstructure c on b.[salesstructurekey] = c.[salesstructurekey]
    where
        b.[clientstatuskey] <> 7
    group by
        c.[salesstructurekey]
        , [salesstructurenamelevel1]
        , [salesstructurenamelevel2]
        , [salesstructurenamelevel3]
        , [salesstructurenamelevel4]
        , [salesstructurenamelevel5]
        , [salesstructurenamelevel6]
) c on replace(replace(b.[name], 'gestor ', ''), 'vendedor ', '') = [salesstructurenamelevel5] and [salesstructurenamelevel1] = 'polos'
group by
    a.[userkey]
    , a.[userrolekey]
    , a.[isactive]

union

select
    '{{ ds_nodash }}'
    , null
    , a.[userkey]
    , a.[userrolekey]
    , a.[isactive]
    , 1
from
    [stonedwv0].[dbo].[dimuser] a
inner join
    [dbo].[dimuserrole] b on a.[userrolekey] = b.[userrolekey]
where
    b.[name] = 'ferias/afastado'
group by
    a.[userkey]
    , a.[userrolekey]
    , a.[isactive]
