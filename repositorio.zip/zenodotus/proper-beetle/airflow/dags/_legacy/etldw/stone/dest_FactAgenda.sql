use stonedwv0

delete from [stonedwv0].[dbo].[factagenda]
where [duedate] = '{{ ds_nodash }}'

insert into [dbo].[factagenda] (
    [companykey]
    , [flagkey]
    , [productkey]
    , [vendorkey]
    , [duedate]
    , [receivablevalue]
    , [affiliationkey]
)

select
    agenda.[companykey]
    , agenda.[flagkey]
    , agenda.[productkey]
    , isnull(a.[vendorkey], 1)
    , agenda.[dt_dia_ref]
    , agenda.[vl_disponivel]
    , isnull(c.[affiliationkey], 1)
from
    {{ ti.xcom_pull('create_table') }} agenda
left join (
    select
        vendoralternatekey
        , max(vendorkey) as [vendorkey]
    from
        [dbo].[dimvendor] 
    where
        vendoralternatekey is not null
    group by
        vendoralternatekey
) a on a.[vendoralternatekey] = isnull(agenda.[id_registro], -1)
inner join (
    select distinct
        n.[clientalternatekey]
        , n.[affiliationkey]
        , m.[clientkey]
    from
        [dbo].[dimclient] m 
    left join
        [dbo].[dimaffiliation] n on m.[clientkey] = n.[clientkey]
    where
        n.[clientalternatekey] is not null
        and n.[companykey] in (1,2)
) c on c.[clientalternatekey] = isnull(agenda.[stone_code], -1)
