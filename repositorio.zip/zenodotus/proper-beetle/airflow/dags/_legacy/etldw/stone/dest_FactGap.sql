use stonedwv0

declare @dfirst_m13 date = dateadd(month, datediff(month, 0, '{{ ds }}')-13, 0)

delete a
from [dbo].[factgap] a
inner join [dbo].[dimdate] b on a.[datekey] = b.[datekey]
where [fulldate] = eomonth('{{ ds }}')

if object_id('tempdb..#ravdw') is not null
	drop table #ravdw;

select
	[clientalternatekey]
	, sum(iif([fulldate] between dateadd(day, -120, '{{ next_ds }}') and dateadd(day, -31, '{{ next_ds }}'), [grossvalue], 0)) as [vl_gap_ant_12030]
	, sum(iif([fulldate] between dateadd(day, -30, '{{ next_ds }}') and '{{ ds }}', [grossvalue], 0)) as [vl_gap_ant_30]
into
	#ravdw
from
	[stonedwv0].[dbo].[factrav]  as ant
inner join
	[stonedwv0].[dbo].[dimdate] b on ant.[contractdate] = b.[datekey]
inner join
	[stonedwv0].[dbo].[dimaffiliation] c on ant.[affiliationkey] = c.[affiliationkey]
where
	[fulldate] >= @dfirst_m13
	and [fulldate] < '{{ next_ds }}'
group by
	[clientalternatekey]

create index clientalternatekey on #ravdw (clientalternatekey)

if object_id('tempdb..#creddw') is not null
	drop table #creddw;

select
	c.[clientalternatekey]
	, sum(iif([fulldate] between dateadd([day], -120, '{{ next_ds }}') and dateadd(day, -31, '{{ next_ds }}'), [tpv], 0)) as [vl_gap_tpv_12030]
	, sum(iif([fulldate] between dateadd([day], -30, '{{ next_ds }}') and '{{ ds }}', [tpv], 0)) as [vl_gap_tpv_30]
into
	#creddw
from
	[stonedwv0].[dbo].[facttpv]  as cred
inner join
	[stonedwv0].[dbo].[dimdate] b on cred.[transactiondate] = b.[datekey]
inner join
	[stonedwv0].[dbo].[dimaffiliation] c on cred.[affiliationkey] = c.[affiliationkey]
inner join
	[stonedwv0].[dbo].[dimproduct] d on cred.[productkey] = d.[productkey]
inner join
	#ravdw e on c.[clientalternatekey] = e.[clientalternatekey]
where
	[fulldate] >= @dfirst_m13
	and isnull([productname], '') in ('crédito','outros')
group by
	c.[clientalternatekey]

insert into [dbo].[factgap] (
	[clientkey]
	, [companykey]
	, [datekey]
	, [gapvalue]
	, [affiliationkey]
)

select
	a.[clientkey]
	, a.[companykey]
	, replace(eomonth('{{ ds }}'), '-', '')
	, case when isnull(case when (r.[vl_gap_ant_12030] / nullif(tc.[vl_gap_tpv_12030],0)) > 2.0 then 2.0 else 0 end * tc.[vl_gap_tpv_30] - r.[vl_gap_ant_30] ,0) < -1000000000.00 then 0 else isnull(case when (r.[vl_gap_ant_12030] / nullif(tc.[vl_gap_tpv_12030],0)) > 2.0 then 2.0 else 0 end * tc.[vl_gap_tpv_30] - r.[vl_gap_ant_30] ,0) end  as [vl_gap_antecipacao]
	, [affiliationkey]
from
	#ravdw r
inner join
	#creddw tc on r.[clientalternatekey] = tc.[clientalternatekey]
inner join
	[stonedwv0].[dbo].[dimaffiliation] a on r.[clientalternatekey] = a.[clientalternatekey]
