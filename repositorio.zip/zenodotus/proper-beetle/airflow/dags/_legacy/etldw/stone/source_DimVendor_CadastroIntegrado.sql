use bdmdmis_stone

select b.[ds_emailvendedor]
, b.[id_registro]
, a.[nm_vendedor] [nm_portal]
, a.[nm_vendedor] [nm_exibicao]
, b.[ds_canal]
, b.[nm_subcanal]
, b.[ds_grupo1]
, b.[ds_grupo2]
, b.[ds_grupo3]
, b.[ds_grupo3] [ds_grupo4]
, b.[nm_forca_venda]
, a.[ds_time_portal]
from [dbo].[tbstonef_cadastro_integrado_ec] a
inner join [dbo].[tbstoned_vendedor_stone] b on a.[id_registro] = b.[id_registro]
