SELECT StoneCode, QtdEcommerce, QtdPOS, QtdMobile, QtdPinpad
FROM DBODMIS_001.dbo.TBT_BUY4_MEIO_DE_CAPTURA
