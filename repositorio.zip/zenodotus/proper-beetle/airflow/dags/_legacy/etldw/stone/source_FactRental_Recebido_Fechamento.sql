select
    sum(vl_receita) as [vl_receita]
    , [nr_mid]
    , eomonth(dt_base) as [dt_base]
from
    [bdmdmis_stone].[dbo].[vwstone_aluguel_recebido_015] 
where
    eomonth([dt_base]) = eomonth('{{ ds }}')
group by
    nr_mid
    , eomonth([dt_base])
