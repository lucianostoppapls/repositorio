-----------------------------dados stone---------------------------------
select distinct
    1 as [companykey]
    , cast(cadastro.[NR_STONECODE] as varchar) as [stonecode]
    ,case
        when cadastro.[cd_brand_id] = 1 then 1
        when cadastro.[cd_brand_id] = 2 then 2
        when cadastro.[cd_brand_id] = 3 then 11
        when cadastro.[cd_brand_id] = 9 then 3
        when cadastro.[cd_brand_id] = 171 then 4
        when cadastro.[cd_brand_id] = 1033 then 9
        when cadastro.[cd_brand_id] = 1341 then 9
        else cadastro.[cd_brand_id]
    end as [flagkey]
    , cadastro.[cd_bank_id] as [bankkey]
    , cast(cadastro.[nr_branch] as varchar) as [bankbranch]
    , cast(cadastro.[nr_account_number] as varchar) as [bankaccountnumber]
from [bdmdmis_stone].[dbo].[tbstonef_cadastro_banco_ec] cadastro


union

-----------------------------dados elavon---------------------------------
select distinct
    2 as [companykey]
    , convert(varchar,cadastro.[NR_MID]) as [stonecode]
    , case
        when cadastro.[cd_bandeira] = 1 then 8
        when cadastro.[cd_bandeira] = 2 then 2
        when cadastro.[cd_bandeira] = 3 then 1
        when cadastro.[cd_bandeira] = 4 then 9
        when cadastro.[cd_bandeira] = 5 then 2
        else cadastro.[cd_bandeira]
    end as [flagkey]
    , cadastro.[nr_banco] as [bankkey]
    , cast(cadastro.[nr_agencia_bancaria] as varchar) as [bankbranch]
    , cast(cadastro.[nr_conta_corrente] as varchar) as [bankaccountnumber]
from [bdmdmis001].[dbo].[tbplf_banco_ec] cadastro
