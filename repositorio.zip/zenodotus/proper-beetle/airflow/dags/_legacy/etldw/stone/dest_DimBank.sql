insert into [stonedwv0].[dbo].[dimbank] (
    bankkey
    , bankname
)
    select
        a.[bankkey]
        ,a.[bankname]
    from
        {{ ti.xcom_pull('create_table') }} a
    where not exists (
        select top 1 1
        from 
            [stonedwv0].[dbo].[dimbank] b
        where 
            a.[bankkey] = b.bankkey
    )


update b
    set 
        b.[bankname] = a.[bankname]
    from 
        {{ ti.xcom_pull('create_table') }} a
    inner join 
        [stonedwv0].[dbo].[dimbank] b on a.[bankkey] = b.[bankkey]
    where 
        a.[bankname] <> b.[bankname]
