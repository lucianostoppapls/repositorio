select
    sum([aluguel]) as [aluguel]
    , [nr_stonecode]
from
    [bdmdmis_stone].[dbo].[tbstonef_aluguel_cobranca]
group by
    [nr_stonecode]
