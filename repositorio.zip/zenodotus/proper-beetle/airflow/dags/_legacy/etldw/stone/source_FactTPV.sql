use bdmdmis_stone

select
    iif(len(g.[stonecode]) > 10, 2, 1) as [companykey]
    , null as [customerkey]
    , null as [flagkey]
    , g.[nm_bandeira] as [nm_bandeira]
    , case
        when g.[nm_produto] = 'credito' then 2
        when g.[nm_produto] = 'debito' then 1
        when g.[nm_produto] = 'boleto' then 4
        else 3
    end as [productkey]
    , case
        when g.[nm_produto] = 'debito' then 1
        when g.[nm_produto] = 'credito' and ds_tipoparcelado = '' then 2
        when g.[nm_produto] = 'credito' and ds_tipoparcelado = 'parcelado loj 2-6' then 3
        when g.[nm_produto] = 'credito' and ds_tipoparcelado = 'parcelado loj 7-12' then 4
        else 9
    end as [installmentkey]
    , cadastro.[id_registro] as [id_registro]
    , replace(g.[dt_transacao], '-', '') as [transactiondate]
    , sum(isnull(g.[nr_transacoes],0)) as [transactions]
    , sum(isnull(g.[vl_tpv],0)) as [tpv]
    , iif(g.[nm_produto] = 'boleto', 0, sum(isnull(g.[vl_mdr], 0))) as [mdr]
    , iif(g.[nm_produto] = 'boleto', 0, sum(isnull(g.[vl_ic], 0))) as [interchange]
    , iif(g.[nm_produto] = 'boleto', 0, sum(isnull(g.[vl_assessment], 0))) as [assessment]
    , iif(g.[nm_produto] = 'boleto', 0, sum(isnull(g.[vl_mdr], 0))-sum(isnull(g.[vl_ic], 0))-sum(isnull(g.[vl_assessment], 0))) as [dia]
    , null as [acquirerkey]
    , g.[nm_empresa] as [nm_empresa]
    , null as typekey
    , g.[type] as [type]
    , g.[stonecode] as [stonecode]
    , null as [closer_id]
from
    [dbo].[vw_tpv_diario_integrado_010] g 
inner join
    [dbo].[tbstonef_cadastro_integrado_ec] as cadastro on cadastro.[nr_mid] = g.[stonecode]
where
    replace(g.[dt_transacao], '-', '') >= '{{ ds_nodash }}'
    and (replace(g.[dt_transacao], '-', '') < '{{ next_ds_nodash }}')
group by
    iif(len(g.[stonecode]) > 10, 2, 1)
    , g.[nm_bandeira]
    , case
        when g.[nm_produto] = 'credito' then 2
        when g.[nm_produto] = 'debito' then 1
        when g.[nm_produto] = 'boleto' then 4
        else 3
    end
    , case
        when g.[nm_produto] = 'debito' then 1
        when g.[nm_produto] = 'credito' and ds_tipoparcelado = '' then 2
        when g.[nm_produto] = 'credito' and ds_tipoparcelado = 'parcelado loj 2-6' then 3
        when g.[nm_produto] = 'credito' and ds_tipoparcelado = 'parcelado loj 7-12' then 4
        else 9
    end
    , cadastro.[id_registro]
    , replace(g.[dt_transacao], '-', '')
    , g.[nm_empresa]
    , g.[type]
    , g.[stonecode]
    , g.[nm_produto]
