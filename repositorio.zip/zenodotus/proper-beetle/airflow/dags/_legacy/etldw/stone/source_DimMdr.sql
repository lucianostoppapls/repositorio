select
	2 as [companykey]
	,cast(mdr.NR_MID as varchar(12)) as [clientalternatekey]
	,case
		when produto.DS_PRODUTO = 'credito' then 2
		when produto.DS_PRODUTO = 'debito' then 1
		else 3
	end as [productkey]
	,case
		when nm_bandeira = 'DINERS' then 8
		when nm_bandeira = 'MASTER' then 2
		when nm_bandeira = 'MASTERCARD' then 2
		when nm_bandeira = 'OUTROS' then 9
		when nm_bandeira = 'VISA' then 1
		else 9
	end as [flagkey]
	,case
		when DS_PARCELADO='2-6' AND produto.DS_PRODUTO = 'credito'    then 3
		when DS_PARCELADO='7-12' AND produto.DS_PRODUTO = 'credito'    then 4
		when DS_PARCELADO='A VISTA' AND produto.DS_PRODUTO = 'credito' then 2
		when DS_PARCELADO='A VISTA' AND produto.DS_PRODUTO = 'debito'  then 1
		else 9
	end as [installmentkey]
	,cast([PC_MDR]/100.00 as float) as [mdrfee]
from
	bdmdmis001.dbo.[TBPLF_MDR] mdr
inner join
	bdmdmis001.dbo.[TBPLD_BANDEIRA] bandeira on mdr.CD_BANDEIRA = bandeira.CD_BANDEIRA
inner join
	bdmdmis001.dbo.[TBPLD_PRODUTO] produto on mdr.CD_PRODUTO = produto.CD_PRODUTO

union

select
	1 as [companykey]
	,cast(mdr.nr_stonecode as varchar(12)) as [clientalternateKey]
	,case
		when [NM_PRODUTO] like 'crédito%' then 2
		when NM_PRODUTO like 'débito%' then 1
		else 3
	end as [productkey]
	,case
		when NM_BANDEIRA = 'MasterCard' then 2
		when NM_BANDEIRA = 'AmericanExpress' then 11
		when NM_BANDEIRA = 'Hipercard' then 3
		when NM_BANDEIRA = 'Elo' then 4
		when NM_BANDEIRA = 'Visa' then 1
		else 9
	end as [flagkey]
	,case when NM_PRODUTO='Crédito com parcelas c/ juros' then 10
			when NM_PRODUTO='Débito à vista' then 1
			when NM_PRODUTO='Crédito de 2 a 6 parcelas s/ juros' then 3
			when NM_PRODUTO='Crédito de  7 a 12 parcelas s/ juros' then 4
			when NM_PRODUTO='Crédito à vista' then 2
			else 9
	end as [installmentkey]
	,cast([NR_TAX]/100.00 as float) as [mdrfee]
from
	[bdmdmis_stone].[dbo].[TBSTONEF_MDR_EC] mdr
where
	[NM_PRODUTO] like 'crédito%' or [NM_PRODUTO] like 'débito%'
