select distinct
    e.[nr_mid] as [nr_mid]
    , e.[nr_cep] as [nr_cep]
    , replace(isnull(e.[dt_criacao_tombamento], e.[dt_criacao]), '-', '') as [dt_criacao_tombamento]
    , replace(isnull(e.[dt_criacao], e.[dt_criacao_tombamento]), '-', '') as [dt_criacao]
    , e.[in_tombamento] as [in_tombamento]
    , e.[nr_mcc] as [nr_mcc]
    , e.[nm_fantasia] as [nm_fantasia]
    , e.[nr_cnpj] as [nr_cnpj]
    , e.[id_registro] as [id_registro]
    , e.[nm_razao_social] as [nm_razao_social]
    , e.[ds_status_ec] as [ds_status_ec]
    , case when isnull(e.[ds_canal],'') = '' then 'N/D' else e.[ds_canal] end as [ds_canal]
    , case when isnull(e.[nm_subcanal],'') = '' then 'N/D' else e.[nm_subcanal] end as [nm_subcanal]
    , case when isnull(e.[ds_grupo1],'') = '' then '-' else e.[ds_grupo1] end as [ds_grupo1]
    , case when isnull(e.[ds_grupo2],'') = '' then '-' else e.[ds_grupo2] end as [ds_grupo2]
    , case when isnull(e.[ds_grupo3],'') = '' then '-' else e.[ds_grupo3] end as [ds_grupo3]
    , f.[nm_cadeia] as [nm_cadeia]
    , null [clientalternatekeymundi]
    , null [zipcode]
    , null [clientcnpjorcpf]
    , null [createdate]
    , null [clientlegalname]
    , null [closer_id]
    , null [companykey]
    , null [clientalternatekeypagarme]
    , null [clientname]
    , null [mcckey]
    , null [status]
    , null [ds_grupo4]
    , e.[nm_canal_portal] [partnername]
    , isnull(e.[nm_aplicacao_cadastro], 'Outros') as [nm_aplicacao_cadastro]
    , null as [clientalternatekeycappta]
    , null as [mccname]
from
    [bdmdmis_stone].[dbo].[tbstonef_cadastro_integrado_ec] e
left join
    [bdmdmis_stone].[dbo].[vwstone_cadeias_019] f on e.[nr_mid] = f.[nr_mid]

union

select distinct
    null [nr_mid]
    , null [nr_cep]
    , null [dt_criacao_tombamento]
    , null [dt_criacao]
    , null [in_tombamento]
    , null [nr_mcc]
    , null [nm_fantasia]
    , null [nr_cnpj]
    , null [id_registro]
    , null [nm_razao_social]
    , null [ds_status_ec]
    , cadastro.[ds_canal] [ds_canal]
    , cadastro.[nm_subcanal] [nm_subcanal]
    , cadastro.[ds_grupo1] [ds_grupo1]
    , cadastro.[ds_grupo2] [ds_grupo2]
    , cadastro.[ds_grupo3] [ds_grupo3]
    , null [nm_cadeia]
    , cadastro.[customerkey] [clientalternatekeymundi]
    , cadastro.[zipcode] [zipcode]
    , cadastro.[cnpj] [clientcnpjorcpf]
    , replace(cadastro.[createdat], '-', '') [createdate]
    , cadastro.[fullname] [clientlegalname]
    , carteira.[closer_id] [closer_id]
    , 5 [companykey]
    , null [clientalternatekeypagarme]
    , null [clientname]
    , null [mcckey]
    , null [status]
    , cadastro.[ds_grupo4] [ds_grupo4]
    , null [partnername]
    , null as [nm_aplicacao_cadastro]
    , null as [clientalternatekeycappta]
    , null as [mccname]
from (
    select distinct
        a.[customerkey]
        , a.[zipcode]
        , convert(bigint,a.[cnpj]) cnpj
        , replace(a.[createdat], '-', '') createdat
        , a.[fullname]
        , a.[closername]
        , isnull(b.[ds_canal]	, 'N/D') [ds_canal]
        , isnull(b.[nm_subcanal], 'N/D') [nm_subcanal]
        , isnull(b.[ds_grupo1], '-') [ds_grupo1]
        , isnull(b.[ds_grupo2], '-') [ds_grupo2]
        , isnull(b.[ds_grupo3], '-') [ds_grupo3]
        , isnull(b.[ds_grupo3], '-')  as [ds_grupo4]
        , 5 companykey
    from
        [stonecoods].[mundi].[tbmundid_client] a
    inner join
        [stonecoods].[mundi].[vw_carteira_mundi] b on a.[customerkey] = b.[customerkey]
) cadastro
left join (
    select distinct
        concat('mundi_',row_number() over( order by [closername])) as [closer_id]
        , isnull([closername], 'mundi') as [closer_name]
    from
        [stonecoods].[mundi].[tbmundid_client] 
    group by [closername]
) carteira on cadastro.[closername] = carteira.[closer_name]

union

select distinct
    null [nr_mid]
    , null [nr_cep]
    , null [dt_criacao_tombamento]
    , null [dt_criacao]
    , null [in_tombamento]
    , null [nr_mcc]
    , null [nm_fantasia]
    , null [nr_cnpj]
    , null [id_registro]
    , null [nm_razao_social]
    , null [ds_status_ec]
    , isnull(b.[ds_canal]	, 'N/D') [ds_canal]
    , isnull(b.[nm_subcanal], 'N/D') [nm_subcanal]
    , isnull(b.[ds_grupo1], '-') [ds_grupo1]
    , isnull(b.[ds_grupo2], '-') [ds_grupo2]
    , isnull(b.[ds_grupo3], '-') [ds_grupo3]
    , null [nm_cadeia]
    , null [clientalternatekeymundi]
    , left(a.[zipcode], 8) as [zipcode]
    , a.[cnpj] as [clientcnpjorcpf]
    , replace(left(a.[affiliation_date], 10), '-', '') [createdate]
    , a.[full_name] as [clientlegalname]
    , a.[closer_id] as [closer_id]
    , 3 [companykey]
    , a.[company_id] as [clientalternatekeypagarme]
    , a.[name] as [clientname]
    , a.[mcc] as [mcckey]
    , case
        when a.[status] in ('pending_data'
            , 'waiting_confirmation'
            , 'pending_affiliation'
            , 'pending_activation'
            , 'pending_risk_analysis'
            , 'pending_confirmation') then 'avaliação interna'
        when a.[status] = 'temporary' then 'em análise'
        when a.[status] = 'inactive' then 'cancelado'
        when a.[status] = 'active' then 'credenciado'
        else 'outros'
    end as [status]
    , isnull(b.[ds_grupo4], '-') [ds_grupo4]
    , null [partnername]
    , null as [nm_aplicacao_cadastro]
    , null as [clientalternatekeycappta]
    , null as [mccname]
from
    [stonecoods].[pagarme].[companies] a
inner join (
    select
        company_id
        , case when isnull([ds_canal],'') = '' then 'N/D' else [ds_canal] end [ds_canal]
        , case when isnull([nm_subcanal],'') = '' then 'N/D' else [nm_subcanal] end [nm_subcanal]
        , case when isnull([grupo1],'') = '' then '-' else [grupo1] end [ds_grupo1]
        , case when isnull([grupo2],'') = '' then '-' else [grupo2] end [ds_grupo2]
        , case when isnull([grupo3],'') = '' then '-' else [grupo3] end [ds_grupo3]
        , case when isnull([grupo3],'') = '' then '-' else [grupo3] end [ds_grupo4]
    from
        [stonecoods].[pagarme].[vw_carteira_pagarme_cubo]
    group by
        company_id
        , case when isnull([ds_canal],'')    = '' then 'N/D' else [ds_canal] end
        , case when isnull([nm_subcanal],'') = '' then 'N/D' else [nm_subcanal] end
        , case when isnull([grupo1],'')   = '' then '-' else [grupo1] end
        , case when isnull([grupo2],'')   = '' then '-' else [grupo2] end
        , case when isnull([grupo3],'')   = '' then '-' else [grupo3] end
        , case when isnull([grupo3],'')   = '' then '-' else [grupo3] end
) b on a.[company_id] = b.[company_id]
where a.[cnpj] is not null

union

select distinct
    null as [nr_mid]
    , null as [nr_cep]
    , null as [dt_criacao_tombamento]
    , null as [dt_criacao]
    , null as [in_tombamento]
    , null as [nr_mcc]
    , null as [nm_fantasia]
    , null as [nr_cnpj]
    , null as [id_registro]
    , null as [nm_razao_social]
    , null as [ds_status_ec]
    , isnull(b.[ds_canal], 'N/D') as [ds_canal]
    , isnull(b.[nm_subcanal], 'N/D') as [nm_subcanal]
    , isnull(b.[ds_grupo1], '-') as [ds_grupo1]
    , isnull(b.[ds_grupo2], '-') as [ds_grupo2]
    , isnull(b.[ds_grupo3], '-') as [ds_grupo3]
    , null as [nm_cadeia]
    , null as [clientalternatekeymundi]
    , cast(a.[cep] as varchar) as [zipcode]
    , cast(isnull([stonecoods].[dbo].fc_regexp_003(a.[cnpj],'^0-9'), 0) as varchar) as [clientcnpjorcpf]
    , isnull(convert(varchar, c.[data], 112), '20170101') as [createdate]
    , a.[razão social] as [clientlegalname]
    , cast(b.[capptor id] as varchar) as [closer_id]
    , 6 as [companykey]
    , null as [clientalternatekeypagarme]
    , A.[Fantasia] as [clientname]
    , null as [mcckey]
    , [status equipamento] as [status]
    , isnull(b.[ds_grupo3], '-')  as [ds_grupo4]
    , null as [partnername]
    , null as [nm_aplicacao_cadastro]
    , convert(varchar, a.[cnpj]) as [clientalternatekeycappta]
    , [segmento] as [mccname]
from 
    stonecoods.[cappta].[tbcapptat_cadastro_ec] a
inner join 
    [stonecoods].[cappta].[vw_carteira_cappta] b on a.[cnpj] = b.[cnpj]
left join (
    select 
        min([data]) as [data]
        , [cnpj]
    from 
        stonecoods.[cappta].[tbcapptat_pedido] 
    group by 
        [cnpj]
) c on a.[cnpj] = c.[cnpj]
