select
    max([nr_estimated_monthly_tpv]) as [nr_estimated_monthly_tpv]
    , nr_stonecode
from
    [bdmdmis_stone].[dbo].[tbstonef_cadastro_ec]
group by
    nr_stonecode
