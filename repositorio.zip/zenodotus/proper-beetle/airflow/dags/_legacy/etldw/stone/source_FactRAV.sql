select
    iif(len(g.[nr_mid]) > 10, 2, 1) as [companykey]
    , case
        when g.[nm_canal_antecipacao] = 'automática' then 1
        when g.[nm_canal_antecipacao] = 'manual' then 2
        else 99
    end as [ravtypekey]
    , cadastro.[id_registro] as [id_registro]
    , null as [closer_id]
    , g.[dt_contract] as [dt_contract]
    , isnull(g.[vl_bruto], 0) as [vl_bruto]
    , isnull(g.[vl_liquido], 0) as [vl_liquido]
    , isnull(g.[vl_receita], 0) as [vl_receita]
    , isnull(g.[vl_duration], 0) as [vl_duration]
    , null as [flagkey]
    , g.[produto] as [produto]
    , g.[bandeira] as [bandeira]
    , null as [duration_numerator]
    , null as [total_anticipated_amount]
    , null as [company_id]
    , isnull(e.[qtd_antecipacoes], 0) as [qtd_antecipacoes]
    , g.[nr_mid] as [nr_mid]
from
    [bdmdmis_stone].[dbo].[vwstone_antecipacao_recebivel_006] g 
inner join
    [bdmdmis_stone].[dbo].[tbstonef_cadastro_integrado_ec] cadastro on g.[nr_mid] = cadastro.[nr_mid]
left join
    [bdmdmis_stone].[dbo].[vwstone_antecipacao_recebivel_005_nr_antecipacoes] e on
        g.[nr_mid] = e.[nr_mid]
    and g.[dt_contract] = e.[dt_contract]
    and g.[nm_canal_antecipacao] = e.[nm_canal_antecipacao]
    and g.[vl_duration] = e.[vl_duration]
    and g.[produto] = e.[produto]
    and g.[bandeira] = e.[bandeira]
where
    g.[dt_contract] = '{{ ds }}'

union all

select
    3 as [companykey]
    , case
        when g.[anticipation_type] = 'automatic' then 1
        when g.[anticipation_type] = 'spot' then 2
        else 99
    end  as [ravtypekey]
    , null as [id_registro]
    , vendor.[closer_id] as [closer_id]
    , cast(g.[payment_date] as date) [dt_contract]
    , isnull(g.[total_anticipated_amount],0) as [vl_bruto]
    , isnull(g.[net_anticipated_amount],0) as [vl_liquido]
    , isnull(g.[anticipation_fee],0) as [vl_receita]
    , round(isnull(g.[duration_numerator]/nullif(g.[total_anticipated_amount],0),0),6) as [vl_duration]
    , case
        when [card_brand] = 'outros' then 9
        when [card_brand] = 'diners' then 8
        when [card_brand] = 'elo' then 4
        when [card_brand] = 'hipercard' then 3
        when [card_brand] = 'mastercard' then 2
        when [card_brand] = 'visa' then 1
        when [card_brand] = 'amex' then 11
        when [card_brand] = 'discover' then 12
        else 9
    end as [flagkey]
    , null as [produto]
    , null as [bandeira]
    , g.[duration_numerator]
    , g.[total_anticipated_amount]
    , g.[company_id] as [company_id]
    , null as [qtd_antecipacoes]
    , null as [nr_mid]
from
    [stonecoods].[pagarme].[anticipation] g 
inner join (
    select
        [company_id]
        , max((isnull(closer_id,'pagarme_001'))) as [closer_id]
    from
        [stonecoods].[pagarme].[companies]
    group by
        [company_id]
) as vendor on vendor.[company_id] = g.[company_id]
where
    eomonth(g.[payment_date]) = eomonth('{{ ds }}')
    and convert(date, g.[payment_date]) < '{{ next_ds }}'
