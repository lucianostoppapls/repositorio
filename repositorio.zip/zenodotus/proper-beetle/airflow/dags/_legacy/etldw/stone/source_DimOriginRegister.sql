select
    isnull([nm_aplicacao_cadastro], 'Outros') as [originregistername]
from 
    [BDMDMIS_STONE].[dbo].[TBSTONEF_CADASTRO_INTEGRADO_EC]
group by 
    isnull([nm_aplicacao_cadastro], 'Outros')
