select distinct
    [id] as [bankkey]
    ,upper([name]) as [bankname]
from
    stonecoods.dbo.tbt_buy4_bank

union

select distinct
    [cd_banco] as [bankkey]
    ,upper([nm_banco]) as [bankname]
from
    [stonecoods].[elavon].[tbpld_bancos]
where not exists (
	select top 1 1 
	from stonecoods.dbo.tbt_buy4_bank 
	where stonecoods.dbo.tbt_buy4_bank.id = [stonecoods].[elavon].[tbpld_bancos].cd_banco
)