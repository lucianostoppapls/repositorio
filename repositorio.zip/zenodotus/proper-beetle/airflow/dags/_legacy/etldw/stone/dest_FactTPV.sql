use stonedwv0

delete
from
    [stonedwv0].[dbo].[facttpv]
where
    [transactiondate] = '{{ ds_nodash }}'
    and companykey in (1,2)

insert into [dbo].[facttpv] (
    [companykey]
    , [flagkey]
    , [productkey]
    , [installmentkey]
    , [vendorkey]
    , [transactiondate]
    , [transactions]
    , [tpv]
    , [mdr]
    , [interchange]
    , [assessment]
    , [dia]
    , [acquirerkey]
    , [typekey]
    , [affiliationkey]
)

select
    a.[companykey]
    , isnull(d.[flagkey], 9)
    , a.[productkey]
    , a.[installmentkey]
    , isnull(e.[vendorkey], 1)
    , a.[transactiondate]
    , a.[transactions]
    , a.[tpv]
    , a.[mdr]
    , a.[interchange]
    , a.[assessment]
    , a.[dia]
    , isnull(b.[acquirerkey], 1)
    , isnull(c.[typekey], 1)
    , isnull(f.[affiliationkey], 1)
from
    {{ ti.xcom_pull('create_table') }} a
left join
    [dbo].[dimacquirer] b on a.[nm_empresa] = b.[acquirername]
left join
    [dbo].[dimtype] c on a.[type] = c.[typename]
left join
    [dbo].[dimflag] d on a.[nm_bandeira] = d.[flagname]
left join (
    select
        vendoralternatekey
        , max(vendorkey) as [vendorkey]
    from
        [dbo].[dimvendor] 
    where
        vendoralternatekey is not null
    group by
        vendoralternatekey
) e on e.[vendoralternatekey] = isnull(a.[id_registro], -1)
left join (
    select distinct
        n.[clientalternatekey]
    , n.[affiliationkey]
    , m.[clientkey]
    from
        [dbo].[dimclient] m 
    left join
        [dbo].[dimaffiliation] n on m.[clientkey] = n.[clientkey]
    where
        n.[clientalternatekey] is not null
        and n.[companykey] in (1,2)
) f on f.[clientalternatekey] = isnull(a.[stonecode],-1)

truncate table
    {{ ti.xcom_pull('create_table') }}
