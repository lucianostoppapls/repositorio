select
    a.[vl_mdr]
    , a.[vl_ic]
    , a.[nr_transacoes]
    , a.[dt_transacao]
    , cadastro.[id_registro] as [id_registro]
    , a.[stonecode]
    , a.[nm_produto]
    , a.[nm_empresa]
    , null as [date]
    , null as [company_id]
    , null as [revenue]
    , null as [type]
    , null as [unitamount]
    , null as [revenuedate]
    , null as [grossrevenue]
    , null as [revenueservicetype]
    , null as [customerkey]
from
    [bdmdmis_stone].[dbo].[vw_tpv_diario_integrado_010] a
left join
    [bdmdmis_stone].[dbo].[tbstonef_cadastro_integrado_ec] cadastro on a.[stonecode] = cadastro.[nr_mid]
where
    a.[dt_transacao] >= '{{ ds }}'
    and a.[dt_transacao] < '{{ next_ds }}'
