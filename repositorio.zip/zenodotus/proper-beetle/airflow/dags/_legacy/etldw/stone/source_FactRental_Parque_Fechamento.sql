select
    [nr_pos]
    , [nr_pinpad]
    , [nr_mid]
    , [dt_base]
from
    [bdmdmis_stone].[dbo].[vwstone_parque_instalado_consolidado_018]
where
    eomonth([dt_base]) = eomonth('{{ ds }}')
