use stonedwv0

truncate table [stonedwv0].[dbo].[dimbasedataclient]

insert into [stonedwv0].[dbo].[dimbasedataclient] (
    [clientkey]
    , [lasttransactiondate]
    , [firsttransactiondate]
    , [firstactivationdate]
    , [firstchurndate]
)

select
    coalesce(churn.[clientkey], tpv.[clientkey]) as [clientkey]
    , tpv.[lasttransactiondate]
    , tpv.[firsttransactiondate]
    , tpv.[firstactivationdate]
    , churn.[transactiondate] as [firstchurndate]
from (
    select
        [clientkey]
        , min([transactiondate]) as [transactiondate]
    from
        [stonedwv0].[dbo].[vwfactchurn]
    where
        [churn] = 1
    group by
        [clientkey]
) churn
full outer join (
    select [clientkey]
    , max(iif([tpv] > 1, [transactiondate], null)) as [lasttransactiondate]
    , min(iif([tpv] > 1, [transactiondate], null)) as [firsttransactiondate]
    , min(iif([tpv] > 500, [transactiondate], null)) as [firstactivationdate]
    from (
        select b.[clientkey]
        , [transactiondate]
        , sum(tpv) as [tpv]
        from
            [stonedwv0].[dbo].[facttpv]  a
        inner join
            [stonedwv0].[dbo].[dimaffiliation]  b on a.[affiliationkey] = b.[affiliationkey]
        group by
        b.[clientkey]
        , transactiondate
    ) a
    group by
        a.[clientkey]
) tpv on churn.[clientkey] = tpv.[clientkey]
