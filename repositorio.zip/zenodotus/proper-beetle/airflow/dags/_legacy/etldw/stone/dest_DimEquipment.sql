if object_id('tempdb..#alteracoesparque') is not null
		drop table #alteracoesparque


--Delete non active equipment

delete b from stonedwv0.dbo.dimequipment b
where exists (
    select top 1 1
    from
        {{ ti.xcom_pull('create_table') }} a
    where
        a.ds_serial_number = b.serialnumber
        and a.ds_customer_stone_code is null
)

select
    a.*
    , b.affiliationkey
    , d.datekey
into
    #alteracoesparque
from
    {{ ti.xcom_pull('create_table') }} a
inner join
    [stonedwv0].[dbo].[dimaffiliation] b on a.ds_customer_stone_code = b.clientalternatekey
inner join
    [stonedwv0].[dbo].[dimequipment] c on a.ds_serial_number = c.serialnumber
inner join
    [stonedwv0].[dbo].[dimaffiliation] e on cast(c.affiliationkey as varchar) = e.clientalternatekey
inner join
    [stonedwv0].[dbo].[dimdate] d on a.dt_last_modified_date = d.fulldate
where
    a.ds_model <> c.model
    or a.ds_technology_type <> c.technologytype
    or a.ds_terminal_status <> c.terminalstatus
    or a.ds_logistics_operator <> c.logisticsoperator
    or a.ds_provider <> c.provider
    or d.datekey <> c.lastmodifieddate
    or a.ds_contractor <> c.contractor
    or a.ds_customer_stone_code <> e.clientalternatekey



update b
set
    b.model = a.ds_model
    , b.technologytype = a.ds_technology_type
    , b.terminalstatus = a.ds_terminal_status
    , b.logisticsoperator = a.ds_logistics_operator
    , b.provider = a.ds_provider
    , b.lastmodifieddate = a.datekey
    , b.contractor = a.ds_contractor
    , b.affiliationkey = a.affiliationkey
from
    #alteracoesparque a
inner join
    stonedwv0.dbo.dimequipment b on
        a.ds_serial_number = b.serialnumber


insert into stonedwv0.dbo.dimequipment (
    [serialnumber]
    , [model]
    , [technologytype]
    , [terminalstatus]
    , [logisticsoperator]
    , [provider]
    , [lastmodifieddate]
    , [contractor]
    , [affiliationkey]
)

select
    a.ds_serial_number
    , a.ds_model
    , a.ds_technology_type
    , a.ds_terminal_status
    , a.ds_logistics_operator
    , a.ds_provider
    , d.datekey
    , a.ds_contractor
    , b.affiliationkey
from
    {{ ti.xcom_pull('create_table') }} a
inner join
    [stonedwv0].[dbo].[dimaffiliation] b on a.ds_customer_stone_code = b.clientalternatekey
inner join
    [stonedwv0].[dbo].[dimdate] d on a.dt_last_modified_date = d.fulldate
where not exists (
    select top 1 1
    from
        stonedwv0.dbo.dimequipment c
    where
        a.ds_serial_number = c.serialnumber
)
