insert into [dbo].[dimoriginregister] (originregistername)

select 
    a.[originregistername]
from 
    {{ ti.xcom_pull('create_table') }} a
where not exists (
    select top 1 1	
    from 
        dimoriginregister b
    where 
        a.[originregistername] = b.[originregistername]
)
group by a.[originregistername]
