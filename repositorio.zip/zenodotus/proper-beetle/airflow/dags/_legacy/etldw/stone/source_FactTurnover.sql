use dbodmis_001

select
    [userhistory__date_time_changed__c]
    , [userhistory__user__c]
    , [userhistory__previous_value__c]
    , [userhistory__new_value__c]
    , [userhistory__date_time_changed__c]
    , [userhistory__field_api_name__c]
    , [userhistory__date_time_changed__c]
from [dbo].[tbsalesforce_obj_user_field_history]
