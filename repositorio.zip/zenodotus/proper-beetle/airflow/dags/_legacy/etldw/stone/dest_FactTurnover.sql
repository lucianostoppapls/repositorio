delete from [stonedwv0].[dbo].[factturnover]
where datekey = '{{ ds_nodash }}'

insert into [stonedwv0].[dbo].[factturnover] (
    datekey
    , vendorkey
    , userkey
    , turnovertypekey
    , salesstructurekey
)

select
    replace(cast(a.[userhistory__date_time_changed__c] as date),'-','')
    , null
    , a.[userhistory__user__c]
    , 1
    , min([salesstructurekey])
from
    {{ ti.xcom_pull('create_table') }} a
inner join (
    select
        c.[salesstructurekey]
        , [salesstructurenamelevel1]
        , [salesstructurenamelevel2]
        , [salesstructurenamelevel3]
        , [salesstructurenamelevel4]
        , [salesstructurenamelevel5]
        , [salesstructurenamelevel6]
    from
        [stonedwv0].[dbo].[dimclient] b
    inner join
        [stonedwv0].[dbo].dimsalesstructure c on b.[salesstructurekey] = c.[salesstructurekey]
    where
        b.[clientstatuskey] <> 7
    group by
        c.[salesstructurekey]
        , [salesstructurenamelevel1]
        , [salesstructurenamelevel2]
        , [salesstructurenamelevel3]
        , [salesstructurenamelevel4]
        , [salesstructurenamelevel5]
        , [salesstructurenamelevel6]
) b on
    replace(replace(a.[userhistory__previous_value__c], 'gestor ', ''), 'vendedor ', '') = b.[salesstructurenamelevel5]
    and replace(replace(a.[userhistory__previous_value__c], 'gestor ', ''), 'vendedor ', '') = b.[salesstructurenamelevel6]
    and (b.[salesstructurenamelevel1] = 'expansao' or b.[salesstructurenamelevel1] = 'expansão')
where (
    (a.[userhistory__previous_value__c] like '%vendedor polo%' and a.[userhistory__new_value__c] not like '%vendedor polo%')
    or (a.[userhistory__previous_value__c] like '%gestor polo%' and a.[userhistory__new_value__c] not like '%gestor polo%')
)
    and (a.[userhistory__previous_value__c] like '%vendedor polo%' or a.[userhistory__previous_value__c] like '%gestor polo%')
    and cast(a.[userhistory__date_time_changed__c] as date) = cast('{{ ds }}' as date)
    and a.[userhistory__field_api_name__c] = 'userroleid'
group by
    replace(cast(a.[userhistory__date_time_changed__c] as date),'-',''), a.[userhistory__user__c]

union

select
    replace(cast(a.[userhistory__date_time_changed__c] as date),'-','')
    , null
    , a.[userhistory__user__c]
    , 2
    , 1
from
    {{ ti.xcom_pull('create_table') }} a
where
    a.[userhistory__field_api_name__c] = 'isactive'
    and (a.[userhistory__previous_value__c] = 'true' and a.[userhistory__new_value__c] = 'false')
    and cast(a.[userhistory__date_time_changed__c] as date) = cast('{{ ds }}' as date)
