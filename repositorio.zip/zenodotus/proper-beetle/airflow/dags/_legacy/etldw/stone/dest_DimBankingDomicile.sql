insert into [stonedwv0].[dbo].[dimbankingdomicile] (
    companykey
    , affiliationkey
    , flagkey
    , bankkey
    , bankbranch
    , bankaccountnumber
)
    select
        cadastro.[companykey]
        , aff.[affiliationkey]
        , cadastro.[flagkey]
        , cadastro.[bankkey]
        , cadastro.[bankbranch]
        , cadastro.[bankaccountnumber]
    from {{ ti.xcom_pull('create_table') }} cadastro
    inner join
        [stonedwv0].[dbo].[dimaffiliation] aff on cadastro.[stonecode] = aff.[clientalternatekey]
    where not exists (
        select top 1 1
        from [stonedwv0].[dbo].[dimbankingdomicile] b
        where
            aff.[affiliationkey] = b.[affiliationkey]
            and cadastro.[flagkey] = b.[flagkey]
            and cadastro.[bankkey] = b.[bankkey]
            and cadastro.[bankbranch] = b.[bankbranch]
            and cadastro.[bankaccountnumber] = b.[bankaccountnumber]
            and cadastro.[companykey] = b.[companykey]
    )
        and cadastro.[bankkey] is not null
        and cadastro.[bankbranch] is not null
        and cadastro.[bankaccountnumber] is not null


if object_id('tempdb..#tempupdatebankingdomicile') is not null
    drop table #tempupdatebankingdomicile


select
    bd.[companykey]
    , bd.[affiliationkey]
    , bd.[flagkey]
    , bd.[bankkey]
    , bd.[bankbranch]
    , bd.[bankaccountnumber]
    ,cast('{{ds_nodash}}' as int) as [enddate]
into
    #tempupdatebankingdomicile
from
    [stonedwv0].[dbo].[dimbankingdomicile] bd
where not exists (
    select top 1 1
    from {{ ti.xcom_pull('create_table') }} cadastro
    inner join [stonedwv0].[dbo].[dimaffiliation] aff on cadastro.[stonecode] = aff.[clientalternatekey]
    where
        cadastro.[companykey] = bd.[companykey]
        and aff.[affiliationkey] = bd.[affiliationkey]
        and cadastro.[flagkey] = bd.[flagkey]
        and cadastro.[bankkey] = bd.[bankkey]
        and cadastro.[bankbranch] = bd.[bankbranch]
        and cadastro.[bankaccountnumber] = bd.[bankaccountnumber]
)


insert into [stonedwv0].[dbo].[factbankingdomicilehistory] (
    companykey
    , affiliationkey
    , flagkey
    , bankkey
    , bankbranch
    , bankaccountnumber
    , enddate
)
    select
        tbd.[companykey]
        ,tbd.[affiliationkey]
        ,tbd.[flagkey]
        ,tbd.[bankkey]
        ,tbd.[bankbranch]
        ,tbd.[bankaccountnumber]
        ,tbd.[enddate]
    from
        #tempupdatebankingdomicile tbd


delete bd
    from [stonedwv0].[dbo].[dimbankingdomicile] bd
        where exists (
            select top 1 1
            from #tempupdatebankingdomicile tbd
            where
                tbd.[companykey] = bd.[companykey]
                and tbd.[affiliationkey] = bd.[affiliationkey]
                and tbd.[flagkey] = bd.[flagkey]
                and tbd.[bankkey] = bd.[bankkey]
                and tbd.[bankbranch] = bd.[bankbranch]
                and tbd.[bankaccountnumber] = bd.[bankaccountnumber]
        )


drop table #tempupdatebankingdomicile
