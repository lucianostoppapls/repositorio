insert into [dbo].[dimsalesstructure] ( [salesstructurenamelevel1]
, [salesstructurenamelevel2]
, [salesstructurenamelevel3]
, [salesstructurenamelevel4]
, [salesstructurenamelevel5]
, [salesstructurenamelevel6]
, [lastupdatedat])

select a.[salesstructurenamelevel1]
, a.[salesstructurenamelevel2]
, a.[salesstructurenamelevel3]
, a.[salesstructurenamelevel4]
, a.[salesstructurenamelevel5]
, a.[salesstructurenamelevel6]
,'{{ ds_nodash }}'
from {{ ti.xcom_pull('create_table') }} a
where not exists (select top 1 1 from [dbo].[dimsalesstructure] b where b.[salesstructurenamelevel1] = a.[salesstructurenamelevel1]
and b.[salesstructurenamelevel2] = a.[salesstructurenamelevel2]
and b.[salesstructurenamelevel3] = a.[salesstructurenamelevel3]
and b.[salesstructurenamelevel4] = a.[salesstructurenamelevel4]
and b.[salesstructurenamelevel5] = a.[salesstructurenamelevel5]
and b.[salesstructurenamelevel6] = a.[salesstructurenamelevel6])
