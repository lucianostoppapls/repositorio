use stonedwv0

delete from [stonedwv0].[dbo].[factrav]
where companykey in (1,2) and [contractdate] = '{{ ds_nodash }}'

insert into [dbo].[factrav] (
	[companykey]
	, [ravtypekey]
	, [vendorkey]
	, [contractdate]
	, [grossvalue]
	, [netvalue]
	, [revenue]
	, [duration]
	, [warranty]
	, [flagkey]
	, [productkey]
	, [durationwd]
	, [clienttypekey]
	, [affiliationkey]
	, [anticipations]
)

select
	rav.[companykey]
	, rav.[ravtypekey]
	, isnull(a.[vendorkey], 1)
	, replace(rav.[dt_contract], '-', '')
	, rav.[vl_bruto]
	, rav.[vl_liquido]
	, rav.[vl_receita]
	, rav.[vl_duration]
	, null
	, isnull(c.[flagkey], 9)
	, isnull(d.[productkey], 2)
	, [stonedwv0].[dbo].fc_workingdays(dateadd(day, isnull(rav.[vl_duration], 0), e.[fulldate]), e.[fulldate])
	, 5
	, isnull(f.[affiliationkey], 1)
	, rav.[qtd_antecipacoes]
from
	(select * from {{ ti.xcom_pull('create_table') }} where [companykey] in (1,2)) rav
left join (
	select
		vendoralternatekey
		, max(vendorkey) as [vendorkey]
	from
		[dbo].[dimvendor] 
	where
		vendoralternatekey is not null
	group by
		vendoralternatekey
) a on a.[vendoralternatekey] = isnull(rav.[id_registro], -1)
left join
	[dbo].[dimflag] c on rav.[bandeira] = c.[flagname]
left join
	[dbo].[dimproduct] d on (
		case
			when rav.[produto] = 'credito' then 'Crédito'
			when rav.[produto] = 'debito' then 'Débito'
			when rav.[produto] = 'outros' then 'Outro' end) = d.[productname]
inner join [dbo].[dimdate] e  on rav.[dt_contract] = e.[fulldate]
left join (select distinct n.[clientalternatekey]
, n.[affiliationkey]
, m.[clientkey]
from [dbo].[dimclient] m 
inner join [dbo].[dimaffiliation] n on m.[clientkey] = n.[clientkey]
where n.[clientalternatekey] is not null and n.[companykey] in (1,2)) f on f.[clientalternatekey] = isnull(rav.[nr_mid], -1)


-- update client type

if object_id('tempdb..#tmpclienttype') is not null
	drop table #tmpclienttype;

select
	a.[affiliationkey]
	, [clientalternatekey]
into
	#tmpclienttype
from
	[dbo].[factrav]  a
inner join
	[dbo].[dimdate] b on a.[contractdate] = b.[datekey]
left join
	[dbo].[dimaffiliation] c on a.[affiliationkey] = c.[affiliationkey]
where
	eomonth([fulldate]) = eomonth('{{ ds }}')
group by
	a.[affiliationkey], [clientalternatekey]


if object_id('tempdb..#ravclienttype') is not null
	drop table #ravclienttype;

select
	c.[affiliationkey]
	, c.[clientalternatekey]
	, '{{ ds_nodash }}' as [contractdate]
	, 3 as [clienttypekey]
into
	#ravclienttype
from
	#tmpclienttype c
where exists (
	select top 1 1
	from
		[dbo].[factrav] a 
	inner join
		[dbo].[dimdate] b on a.[contractdate] = b.[datekey]
	where
		c.[affiliationkey] = a.[affiliationkey]
		and eomonth(b.[fulldate]) = eomonth('{{ ds }}', -1)
)
group by
	c.[affiliationkey]
	, c.[clientalternatekey]

union

select
	c.[affiliationkey]
	, c.[clientalternatekey]
	, '{{ds_nodash}}' as [contractdate]
	, 1 as [clienttypekey]
from
	#tmpclienttype c
where
	not exists (
		select top 1 1
		from
			[dbo].[factrav] a 
		inner join
			[dbo].[dimdate] b on a.[contractdate] = b.[datekey]
		where
			c.[affiliationkey] = a.[affiliationkey]
			and eomonth(b.[fulldate]) = eomonth('{{ ds }}', -1)
	)
	and not exists (
		select top 1 1
		from
			[dbo].[dimaffiliation] a
		inner join
			[dbo].[dimclient] b on a.[clientkey] = b.[clientkey]
		inner join
			[dbo].[dimdate] d on b.[createdate] = d.[datekey]
		where
			c.[affiliationkey] = a.[affiliationkey]
			and eomonth(fulldate) = eomonth('{{ds}}')
	)
group by
	c.[affiliationkey]
	, c.[clientalternatekey]

union

select
	c.affiliationkey
	, c.clientalternatekey
	, '{{ds_nodash}}' as contractdate
	, 6 as clienttypekey
from
	#tmpclienttype c
inner join
	[dbo].[dimaffiliation] d on c.affiliationkey = d.affiliationkey
inner join
	[dbo].[dimclient] e on d.clientkey = e.clientkey
inner join
	[dbo].[dimdate] f on e.createdate = f.datekey
where
	eomonth(fulldate) = eomonth('{{ds}}')
group by
	c.affiliationkey,
	c.clientalternatekey


update a
set
	a.[clienttypekey] = b.[clienttypekey]
from
	[dbo].[factrav] a
inner join
	#ravclienttype b on a.[affiliationkey] = b.[affiliationkey]
inner join
	[dbo].[dimdate] c on a.[contractdate] = c.[datekey]
where
	eomonth(fulldate) = eomonth('{{ ds }}')


-- update rav


--------------------------------------------------------
-------------------- Filtro de Data --------------------
--------------------------------------------------------
	

	IF DATENAME(WEEKDAY, GETDATE()) = 'Monday'

		BEGIN

			UPDATE [StoneDWv0].[dbo].[DimDate] 
			SET [Filter] = 1
			WHERE [Filter] = 0


			UPDATE [StoneDWv0].[dbo].[DimDate] 
			SET [Filter] = 0
			WHERE DateKey IN (SELECT MAX(DateKey) DateKey
								FROM [StoneDWv0].[dbo].[DimDate]
								WHERE FullDate <=  GETDATE() - 1
									AND DayNameOfWeek in ('sábado', 'domingo')
								GROUP BY DayNameOfWeek)

		END

		ELSE 

		BEGIN

			UPDATE [StoneDWv0].[dbo].[DimDate] 
			SET [Filter] = 1
			WHERE [Filter] = 0

		END 


--------------------------------------------------------
----------------------- Curba DI -----------------------
--------------------------------------------------------

update a
set
	a.[workdaydirate] = b.[workdaydirate],
	a.[rateoverdi] = isnull((power(([grossvalue] / nullif(([grossvalue] - [revenue]), 0)), (1.00 / nullif([durationwd], 0)))-1) / nullif(b.[workdaydirate], 0), 0)
from
	[dbo].[factrav] a
left join
	[stonedwv0].[dbo].[factdicurve] b on 
		a.[contractdate] = b.[referencedate] 
		and a.[durationwd] = b.[workdays]
inner join
	[stonedwv0].[dbo].dimdate c on a.[contractdate] = c.[datekey]
where
	eomonth([fulldate]) = eomonth('{{ ds }}')
