use stonedwv0

delete a
from [stonedwv0].[dbo].[factrental] a
inner join [stonedwv0].[dbo].[dimdate] b on a.[datekey] = b.[datekey]
where eomonth([fulldate]) = eomonth('{{ ds }}') and companykey in (1,2)

if object_id('tempdb..#carteirarota') is not null
	drop table #carteirarota;

 select distinct 
	e.[nr_mid] as [nr_mid]
	, isnull(iif(y.[geographykey] is null,1 ,e.[nr_cep]),1) as [nr_cep]
	, isnull(e.[dt_criacao_tombamento], e.[dt_criacao]) as [dt_criacao_tombamento]
	, isnull(e.[dt_criacao], e.[dt_criacao_tombamento]) as [dt_criacao]
	, e.[in_tombamento] as [in_tombamento]
	, e.[nr_mcc] as [nr_mcc]
	, e.[nm_fantasia] as [nm_fantasia]
	, e.[nr_cnpj] as [nr_cnpj]
	, e.[id_registro] as [id_registro]
	, e.[nm_razao_social] as [nm_razao_social]
	, e.[ds_status_ec] as [ds_status_ec]
	, (case when isnull(e.[ds_canal],'') = '' then 'n/d' else e.[ds_canal] end) as [ds_canal]
	, (case when isnull(e.[nm_subcanal],'') = '' then 'n/d' else e.[nm_subcanal] end) as [nm_subcanal]
	, (case when isnull(e.[ds_grupo1],'') = '' then '-' else e.[ds_grupo1] end) as [ds_grupo1]
	, (case when isnull(e.[ds_grupo2],'') = '' then '-' else e.[ds_grupo2] end) as [ds_grupo2]
	, (case when isnull(e.[ds_grupo3],'') = '' then '-' else e.[ds_grupo3] end) as [ds_grupo3]
	, isnull(b.[name], case when isnull([ds_grupo3],'') = '' then '-' else [ds_grupo3] end) as [ds_grupo4]
	, e.[nm_cadeia] as [nm_cadeia]
into #carteirarota
from [stonedwv0].[dbo].[dimaccount] a
inner join [stonedwv0].[dbo].[dimterritory2] b on b.[territory2key] = a.[route]
inner join [stonedwv0].[dbo].[dimterritory2type] c on b.[territory2typekey] = c.[territory2typekey]
inner join [stonedwv0].[dbo].[dimterritory2] d on b.[parentterritory2key] = d.[territory2key]
inner join {{ ti.xcom_pull('create_table') }} e on a.[clientalternatekey] = e.[nr_mid] and d.[name] = e.[ds_grupo3]
left join [stonedwv0].[dbo].[dimgeography] y on e.[nr_cep] = y.[geographykey]
where (c.[masterlabel] = 'rota'
and b.[active] = 1
and a.[clientalternatekey] <> 1
and e.[nm_subcanal] = 'polo próprio'
and a.[name] <> 'duplicada')

if object_id('tempdb..#cadastro') is not null
	drop table #cadastro;

 select distinct a.[nr_mid] as [nr_mid]
, isnull(iif(y.[geographykey] is null, 1,a.[nr_cep]), 1) as [nr_cep]
, a.[nr_cnpj] as [nr_cnpj]
, iif(a.[dt_criacao]<=a.[dt_criacao_tombamento],replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao_tombamento]
, isnull(replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao]
, a.[in_tombamento] as [in_tombamento]
, a.[nr_mcc] as [nr_mcc]
, a.[nm_fantasia] as [nm_fantasia]
, a.[id_registro] as [id_registro]
, a.[nm_razao_social] as [nm_razao_social]
, isnull(a.[ds_status_ec], 'credenciado') as [ds_status_ec]
, isnull(a.[ds_canal], 'n/d') as [ds_canal]
, isnull(a.[nm_subcanal], 'n/d') as [nm_subcanal]
, isnull(a.[ds_grupo1], '-') as [ds_grupo1]
, isnull(a.[ds_grupo2], '-') as [ds_grupo2]
, isnull(a.[ds_grupo3], '-') as [ds_grupo3]
, isnull(a.[ds_grupo3], '-') as [ds_grupo4]
, iif(len(a.[nr_mid]) > 10, 2, 1) as [companykey]
, a.[nm_cadeia]
into #cadastro
from {{ ti.xcom_pull('create_table') }} a
left join [stonedwv0].[dbo].[dimgeography] y on a.[nr_cep] = y.[geographykey]
where not exists (select top 1 1 from #carteirarota b where a.[nr_mid] = b.[nr_mid])

union

select a.[nr_mid] as [nr_mid]
, isnull(iif(y.[geographykey] is null, 1,a.[nr_cep]), 1) as [nr_cep]
, a.[nr_cnpj] as [nr_cnpj]
, iif(a.[dt_criacao]<=a.[dt_criacao_tombamento],replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao_tombamento]
, isnull(replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao]
, a.[in_tombamento] as [in_tombamento]
, a.[nr_mcc] as [nr_mcc]
, a.[nm_fantasia] as [nm_fantasia]
, a.[id_registro] as [id_registro]
, a.[nm_razao_social] as [nm_razao_social]
, a.[ds_status_ec] as [ds_status_ec]
, a.[ds_canal] as [ds_canal]
, a.[nm_subcanal] as [nm_subcanal]
, a.[ds_grupo1] as [ds_grupo1]
, a.[ds_grupo2] as [ds_grupo2]
, a.[ds_grupo3] as [ds_grupo3]
, min(a.[ds_grupo4]) as [ds_grupo4]
, iif(len(a.[nr_mid]) > 10, 2, 1) as [companykey]
, a.[nm_cadeia]
from #carteirarota a
left join [stonedwv0].[dbo].[dimgeography] y on a.[nr_cep] = y.[geographykey]
group by a.[nr_mid]
, isnull(iif(y.[geographykey] is null,1 ,a.[nr_cep]),1)
, a.[nr_cnpj]
, iif(a.[dt_criacao]<=a.[dt_criacao_tombamento],replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', ''))
, isnull(replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', ''))
, a.[in_tombamento]
, a.[nr_mcc]
, a.[nm_fantasia]
, a.[id_registro]
, a.[nm_razao_social]
, a.[ds_status_ec]
, a.[ds_canal]
, a.[nm_subcanal]
, a.[ds_grupo1]
, a.[ds_grupo2]
, a.[ds_grupo3]
, iif(len(a.[nr_mid]) > 10,2,1)
, [nm_cadeia]

if object_id('tempdb..#basedataaluguel') is not null
	drop table #basedataaluguel;

select eomonth('{{ ds }}') as [dt_base]
, b.[nr_mid]
, min(vendor.[vendorkey]) [vendorkey]
, cast(0 as [decimal](38, 2)) as [chargedrent]
, cast(0 as [decimal](38, 2)) as [receivedrent]
, cast(0 as [decimal](38, 2)) as [estimatedrent]
, 0 as [totalpos]
, 0 as [totalpinpad]
, client.[affiliationkey]
into #basedataaluguel
from #cadastro b 
inner join (select [vendoralternatekey], [vendorkey]
from [stonedwv0].[dbo].[dimvendor] 
where [vendoralternatekey] is not null) vendor on vendor.[vendoralternatekey] =  isnull(b.[id_registro],-1)
inner join (select distinct b.[clientalternatekey]
, b.[affiliationkey]
, a.[clientkey]
from [stonedwv0].[dbo].[dimclient] a 
inner join [stonedwv0].[dbo].[dimaffiliation] b on a.[clientkey] = b.[clientkey]
where b.[clientalternatekey] is not null and b.[companykey] in (1,2)) client on client.[clientalternatekey] = isnull(b.[nr_mid],-1)
group by b.[nr_mid]
, [affiliationkey]

create index tmp_idx_3 on #basedataaluguel (nr_mid, vendorkey)

update a
set a.[totalpos] = [nr_pos]
, a.[totalpinpad] = [nr_pinpad]
from #basedataaluguel a
inner join {{ ti.xcom_pull('create_support_table_1') }} b 
on a.[nr_mid] = b.[nr_mid] and eomonth(a.[dt_base]) = eomonth(b.[dt_base])

update a
set a.[receivedrent] = isnull(g.[vl_receita], 0)
from #basedataaluguel a
inner join {{ ti.xcom_pull('create_support_table_2') }} as g
on a.[nr_mid] = g.[nr_mid]  and eomonth(a.[dt_base]) = eomonth(g.[dt_base])

update a
set a.[chargedrent] = isnull(g.[vl_cobrado], 0)
from #basedataaluguel a
inner join {{ ti.xcom_pull('create_support_table_3') }} as g
on a.[nr_mid] = g.[nr_mid] and eomonth(a.[dt_base]) = eomonth(g.[dt_base])

update a
set a.[estimatedrent] = b.[aluguel]
from #basedataaluguel a
inner join {{ ti.xcom_pull('create_support_table_4') }} b on a.[nr_mid] = b.[nr_stonecode]

delete from #basedataaluguel
where [chargedrent] = 0 and [receivedrent] = 0 and [estimatedrent] = 0

insert into [dbo].[factrental] ([companykey]
, [datekey]
, [vendorkey]
, [chargedrent]
, [receivedrent]
, [estimatedrent]
, [totalpos]
, [totalpinpad]
, [affiliationkey])

select iif(len(z.[nr_mid]) > 10, 2, 1)
, replace(eomonth(z.[dt_base]), '-', '')
, z.[vendorkey]
, isnull(z.[chargedrent],0) [chargedrent]
, isnull(z.[receivedrent],0) [receivedrent]
, isnull(z.[estimatedrent],0) [estimatedrent]
, isnull(z.[totalpos],0) [totalpos]
, isnull(z.[totalpinpad],0) [totalpinpad]
, [affiliationkey]
from #basedataaluguel z
