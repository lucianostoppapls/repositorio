select
    sum(vl_cobrado) as [vl_cobrado]
    , [nr_mid]
    , eomonth(dt_base) as [dt_base]
from
    [bdmdmis_stone].[dbo].[tbstonef_receita_al_cn_outras] 
where
    ds_categoria = 'aluguel'
    and eomonth([dt_base]) = eomonth('{{ ds }}')
group by
    nr_mid
    , eomonth([dt_base])
