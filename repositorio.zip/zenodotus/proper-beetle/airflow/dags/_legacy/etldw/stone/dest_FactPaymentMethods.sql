INSERT INTO StoneDWv0.dbo.FactPaymentMethods (
    AffiliationKey,
    POSQuantity,
    PinPadQuantity,
    MobileQuantity,
    EccomerceQuantity
)
SELECT Affiliationkey,
        QtdPOS,
        QtdPinpad,
        QtdMobile,
        QtdEcommerce
FROM {{ ti.xcom_pull('create_table') }} A
JOIN StoneDWv0.dbo.DimAffiliation B ON CAST(A.Stonecode as varchar(12)) = B.ClientAlternateKey
WHERE NOT EXISTS (SELECT TOP 1 1 FROM StoneDWv0.dbo.FactPaymentMethods C WHERE B.AffiliationKey = C.AffiliationKey)

INSERT INTO StoneDWv0.dbo.FactPaymentMethodsHistory (
    AffiliationKey,
    EndDate,
    POSQuantity,
    PinPadQuantity,
    MobileQuantity,
    EccomerceQuantity
)
SELECT A.Affiliationkey,
    CAST(REPLACE(CAST(GETDATE() AS DATE),'-','') AS INT),
    A.POSQuantity,
    A.PinPadQuantity,
    A.MobileQuantity,
    A.EccomerceQuantity
FROM StoneDWv0.dbo.FactPaymentMethods A
JOIN StoneDWv0.dbo.DimAffiliation B ON A.Affiliationkey = B.Affiliationkey
JOIN {{ ti.xcom_pull('create_table') }} C ON B.ClientAlternateKey = CAST(C.Stonecode AS VARCHAR(12))
WHERE (
    A.POSQuantity <> QtdPOS
    OR A.PinPadQuantity <> QtdPinpad
    OR A.MobileQuantity <> QtdMobile
    OR A.EccomerceQuantity <> QtdEcommerce)

UPDATE A
SET
    A.POSQuantity = QtdPOS,
    A.PinPadQuantity = QtdPinpad,
    A.MobileQuantity = QtdMobile,
    A.EccomerceQuantity = QtdEcommerce
FROM StoneDWv0.dbo.FactPaymentMethods A
JOIN StoneDWv0.dbo.DimAffiliation B ON A.Affiliationkey = B.Affiliationkey
JOIN {{ ti.xcom_pull('create_table') }} C ON B.ClientAlternateKey = CAST(C.Stonecode AS  VARCHAR(12))
WHERE (
    A.POSQuantity <> QtdPOS
    OR A.PinPadQuantity <> QtdPinpad
    OR A.MobileQuantity <> QtdMobile
    OR A.EccomerceQuantity <> QtdEcommerce
)
