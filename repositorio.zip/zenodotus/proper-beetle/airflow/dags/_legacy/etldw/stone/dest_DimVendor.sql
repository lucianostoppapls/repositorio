use stonedwv0

if object_id('tempdb..#cadastrovendedorrota_vendor') is not null
	drop table #cadastrovendedorrota_vendor;

select distinct h.[ds_emailvendedor]
, h.[id_registro]
, h.[nm_portal]
, h.[nm_exibicao]
, g.[salesstructurenamelevel1] [ds_canal]
, g.[salesstructurenamelevel2] [nm_subcanal]
, g.[salesstructurenamelevel3] [ds_grupo1]
, g.[salesstructurenamelevel4] [ds_grupo2]
, g.[salesstructurenamelevel5] [ds_grupo3]
, g.[salesstructurenamelevel6] [ds_grupo4]
, h.[nm_forca_venda]
into #cadastrovendedorrota_vendor
from [dbo].[dimuserterritory2association] a
inner join [dbo].[dimuser] b on a.[userkey] = b.[userkey]
inner join [dbo].[dimterritory2] c on a.[territory2key] = c.[territory2key]
and c.[active] = 1
and c.[territory2typekey] = '0m541000000cdhvcak'
inner join [dbo].dimterritory2 d on c.[parentterritory2key] = d.[territory2key]
and d.[active] = 1
and d.[territory2typekey] = '0m541000000cdi0cak'
inner join [dbo].[dimterritory2] e on d.[parentterritory2key]  = e.[territory2key]
and e.[active] = 1
and e.[territory2typekey] = '0m541000000cdi5cak'
inner join dimterritory2 f on e.[parentterritory2key]  = f.[territory2key]
and f.[territory2typekey] = '0m541000000cdiaca0'
inner join [dbo].[dimsalesstructure] g on g.[salesstructurenamelevel6] = isnull(c.[name], d.[name])
and g.[salesstructurenamelevel5] = isnull(d.[name], '-')
and g.[salesstructurenamelevel4] = isnull(e.[name], '-')
and g.[salesstructurenamelevel3] = isnull(f.[name], '-')
and g.[salesstructurenamelevel2] = 'Polo Proprio'
and g.[salesstructurenamelevel1] = 'Expansao'
inner join (select * from {{ ti.xcom_pull('create_table') }} where companykey = 1) h on h.[ds_emailvendedor] = b.[email]

-- carrega #cadastrovendedor_vendor

if object_id('tempdb..#cadastrovendedor_vendor') is not null
	drop table #cadastrovendedor_vendor;

select b.[ds_emailvendedor]
, b.[id_registro]
, b.[nm_portal]
, b.[nm_exibicao]
, b.[ds_canal]
, b.[nm_subcanal]
, b.[ds_grupo1]
, b.[ds_grupo2]
, b.[ds_grupo3]
, b.[ds_grupo4]
, b.[nm_forca_venda]
, b.[ds_time_portal]
into #cadastrovendedor_vendor
from {{ ti.xcom_pull('create_support_table') }} b
where not exists (select top 1 1 from #cadastrovendedorrota_vendor c where b.[id_registro] = c.id_registro)

union

select m.[ds_emailvendedor]
, m.[id_registro]
, m.[nm_portal]
, m.[nm_exibicao]
, m.[ds_canal]
, m.[nm_subcanal]
, m.[ds_grupo1]
, m.[ds_grupo2]
, m.[ds_grupo3]
, m.[ds_grupo4]
, m.[nm_forca_venda]
, o.[ds_time_portal]
from #cadastrovendedorrota_vendor m
inner join [bdmdmis_stone].[dbo].[tbstonef_cadastro_integrado_ec] o on  m.[id_registro] = o.[id_registro]

-- carrega #tempvendor

if object_id('tempdb..#tempvendor') is not null
	drop table #tempvendor;

select a.[vendorkey]
into #tempvendor
from [stonedwv0].[dbo].[dimvendor] a 
where exists (select top(1) 1 from #cadastrovendedor_vendor t 
	inner join [stonedwv0].[dbo].[dimsalesstructure] c  on c.[salesstructurekey] = a.[salesstructurekey] and t.[id_registro] = a.[vendoralternatekey]
	where (replace(ltrim(rtrim(replace(replace(t.[nm_portal], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(a.[vendorname], char(9), ''), char(32), ''))), '"', '')
		or isnull(replace(ltrim(rtrim(replace(replace(t.[nm_exibicao], char(9), ''), char(32), ''))), '"', ''),replace(ltrim(rtrim(replace(replace(t.[nm_portal], char(9), ''), char(32), ''))), '"', '')) <> replace(ltrim(rtrim(replace(replace(a.[vendornickname], char(9), ''), char(32), ''))), '"', '')
		or isnull(replace(ltrim(rtrim(replace(replace(t.[ds_emailvendedor], char(9), ''), char(32), ''))), '"', ''),'') <> isnull(isnull(replace(ltrim(rtrim(replace(replace(a.[EmailAddress], char(9), ''), char(32), ''))), '"', ''),''),'')
		or c.[salesstructurenamelevel1] <>  case when isnull(t.[ds_canal],'')    = '' then 'N/D' else t.[ds_canal] end
		or c.[salesstructurenamelevel2] <>  case when isnull(t.[nm_subcanal],'') = '' then 'N/D' else t.[nm_subcanal] end
		or c.[salesstructurenamelevel3] <>  case when isnull(t.[ds_grupo1],'')   = '' then '-' else t.[ds_grupo1] end
		or c.[salesstructurenamelevel4] <>  case when isnull(t.[ds_grupo2],'')   = '' then '-' else t.[ds_grupo2] end
		or c.[salesstructurenamelevel5] <>  case when isnull(t.[ds_grupo3],'')   = '' then '-' else t.[ds_grupo3] end
		or c.[salesstructurenamelevel6] <> t.[ds_grupo4])
		or isnull(replace(ltrim(rtrim(replace(replace(t.[nm_forca_venda], char(9), ''), char(32), ''))), '"', ''),'') <> isnull(replace(ltrim(rtrim(replace(replace(a.[salesforcename], char(9), ''), char(32), ''))), '"', ''),'')
		or isnull(a.[saleschannel], 'N/D') <> isnull(t.[ds_time_portal], 'N/D'))

-- insert dimvendorhist

insert into [stonedwv0].[dbo].[dimvendorhist] ([vendorkey]
, [parentvendorkey]
, [cpf]
, [salesstructurekey]
, [vendorname]
, [vendornickname]
, [hiredate]
, [birthdate]
, [loginid]
, [emailaddress]
, [phone]
, [gender]
, [enddate]
, [vendoralternatekey]
, [salesforcename]
, [saleschannel])

select [vendorkey]
, [parentvendorkey]
, [cpf]
, [salesstructurekey]
, [vendorname]
, [vendornickname]
, [hiredate]
, [birthdate]
, [loginid]
, [emailaddress]
, [phone]
, [gender]
, '{{ ds }}'
, [vendoralternatekey]
, [salesforcename]
, [saleschannel]
from [stonedwv0].[dbo].[dimvendor] 
where [vendorkey] in (select vendorkey from #tempvendor)

-- update dimvendor

update d
set d.[salesstructurekey] = c.[salesstructurekey]
, d.[vendorname] = a.[nm_portal]
, d.[vendornickname] = isnull(a.[nm_exibicao],a.[nm_portal])
, d.[emailaddress] = case when a.[ds_emailvendedor] = '' then null else a.[ds_emailvendedor] end
, d.[salesforcename] = a.[nm_forca_venda]
, d.[saleschannel] = isnull(a.[ds_time_portal], 'N/D')
from [stonedwv0].[dbo].[dimvendor] d 
inner join #cadastrovendedor_vendor a  on a.[id_registro] = d.[vendoralternatekey]
inner join [stonedwv0].[dbo].[dimsalesstructure] c  on (c.[salesstructurenamelevel1] = case when isnull(a.[ds_canal],'') = '' then 'N/D' else a.[ds_canal] end
and c.[salesstructurenamelevel2] = case when isnull(a.[nm_subcanal],'') = '' then 'N/D' else a.[nm_subcanal] end
and c.[salesstructurenamelevel3] = case when isnull(a.[ds_grupo1],'') = '' then '-' else a.[ds_grupo1] end
and c.[salesstructurenamelevel4] = case when isnull(a.[ds_grupo2],'') = '' then '-' else a.[ds_grupo2] end
and c.[salesstructurenamelevel5] = case when isnull(a.[ds_grupo3],'') = '' then '-' else a.[ds_grupo3] end
and c.[salesstructurenamelevel5] = case when isnull(a.[ds_grupo3],'') = '' then '-' else a.[ds_grupo3] end
and c.[salesstructurenamelevel6] = case when isnull(a.[ds_grupo4],'') = '' then '-' else a.[ds_grupo4] end )
where d.[vendorkey] in (select [vendorkey] from #tempvendor)

-- insert dimvendor

insert into [stonedwv0].[dbo].[dimvendor] ([salesstructurekey]
, [vendorname]
, [vendornickname]
, [emailaddress]
, [vendoralternatekey]
, [salesforcename]
, [saleschannel])

select c.[salesstructurekey]
, a.[nm_portal]
, isnull(a.[nm_exibicao],a.[nm_portal])
, case when a.[ds_emailvendedor] = '' then null else a.[ds_emailvendedor] end
, a.[id_registro]
, a.[nm_forca_venda]
, isnull(a.[ds_time_portal], 'N/D')
from #cadastrovendedor_vendor a 
inner join [stonedwv0].[dbo].[dimsalesstructure] c  on (c.[salesstructurenamelevel1] = isnull(a.[ds_canal],'N/D')
and c.[salesstructurenamelevel2] = isnull(a.[nm_subcanal],'N/D')
and c.[salesstructurenamelevel3] = isnull(a.[ds_grupo1],'-')
and c.[salesstructurenamelevel4] = isnull(a.[ds_grupo2],'-')
and c.[salesstructurenamelevel5] = isnull(a.[ds_grupo3],'-')
and c.[salesstructurenamelevel6] = isnull(a.[ds_grupo4], '-'))
where not exists (select top(1) 1 from [stonedwv0].[dbo].[dimvendor] b   where a.[id_registro] = b.[vendoralternatekey])

-- insert dimvendorhistory

insert into [stonedwv0].[dbo].[dimvendorhistory] ([vendorkey]
, [parentvendorkey]
, [cpf]
, [salesstructurekey]
, [vendorname]
, [vendornickname]
, [hiredate]
, [birthdate]
, [loginid]
, [emailaddress]
, [phone]
, [gender]
, [vendoralternatekey]
, [vendoralternatekeypagarme]
, [salesforcename]
, [vendoralternatekeymundi]
, [saleschannel])

select [vendorkey]
, a.[parentvendorkey]
, a.[cpf]
, a.[salesstructurekey]
, a.[vendorname]
, a.[vendornickname]
, a.[hiredate]
, a.[birthdate]
, a.[loginid]
, a.[emailaddress]
, a.[phone]
, a.[gender]
, a.[vendoralternatekey]
, a.[vendoralternatekeypagarme]
, a.[salesforcename]
, a.[vendoralternatekeymundi]
, a.[saleschannel]
from [stonedwv0].[dbo].[dimvendor] a
where not exists (select top 1 1 from [stonedwv0].[dbo].[dimvendorhistory] b where a.[vendorkey] = b.[vendorkey])
