use stonedwv0

insert into [dbo].[dimmcc] (mcckey
, mccname
, mcccluster
, lastupdatedat)

select a.[mcckey]
, a.[mccname]
, a.[mcccluster]
,'{{ ds_nodash }}'
from {{ ti.xcom_pull('create_table') }} a
where not exists (select top 1 1 from [dbo].[dimmcc] b where a.[mcckey] = b.[mcckey])

update c
set c.[mccname] = d.[mcccluster]
, c.[mcccluster] = d.[mcccluster]
, c.[lastupdatedat] = '{{ ds_nodash }}'
from {{ ti.xcom_pull('create_table') }} d
inner join [dbo].[dimmcc] c on c.[mcckey] = d.[mcckey]
where isnull(d.[mccname], 'default') <> isnull(c.[mccname], 'default')
or isnull(d.[mcccluster], 'default') <> isnull(c.[mcccluster], 'default')

