insert into StoneDWv0.dbo.DimSalesStructure (
    SalesStructureNameLevel1,
    SalesStructureNameLevel2,
    SalesStructureNameLevel3,
    SalesStructureNameLevel4,
    SalesStructureNameLevel5,
    SalesStructureNameLevel6
)
select distinct
    coalesce(ds_canal,'N/D'),
    coalesce(ds_subcanal,'N/D'),
    coalesce(ds_grupo1,'N/D'),
    coalesce(ds_grupo2,'N/D'),
    coalesce(nm_cadeia,'N/D'),
    coalesce(nm_cadeia,'N/D')
from {{ ti.xcom_pull('create_chains_temp_table') }} a
where not exists (
    select top 1 1
    from StoneDWv0.dbo.DimSalesStructure ss
    where coalesce(a.ds_canal,'N/D') = ss.SalesStructureNameLevel1
        and coalesce(a.ds_subcanal,'N/D') = ss.SalesStructureNameLevel2
        and coalesce(a.ds_grupo1,'N/D') = ss.SalesStructureNameLevel3
        and coalesce(a.ds_grupo2,'N/D') = ss.SalesStructureNameLevel4
        and coalesce(a.nm_cadeia,'N/D') = ss.SalesStructureNameLevel5
        and coalesce(a.nm_cadeia,'N/D') = ss.SalesStructureNameLevel6
);


insert into StoneDwV0.dbo.DimChain (
    ChainName,
    CreateDate,
    ChainTypeKey,
    SalesStructurekey,
    AccountKey,
    ChainAlternatekey
)

select
    nm_cadeia,
    cast(replace(cast(dt_criacao as date),'-','') as int),
    case when ds_tipo='c' then 1
        when ds_tipo='f' then 2
        else 3 end,
    ss.SalesStructurekey,
    cadeia_alternate_key,
    nr_cadeia
from {{ ti.xcom_pull('create_chains_temp_table') }} a
join StoneDWv0.dbo.DimSalesStructure ss on coalesce(a.ds_canal,'N/D') = ss.SalesStructureNameLevel1
                                        and coalesce(a.ds_subcanal,'N/D') = ss.SalesStructureNameLevel2
                                        and coalesce(a.ds_grupo1,'N/D') = ss.SalesStructureNameLevel3
                                        and coalesce(a.ds_grupo2,'N/D') = ss.SalesStructureNameLevel4
                                        and coalesce(a.nm_cadeia,'N/D') = ss.SalesStructureNameLevel5
                                        and coalesce(a.nm_cadeia,'N/D') = ss.SalesStructureNameLevel6
where not exists (
    select top 1 1
    from StoneDwV0.dbo.DimChain b
    where a.nr_cadeia = b.ChainAlternatekey
);

update a
set
    a.ChainName = b.nm_cadeia,
    a.CreateDate = cast(replace(cast(b.dt_criacao as date),'-','') as int),
    a.ChainTypeKey = case when ds_tipo='c' then 1  when ds_tipo='f' then 2 else 3 end,
    a.SalesStructurekey = ss.SalesStructurekey,
    a.AccountKey = b.cadeia_alternate_key
from StoneDwV0.dbo.DimChain a
join {{ ti.xcom_pull('create_chains_temp_table') }} b on a.ChainAlternatekey = b.nr_cadeia
join StoneDWv0.dbo.DimSalesStructure ss on coalesce(b.ds_canal,'N/D') = ss.SalesStructureNameLevel1
                                        and coalesce(b.ds_subcanal,'N/D') = ss.SalesStructureNameLevel2
                                        and coalesce(b.ds_grupo1,'N/D') = ss.SalesStructureNameLevel3
                                        and coalesce(b.ds_grupo2,'N/D') = ss.SalesStructureNameLevel4
                                        and coalesce(b.nm_cadeia,'N/D') = ss.SalesStructureNameLevel5
                                        and coalesce(b.nm_cadeia,'N/D') = ss.SalesStructureNameLevel6
where (
    a.ChainName <> b.nm_cadeia
    or a.CreateDate <> cast(replace(cast(b.dt_criacao as date),'-','') as int)
    or a.ChainTypeKey <> case when ds_tipo='c' then 1  when ds_tipo='f' then 2 else 3 end
    or a.SalesStructurekey <> ss.SalesStructurekey
    or a.AccountKey <> b.cadeia_alternate_key
);
