use stonedwv0

if object_id('tempdb..#dimaffiliation_carteirarota') is not null
	drop table #dimaffiliation_carteirarota;

select distinct
	e.[nr_mid] as [nr_mid]
	, isnull(iif(y.[geographykey] is null,1 ,e.[nr_cep]),1) as [nr_cep]
	, isnull(e.[dt_criacao_tombamento], e.[dt_criacao]) as [dt_criacao_tombamento]
	, isnull(e.[dt_criacao], e.[dt_criacao_tombamento]) as [dt_criacao]
	, e.[in_tombamento] as [in_tombamento]
	, e.[nr_mcc] as [nr_mcc]
	, e.[nm_fantasia] as [nm_fantasia]
	, e.[nr_cnpj] as [nr_cnpj]
	, e.[id_registro] as [id_registro]
	, e.[nm_razao_social] as [nm_razao_social]
	, e.[ds_status_ec] as [ds_status_ec]
	, (case when isnull(e.[ds_canal],'') = '' then 'N/D' else e.[ds_canal] end) as [ds_canal]
	, (case when isnull(e.[nm_subcanal],'') = '' then 'N/D' else e.[nm_subcanal] end) as [nm_subcanal]
	, (case when isnull(e.[ds_grupo1],'') = '' then '-' else e.[ds_grupo1] end) as [ds_grupo1]
	, (case when isnull(e.[ds_grupo2],'') = '' then '-' else e.[ds_grupo2] end) as [ds_grupo2]
	, (case when isnull(e.[ds_grupo3],'') = '' then '-' else e.[ds_grupo3] end) as [ds_grupo3]
	, isnull(b.[name], case when isnull([ds_grupo3],'') = '' then '-' else [ds_grupo3] end) as [ds_grupo4]
	, e.[nm_cadeia] as [nm_cadeia]
	, ISNULL(e.[partnername], 'N/D') as [partnername]
	, ISNULL(e.[subscriptionplanid], 'N/D') as [subscriptionplanid]
into #dimaffiliation_carteirarota
from
	[stonedwv0].[dbo].[dimaccount] a
inner join
	[stonedwv0].[dbo].[dimterritory2] b on b.[territory2key] = a.[route]
inner join
	[stonedwv0].[dbo].[dimterritory2type] c on b.[territory2typekey] = c.[territory2typekey]
inner join
	[stonedwv0].[dbo].[dimterritory2] d on b.[parentterritory2key] = d.[territory2key]
inner join (
	select *
	from
		{{ ti.xcom_pull('create_table') }} 
	where [nr_mid] is not null
) e on a.[clientalternatekey] = e.[nr_mid] and d.[name] = e.[ds_grupo3]
left join
	[stonedwv0].[dbo].[dimgeography] y on e.[nr_cep] = y.[geographykey]
where
	c.[masterlabel] = 'Rota'
	and b.[active] = 1
	and a.[clientalternatekey] <> 1
	and e.[nm_subcanal] = 'Polo Proprio'
	and a.[name] <> 'Duplicada'

if object_id('tempdb..#dimaffiliation_cadastro') is not null
	drop table #dimaffiliation_cadastro;

select distinct
	a.[nr_mid] as [nr_mid]
	, isnull(iif(y.[geographykey] is null, 1,a.[nr_cep]), 1) as [nr_cep]
	, a.[nr_cnpj] as [nr_cnpj]
	, iif(a.[dt_criacao]<=a.[dt_criacao_tombamento],replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao_tombamento]
	, isnull(replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao]
	, a.[in_tombamento] as [in_tombamento]
	, a.[nr_mcc] as [nr_mcc]
	, a.[nm_fantasia] as [nm_fantasia]
	, a.[id_registro] as [id_registro]
	, a.[nm_razao_social] as [nm_razao_social]
	, isnull(a.[ds_status_ec], 'Credenciado') as [ds_status_ec]
	, isnull(a.[ds_canal], 'N/D') as [ds_canal]
	, isnull(a.[nm_subcanal], 'N/D') as [nm_subcanal]
	, isnull(a.[ds_grupo1], '-') as [ds_grupo1]
	, isnull(a.[ds_grupo2], '-') as [ds_grupo2]
	, isnull(a.[ds_grupo3], '-') as [ds_grupo3]
	, isnull(a.[ds_grupo3], '-') as [ds_grupo4]
	, iif(len(a.[nr_mid]) > 10, 2, 1) as [companykey]
	, a.[nm_cadeia]
	, isnull(a.[partnername], 'N/D') as  [partnername]
	, isnull(a.[subscriptionplanid], 'N/D') as [subscriptionplanid]
into #dimaffiliation_cadastro
from (
	select *
	from
		{{ ti.xcom_pull('create_table') }} 
	where
		[nr_mid] is not null
) a
left join
	[stonedwv0].[dbo].[dimgeography] y on a.[nr_cep] = y.[geographykey]
where not exists (
	select top 1 1
	from
		#dimaffiliation_carteirarota b
	where
		a.[nr_mid] = b.[nr_mid]
)

union

select
	a.[nr_mid] as [nr_mid]
	, isnull(iif(y.[geographykey] is null, 1,a.[nr_cep]), 1) as [nr_cep]
	, a.[nr_cnpj] as [nr_cnpj]
	, iif(a.[dt_criacao]<=a.[dt_criacao_tombamento],replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao_tombamento]
	, isnull(replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao]
	, a.[in_tombamento] as [in_tombamento]
	, a.[nr_mcc] as [nr_mcc]
	, a.[nm_fantasia] as [nm_fantasia]
	, a.[id_registro] as [id_registro]
	, a.[nm_razao_social] as [nm_razao_social]
	, a.[ds_status_ec] as [ds_status_ec]
	, a.[ds_canal] as [ds_canal]
	, a.[nm_subcanal] as [nm_subcanal]
	, a.[ds_grupo1] as [ds_grupo1]
	, a.[ds_grupo2] as [ds_grupo2]
	, a.[ds_grupo3] as [ds_grupo3]
	, min(a.[ds_grupo4]) as [ds_grupo4]
	, iif(len(a.[nr_mid]) > 10, 2, 1) as [companykey]
	, a.[nm_cadeia]
	, ISNULL(a.[partnername], 'N/D') as [partnername]
from #dimaffiliation_carteirarota a
left join
	[stonedwv0].[dbo].[dimgeography] y on a.[nr_cep] = y.[geographykey]
group by
	a.[nr_mid]
	, isnull(iif(y.[geographykey] is null,1 ,a.[nr_cep]),1)
	, a.[nr_cnpj]
	, iif(a.[dt_criacao]<=a.[dt_criacao_tombamento],replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', ''))
	, isnull(replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', ''))
	, a.[in_tombamento]
	, a.[nr_mcc]
	, a.[nm_fantasia]
	, a.[id_registro]
	, a.[nm_razao_social]
	, a.[ds_status_ec]
	, a.[ds_canal]
	, a.[nm_subcanal]
	, a.[ds_grupo1]
	, a.[ds_grupo2]
	, a.[ds_grupo3]
	, iif(len(a.[nr_mid]) > 10,2,1)
	, [nm_cadeia]
	, isnull(a.[partnername], 'N/D')

if object_id('tempdb..#alteracoesdimaffiliation') is not null
	drop table #alteracoesdimaffiliation;

select distinct
	a.[affiliationkey]
	, c.[salesstructurekey]
	, replace(ltrim(rtrim(replace(replace(b.[nm_fantasia], char(9), ''), char(32), ''))), '"', '') as [clientname]
	, isnull(iif(y.[geographykey] is null, 1,b.[nr_cep]), 1) as [geographykey]
	, replace(ltrim(rtrim(replace(replace(b.[nm_razao_social], char(9), ''), char(32), ''))), '"', '') as [clientlegalname]
	, b.[dt_criacao] as [migrationdate]
	, isnull(b.[dt_criacao_tombamento], b.[dt_criacao]) as [createdate]
	, case when isnull(b.[in_tombamento],'n') = 'n' then 0 else 1 end as [migrated]
	, b.[nr_mcc] as [mcckey]
	, replace(ltrim(rtrim(replace(replace(b.[nm_cadeia], char(9), ''), char(32), ''))), '"', '') as [chainname]
	, b.[nr_cnpj] as [clientcnpjorcpf]
	, isnull(g.[clientstatuskey], 1) as [clientstatuskey]
	, cast(b.[nr_mid] as varchar) as [clientalternatekey]
	, h.[vendorkey]
	, i.[clientkey]
	, j.[originregisterkey]
	, b.[partnername] as [partnername]
	, isnull(b.[subscriptionplanid], 'N/D') as [subscriptionplanid]
into #alteracoesdimaffiliation
from
	[dbo].[dimaffiliation] a
inner join
	#dimaffiliation_cadastro b on a.[clientalternatekey] = convert(varchar,b.[nr_mid])
left join
	[stonedwv0].[dbo].[dimgeography] y on b.[nr_cep] = y.[geographykey]
left join
	[stonedwv0].[dbo].[dimclientstatus] g on iif(b.[ds_status_ec] = 'Em analise', 'Em análise', b.[ds_status_ec]) = g.[clientstatusdesc]
inner join
	[stonedwv0].[dbo].[dimsalesstructure] c on
		b.[ds_canal] = c.[salesstructurenamelevel1]
		and b.[nm_subcanal] = c.[salesstructurenamelevel2]
		and b.[ds_grupo1] = c.[salesstructurenamelevel3]
		and b.[ds_grupo2] = c.[salesstructurenamelevel4]
		and b.[ds_grupo3] = c.[salesstructurenamelevel5]
		and b.[ds_grupo4] = c.[salesstructurenamelevel6]
left join
	[stonedwv0].[dbo].[dimvendor] h on b.[id_registro] = h.[vendoralternatekey]
inner join (
	select distinct
		[clientcnpjorcpf]
		, [salesstructurekey]
		, iif([companykey] =2 , 1, [companykey]) as [companykey]
		, [clientkey]
	from [dbo].[dimclient]
	where
		(clientstatuskey <> 7 or clientstatuskey is null)
		and companykey in (1,2)
) i on
		b.[nr_cnpj] = i.[clientcnpjorcpf]
		and c.[salesstructurekey] = i.[salesstructurekey]
		and iif(a.[companykey] = 2, 1, a.[companykey]) = i.[companykey]
left join
	[stonedwv0].[dbo].[dimoriginregister] j on isnull(b.[nm_cadeia], 'Outros') = j.[originregistername]
where
	isnull(a.[salesstructurekey], 1) <> isnull(c.[salesstructurekey], 1)
	or isnull(replace(ltrim(rtrim(replace(replace(b.[nm_fantasia], char(9), ''), char(32), ''))), '"', ''), '') <> isnull(replace(ltrim(rtrim(replace(replace(a.[clientname], char(9), ''), char(32), ''))), '"', ''), '')
	or isnull(b.[nr_cep], 1) <> isnull(a.[geographykey], 1)
	or isnull(replace(ltrim(rtrim(replace(replace(b.[nm_razao_social], char(9), ''), char(32), ''))), '"', ''), '') <> isnull(replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', ''), '')
	or isnull(b.[dt_criacao], '19900101') <> isnull(a.[migrationdate], '19900101')
	or isnull(b.[dt_criacao_tombamento], b.[dt_criacao]) <> isnull(a.[createdate], 1)
	or (case when isnull(b.[in_tombamento], 'n') = 'n' then 0 else 1 end) <> isnull(a.[migrated], 0)
	or b.[nr_mcc] <> a.[mcckey]
	or isnull(replace(ltrim(rtrim(replace(replace(b.[nm_cadeia], char(9), ''), char(32), ''))), '"', ''), '') <> isnull(replace(ltrim(rtrim(replace(replace(a.[chainname], char(9), ''), char(32), ''))), '"', ''), '')
	or isnull(b.[nr_cnpj], '0') <> isnull(a.[clientcnpjorcpf], '0')
	or isnull(g.[clientstatuskey], 1) <> isnull(a.[clientstatuskey], 1)
	or isnull(h.[vendorkey], 1) <> isnull(a.[vendorkey], 1)
	or isnull(i.[clientkey], 1) <> isnull(a.[clientkey], 1)
	or isnull(j.[originregisterkey], 1) <> isnull(a.[originregisterkey], 1)
	or isnull(b.[partnername], '') <> isnull(a.[partnername], '')



if object_id('tempdb..#alteracoesclientstatusdetailkey') is not null
	drop table #alteracoesclientstatusdetailkey

select 
	b.affiliationkey
	, isnull(d.clientstatusdetailkey, 10) as [clientstatusdetailkey_old]
	, isnull(e.clientstatusdetailkey, 10) as [clientstatusdetailkey_new]
	, case when isnull(d.clientstatusdetailkey, 10) <> isnull(e.clientstatusdetailkey, 10) then 1 else 0 end as condition
into 
	#alteracoesclientstatusdetailkey
from 
	[bdmdmis_stone].[dbo].[tbstonef_cadastro_ec] a
inner join dimaffiliation b on a.nr_stonecode = b.clientalternatekey
left join (
	select 
		clientalternatekey
		, affiliationkey
		, max(datekey) as datekey
	from 
		[stonedwv0].[dbo].[dimaffiliationhist]
	group by 
		clientalternatekey
		, affiliationkey
) c on b.affiliationkey = c.affiliationkey
left join 
	[stonedwv0].[dbo].[dimaffiliationhist] d on 
		c.affiliationkey = d.affiliationkey
		and c.datekey = d.datekey
left join 
	[stonedwv0].[dbo].[dimclientstatusdetail] e on isnull(a.ds_status_portal, 'Outro') = e.clientstatusdetaildesc
group by 
	b.affiliationkey
	, d.clientstatusdetailkey 
	, e.clientstatusdetailkey 

-- insert dimaffiliationhist

insert into  [stonedwv0].[dbo].[dimaffiliationhist] (
    affiliationkey
    , clientalternatekey
    , clientkey
    , clientcnpjorcpf
    , clientname
    , geographykey
    , clientlegalname
    , salesstructurekey
    , createdate
    , migrationdate
    , migrated
    , mcckey
    , companykey
    , chainname
    , clientstatuskey
    , vendorkey
    , originregisterkey
    , partnername
	, subscriptionplanid
    , clientstatusdetailkey
    , datekey)

select
    a.*
	, case
        when b.condition = 1 then b.clientstatusdetailkey_new
        else b.clientstatusdetailkey_old
    end  as [clientstatusdetailkey]
	, '{{ds_nodash}}' as [datekey]
from
    [stonedwv0].[dbo].[dimaffiliation] a
inner join
    #alteracoesclientstatusdetailkey b on a.affiliationkey = b.affiliationkey
where
    exists (
        select top 1 1
        from
            #alteracoesdimaffiliation b
        where
            a.affiliationkey = b.affiliationkey
    )
    or exists (
        select top 1 1
        from
            #alteracoesclientstatusdetailkey c
        where
            a.affiliationkey = c.affiliationkey
            and c.condition = 1
    )


-- update dimaffiliation

update m
set m.[salesstructurekey] = n.[salesstructurekey]
	, m.[clientname] = n.[clientname]
	, m.[geographykey] = n.[geographykey]
	, m.[clientlegalname]	= n.[clientlegalname]
	, m.[migrationdate] = n.[migrationdate]
	, m.[createdate] = n.[createdate]
	, m.[migrated] = n.[migrated]
	, m.[mcckey] = n.[mcckey]
	, m.[chainname] = n.[chainname]
	, m.[clientcnpjorcpf] = n.[clientcnpjorcpf]
	, m.[clientstatuskey] = n.[clientstatuskey]
	, m.[vendorkey] = n.[vendorkey]
	, m.[clientkey] = n.[clientkey]
	, m.[originregisterkey] = n.[originregisterkey]
	, m.[partnername] = n.[partnername]
	, m.[subscriptionplanid] = n.[subscriptionplanid]
from [dbo].[dimaffiliation] m
inner join #alteracoesdimaffiliation n on m.[clientalternatekey] = n.[clientalternatekey]

-- insert dimaffiliation

insert into [stonedwv0].[dbo].[dimaffiliation] ([clientcnpjorcpf]
	, [clientname]
	, [geographykey]
	, [clientlegalname]
	, [clientalternatekey]
	, [salesstructurekey]
	, [createdate]
	, [migrationdate]
	, [migrated]
	, [mcckey]
	, [companykey]
	, [chainname]
	, [clientstatuskey]
	, [vendorkey]
	, [clientkey]
	, [originregisterkey]
	, [partnername]
	, [subscriptionplanid])

select distinct
	a.[nr_cnpj]
	, replace(ltrim(rtrim(replace(replace(a.[nm_fantasia], char(9), ''), char(32), ''))), '"', '')
	, isnull(iif(b.[geographykey] is null, 1, a.[nr_cep]), 1)
	, replace(ltrim(rtrim(replace(replace(a.[nm_razao_social], char(9), ''), char(32), ''))), '"', '')
	, a.[nr_mid]
	, c.[salesstructurekey]
	, a.[dt_criacao_tombamento]
	, a.[dt_criacao]
	, (case when isnull(a.[in_tombamento], 'n') = 'n' then 0 else 1 end)
	, a.[nr_mcc]
	, iif(len(a.[nr_mid]) > 10, 2, 1)
	, replace(ltrim(rtrim(replace(replace(a.[nm_cadeia], char(9), ''), char(32), ''))), '"', '')
	, isnull(s.[clientstatuskey], 1)
	, max(v.[vendorkey])
	, min(e.[clientkey])
	, h.[originregisterkey]
	, a.[partnername]
	, isnull(a.[subscriptionplanid], 'N/D')
from #dimaffiliation_cadastro a 
left join
	[stonedwv0].[dbo].dimgeography b on a.[nr_cep] = b.[geographykey]
inner join
	[stonedwv0].[dbo].[dimsalesstructure] c on (
		[salesstructurenamelevel1] = a.[ds_canal]
		and [salesstructurenamelevel2] = a.[nm_subcanal]
		and [salesstructurenamelevel3] = a.[ds_grupo1]
		and [salesstructurenamelevel4] = a.[ds_grupo2]
		and [salesstructurenamelevel5] = a.[ds_grupo3]
		and [salesstructurenamelevel6] = a.[ds_grupo4]
	)
left join
	[stonedwv0].[dbo].[dimclientstatus] s on iif(a.[ds_status_ec] = 'Em analise', 'Em análise', a.[ds_status_ec]) = s.[clientstatusdesc]
left join
	[stonedwv0].[dbo].[dimvendor] v on a.[id_registro] = v.[vendoralternatekey]
inner join
	[stonedwv0].[dbo].[dimclient] e on a.[nr_cnpj] = e.[clientcnpjorcpf] and e.[companykey] in (1,2) and c.[salesstructurekey] = e.[salesstructurekey]
left join
	[stonedwv0].[dbo].[dimoriginregister] h on isnull(a.[nm_cadeia], 'Outros') = h.[originregistername]
where not exists (
	select top (1) 1
	from
		[stonedwv0].[dbo].[dimaffiliation] d 
	where
		convert(varchar, a.[nr_mid]) = d.[clientalternatekey]
)
group by
	a.[nr_cnpj]
	, replace(ltrim(rtrim(replace(replace(a.[nm_fantasia], char(9), ''), char(32), ''))), '"', '')
	, isnull(iif(b.[geographykey] is null, 1, a.[nr_cep]), 1)
	, replace(ltrim(rtrim(replace(replace(a.[nm_razao_social], char(9), ''), char(32), ''))), '"', '')
	, a.[nr_mid]
	, c.[salesstructurekey]
	, a.[dt_criacao_tombamento]
	, a.[dt_criacao]
	, (case when isnull(a.[in_tombamento], 'n') = 'n' then 0 else 1 end)
	, a.[nr_mcc]
	, iif(len(a.[nr_mid]) > 10, 2, 1)
	, replace(ltrim(rtrim(replace(replace(a.[nm_cadeia], char(9), ''), char(32), ''))), '"', '')
	, s.[clientstatuskey]
	, h.[originregisterkey]
	, a.[partnername]
	, isnull(a.[subscriptionplanid], 'N/D')
