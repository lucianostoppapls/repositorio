with agenda as (
    select
        replace(convert(date,[dt_dia_ref]), '-', '') as [dt_dia_ref]
        , [stone_code]
        , sum(vl_disponivel) as [vl_disponivel]
    from
        [bdmdmis_stone].[dbo].[tbstonef_historico_disponivel_agenda_rav] 
    where
        [dt_dia_ref] >= '{{ ds }}'
        and [dt_dia_ref] < '{{ next_ds }}'
    group by
        dt_dia_ref
        , stone_code
    union all
    select
        replace(convert(date,[dt_dia_ref]), '-', '') as [dt_dia_ref]
        , [nr_mid]
        , sum(vl_disponivel) as [vl_disponivel]
    from
        [bdmdmis001].[dbo].[tbplf_historico_disponivel_antecipacao] 
    where
        [dt_dia_ref] >= '{{ ds }}'
        and [dt_dia_ref] < '{{ next_ds }}'
    group by
        dt_dia_ref
        , nr_mid
)

select
    iif(len(agenda.[stone_code]) > 10,2,1) as [companykey]
    , 9 as [flagkey]
    , 3 as [productkey]
    , cadastro.[id_registro] as [id_registro]
    , agenda.[dt_dia_ref] as [dt_dia_ref]
    , isnull(agenda.[vl_disponivel],0) as [vl_disponivel]
    , agenda.[stone_code] as [stone_code]
from
    agenda
inner join
    [bdmdmis_stone].[dbo].[tbstonef_cadastro_integrado_ec] cadastro on agenda.[stone_code] = cadastro.[nr_mid]
