select distinct
    e.[nr_mid] as [nr_mid]
    , e.[nr_cep] as [nr_cep]
    , replace(isnull(e.[dt_criacao_tombamento], e.[dt_criacao]), '-', '') as [dt_criacao_tombamento]
    , replace(isnull(e.[dt_criacao], e.[dt_criacao_tombamento]), '-', '') as [dt_criacao]
    , e.[in_tombamento] as [in_tombamento]
    , e.[nr_mcc] as [nr_mcc]
    , e.[nm_fantasia] as [nm_fantasia]
    , e.[nr_cnpj] as [nr_cnpj]
    , e.[id_registro] as [id_registro]
    , e.[nm_razao_social] as [nm_razao_social]
    , e.[ds_status_ec] as [ds_status_ec]
    , case when isnull(e.[ds_canal],'') = '' then 'N/D' else e.[ds_canal] end as [ds_canal]
    , case when isnull(e.[nm_subcanal],'') = '' then 'N/D' else e.[nm_subcanal] end as [nm_subcanal]
    , case when isnull(e.[ds_grupo1],'') = '' then '-' else e.[ds_grupo1] end as [ds_grupo1]
    , case when isnull(e.[ds_grupo2],'') = '' then '-' else e.[ds_grupo2] end as [ds_grupo2]
    , case when isnull(e.[ds_grupo3],'') = '' then '-' else e.[ds_grupo3] end as [ds_grupo3]
    , f.[nm_cadeia] as [nm_cadeia]
from
    [bdmdmis_stone].[dbo].[tbstonef_cadastro_integrado_ec] e
left join
    [bdmdmis_stone].[dbo].[vwstone_cadeias_019] f on e.[nr_mid] = f.[nr_mid]
