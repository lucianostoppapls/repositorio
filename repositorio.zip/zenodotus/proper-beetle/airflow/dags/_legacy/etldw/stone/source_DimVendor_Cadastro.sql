select distinct
    [ds_emailvendedor]
    , [id_registro]
    , [nm_portal]
    , [nm_exibicao]
    , [nm_forca_venda]
    , null as [closer_id]
    , null as [closer_name]
    , 1 as [companykey]
from
    [BDMDMIS_STONE].[dbo].[tbstoned_vendedor_stone]

union

select distinct
    null as [ds_emailvendedor]
    , null as [id_registro]
    , null as [nm_portal]
    , null as [nm_exibicao]
    , null as [nm_forca_venda]
    , concat('mundi_',row_number() over( order by [closername])) as [closer_id]
    , isnull([closername], 'Mundi') as [closer_name]
    , 5 as [companykey]
from
    [StoneCoODS].[mundi].[tbmundid_client] 
group by
    [closername]

union

select distinct
    null as [ds_emailvendedor]
    , null as [id_registro]
    , null as [nm_portal]
    , null as [nm_exibicao]
    , null as [nm_forca_venda]
    , left(isnull(closer_id,'pagarme_001'),99) as [closer_id]
    , isnull(closer_name, 'Pagar.me') as [closer_name]
    , 3 as [companykey]
from
    [StoneCoODS].[pagarme].[companies] 

union

select distinct
    [e-mail] as [ds_emailvendedor]
    , null as [id_registro]
    , null as [nm_portal]
    , [responsável] as [nm_exibicao]
    , null as [nm_forca_venda]
    , cast([capptor id] as varchar) as [closer_id]
    , isnull([capptor], 'Cappta') as [closer_name]
    , 6 as [companykey]
from
    stonecoods.[cappta].[tbcapptat_capptor]
