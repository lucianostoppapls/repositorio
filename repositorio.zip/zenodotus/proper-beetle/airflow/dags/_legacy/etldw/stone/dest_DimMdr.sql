if object_id('tempdb..#MDRECAveraged') is not null
	drop table #MDRECAveraged

select
	mdrec.Companykey
	,AffiliationKey
	,Productkey
	,FlagKey
	,InstallmentKey
	,avg(MdrFee) MdrFee
into
	#MDRECAveraged
from
	{{ ti.xcom_pull('create_table') }} mdrec
inner join
	StoneDWv0.dbo.DimAffiliation affiliation on mdrec.ClientAlternateKey = affiliation.ClientAlternateKey
group by
	mdrec.Companykey
	,AffiliationKey
	,Productkey
	,FlagKey
	,InstallmentKey

insert into StoneDWv0..DimMDR (
		Companykey
		,AffiliationKey
		,Productkey
		,FlagKey
		,InstallmentKey
		,MdrFee
)
	select
		Companykey
		,AffiliationKey
		,Productkey
		,FlagKey
		,InstallmentKey
		,avg(MdrFee) MdrFee
	from #MDRECAveraged mdrec
	where not exists (
		select top 1 1
		from StoneDWv0..DimMDR mdr
		where mdrec.AffiliationKey = mdr.AffiliationKey
			and mdrec.Productkey = mdr.ProductKey
			and mdrec.FlagKey = mdr.FlagKey
			and mdrec.InstallmentKey = mdr.InstallmentKey
	)
	group by
		Companykey
		,AffiliationKey
		,Productkey
		,FlagKey
		,InstallmentKey

insert into StoneDWv0..DimMDRHistory (
	Companykey
	,AffiliationKey
	,Productkey
	,FlagKey
	,InstallmentKey
	,MdrFee
	,EndDate
)
	select
		mdr.Companykey
		,mdr.AffiliationKey
		,mdr.Productkey
		,mdr.FlagKey
		,mdr.InstallmentKey
		,mdr.MdrFee
		,'{{ ds_nodash }}'
	from
		StoneDWv0.dbo.DimMDR mdr
	inner join
		#MDRECAveraged mdrec on
			mdr.Companykey		    = mdrec.Companykey
			and mdr.AffiliationKey	= mdrec.AffiliationKey
			and mdr.Productkey		= mdrec.Productkey
			and mdr.FlagKey			= mdrec.FlagKey
			and mdr.InstallmentKey	= mdrec.InstallmentKey
			and mdr.MdrFee			<> mdrec.Mdrfee

update mdr
	set
		mdr.MdrFee = mdrec.MdrFee
from StoneDWv0.dbo.DimMDR mdr
inner join
	#MDRECAveraged mdrec on
	mdr.Companykey			= mdrec.Companykey
	and mdr.AffiliationKey	= mdrec.AffiliationKey
	and mdr.Productkey		= mdrec.Productkey
	and mdr.FlagKey			= mdrec.FlagKey
	and mdr.InstallmentKey	= mdrec.InstallmentKey
	and mdr.MdrFee			<> mdrec.Mdrfee
