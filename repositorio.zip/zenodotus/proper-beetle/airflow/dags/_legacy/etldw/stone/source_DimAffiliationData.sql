use bdmdmis_stone

select
  [nr_stonecode]
  , case
      when cd_rav_auto=0 then '0'
      when cd_rav_auto=1 then '1'
      else '0'
    end as [cd_rav_auto]
  , case
      when cd_bloqued=0 then '0'
      when cd_bloqued=1 then '1'
      else '0'
    end as [cd_bloqued]
from [dbo].[tbstonef_cadastro_rav]
