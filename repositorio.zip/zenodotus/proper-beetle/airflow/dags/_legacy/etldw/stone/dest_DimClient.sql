use stonedwv0

if object_id('tempdb..#dimclient_stone_carteirarota') is not null
	drop table #dimclient_stone_carteirarota;

select distinct e.[nr_mid] as [nr_mid]
	, isnull(iif(y.[geographykey] is null,1 ,e.[nr_cep]),1) as [nr_cep]
	, isnull(e.[dt_criacao_tombamento], e.[dt_criacao]) as [dt_criacao_tombamento]
	, isnull(e.[dt_criacao], e.[dt_criacao_tombamento]) as [dt_criacao]
	, e.[in_tombamento] as [in_tombamento]
	, e.[nr_mcc] as [nr_mcc]
	, e.[nm_fantasia] as [nm_fantasia]
	, e.[nr_cnpj] as [nr_cnpj]
	, e.[id_registro] as [id_registro]
	, e.[nm_razao_social] as [nm_razao_social]
	, e.[ds_status_ec] as [ds_status_ec]
	, (case when isnull(e.[ds_canal],'') = '' then 'N/D' else e.[ds_canal] end) as [ds_canal]
	, (case when isnull(e.[nm_subcanal],'') = '' then 'N/D' else e.[nm_subcanal] end) as [nm_subcanal]
	, (case when isnull(e.[ds_grupo1],'') = '' then '-' else e.[ds_grupo1] end) as [ds_grupo1]
	, (case when isnull(e.[ds_grupo2],'') = '' then '-' else e.[ds_grupo2] end) as [ds_grupo2]
	, (case when isnull(e.[ds_grupo3],'') = '' then '-' else e.[ds_grupo3] end) as [ds_grupo3]
	, isnull(b.[name], case when isnull([ds_grupo3],'') = '' then '-' else [ds_grupo3] end) as [ds_grupo4]
	, e.[nm_cadeia] as [nm_cadeia]
	, isnull(e.[partnername], 'N/D') as [partnername]
	, isnull(e.[nm_aplicacao_cadastro], 'Outros') as [nm_aplicacao_cadastro]
into #dimclient_stone_carteirarota
from [stonedwv0].[dbo].[dimaccount] a
inner join [stonedwv0].[dbo].[dimterritory2] b on b.[territory2key] = a.[route]
inner join [stonedwv0].[dbo].[dimterritory2type] c on b.[territory2typekey] = c.[territory2typekey]
inner join [stonedwv0].[dbo].[dimterritory2] d on b.[parentterritory2key] = d.[territory2key]
inner join {{ ti.xcom_pull('create_table') }} e on a.[clientalternatekey] = e.[nr_mid] and d.[name] = e.[ds_grupo3]
left join [stonedwv0].[dbo].[dimgeography] y on e.[nr_cep] = y.[geographykey]
where (c.[masterlabel] = 'Rota'
	and b.[active] = 1
	and a.[clientalternatekey] <> 1
	and e.[nm_subcanal] = 'Polo Proprio'
	and a.[name] <> 'Duplicada')


if object_id('tempdb..#dimclient_stone_cadastro') is not null
	drop table #dimclient_stone_cadastro;

select distinct a.[nr_mid] as [nr_mid]
	, isnull(iif(y.[geographykey] is null, 1,a.[nr_cep]), 1) as [nr_cep]
	, a.[nr_cnpj] as [nr_cnpj]
	, iif(a.[dt_criacao]<=a.[dt_criacao_tombamento],replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao_tombamento]
	, isnull(replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao]
	, a.[in_tombamento] as [in_tombamento]
	, a.[nr_mcc] as [nr_mcc]
	, a.[nm_fantasia] as [nm_fantasia]
	, a.[id_registro] as [id_registro]
	, a.[nm_razao_social] as [nm_razao_social]
	, isnull(a.[ds_status_ec], 'Credenciado') as [ds_status_ec]
	, isnull(a.[ds_canal], 'N/D') as [ds_canal]
	, isnull(a.[nm_subcanal], 'N/D') as [nm_subcanal]
	, isnull(a.[ds_grupo1], '-') as [ds_grupo1]
	, isnull(a.[ds_grupo2], '-') as [ds_grupo2]
	, isnull(a.[ds_grupo3], '-') as [ds_grupo3]
	, isnull(a.[ds_grupo3], '-') as [ds_grupo4]
	, iif(len(a.[nr_mid]) > 10, 2, 1) as [companykey]
	, a.[nm_cadeia] as [nm_cadeia]
	, isnull(a.[partnername], 'N/D') as [partnername]
	, isnull(a.[nm_aplicacao_cadastro], 'Outros') as [nm_aplicacao_cadastro]
into #dimclient_stone_cadastro
from (select * from {{ ti.xcom_pull('create_table') }} where [nr_mid] is not null) a
left join [stonedwv0].[dbo].[dimgeography] y on a.[nr_cep] = y.[geographykey]
where not exists (select top 1 1 from #dimclient_stone_carteirarota b where a.[nr_mid] = b.[nr_mid])

union

select a.[nr_mid] as [nr_mid]
	, isnull(iif(y.[geographykey] is null, 1,a.[nr_cep]), 1) as [nr_cep]
	, a.[nr_cnpj] as [nr_cnpj]
	, iif(a.[dt_criacao]<=a.[dt_criacao_tombamento],replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao_tombamento]
	, isnull(replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', '')) as [dt_criacao]
	, a.[in_tombamento] as [in_tombamento]
	, a.[nr_mcc] as [nr_mcc]
	, a.[nm_fantasia] as [nm_fantasia]
	, a.[id_registro] as [id_registro]
	, a.[nm_razao_social] as [nm_razao_social]
	, a.[ds_status_ec] as [ds_status_ec]
	, a.[ds_canal] as [ds_canal]
	, a.[nm_subcanal] as [nm_subcanal]
	, a.[ds_grupo1] as [ds_grupo1]
	, a.[ds_grupo2] as [ds_grupo2]
	, a.[ds_grupo3] as [ds_grupo3]
	, min(a.[ds_grupo4]) as [ds_grupo4]
	, iif(len(a.[nr_mid]) > 10, 2, 1) as [companykey]
	, a.[nm_cadeia]
	, isnull(a.[partnername], 'N/D') as [partnername]
	, isnull(a.[nm_aplicacao_cadastro], 'Outros') as [nm_aplicacao_cadastro]
from #dimclient_stone_carteirarota a
left join [stonedwv0].[dbo].[dimgeography] y on a.[nr_cep] = y.[geographykey]
group by a.[nr_mid]
	, isnull(iif(y.[geographykey] is null,1 ,a.[nr_cep]),1)
	, a.[nr_cnpj]
	, iif(a.[dt_criacao]<=a.[dt_criacao_tombamento],replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', ''))
	, isnull(replace(a.[dt_criacao], '-', ''),replace(a.[dt_criacao_tombamento], '-', ''))
	, a.[in_tombamento]
	, a.[nr_mcc]
	, a.[nm_fantasia]
	, a.[id_registro]
	, a.[nm_razao_social]
	, a.[ds_status_ec]
	, a.[ds_canal]
	, a.[nm_subcanal]
	, a.[ds_grupo1]
	, a.[ds_grupo2]
	, a.[ds_grupo3]
	, iif(len(a.[nr_mid]) > 10,2,1)
	, a.[nm_cadeia]
	, isnull(a.[partnername], 'N/D')
	, isnull(a.[nm_aplicacao_cadastro], 'Outros')

if object_id('tempdb..#dimclient_stone_client_date') is not null
	drop table #dimclient_stone_client_date


select a.[dt_criacao]
	, a.[ds_canal]
	, a.[nm_subcanal]
	, a.[ds_grupo1]
	, a.[ds_grupo2]
	, a.[ds_grupo3]
	, a.[ds_grupo4]
	, a.[nr_cnpj]
	, b.[nr_mid]
into #dimclient_stone_client_date
from (select min(dt_criacao) [dt_criacao]
		, [ds_canal]
		, [nm_subcanal]
		, [ds_grupo1]
		, [ds_grupo2]
		, [ds_grupo3]
		, [ds_grupo4]
		, [nr_cnpj]
	from #dimclient_stone_cadastro
	group by [ds_canal]
		, [nm_subcanal]
		, [ds_grupo1]
		, [ds_grupo2]
		, [ds_grupo3]
		, [ds_grupo4]
		, [nr_cnpj]) a
	join (select dt_criacao
			, case when [nr_cnpj] = '18727053000174' then 171851857 else min([nr_mid]) end [nr_mid]
			, [ds_canal]
			, [nm_subcanal]
			, [ds_grupo1]
			, [ds_grupo2]
			, [ds_grupo3]
			, [ds_grupo4]
			, [nr_cnpj]
		from #dimclient_stone_cadastro
		group by [dt_criacao]
			, [ds_canal]
			, [nm_subcanal]
			, [ds_grupo1]
			, [ds_grupo2]
			, [ds_grupo3]
			, [ds_grupo4]
			, [nr_cnpj]) b
		on a.[nr_cnpj] = b.[nr_cnpj]
			AND a.[ds_canal] = b.[ds_canal]
			AND a.[nm_subcanal] = b.[nm_subcanal]
			AND a.[ds_grupo1] = b.[ds_grupo1]
			AND a.[ds_grupo2] = b.[ds_grupo2]
			AND a.[ds_grupo3] = b.[ds_grupo3]
			AND a.[ds_grupo4] = b.[ds_grupo4]
			AND a.[dt_criacao] = b.[dt_criacao]
group by a.[dt_criacao]
	, a.[ds_canal]
	, a.[nm_subcanal]
	, a.[ds_grupo1]
	, a.[ds_grupo2]
	, a.[ds_grupo3]
	, a.[ds_grupo4]
	, a.[nr_cnpj]
	, b.[nr_mid]


if object_id('tempdb..#dimclient_stone_alteracoesdimclient') is not null
	drop table #dimclient_stone_alteracoesdimclient;

select distinct a.[clientkey] as [clientkey]
	, c.[salesstructurekey] as [salesstructurekey]
	, replace(ltrim(rtrim(replace(replace(b.[nm_fantasia], char(9), ''), char(32), ''))), '"', '') as [clientname]
	, b.[nr_cep] as [geographykey]
	, replace(ltrim(rtrim(replace(replace(b.[nm_razao_social], char(9), ''), char(32), ''))), '"', '') as [clientlegalname]
	, b.[dt_criacao] as [migrationdate]
	, isnull(b.[dt_criacao_tombamento], b.[dt_criacao]) as [createdate]
	, (case when isnull(b.[in_tombamento], 'n') = 'n' then 0 else 1 end) as [migrated]
	, b.[nr_mcc] as [mcckey]
	, replace(ltrim(rtrim(replace(replace(b.[nm_cadeia], char(9), ''), char(32), ''))), '"', '') as [chainname]
	, b.[nr_cnpj] as [clientcnpjorcpf]
	, isnull(g.[clientstatuskey], 1) as [clientstatuskey]
	, b.[nr_mid] as [clientalternatekey]
	, h.[vendorkey] as [vendorkey]
	,case
	     when len(b.[nr_cnpj]) <= 11 then 'PF'
	     when isnumeric(RIGHT(replace(ltrim(rtrim(replace(replace(b.[nm_razao_social], char(9), ''), char(32), ''))), '"', ''), 11)) = 1 then 'MEI'
	     else 'PJ'
	end as [clientcnpjorcpfclassification]
	, i.[originregisterkey] as [originregisterkey]
into #dimclient_stone_alteracoesdimclient
from [dbo].[dimclient]  a
inner join #dimclient_stone_cadastro b on a.[clientalternatekey] = b.[nr_mid]
inner join [dbo].[dimsalesstructure] c on b.[ds_canal] = c.[salesstructurenamelevel1]
	and b.[nm_subcanal] = c.[salesstructurenamelevel2]
	and b.[ds_grupo1] = c.[salesstructurenamelevel3]
	and b.[ds_grupo2] = c.[salesstructurenamelevel4]
	and b.[ds_grupo3] = c.[salesstructurenamelevel5]
	and b.[ds_grupo4] = c.[salesstructurenamelevel6]
left join [dbo].[dimclientstatus] g on iif(b.[ds_status_ec] = 'Em analise', 'Em análise', b.[ds_status_ec]) = g.[clientstatusdesc]
left join [dbo].[dimvendor] h on b.[id_registro] = h.[vendoralternatekey]
left join [dbo].[dimoriginregister] i on b.[nm_aplicacao_cadastro] = i.[originregistername]
where (isnull(a.[salesstructurekey], 1) <> isnull(c.[salesstructurekey], 1)
	or replace(ltrim(rtrim(replace(replace(b.[nm_fantasia], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(a.[clientname], char(9), ''), char(32), ''))), '"', '')
	or isnull(b.[nr_cep], 1) <> isnull(a.[geographykey], 1)
	or replace(ltrim(rtrim(replace(replace(b.[nm_razao_social], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(a.[clientlegalname], char(9), ''), char(32), ''))), '"', '')
	or isnull(b.[dt_criacao], '19900101') <> isnull(a.[migrationdate], '19900101')
	or isnull(b.[dt_criacao_tombamento], b.[dt_criacao]) <> isnull(a.[createdate], 1)
	or (case when isnull(b.[in_tombamento],'n') = 'n' then 0 else 1 end) <> a.[migrated]
	or b.[nr_mcc] <> a.[mcckey]
	or replace(ltrim(rtrim(replace(replace(b.[nm_cadeia], char(9), ''), char(32), ''))), '"', '') <> replace(ltrim(rtrim(replace(replace(a.[chainname], char(9), ''), char(32), ''))), '"', '')
	or isnull(b.[nr_cnpj], '0') <> isnull(a.[clientcnpjorcpf], '0')
	or isnull(g.[clientstatuskey], 1) <> isnull(a.[clientstatuskey], 1)
	or isnull(h.[vendorkey], 1) <> isnull(a.[vendorkey], 1)
	or isnull(i.[originregisterkey], 19) <> isnull(a.[originregisterkey], 19))

-- -- insert dimclienthist

-- insert into [dbo].[dimclienthist] (clientkey
-- , companykey
-- , clientcnpjorcpf
-- , clientname
-- , geographykey
-- , clientparentkey
-- , clientlegalname
-- , enddate
-- , clientalternatekey
-- , salesstructurekey
-- , createdate
-- , migrationdate
-- , migrated
-- , mcckey
-- , clientalternatekeypagarme
-- , chainname
-- , clientstatuskey
-- , vendorkey
-- , clientcnpjorcpfclassification
-- , originregisterkey)

-- select a.[clientkey]
-- , a.[companykey]
-- , a.[clientcnpjorcpf]
-- , a.[clientname]
-- , a.[geographykey]
-- , a.[clientparentkey]
-- , a.[clientlegalname]
-- , convert(date, getdate())
-- , a.[clientalternatekey]
-- , a.[salesstructurekey]
-- , a.[createdate]
-- , a.[migrationdate]
-- , a.[migrated]
-- , a.[mcckey]
-- , a.[clientalternatekeypagarme]
-- , a.[chainname]
-- , a.[clientstatuskey]
-- , a.[vendorkey]
-- , a.[clientcnpjorcpfclassification]
-- , a.[originregisterkey]
-- from [dbo].[dimclient] a
-- inner join #dimclient_stone_alteracoesdimclient b on a.[clientkey] = b.[clientkey]

-- update dimclient

update m
set m.[salesstructurekey] = n.[salesstructurekey]
	, m.[clientname] = n.[clientname]
	, m.[geographykey] = n.[geographykey]
	, m.[clientlegalname]	= n.[clientlegalname]
	, m.[migrationdate] = n.[migrationdate]
	, m.[createdate] = n.[createdate]
	, m.[migrated] = n.[migrated]
	, m.[mcckey] = n.[mcckey]
	, m.[chainname] = n.[chainname]
	, m.[clientcnpjorcpf] = n.[clientcnpjorcpf]
	, m.[clientstatuskey] = n.[clientstatuskey]
	, m.[vendorkey] = n.[vendorkey]
	, m.[clientcnpjorcpfclassification] = n.[clientcnpjorcpfclassification]
	, m.[originregisterkey] = n.[originregisterkey]
from [dbo].[dimclient]  m
inner join #dimclient_stone_alteracoesdimclient n on m.clientkey = n.clientkey


-- update clientes com data menor

update A
set clientstatuskey = 7
from [dbo].[dimclient] a
	join (select clientcnpjorcpf, salesstructurekey, clientkey
		from [dbo].[dimclient] a
		where not exists (select top 1 1
			from #dimclient_stone_client_date b
			where a.clientalternatekey = b.nr_mid)
		group by clientcnpjorcpf, salesstructurekey, clientkey) b on a.clientkey = b.clientkey
where companykey in (1,2)


-- update conceito cnpj/canal

declare @cont int = (select sum(qtd)
	from (select count(*) qtd, clientcnpjorcpf, salesstructurekey, max(clientkey) clientkey
		from [dbo].[dimclient]
		where companykey in (1,2) and (clientstatuskey <> 7 or clientstatuskey is null)
		group by clientcnpjorcpf, salesstructurekey
		having count(*) > 1) a)

while @cont > 0

begin

update a
set clientstatuskey = 7
from [dbo].[dimclient]   a
	join (select count(*) qtd, clientcnpjorcpf, salesstructurekey, max(clientkey) clientkey
		from [dbo].[dimclient]
		where companykey in (1,2)
		and (clientstatuskey <> 7 or clientstatuskey is null)
		group by clientcnpjorcpf, salesstructurekey
		having count(*) > 1) b
		on a.clientkey = b.clientkey

set @cont = (select sum(qtd)
	from (select count(*) qtd, clientcnpjorcpf, salesstructurekey, max(clientkey) clientkey
		from [dbo].[dimclient]
		where companykey in (1,2)
		and (clientstatuskey <> 7 or clientstatuskey is null)
		group by clientcnpjorcpf, salesstructurekey
		having count(*) > 1) a )

end

-- insert dimclient

insert into [stonedwv0].[dbo].[dimclient] ([clientcnpjorcpf]
	, [clientname]
	, [geographykey]
	, [clientparentkey]
	, [clientlegalname]
	, [clientalternatekey]
	, [salesstructurekey]
	, [createdate]
	, [migrationdate]
	, [migrated]
	, [mcckey]
	, [companykey]
	, [chainname]
	, [clientstatuskey]
	, [vendorkey]
	, [clientcnpjorcpfclassification]
	, [originregisterkey])

select distinct a.[nr_cnpj]
	, min(replace(ltrim(rtrim(replace(replace(a.[nm_fantasia], char(9), ''), char(32), ''))), '"', ''))
	, max(a.[nr_cep])
	, null
	, min(replace(ltrim(rtrim(replace(replace(a.[nm_razao_social], char(9), ''), char(32), ''))), '"', ''))
	, min(a.[nr_mid])
	, c.[salesstructurekey]
	, min(a.[dt_criacao_tombamento])
	, min(a.[dt_criacao])
	, max(case when isnull(a.[in_tombamento],'n') = 'n' then 0 else 1 end)
	, max(a.[nr_mcc])
	, min(iif(len(a.[nr_mid]) > 10,2,1))
	, min(replace(ltrim(rtrim(replace(replace(a.[nm_cadeia], char(9), ''), char(32), ''))), '"', ''))
	, isnull(min(g.[clientstatuskey]), 1)
	, max(v.[vendorkey])
	,case
		when len(a.[nr_cnpj]) <= 11 then 'PF'
		when isnumeric(RIGHT(min(replace(ltrim(rtrim(replace(replace(a.[nm_razao_social], char(9), ''), char(32), ''))), '"', '')), 11)) = 1 then 'MEI'
		else 'PJ'
	end
	, i.[originregisterkey]
from #dimclient_stone_cadastro a
inner join [stonedwv0].[dbo].[dimsalesstructure] c on (c.[salesstructurenamelevel1] = a.[ds_canal]
	and c.[salesstructurenamelevel2] = a.[nm_subcanal]
	and c.[salesstructurenamelevel3] = a.[ds_grupo1]
	and c.[salesstructurenamelevel4] = a.[ds_grupo2]
	and c.[salesstructurenamelevel5] = a.[ds_grupo3]
	and c.[salesstructurenamelevel6] = a.[ds_grupo4])
left join [dbo].[dimclientstatus] g on iif(a.[ds_status_ec] = 'Em Analise', 'Em Análise', a.[ds_status_ec]) = g.[clientstatusdesc]
left join (select vendoralternatekey, max(vendorkey) as vendorkey
	from [dbo].[dimvendor]
	where vendoralternatekey is not null
	group by vendoralternatekey) v on a.[id_registro] = v.[vendoralternatekey]
inner join dimoriginregister i on a.[nm_aplicacao_cadastro] = i.[originregistername]
where not exists (select top (1) 1
	from [stonedwv0].[dbo].[dimclient]  d 
	where a.[nr_cnpj] = d.[clientcnpjorcpf]
		and iif(a.[companykey] = 2, 1, a.[companykey]) = iif(d.[companykey] = 2, 1, d.[companykey])
		and c.[salesstructurekey] = d.[salesstructurekey]
		and (d.[clientstatuskey] <> 7 or d.[clientstatuskey]  is null))
	and exists (select top 1 1 
		from #dimclient_stone_client_date cd
		where a.[nr_mid] = cd.[nr_mid])
		
group by a.[nr_cnpj]
	, c.[salesstructurekey]
	, i.[originregisterkey]
