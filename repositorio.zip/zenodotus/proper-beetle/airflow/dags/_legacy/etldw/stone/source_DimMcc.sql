use bdmdmis_stone

select 
a.[nr_mcc] as [mcckey]
, a.[ds_name] as [mccname]
, b.[ds_mcc_agrupado] as [mcccluster]
from [dbo].[tbstoned_mcc] a
left join [dbo].[tbstone_mcc_agrupado] b on a.[nr_mcc] = b.[nr_mcc]
