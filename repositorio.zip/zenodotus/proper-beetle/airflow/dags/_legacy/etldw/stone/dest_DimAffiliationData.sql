truncate table [stonedwv0].[dbo].[dimaffiliationdata]

insert into [stonedwv0].[dbo].[dimaffiliationdata] (
    [affiliationkey]
    , [firsttransactiondate]
    , [lasttransactiondate]
    , [firstanticipationautodate]
    , [lastanticipationautodate]
    , [firstanticipationspotdate]
    , [lastanticipationspotdate]
    , [channeltypekey]
    , [firstanticipationdate]
    , [lastanticipationdate]
    , [firstchurndate]
    , [firstactivationdate]
    , [tpvestimate]
    , [expectedmigration]
    , [storequantity]
    , [ravstatuskey]
)

select
    affiliation.[affiliationkey]
    , tpv.[firsttransactiondate]
    , tpv.[lasttransactiondate]
    , rav.[firstanticipationautodate]
    , rav.[lastanticipationautodate]
    , rav.[firstanticipationspotdate]
    , rav.[lastanticipationspotdate]
    , cadrav.[cd_rav_auto] as [channeltypekey]
    , rav.[firstanticipationdate]
    , rav.[lastanticipationdate]
    , churn.[firstchurndate]
    , tpv.[firstactivationdate]
    , iif(isnull(tpvestimate.expectedtpv, 0) = 0 ,tpvestimatecadastro.[nr_estimated_monthly_tpv], tpvestimate.expectedtpv) as [tpvestimate]
    , tpvestimate.[expectedmigration] as [expectedmigration]
    , tpvestimate.[storequantity] as [storequantity]
    , cadrav.[cd_bloqued]
from
    [stonedwv0].[dbo].[dimaffiliation] affiliation
left join (
    select
        a.[affiliationkey]
        , min(iif(tpv> 1, transactiondate, null)) as [firsttransactiondate]
        , max(iif(tpv> 1, transactiondate, null)) as [lasttransactiondate]
        , min(iif(tpv> 500, transactiondate, null)) as [firstactivationdate]
    from
        [stonedwv0].[dbo].[facttpv]  a
    group by
        a.[affiliationkey]
) tpv on affiliation.[affiliationkey] = tpv.[affiliationkey]
left join (
    select
        a.[affiliationkey]
        , min(iif(ravtypekey = 1, contractdate, null)) as [firstanticipationautodate]
        , max(iif(ravtypekey = 1, contractdate, null)) as [lastanticipationautodate]
        , min(iif(ravtypekey = 2, contractdate, null)) as [firstanticipationspotdate]
        , max(iif(ravtypekey = 2, contractdate, null)) as [lastanticipationspotdate]
        , min(contractdate) as [firstanticipationdate]
        , max(contractdate) as [lastanticipationdate]
    from
        [stonedwv0].[dbo].[factrav]  a
    group by
        a.[affiliationkey]
) rav on affiliation.[affiliationkey] = rav.[affiliationkey]
left join
    {{ ti.xcom_pull('create_support_table_1') }} cadrav on affiliation.[clientalternatekey] = cast(cadrav.[nr_stonecode] as varchar(13))
left join (
    select affiliationkey
    , min(churn) as firstchurndate
    from (
        select
            affiliation.[affiliationkey]
            , case when lag(isnull(tpv, 0), 1, null) over (partition by affiliation.[affiliationkey] order by datekey asc) > 1 and isnull(tpv, 0) <= 1 then datekey else null end [churn]
        from (
            select
                datekey
                , [affiliationkey]
            from
                [stonedwv0].[dbo].[dimaffiliation]  a
            cross join
                [stonedwv0].[dbo].[dimdate]  b
            where
                b.[islastdayofmonth] = 'y'
                and fulldate between '2016-01-01' and eomonth('{{ next_ds }}')
            group by
                datekey
                , [affiliationkey]
        ) affiliation
        left join
            [stonedwv0].[dbo].[factmonthlytpv]  tpv on
                affiliation.[affiliationkey] = tpv.[affiliationkey]
                and affiliation.[datekey] = tpv.[transactiondate]
    ) a
group by
    [affiliationkey]
) churn on affiliation.[affiliationkey] = churn.[affiliationkey]
left join (
    select
        [clientalternatekey]
        , max([expectedtpv]) as expectedtpv
        , max([expectedmigration]) as expectedmigration
        , max([storequantity]) as storequantity
    from
        [stonedwv0].[dbo].[dimopportunity]
    group by
        [clientalternatekey]
) tpvestimate on affiliation.[clientalternatekey] = cast(tpvestimate.[clientalternatekey] as varchar(50))
left join (
    select
        max([nr_estimated_monthly_tpv]) as [nr_estimated_monthly_tpv]
        , nr_stonecode
    from
        {{ ti.xcom_pull('create_support_table_2') }}
    group by
        nr_stonecode
) tpvestimatecadastro on affiliation.clientalternatekey = tpvestimatecadastro.nr_stonecode
