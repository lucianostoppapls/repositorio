use stonedwv0

delete from [stonedwv0].[dbo].[factotherrevenues]
where [datekey] = '{{ ds_nodash }}' and companykey in (1,2)

insert into [stonedwv0].[dbo].[factotherrevenues] (
    [companykey]
    , [datekey]
    , [vendorkey]
    , [revenue]
    , [revenuetypekey]
    , [affiliationkey]
    , [quantity]
)

select
    1
    , replace(z.[dt_transacao], '-', '')
    , isnull(a.[vendorkey], 1)
    , sum(z.[vl_mdr]) - sum(z.[vl_ic])
    , 13
    , isnull(c.[affiliationkey], 1)
    , sum(z.[nr_transacoes])
from
    {{ ti.xcom_pull('create_table') }} z
left join (
    select
        vendoralternatekey
        , max(vendorkey) as [vendorkey]
    from
        [dbo].[dimvendor] 
    where
        vendoralternatekey is not null
    group by
        vendoralternatekey
) a on a.[vendoralternatekey] = isnull(z.[id_registro], -1)
left join (
    select distinct
        n.[clientalternatekey]
        , n.[affiliationkey]
        , m.[clientkey]
    from
        [dbo].[dimclient] m 
    inner join
        [dbo].[dimaffiliation] n on m.[clientkey] = n.[clientkey]
    where n.[clientalternatekey] is not null and n.[companykey] in (1,2)
) c on c.[clientalternatekey] = isnull(z.[stonecode], -1)
where
    z.[nm_produto] = 'boleto'
    and z.[nm_empresa] = 'stone'
group by
    replace(z.[dt_transacao], '-', ''),
    a.[vendorkey]
    , c.[affiliationkey]
