select distinct
    case when isnull([ds_canal],'') = '' then 'N/D' else [ds_canal] end as [salesstructurenamelevel1]
    , case when isnull([nm_subcanal],'') = '' then 'N/D' else [nm_subcanal] end as [salesstructurenamelevel2]
    , case when isnull([ds_grupo1],'') = '' then '-' else [ds_grupo1] end as [salesstructurenamelevel3]
    , case when isnull([ds_grupo2],'') = '' then '-' else [ds_grupo2] end as [salesstructurenamelevel4]
    , case when isnull([ds_grupo3],'') = '' then '-' else [ds_grupo3] end as [salesstructurenamelevel5]
    , case when isnull([ds_grupo3],'') = '' then '-' else [ds_grupo3] end as [salesstructurenamelevel6]
into
    #carteira
from
    [bdmdmis_stone].[dbo].[tbstoned_vendedor_stone] 

union

select distinct
    case when isnull([ds_canal],'') = '' then 'N/D' else [ds_canal] end as [salesstructurenamelevel1]
    , case when isnull([nm_subcanal],'') = '' then 'N/D' else [nm_subcanal] end as [salesstructurenamelevel2]
    , case when isnull([ds_grupo1],'') = '' then '-' else [ds_grupo1] end as [salesstructurenamelevel3]
    , case when isnull([ds_grupo2],'') = '' then '-' else [ds_grupo2] end as [salesstructurenamelevel4]
    , case when isnull([ds_grupo3],'') = '' then '-' else [ds_grupo3] end as [salesstructurenamelevel5]
    , case when isnull([ds_grupo3],'') = '' then '-' else [ds_grupo3] end as [salesstructurenamelevel6]
from
    [bdmdmis_stone].[dbo].[tbstonef_cadastro_integrado_ec] 

union

select
    case when isnull([ds_canal],'') = '' then 'N/D' else [ds_canal] end as [salesstructurenamelevel1]
    , case when isnull([nm_subcanal],'') = '' then 'N/D' else [nm_subcanal] end as [salesstructurenamelevel2]
    , case when isnull([grupo1],'') = '' then '-' else [grupo1] end as [salesstructurenamelevel3]
    , case when isnull([grupo2],'') = '' then '-' else [grupo2] end as [salesstructurenamelevel4]
    , case when isnull([grupo3],'') = '' then '-' else [grupo3] end as [salesstructurenamelevel5]
    , case when isnull([grupo3],'') = '' then '-' else [grupo3] end as [salesstructurenamelevel6]
from
    [stonecoods].[pagarme].[vw_carteira_pagarme_cubo] 

union

select distinct
    isnull([ds_canal], 'N/D') as [salesstructurenamelevel1]
    , isnull([nm_subcanal], 'N/D') as [salesstructurenamelevel2]
    , isnull([ds_grupo1], '-') as [salesstructurenamelevel3]
    , isnull([ds_grupo2], '-') as [salesstructurenamelevel4]
    , isnull([ds_grupo3], '-') as [salesstructurenamelevel5]
    , isnull([ds_grupo3], '-') as [salesstructurenamelevel6]
from [stonecoods].[mundi].[vw_carteira_mundi]

union

select distinct
    isnull([ds_canal], 'N/D') as [salesstructurenamelevel1]
    , isnull([nm_subcanal], 'N/D') as [salesstructurenamelevel2]
    , isnull([ds_grupo1], '-') as [salesstructurenamelevel3]
    , isnull([ds_grupo2], '-') as [salesstructurenamelevel4]
    , isnull([ds_grupo3], '-') as [salesstructurenamelevel5]
    , isnull([ds_grupo3], '-') as [salesstructurenamelevel6]
from
    [stonecoods].[cappta].[vw_carteira_cappta]


select [salesstructurenamelevel1]
, [salesstructurenamelevel2]
, [salesstructurenamelevel3]
, [salesstructurenamelevel4]
, [salesstructurenamelevel5]
, [salesstructurenamelevel6]
from #carteira
group by [salesstructurenamelevel1]
, [salesstructurenamelevel2]
, [salesstructurenamelevel3]
, [salesstructurenamelevel4]
, [salesstructurenamelevel5]
, [salesstructurenamelevel6]
