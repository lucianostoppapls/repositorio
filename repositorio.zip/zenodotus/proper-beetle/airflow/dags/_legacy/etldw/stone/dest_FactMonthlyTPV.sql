use stonedwv0

delete from
    [stonedwv0].[dbo].[factmonthlytpv]
where
    [transactiondate] = replace(eomonth('{{ ds }}'),'-','')


insert into [stonedwv0].[dbo].[factmonthlytpv] (
    [transactiondate]
    , [affiliationkey]
    , [tpv]
    , [dia]
)

select
    replace(eomonth([fulldate]),'-','')
    , tpv.[affiliationkey]
    , sum(tpv)
    , sum(dia)
from
    [stonedwv0].[dbo].[facttpv] tpv
inner join
    [stonedwv0].[dbo].[dimdate] dt on tpv.[transactiondate] = dt.[datekey]
where
    eomonth([fulldate]) = eomonth('{{ ds }}')
group by
    eomonth([fulldate])
    , tpv.[affiliationkey]
