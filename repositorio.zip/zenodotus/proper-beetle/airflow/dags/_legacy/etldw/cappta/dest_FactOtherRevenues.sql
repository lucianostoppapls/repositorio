--------------------------------------------------------
---------------------- carga ---------------------------
--------------------------------------------------------

if object_id('tempdb..#baseclient') is not null
    drop table #baseclient

if object_id('tempdb..#basevendor') is not null
    drop table #basevendor

if object_id('tempdb..#basedataint') is not null
    drop table	#basedataint

if object_id('tempdb..#basedata') is not null
    drop table #basedata


select distinct
    b.clientalternatekey as clientalternatekeycappta
    , min(b.affiliationkey) as affiliationkey
    , min(a.clientkey) as clientkey
into
    #baseclient
from
    [stonedwv0].[dbo].[dimclient] a 
inner join
    [stonedwv0].[dbo].[dimaffiliation] b on a.clientkey = b.clientkey
where
    b.clientalternatekey is not null
    and b.companykey = 6
group by
    b.clientalternatekey

create index tmp_idx_1 on #baseclient (clientalternatekeycappta, affiliationkey, clientkey)


select
    vendoralternatekeycappta
    , max(vendorkey) vendorkey
into
    #basevendor
from
    [stonedwv0].[dbo].[dimvendor] 
where
    vendoralternatekeycappta is not null
group by
    vendoralternatekeycappta

create nonclustered index tmp_idx_2 on #basevendor(vendoralternatekeycappta) include (vendorkey)



select
    b.cnpj as customerkey
    , f.clientkey
    , f.affiliationkey
    , e.vendoralternatekeycappta
    , e.vendorkey
into
    #basedataint
from
    {{ ti.xcom_pull('create_support_table_cadastro_ec') }} b 
left join
    {{ ti.xcom_pull('create_support_table_capptor') }} c on b.[capptor] = c.[capptor]
left join
    #basevendor e on e.vendoralternatekeycappta = c.[capptor_id]
left join
    #baseclient f on f.clientalternatekeycappta = b.cnpj
left join
    {{ ti.xcom_pull('create_support_table_carteira_cappta') }} car on f.clientalternatekeycappta = car.[cnpj]



select
    convert(varchar(255), a.customerkey ) customerkey
    , a.clientkey
    , a.vendoralternatekeycappta
    , isnull(a.vendorkey, 1) vendorkey
    , a.affiliationkey
into
    #basedata
from
    #basedataint a

create nonclustered index tmp_idx_3 on #basedata(customerkey) include(clientkey,vendoralternatekeycappta, affiliationkey)




delete
from stonedwv0.dbo.[factotherrevenues]
where companykey in (6)
and eomonth(convert(date,convert(char(8),[datekey]))) = eomonth('{{ ds }}')

insert into [stonedwv0].[dbo].[factotherrevenues] (
	[companykey]
	, [datekey]
	, [vendorkey]
	, [revenue]
	, [revenuetypekey]
	, [quantity]
	, [affiliationkey])


select
	6
    , d.datekey
    , e.vendorkey
    , sum(convert(decimal(38,2), valor))
    , isnull(b.revenuetypekey,9)
    , 1
    , [affiliationkey]
from
    {{ ti.xcom_pull('create_support_table_areceber') }}  a
left join
    [stonedwv0].[dbo].[dimrevenuetype] b on a.[tipo_do_faturamento] = b.[revenuetypename]
inner join
    [stonedwv0].[dbo].[dimdate] d on convert(date, a.[data_do_faturamento])= d.fulldate
inner join
    #basedata e on a.[cnpj] = e.customerkey
where
    eomonth(convert(date,a.[data_do_faturamento])) = eomonth('{{ ds }}')
group by
    d.datekey
    , e.clientkey
    , e.vendorkey
    , b.revenuetypekey
    , [affiliationkey]
having
    sum(convert(decimal(38,2), valor)) > 0

union

select
    6
    , b.datekey
    , 1
    , sum([valor])
    , 30
    , 1
    , 698240
from
    {{ ti.xcom_pull('create_support_table_rebate') }}  a
inner join
    dimdate b on convert(date, a.data) = b.fulldate
where
    eomonth(a.[data]) = eomonth('{{ ds }}')
group by
    b.datekey