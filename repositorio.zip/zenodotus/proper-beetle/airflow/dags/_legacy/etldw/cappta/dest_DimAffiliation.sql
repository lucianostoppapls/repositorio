use stonedwv0

if object_id('tempdb..#alteracoesdimaffiliation') is not null
	drop table #alteracoesdimaffiliation


select distinct
	b.clientalternatekeycappta as clientalternatekeycappta
	, c.salesstructurekey
	, isnull(t.geographykey,1) as geographykey
	, b.clientlegalname
	, b.clientname
	, cast(replace(b.createdate, '-', '') as int) as createdate
	, b.clientcnpjorcpf as clientcnpjorcpf
	, v.vendorkey
	, i.clientkey
	, s.clientstatuskey
	, m.mcckey
into 
	#alteracoesdimaffiliation
from 
	dimaffiliation a 
inner join 
	(select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 6) b on a.clientalternatekey = b.clientalternatekeycappta
inner join 
	dimsalesstructure c on 
		b.ds_canal = c.salesstructurenamelevel1
		and b.nm_subcanal = c.salesstructurenamelevel2
		and b.ds_grupo1 = c.salesstructurenamelevel3
		and b.ds_grupo2 = c.salesstructurenamelevel4
		and b.ds_grupo3 = c.salesstructurenamelevel5
		and b.ds_grupo4 = c.salesstructurenamelevel6
left join 
	[stonedwv0].[dbo].[dimvendor] v on b.[closer_id] = (isnull(v.vendoralternatekeycappta,0001))
left join 
	dimgeography t on t.geographykey = isnull([dbo].fc_regexp_003(b.[zipcode],'^0-9'),1)
inner join (
	select distinct 
		[clientcnpjorcpf]
		, [salesstructurekey]
		, [companykey]
		, [clientkey]
	from dimclient
	where 
		(clientstatuskey <> 7 or clientstatuskey is null)
		and companykey in (6)
) i on 
	b.clientcnpjorcpf = i.[clientcnpjorcpf]
	and c.[salesstructurekey] = i.[salesstructurekey]
	and a.[companykey] = i.[companykey]
left join 
	dimclientstatus s on iif(b.[status] = 'fechado', 'credenciado', b.[status]) = s.clientstatusdesc
left join 
	dimmcc m on b.mccname = m.mccname
where 
	a.salesstructurekey <> c.salesstructurekey
	or b.clientname <> a.clientname
	or isnull(t.geographykey,1) <> isnull(a.geographykey,1)
	or b.clientlegalname <> a.clientlegalname
	or cast(replace(b.createdate, '-', '') as int) <> a.createdate
	or b.clientcnpjorcpf <> a.clientcnpjorcpf
	or v.vendorkey <> a.vendorkey
	or i.clientkey <> a.clientkey
	or s.clientstatuskey <> a.clientstatuskey
	or m.mcckey <> a.mcckey


update a
set
	a.salesstructurekey = b.salesstructurekey
	, a.clientname = b.clientlegalname
	, a.geographykey = b.geographykey
	, a.clientlegalname	= b.clientlegalname
	, a.createdate = b.createdate
	, a.clientcnpjorcpf = b.clientcnpjorcpf
	, a.vendorkey = b.vendorkey
	, a.clientkey = b.clientkey
	, a.clientstatuskey = b.clientstatuskey
	, a.mcckey = b.mcckey
from
	dimaffiliation a
inner join
	#alteracoesdimaffiliation b on a.clientalternatekey = b.clientalternatekeycappta




insert into [stonedwv0].[dbo].[dimaffiliation] (
	[clientcnpjorcpf]
	, [clientname]
	, [geographykey]
	, [clientlegalname]
	, [clientalternatekey]
	, [salesstructurekey]
	, [createdate]
	, [migrationdate]
	, [migrated]
	, [mcckey]
	, [companykey]
	, [chainname]
	, [clientstatuskey]
	, [vendorkey]
	, [clientkey]
	, [originregisterkey]
)

select
	a.[clientcnpjorcpf]
	, a.[clientname]
	, isnull(b.geographykey,1)
	, a.[clientlegalname]
	, a.[clientalternatekeycappta]
	, c.[salesstructurekey]
	, a.[createdate]
	, a.[createdate]
	, 0
	, m.[mcckey]
	, a.[companykey]
	, null
	, 1
	, min(v.vendorkey)
	, min(e.clientkey)
	, 19
from
	(select * from {{ ti.xcom_pull('create_table') }}  where [companykey] = 6) a 
left join
	stonedwv0.dbo.dimgeography  b on isnull([dbo].fc_regexp_003(a.[zipcode],'^0-9'),1) = b.geographykey
left join
	[stonedwv0].[dbo].[dimvendor] v on a.[closer_id] = (isnull(v.vendoralternatekeycappta,0001))
left join
	[stonedwv0].[dbo].[dimdate]  g on a.createdate = g.datekey
inner join
	[stonedwv0].[dbo].[dimsalesstructure]  c on (
		[salesstructurenamelevel1] = a.[ds_canal]
		and [salesstructurenamelevel2] = a.[nm_subcanal]
		and [salesstructurenamelevel3] = a.[ds_grupo1]
		and [salesstructurenamelevel4] = a.[ds_grupo2]
		and [salesstructurenamelevel5] = a.[ds_grupo3]
		and [salesstructurenamelevel6] = a.[ds_grupo4]
)
inner join [stonedwv0].[dbo].[dimclient]  e on
	a.clientcnpjorcpf = e.clientcnpjorcpf
	and a.companykey = e.companykey
	and c.salesstructurekey = e.salesstructurekey
	and (e.clientstatuskey <> 7 or clientstatuskey is null)
left join
	dimmcc m on a.mccname = m.mccname
where not exists (
	select top (1) 1
	from
		[stonedwv0].[dbo].[dimaffiliation]  d
	where
		a.clientalternatekeycappta = d.clientalternatekey
)
group by
	a.[clientcnpjorcpf]
	, a.[clientname]
	, isnull(b.geographykey,1)
	, a.[clientlegalname]
	, a.[clientalternatekeycappta]
	, c.[salesstructurekey]
	, a.createdate
	, a.createdate
	, a.companykey
	, m.[mcckey]
