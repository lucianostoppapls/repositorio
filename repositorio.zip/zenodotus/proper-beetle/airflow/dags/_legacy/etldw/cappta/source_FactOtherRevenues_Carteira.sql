select
    [cnpj] as [cnpj]
    , [capptor id] as [capptor_id]
    , [capptor] as [capptor]
    , [ds_canal] as [ds_canal]
    , [nm_subcanal] as [nm_subcanal]
    , [ds_grupo1] as [ds_grupo1]
    , [ds_grupo2] as [ds_grupo2]
    , [ds_grupo3] as [ds_grupo3]
from
    [stonecoods].[cappta].[vw_carteira_cappta]
