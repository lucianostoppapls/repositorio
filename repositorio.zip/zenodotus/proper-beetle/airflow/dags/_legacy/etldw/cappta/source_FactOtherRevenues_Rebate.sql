select *
from
    stonecoods.[cappta].[tbcapptat_rebate]
