select 
    [número do pedido] as [número_do_pedido]
    , [número do boleto] as [número_do_boleto]
    , [cnpj] as [cnpj]
    , [data do faturamento] as [data_do_faturamento]
    , [tipo do faturamento] as [tipo_do_faturamento]
    , [parcela] as [parcela]
    , [forma de pagamento] as [forma_de_pagamento]
    , [data de vencimento parcela] as [data_de_vencimento_parcela]
    , [data de pagto] as [data_de_pagto]
    , [status ] as [status ]
    , [número autorização] as [número_autorização]
    , [valor cartões] as [valor_cartões]
    , [valor controle] as [valor_controle]
    , [valor conecta] as [valor_conecta]
    , [valor] as [valor]
    , [valor pago] as [valor_pago]
    , [multa] as [multa]
    , [diferença pagamento (+)] as [diferença_pagamento_(+)]
    , [diferença pagamento (-)] as [diferença_pagamento_(-)]
    , [remuneração cartões] as [remuneração_cartões]
    , [remuneração controle] as [remuneração_controle]
    , [remuneração conecta] as [remuneração_conecta]
    , [remuneração] as [remuneração]
    , [remuneração original] as [remuneração_original]
    , [valor glosado] as [valor_glosado]
    , [nfe cartões] as [nfe_cartões]
    , [nfe consulta] as [nfe_consulta]
    , [nfe conecta] as [nfe_conecta]
    , [data perda] as [data_perda]
    , [usuário da perda] as [usuário_da_perda]
    , [simples?] as [simples?]
    , [tipo de cobrança] as [tipo_de_cobrança]
    , [nome do grupo] as [nome_do_grupo]
    , [capptor] as [capptor]
from
    [stonecoods].[cappta].[tbcapptat_areceber]
where
    eomonth(convert(date, [data do faturamento])) = eomonth('{{ ds }}')






