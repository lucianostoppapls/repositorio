use stonedwv0

if object_id('tempdb..#client_date') is not null
    drop table #client_date

select a.createdate
    , a.[ds_canal]
    , a.[nm_subcanal]
    , a.[ds_grupo1]
    , a.[ds_grupo2]
    , a.[ds_grupo3]
    , a.[ds_grupo4]
    , a.[clientcnpjorcpf]
    , b.clientalternatekeycappta
into #client_date
from (
    select
        min(createdate) createdate
        , [ds_canal]
        , [nm_subcanal]
        , [ds_grupo1]
        , [ds_grupo2]
        , [ds_grupo3]
        , [ds_grupo4]
        , clientcnpjorcpf
    from
        (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 6)
    group by
        [ds_canal]
        , [nm_subcanal]
        , [ds_grupo1]
        , [ds_grupo2]
        , [ds_grupo3]
        , [ds_grupo4]
        , clientcnpjorcpf
    ) a
inner join (
    select
        createdate
        , min(clientalternatekeycappta) clientalternatekeycappta
        , [ds_canal]
        , [nm_subcanal]
        , [ds_grupo1]
        , [ds_grupo2]
        , [ds_grupo3]
        , [ds_grupo4]
        , clientcnpjorcpf
    from
        (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 6)
    group by
        createdate
        , [ds_canal]
        , [nm_subcanal]
        , [ds_grupo1]
        , [ds_grupo2]
        , [ds_grupo3]
        , [ds_grupo4]
        , clientcnpjorcpf
) b on
    a.clientcnpjorcpf = b.clientcnpjorcpf
    and a.ds_canal = b.ds_canal
    and a.nm_subcanal = b.nm_subcanal
    and a.ds_grupo1 = b.ds_grupo1
    and a.ds_grupo2 = b.ds_grupo2
    and a.ds_grupo3 = b.ds_grupo3
    and a.ds_grupo4 = b.ds_grupo4
    and a.createdate = b.createdate
group by
    a.createdate
    , a.[ds_canal]
    , a.[nm_subcanal]
    , a.[ds_grupo1]
    , a.[ds_grupo2]
    , a.[ds_grupo3]
    , a.[ds_grupo4]
    , a.clientcnpjorcpf
    , b.clientalternatekeycappta


update dimclient
set clientstatuskey = 1
where companykey = 6


if object_id('tempdb..#alteracoesdimclient') is not null
    drop table #alteracoesdimclient


select distinct
    a.clientkey
    , b.clientalternatekeycappta as clientalternatekeycappta
    , c.salesstructurekey
    , isnull(t.geographykey,1) as geographykey
    , b.clientlegalname
    , b.createdate
    , b.clientcnpjorcpf as clientcnpjorcpf
    , isnull(v.vendorkey, 1) vendorkey
    , s.clientstatuskey
    , m.mcckey
    , case
        when len(b.clientcnpjorcpf) <= 11 then 'PF'
        when isnumeric(right(b.clientlegalname, 11)) = 1 then 'MEI'
        else 'PJ'
    end as clientcnpjorcpfclassification
into
    #alteracoesdimclient
from
    dimclient a
inner join
    (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 6) b on a.clientalternatekeycappta = b.clientalternatekeycappta
inner join
    dimsalesstructure c on
        b.ds_canal = c.salesstructurenamelevel1
        and b.nm_subcanal = c.salesstructurenamelevel2
        and b.ds_grupo1 = c.salesstructurenamelevel3
        and b.ds_grupo2 = c.salesstructurenamelevel4
        and b.ds_grupo3 = c.salesstructurenamelevel5
        and b.ds_grupo4 = c.salesstructurenamelevel6
left join
    [stonedwv0].[dbo].[dimvendor] v on b.[capptor id] = (isnull(v.vendoralternatekeycappta,0001))
left join
    dimgeography t on t.geographykey = isnull([dbo].fc_regexp_003(b.[cep],'^0-9'),1)
left join
    dimclientstatus s on iif(b.[status] = 'Fechado', 'Credenciado', b.[status]) = s.clientstatusdesc
left join
    dimmcc m on b.mccname = m.mccname
where (
    a.salesstructurekey <> c.salesstructurekey
    or b.clientname <> a.clientname
    or isnull(t.geographykey,1) <> isnull(a.geographykey,1)
    or b.clientlegalname <> a.clientlegalname
    or b.createdate <> a.createdate
    or b.clientcnpjorcpf <> convert(varchar,a.clientcnpjorcpf)
    or v.vendorkey <> a.vendorkey
    or s.clientstatuskey <> a.clientstatuskey
    or m.mcckey <> a.mcckey
    or case
        when len(b.clientcnpjorcpf) <= 11 then 'pf'
        when isnumeric(right(b.clientlegalname, 11)) = 1 then 'mei'
        else 'pj'
    end <> a.clientcnpjorcpfclassification
)



update a
set
    a.salesstructurekey = b.salesstructurekey
    , a.clientname = b.clientlegalname
    , a.geographykey = b.geographykey
    , a.clientlegalname	= b.clientlegalname
    , a.createdate = b.createdate
    , a.clientcnpjorcpf = b.clientcnpjorcpf
    , a.vendorkey = b.vendorkey
    , a.clientstatuskey = b.clientstatuskey
    , a.mcckey = b.mcckey
    , a.clientcnpjorcpfclassification = b.clientcnpjorcpfclassification
from
    dimclient a
inner join
    #alteracoesdimclient b on a.clientkey = b.clientkey
--where a.clientstatuskey <> 7 or clientstatuskey is null



-- update clientes com data menor

update a
set clientstatuskey = 7
from dimclient a
    inner join (
        select
            clientcnpjorcpf
            , salesstructurekey
            , clientkey
        from
            dimclient a
        where not exists (
            select top 1 1
            from
                #client_date b
            where
                a.clientalternatekeycappta = b.clientalternatekeycappta
        )
        group by
            clientcnpjorcpf
            , salesstructurekey
            , clientkey
    ) b on a.clientkey = b.clientkey
where
    companykey = 6
and
    a.clientkey <> 1258604 -- cliente rebate



-- update conceito cnpj/canal

declare @cont int = (
    select sum(qtd)
    from (
        select
            count(*) as qtd
            , clientcnpjorcpf
            , salesstructurekey
            , max(clientkey) as clientkey
        from
            dimclient
        where
            companykey in (6)
            and clientstatuskey <> 7
        group by
            clientcnpjorcpf
            , salesstructurekey
        having
            count(*) > 1
    ) a
)

while @cont > 0


begin

update a
set
    clientstatuskey = 7
from
    dimclient a
inner join (
    select
        count(*) as qtd
        , clientcnpjorcpf
        , salesstructurekey
        , max(clientkey) as clientkey
    from
        dimclient
    where
        companykey in (6)
        and clientstatuskey <> 7
    group by
        clientcnpjorcpf
        , salesstructurekey
    having
        count(*) > 1
) b on a.clientkey = b.clientkey

set @cont = (
    select sum(qtd)
    from (
        select
            count(*) as  qtd
            , clientcnpjorcpf
            , salesstructurekey
            , max(clientkey) as clientkey
        from
            dimclient
        where
            companykey in (6)
            and clientstatuskey <> 7
        group by
            clientcnpjorcpf
            , salesstructurekey
        having
            count(*) > 1
    ) a
)

end



if object_id('tempdb..#cnpjcanal') is not null
    drop table #cnpjcanal

select
    clientcnpjorcpf
    , ds_canal
    , nm_subcanal
    , ds_grupo1
    , ds_grupo2
    , ds_grupo3
    , ds_grupo4
    , convert(varchar, min(clientalternatekeycappta)) as clientalternatekeycappta
into
    #cnpjcanal
from
    (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 6)
group by
    clientcnpjorcpf
    , ds_canal
    , nm_subcanal
    , ds_grupo1
    , ds_grupo2
    , ds_grupo3
    , ds_grupo4


insert into [stonedwv0].[dbo].[dimclient] (
    [clientcnpjorcpf]
    , [clientname]
    , [geographykey]
    , [clientparentkey]
    , [clientlegalname]
    , [clientalternatekeycappta]
    , [salesstructurekey]
    , [createdate]
    , [migrationdate]
    , [migrated]
    , [mcckey]
    , [companykey]
    , [chainname]
    , [clientstatuskey]
    , [vendorkey]
    , [originregisterkey]
    , [clientcnpjorcpfclassification]
)

select
    iif(a.[clientcnpjorcpf] = 'cnpj invalido', '0', a.[clientcnpjorcpf])
    , a.[clientname]
    , isnull(b.geographykey,1)
    , null
    , a.[clientlegalname]
    , a.[clientalternatekeycappta]
    , c.[salesstructurekey]
    , a.[createdate]
    , a.[createdate]
    , 0
    , m.[mcckey]
    , a.[companykey]
    , null
    , 1
    , max(v.vendorkey)
    , 19
    , case
        when len(a.[clientcnpjorcpf]) <= 11 then 'PF'
        when isnumeric(right(a.[clientlegalname], 11)) = 1 then 'MEI'
        else 'PJ'
    end as clientcnpjorcpfclassification
from
    #cnpjcanal cc
inner join
    (select * from {{ ti.xcom_pull('create_table') }} where [companykey] = 6) a  on cc.clientalternatekeycappta = a.clientalternatekeycappta
left join
    stonedwv0.dbo.dimgeography b  on isnull([dbo].fc_regexp_003(a.[cep],'^0-9'),1) = b.geographykey
left join
    [stonedwv0].[dbo].[dimvendor] v on a.[capptor id] = (isnull(v.vendoralternatekeycappta,0001))
inner join
    [stonedwv0].[dbo].[dimsalesstructure] c  on (
        [salesstructurenamelevel1] = a.[ds_canal]
        and [salesstructurenamelevel2] = a.[nm_subcanal]
        and [salesstructurenamelevel3] = a.[ds_grupo1]
        and [salesstructurenamelevel4] = a.[ds_grupo2]
        and [salesstructurenamelevel5] = a.[ds_grupo3]
        and [salesstructurenamelevel6] = a.[ds_grupo4]
)
left join
    dimmcc m on a.mccname = m.mccname
where not exists (
    select top (1) 1
    from
        [stonedwv0].[dbo].[dimclient] d 
    where
        a.clientcnpjorcpf = d.clientcnpjorcpf
        and a.companykey = d.companykey
        and c.salesstructurekey = d.salesstructurekey
        and (clientstatuskey is null or clientstatuskey <> 7)
)
and exists (
    select top 1 1
    from
        #client_date cd
    where
        a.clientalternatekeycappta = cd.clientalternatekeycappta
)
group by
    iif(a.[clientcnpjorcpf] = 'cnpj invalido', '0', a.[clientcnpjorcpf])
    , a.[clientname]
    , isnull(b.geographykey,1)
    , a.[clientlegalname]
    , a.[clientalternatekeycappta]
    , c.[salesstructurekey]
    , a.[createdate]
    , a.[createdate]
    , a.[companykey]
    , m.[mcckey]
    , case
        when len(a.[clientcnpjorcpf]) <= 11 then 'pf'
        when isnumeric(right(a.[clientlegalname], 11)) = 1 then 'mei'
        else 'pj'
    end
