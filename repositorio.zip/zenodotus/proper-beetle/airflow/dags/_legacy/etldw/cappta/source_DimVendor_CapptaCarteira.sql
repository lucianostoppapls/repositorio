select
    [cnpj]
    , [capptor id] as [capptor_id]
    , [capptor]
    , [ds_canal]
    , [nm_subcanal]
    , [ds_grupo1]
    , [ds_grupo2]
    , [ds_grupo3]
from
    [stonecoods].[cappta].[vw_carteira_cappta]