if object_id('tempdb..#tempvendor') is not null
    drop table #tempvendor

select
    a.[vendorkey]
into
    #tempvendor
from
    [stonedwv0].[dbo].[dimvendor] a 
where exists (
    select top (1) 1
    from
        (select * from {{ ti.xcom_pull('create_table') }} where companykey = 6) b
    left join
        {{ ti.xcom_pull('create_support_table_2') }} d on b.[closer_id] = d.[capptor_id]
    left join
        stonedwv0.dbo.dimsalesstructure e on
            isnull(d.ds_canal, 'N/D') = e.salesstructurenamelevel1
            and isnull(d.nm_subcanal, 'N/D') = e.salesstructurenamelevel2
            and isnull(d.ds_grupo1, '-') = e.salesstructurenamelevel3
            and isnull(d.ds_grupo2, '-') = e.salesstructurenamelevel4
            and isnull(d.ds_grupo3, '-') = e.salesstructurenamelevel5
            and isnull(d.ds_grupo3, '-') = e.salesstructurenamelevel6
    where
        b.[closer_id] = a.[vendoralternatekeycappta]
        and (
            b.[closer_name] <> a.[vendorname]
            or b.[nm_exibicao] <> a.[vendornickname]
            or b.[ds_emailvendedor] <> a.[emailaddress]
            or e.[salesstructurekey] <> a.[salesstructurekey]
        )
)



insert into [stonedwv0].[dbo].[dimvendor] (
    [salesstructurekey]
    , [vendorname]
    , [vendornickname]
    , [emailaddress]
    , [vendoralternatekeycappta]
)

select
    e.[salesstructurekey]
    , a.[closer_name]
    , a.[nm_exibicao]
    , a.[ds_emailvendedor]
    , a.[closer_id]
from
    (select * from {{ ti.xcom_pull('create_table') }} where companykey = 6)  a
left join
    {{ ti.xcom_pull('create_support_table_2') }} d on a.[closer_id] = d.[capptor_id]
left join
    stonedwv0.dbo.dimsalesstructure e on
        isnull(d.ds_canal, 'N/D') = e.salesstructurenamelevel1
        and isnull(d.nm_subcanal, 'N/D') = e.salesstructurenamelevel2
        and isnull(d.ds_grupo1, '-') = e.salesstructurenamelevel3
        and isnull(d.ds_grupo2, '-') = e.salesstructurenamelevel4
        and isnull(d.ds_grupo3, '-') = e.salesstructurenamelevel5
        and isnull(d.ds_grupo3, '-') = e.salesstructurenamelevel6
where not exists (
    select top (1) 1
    from
        [stonedwv0].[dbo].[dimvendor] b 
    where
        b.[vendoralternatekeycappta] = a.[closer_id]
)
group by
    e.[salesstructurekey]
    , a.[closer_name]
    , a.[nm_exibicao]
    , a.[ds_emailvendedor]
    , a.[closer_id]


update v
set
    v.[vendorname] = a.[closer_name]
    , v.[vendornickname] = a.[nm_exibicao]
    , v.[emailaddress] = a.[ds_emailvendedor]
    , v.[salesstructurekey] = e.[salesstructurekey]
from
    [stonedwv0].[dbo].[dimvendor] v 
    inner join
        (select * from {{ ti.xcom_pull('create_table') }} where companykey = 6) a on v.vendoralternatekeycappta = a.[closer_id]
    left join
        {{ ti.xcom_pull('create_support_table_2') }} d on a.[closer_id] = d.[capptor_id]
    left join
        stonedwv0..dimsalesstructure e on
            isnull(d.ds_canal, 'N/D') = e.salesstructurenamelevel1
            and isnull(d.nm_subcanal, 'N/D') = e.salesstructurenamelevel2
            and isnull(d.ds_grupo1, '-') = e.salesstructurenamelevel3
            and isnull(d.ds_grupo2, '-') = e.salesstructurenamelevel4
            and isnull(d.ds_grupo3, '-') = e.salesstructurenamelevel5
            and isnull(d.ds_grupo3, '-') = e.salesstructurenamelevel6
where
    v.[vendorkey] in (select [vendorkey] from #tempvendor)
