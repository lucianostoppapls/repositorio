from mssql_utils import MsSqlOperatorPYODBC
from airflow.utils.decorators import apply_defaults


class CleanTableOperator(MsSqlOperatorPYODBC):
    @apply_defaults
    def __init__(self, table, database, date_column, autocommit=True, *args, **kwargs):
        self.autocommit = autocommit

        kwargs.update(
            params={"table": table, "database": database, "date_column": date_column},
            sql="""
                DELETE FROM {{ params.database }}.{{ params.table }}
                WHERE [{{ params.date_column }}] = '{{ ds_nodash }}'
                """,
        )
        super().__init__(autocommit=self.autocommit, *args, **kwargs)


class TruncateTableOperator(MsSqlOperatorPYODBC):
    @apply_defaults
    def __init__(self, table, database, autocommit=True, *args, **kwargs):
        self.autocommit = autocommit

        kwargs.update(
            params={"table": table, "database": database},
            sql="TRUNCATE TABLE {{params.database}}.{{params.table}}",
        )
        super().__init__(autocommit=self.autocommit, *args, **kwargs)
