from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args, transfer_tasks


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_opportunity_stage_v2",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 6, 0),
    default_args=default_args,
)

transfer_tasks(
    dag=dag,
    repo_name="salesforce",
    table="DimOpportunityStage",
    database="StoneDWv0",
    column_types={
        "[OpportunityStageKey]": "[nvarchar](18) NOT NULL",
        "[IsClosed]": "[bit] NULL",
        "[CreatedDate]": "[varchar](8) NULL",
        "[Description]": "[nvarchar](255) NULL",
        "[IsActive]": "[bit] NULL",
        "[LastModifiedDate]": "[varchar](8) NULL",
    },
    prod_schema="dbo",
    date_column="LastUpdatedAt",
)
