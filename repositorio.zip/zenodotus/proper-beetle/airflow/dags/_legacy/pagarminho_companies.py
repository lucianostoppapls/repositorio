from datetime import datetime, timedelta
from airflow import DAG
from _legacy.pagarminho import default_args, inject_tasks

dag = DAG(
    dag_id=f"_legacy__pagarminho_companies_v2",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2021, 7, 8, 6, 0),
    default_args=default_args,
)

inject_tasks(
    dag=dag,
    etl_name="companies_test",
    looker_tables=[],
    source_sql="pagarminho/companies.sql",
    gcs_file="airflow-files/_legacy/pagarminho/{{ ds }}-companies.csv",
    dest_database="StoneCoODS",
    dest_schema="pagarme",
    dest_table="companies",
    date_column=None,
)
