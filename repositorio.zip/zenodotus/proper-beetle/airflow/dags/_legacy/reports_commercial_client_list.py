from mssql_utils import MsSqlOperatorPYODBC
from airflow import DAG
from datetime import datetime, timedelta
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts
from airflow.operators.latest_only import LatestOnlyOperator


dag = DAG(
    dag_id="_legacy__reports_commercial_client_list",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 17, 0),
    default_args={
        "autocommit": True,
        "retries": 4,
        "retry_delay": timedelta(minutes=15),
        "google_cloud_storage_conn_id": "gcp_mis",
        "mssql_conn_id": "bw_azure",
        "on_failure_callback": PagerDutyAlerts.failure_incident,
        "on_success_callback": PagerDutyAlerts.resolve_incident,
    },
)

ds = "{{ds}}"
with dag:
    only_latest = LatestOnlyOperator(task_id="only_latest")

    truncate_mssql_task = MsSqlOperatorPYODBC(
        task_id="truncate_mssql_kpi_commercial_client_list",
        database="StoneDwv0",
        sql="""
            truncate table StoneDWv0.kpi.CommercialClientList
        """,
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_mssql_task = MsSqlOperatorPYODBC(
        task_id="load_mssql_kpi_commercial_client_list",
        database="StoneDwv0",
        sql="reports/kpi_commercial_client_list.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    only_latest >> truncate_mssql_task >> load_mssql_task
