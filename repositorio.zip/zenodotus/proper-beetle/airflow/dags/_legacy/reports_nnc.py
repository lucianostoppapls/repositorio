from mssql_utils import MsSqlOperatorPYODBC
from airflow import DAG
from datetime import datetime, timedelta

dag = DAG(
    dag_id="_legacy__reports_nnc",
    schedule_interval=timedelta(days=7),
    start_date=datetime(2020, 4, 26, 20, 0),
    default_args={
        "autocommit": True,
        "retries": 4,
        "retry_delay": timedelta(minutes=15),
    },
)

ds = "{{ds}}"

with dag:
    nnc_weekly = MsSqlOperatorPYODBC(
        task_id="nnc_weekly",
        database="StoneDwv0",
        sql="/reports/nnc/nnc_weekly.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )
