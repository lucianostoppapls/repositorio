DECLARE @Stonecode BIGINT
DECLARE @DueDate Date
DECLARE @AmountPos NUMERIC(18,2)
DECLARE @AmountNeg NUMERIC(18,2)
DECLARE @WalletType Varchar(255)
DECLARE @RowNumb BIGINT

SET NOCOUNT ON

DELETE FROM [DBMis].[etl].[cobranca_Balance]
WHERE [DueDate] >= CAST(GETUTCDATE() AS DATE);

DELETE FROM [DBMis].[cobranca].[Balance]
WHERE referenceDate = CAST(GETUTCDATE() AS DATE);

INSERT INTO [DBMis].[cobranca].[Balance]
           ([DueDate]
           ,[Stonecode]
           ,[Amount]
           ,[WalletType])
SELECT A.[DueDate]
      ,B.AffiliationCode AS Stonecode
      ,A.[Amount]
      ,c.Description [WalletType]
FROM [DBMis].[etl].[cobranca_Balance] A 
JOIN [DBMis].[cobranca].[Merchant] B  ON A.[AffiliationKey] = B.[AffiliationKey]
JOIN [DBMis].[etl].[cobranca_WalletType] C  ON A.[WalletTypeId] = C.[id];

IF OBJECT_ID('tempdb..#PositiveValues') IS NOT NULL
	DROP TABLE #PositiveValues

CREATE TABLE #PositiveValues (
	Stonecode BIGINT,
	WalletType VARCHAR(255),
	Amount NUMERIC(18,2)
)

INSERT INTO #PositiveValues (Stonecode,WalletType,Amount)
SELECT B.AffiliationCode
      ,c.Description
      ,SUM(A.[Amount])      
FROM [DBMis].[etl].[cobranca_Balance] A 
JOIN [DBMis].[cobranca].[Merchant] B  ON A.[AffiliationKey] = B.[AffiliationKey]
JOIN [DBMis].[etl].[cobranca_WalletType] C  ON A.[WalletTypeId] = C.[id]
WHERE A.[Amount] > 0
GROUP BY B.AffiliationCode
        ,c.Description

IF OBJECT_ID('tempdb..#NetValues') IS NOT NULL
	DROP TABLE #NetValues

CREATE TABLE #NetValues (
	DueDate DATE,
	RowNumb BIGINT,
	Stonecode BIGINT,
	WalletType VARCHAR(255),
	Amount NUMERIC(18,2),
	AmountPay  NUMERIC(18,2),
	netAmount AS (Amount+AmountPay)
)

INSERT INTO #NetValues (DueDate,RowNumb,Stonecode,Amount,WalletType,AmountPay)
SELECT [DueDate]
	  ,ROW_NUMBER() OVER(Partition by Stonecode,[DueDate],[WalletType] Order by [Amount])
      ,Stonecode
      ,[Amount]
      ,[WalletType] [WalletType]
	  ,0
FROM  (
	SELECT A.[DueDate]
		  ,B.AffiliationCode AS Stonecode
		  ,SUM(A.[Amount])[Amount]
		  ,c.Description [WalletType]
	FROM [DBMis].[etl].[cobranca_Balance] A 
	JOIN [DBMis].[cobranca].[Merchant] B  ON A.[AffiliationKey] = B.[AffiliationKey]
	JOIN [DBMis].[etl].[cobranca_WalletType] C  ON A.[WalletTypeId] = C.[id]
	WHERE A.[Amount] < 0
	  AND EXISTS(
		SELECT TOP(1) 1
		FROM #PositiveValues PV
		WHERE B.AffiliationCode = PV.Stonecode
		  AND C.Description = PV.WalletType
	  )
	GROUP BY
		   A.[DueDate]
		  ,B.AffiliationCode
		  ,c.Description
) A


DECLARE C_Positive CURSOR LOCAL FOR
	SELECT
		Stonecode,
		WalletType,
		Amount
	FROM #PositiveValues
OPEN C_Positive
	FETCH NEXT FROM C_Positive INTO @Stonecode,@WalletType,@AmountPos
	WHILE @@fetch_status=0 BEGIN

			DECLARE C_NetValue CURSOR LOCAL FOR
				SELECT
					DueDate,
					RowNumb,
					Amount
				FROM #NetValues
				WHERE Stonecode = @Stonecode
				  AND WalletType = @WalletType
				ORDER BY DueDate ASC, RowNumb ASC
			OPEN C_NetValue
				FETCH NEXT FROM C_NetValue INTO @DueDate,@RowNumb,@AmountNeg
				WHILE @@fetch_status=0 BEGIN

					UPDATE #NetValues
					SET AmountPay = IIF(@AmountPos+@AmountNeg >= 0,ABS(@AmountNeg),@AmountPos)
					WHERE Stonecode = @Stonecode
					  AND WalletType = @WalletType
					  AND DueDate = @DueDate
					  AND RowNumb = @RowNumb
					
					SET @AmountPos = @AmountPos+@AmountNeg

					IF(@AmountPos <= 0)
						BREAK

					FETCH NEXT FROM C_NetValue INTO @DueDate,@RowNumb,@AmountNeg
				END
			CLOSE C_NetValue
			DEALLOCATE C_NetValue

		FETCH NEXT FROM C_Positive INTO @Stonecode,@WalletType,@AmountPos
	END
CLOSE C_Positive
DEALLOCATE C_Positive

DELETE FROM [DBMis].[cobranca].[BalanceNet]
WHERE referenceDate = CAST(GETUTCDATE() AS DATE);

INSERT INTO [DBMis].[cobranca].[BalanceNet]
           ([DueDate]
           ,[Stonecode]
           ,[WalletType]
           ,[Amount]
           ,[AmountPay]
           ,[netAmount])
		    
SELECT
	DueDate,
	Stonecode,
	WalletType,
	Amount,
	AmountPay,
	netAmount
FROM #NetValues
WHERE netAmount <> 0
UNION ALL
SELECT A.[DueDate]
	  ,B.AffiliationCode AS Stonecode
      ,c.Description [WalletType]
	  ,SUM(A.[Amount])
      ,0
	  ,SUM(A.[Amount])
FROM [DBMis].[etl].[cobranca_Balance] A 
JOIN [DBMis].[cobranca].[Merchant] B  ON A.[AffiliationKey] = B.[AffiliationKey]
JOIN [DBMis].[etl].[cobranca_WalletType] C  ON A.[WalletTypeId] = C.[id]
WHERE A.[Amount] < 0
  AND NOT EXISTS(
	SELECT TOP(1) 1
	FROM #PositiveValues PV
	WHERE B.AffiliationCode = PV.Stonecode
	  AND C.Description = PV.WalletType
  )
GROUP BY
	   A.[DueDate]
	  ,B.AffiliationCode
      ,c.Description

SET NOCOUNT OFF