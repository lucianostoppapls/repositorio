DELETE FROM [DBMis].[cobranca].[FutureReceivables]
WHERE referenceDate = '{{ next_execution_date.strftime('%Y-%m-%d') }}';

INSERT INTO [DBMis].[cobranca].[FutureReceivables]
           ([stonecode]
           ,[futureReceivables])
SELECT Stonecode
      ,[ToPay]
FROM [DBMis].[etl].[cobranca_FutureReceivables];