WITH sanitized_wallettype AS (
    SELECT
        [Id]
        ,[Description]
        ,CASE
            WHEN [Description] = 'Default' THEN 'Produto'
            WHEN [Description] = 'PaymentSlip' THEN 'Produto'
            ELSE 'Adquirente'
        END AS GroupName
FROM [DBMis].[etl].[cobranca_WalletType]
)

MERGE
    [DBMis].[cobranca].[WalletType] AS final
USING
    sanitized_wallettype AS temp ON (final.Id = temp.Id)

WHEN MATCHED AND (final.Description <> temp.Description OR final.GroupName <> temp.GroupName) THEN
    UPDATE SET
        final.Description = temp.Description,
        final.GroupName = temp.GroupName

WHEN NOT MATCHED THEN
    INSERT
    VALUES(temp.Id, temp.Description, temp.GroupName);
