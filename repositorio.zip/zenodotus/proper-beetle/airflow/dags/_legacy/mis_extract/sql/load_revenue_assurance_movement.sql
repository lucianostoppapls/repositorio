DELETE FROM [DBMis].[revenue_assurance].[Movement]
WHERE CAST(EntryDate as DATE) IN (
	SELECT CAST(ENTRY_DATE as DATE) FROM [DBMis].[etl].[revenueAssurance_Movement]
);

INSERT INTO [DBMis].[revenue_assurance].[Movement]
           ([IdMovement]
           ,[EntryDate]
           ,[DueDate]
           ,[IdMerchant]
           ,[IdProduct]
           ,[Stonecode]
           ,[IdMovementType]
           ,[MovementNAme]
           ,[idBrand]
           ,[Amount])
SELECT
	 [ID_MOVEMENT]
	,[ENTRY_DATE]
	,[DUE_DATE]
	,[ID_MERCHANT]
	,[ID_PRODUCT]
	,[MERCHANT_IDENTIFIER]
	,[BUY4_MOVEMENT_CATEGORY]
	,[BUY4_MOVEMENT_NAME]
	,[ID_BRAND]
	,[AMOUNT]
FROM [DBMis].[etl].[revenueAssurance_Movement];
