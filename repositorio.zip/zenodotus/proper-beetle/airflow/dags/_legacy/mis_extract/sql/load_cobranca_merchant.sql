TRUNCATE TABLE [DBMis].[cobranca].[Merchant];

INSERT INTO [DBMis].[cobranca].[Merchant]
           ([AffiliationCode]
           ,[AffiliationKey]
           ,[CreationDate]
           ,[MerchantType]
           ,[MerchantDocument]
		   ,[MerchantStatus])
SELECT CAST([AffiliationCode] AS BIGINT)
      ,[AffiliationKey]
      ,[CreationDate]
      ,[MerchantType]
      ,[MerchantDocument]
	  ,[MerchantStatus]
FROM [DBMis].[etl].[cobranca_Merchant]
WHERE [AffiliationCode] IS NOT NULL
  AND [AffiliationKey] IS NOT NULL