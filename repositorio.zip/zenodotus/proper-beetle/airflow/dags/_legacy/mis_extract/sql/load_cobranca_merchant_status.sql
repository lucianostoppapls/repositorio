TRUNCATE TABLE [DBMis].[cobranca].[MerchantStatus];

WITH MerchantStatus AS (
	SELECT [AffiliationCode]
		  ,[CreationDate]
		  ,[MerchantStatus]
		  ,ROW_NUMBER() OVER (PARTITION BY [AffiliationCode], CAST([CreationDate] AS DATE) ORDER BY [CreationDate] desc) as rw
	FROM [DBMis].[etl].[cobranca_MerchantStatus]
)

INSERT INTO [DBMis].[cobranca].[MerchantStatus]
           ([AffiliationCode]
           ,[CreationDate]
           ,[MerchantStatus])
SELECT
	 [AffiliationCode]
	,CAST([CreationDate] AS DATE) [CreationDate]
	,[MerchantStatus]
FROM MerchantStatus
WHERE rw = 1

