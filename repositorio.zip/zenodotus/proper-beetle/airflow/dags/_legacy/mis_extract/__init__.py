from datetime import timedelta
from _legacy.stone_extract import create_dags
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts


default_args = {
    "mssql_conn_id": "bw_azure",
    "pool": "mis_extract_job_control",
    "autocommit": True,
    "depends_on_past": True,
    "retries": 4,
    "retry_delay": timedelta(minutes=15),
    "on_failure_callback": PagerDutyAlerts.failure_incident,
    "on_success_callback": PagerDutyAlerts.resolve_incident,
}

create_dags
