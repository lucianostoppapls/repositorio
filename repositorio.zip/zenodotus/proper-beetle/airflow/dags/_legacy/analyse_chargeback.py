from datetime import datetime, timedelta
from airflow import DAG
from mssql_utils import MsSqlOperatorPYODBC
from plugins.mssql_utils import GCSToMssqlExtractOperator
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts
from airflow import configuration as conf
from plugins.gcp_utils import BigqueryToGCSOperator


default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "retries": 4,
    "retry_delay": timedelta(minutes=15),
    "autocommit": True,
    "google_cloud_storage_conn_id": "gcp_mis",
    "mssql_conn_id": "bw_azure",
    "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "on_failure_callback": PagerDutyAlerts.failure_incident,
    "on_success_callback": PagerDutyAlerts.resolve_incident,
}

dag = DAG(
    dag_id="_legacy__analyse_chargeback_recents",
    default_args=default_args,
    schedule_interval="@monthly",
    start_date=datetime(2021, 12, 1, 8, 20),
)

with dag:
    extractAP = BigqueryToGCSOperator(
        task_id="extract_analyze_chargeback_tratadoAP",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/analyse_chargeback/movement_tratadoAP_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="""
            WITH TMP_TRATAMENTO_AP AS (
                SELECT ATX.IdBrand,
                    ATX.AcquirerTransactionKey,
                    AMR.ConfirmedTransactionId,
                    AMR.IdMovement,
                    AMR.InstallmentNumber,
                    AMR.InstallmentQuantity,
                    AMR.EntryDate,
                    AMR.Amount, 
                    AMR.MovementCategory,	
                    CASE
                        WHEN (AMR.MovementCategory = 28)
                            THEN 'MDR'
                        WHEN (AMR.MovementCategory = 20)
                            THEN 'Chargeback'
                        WHEN (AMR.MovementCategory = 31)
                            THEN 'ChargebackParcial'
                        WHEN (AMR.MovementCategory = 21)
                            THEN 'Reapresentacao'
                        WHEN (AMR.MovementCategory = 32)
                            THEN 'ReapresentacaoParcial'
                        ELSE 'Erro_WTF'
                        END as DescMovementCategory,
                    CASE WHEN (AMR.MovementCategory = 20) 
                            THEN 20 ELSE 10 END AS OperationType
                FROM (SELECT A.*,
                    ROW_NUMBER () OVER (PARTITION BY A.ConfirmedTransactionId, A.IdMovement, A.InstallmentNumber, A.InstallmentQuantity, A.EntryDate ORDER BY A.ExecutionDate desc) AS RK
                    FROM `dataplatform-prd.client_fin_movement.movements` A
                    WHERE date(A.EntryDate) >= date_trunc((date_trunc('{{ ds }}', month) - 1), month) and
                    date(A.EntryDate) <= date_trunc('{{ ds }}', month) - 1
                    AND A.MovementCategory IN (28, 20, 21, 31, 32)
                    AND A.MovementType IN (3, 4)) AMR -- movement type identifica se um movimento teve origem em descontos ou RAV 3 = PartialRefunded / 4 = Imposto
                JOIN (select IdBrand, AcquirerTransactionKey, IdConfirmedTransaction, IdTransactionStatus
                    FROM `dataplatform-prd.client_fin_movement.confirmed_transaction`
                    WHERE IdTransactionStatus = 3 --Confirmado
                    GROUP BY IdBrand, AcquirerTransactionKey, IdConfirmedTransaction,IdTransactionStatus)	  ATX
                    ON ATX.IdConfirmedTransaction = AMR.ConfirmedTransactionId
                WHERE AMR.RK = 1
                )
                SELECT 
                    D.AcquirerTransactionKey,
                    D.IdBrand,
                    D.ConfirmedTransactionId,
                    D.IdMovement,
                    D.OperationType,
                    D.FinalAmount,
                    D.installmentnumber_AP,
                    D.installmentquantity_AR,
                    CASE WHEN (D.DescMovementCategory ='ChargebackParcial') THEN '4'||D.RkServiceTypeId
                            WHEN (D.DescMovementCategory ='Chargeback') THEN '1'||D.RkServiceTypeId
                            WHEN (D.DescMovementCategory ='Reapresentacao') THEN '2'||D.RkServiceTypeId
                            WHEN (D.DescMovementCategory ='ReapresentacaoParcial') THEN '4'||D.RkServiceTypeId
                            ELSE 'Erro_WTF' END AS ServiceTypeId,
                    D.DescMovementCategory || '' || D.RkServiceTypeId AS MovementCategory,
                    '1' AS ParcRefMovimentoAP,
                    D.reference_month_ap,
                    D.reference_date,
                    '{{ ds }}' as executionDate
                FROM 
                (SELECT C.IdBrand,
                    C.AcquirerTransactionKey,
                    C.ConfirmedTransactionId,
                    C.IdMovement,
                    C.InstallmentNumber,
                    C.InstallmentQuantity,
                    CAST(C.EntryDate AS STRING FORMAT 'YYYY-MM-DD') AS reference_date,
                    C.MovementCategory AS MovementCategoryId,
                    C.OperationType,
                    C.FinalAmount,
                    C.RefMes AS reference_month_ap,
                    C.RK_PARCELA AS installmentnumber_AP,
                    C.transactionkey,
                    C.installmentquantity_AR,
                    C.DescMovementCategory,
                    RANK () OVER (PARTITION BY C.AcquirerTransactionKey, C.DescMovementCategory, C.InstallmentNumber ORDER BY C.RefDia) AS RkServiceTypeId
                FROM(SELECT B.IdBrand,
                    B.AcquirerTransactionKey,
                    B.ConfirmedTransactionId,
                    B.IdMovement,
                    B.InstallmentNumber,
                    B.InstallmentQuantity,
                    B.EntryDate,
                    CAST(B.EntryDate AS STRING FORMAT 'YYYYMMDD') AS RefDia,
                    B.MovementCategory,
                    B.DescMovementCategory,
                    B.OperationType,
                    CASE WHEN B.DescMovementCategory  like '%Chargeback%' THEN (B.TotalAmout)*1 
                        ELSE (B.TotalAmout)*-1 END AS FinalAmount,
                    CAST(B.EntryDate AS STRING FORMAT 'YYYYMM') AS RefMes,
                    RANK () OVER (PARTITION BY B.AcquirerTransactionKey, B.MovementCategory ORDER BY B.EntryDate, B.IdMovement) AS RK_PARCELA,
                    AR.transactionkey,
                    AR.installmentquantity AS installmentquantity_AR
                    FROM (
                        SELECT A.IdBrand,
                            A.AcquirerTransactionKey,
                            A.ConfirmedTransactionId,
                            A.IdMovement,
                            A.InstallmentNumber,
                            A.InstallmentQuantity,
                            A.EntryDate,
                            A.MovementCategory,
                            A.DescMovementCategory,
                            A.OperationType,
                            round(SUM(A.Amount + IFNULL(B.Amount,0)),4) as TotalAmout
                        FROM (SELECT * FROM TMP_TRATAMENTO_AP WHERE DescMovementCategory <> 'MDR') A
                        LEFT JOIN (SELECT * FROM TMP_TRATAMENTO_AP WHERE DescMovementCategory = 'MDR') B
                            ON A.ConfirmedTransactionId = B.ConfirmedTransactionId
                        GROUP BY A.IdBrand,
                            A.AcquirerTransactionKey,
                            A.ConfirmedTransactionId,
                            A.IdMovement,
                            A.InstallmentNumber,
                            A.InstallmentQuantity,
                            A.EntryDate,
                            A.MovementCategory,
                            A.DescMovementCategory,
                            A.OperationType) B
                            LEFT JOIN (select m.transactionkey, m.installmentquantity
                                        from `dataplatform-prd.receivables.vw_movement` m
                                            where m.servicetypeid in (70,75,80,85, 90, 100, 105)
                                            and date(m.referencedate) >= date_trunc((date_trunc('{{ ds }}', month) - 1), month)
                                            and date(m.referencedate) <= date_trunc('{{ ds }}', month) - 1
                                            and m.serviceid = 10 --Acquirer
                                            GROUP BY m.transactionkey,
                                                m.installmentquantity) AR 
                    ON B.AcquirerTransactionKey = AR.transactionkey) C
                    )D     

        """,
    )

    extractAR = BigqueryToGCSOperator(
        task_id="extract_analyze_chargeback_tratadoAR",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/analyse_chargeback/movement_tratadoAR_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="""
            WITH TMP_TRATAMENTO_AR AS (
            select		
                m.transactionkey,		
                m.externalid,		
                m.movementid,		
                m.installmentnumber,		
                m.installmentquantity,		
                m.grossamount,
                m.settlementcurrencycode,
                m.currencycode,	
                m.institutionid,		
                m.operationtypeid,		
                m.referencedate as RefDate,
                m.servicetypeid,	
            CASE		
                    WHEN (m.servicetypeid = 70) THEN 'Chargeback'
                    WHEN (m.servicetypeid = 75) THEN 'Chargeback'		
                    WHEN (m.servicetypeid = 80) THEN 'Suspensao'		
                    WHEN (m.servicetypeid = 85) THEN 'Suspensao'		
                    WHEN (m.servicetypeid = 90) THEN 'Reapresentacao'
                    WHEN (m.servicetypeid = 100) THEN 'Liberacao'
                    WHEN (m.servicetypeid = 105) THEN 'Liberacao'		
                    ELSE 'Erro_WTF'
                    END as ServiceType		
            from dataplatform-prd.receivables.vw_movement m		
            where m.servicetypeid in (70,75,80,85, 90, 100, 105)		
            and m.serviceid = 10 --Acquirer
            and date(m.referencedate) >= date_trunc((date_trunc('{{ ds }}', month) - 1), month)
            and date(m.referencedate) <= date_trunc('{{ ds }}', month) - 1
            ), 
            FINAL AS (SELECT  AR.transactionkey,		
                    AR.externalid,		
                    AR.movementid,		
                    AR.installmentnumber AS installmentnumber_AR,		
                    AR.installmentquantity AS installmentquantity_AR,		
                    AR.grossamount,
                    AR.settlementcurrencycode,
                    AR.currencycode,	
                    AR.institutionid,		
                    AR.operationtypeid,		
                    AR.RefDate AS reference_date,
                    AR.ServiceType AS servicetype_AR,
                    CASE 
                        WHEN (AR.operationtypeid = 10 AND AR.ServiceType ='Suspensao') THEN '11'
                        WHEN (AR.operationtypeid = 10 AND AR.ServiceType ='Liberacao') THEN '21'
                        WHEN (AR.operationtypeid = 10 AND AR.ServiceType ='Chargeback') THEN '3'||AR.RK
                        WHEN (AR.operationtypeid = 10 AND AR.ServiceType ='Reapresentacao') THEN '2'||AR.RK
                        WHEN (AR.operationtypeid = 20 AND AR.ServiceType ='Suspensao') THEN '11'
                        WHEN (AR.operationtypeid = 20 AND AR.ServiceType ='Liberacao') THEN '21'
                        WHEN (AR.operationtypeid = 20 AND AR.ServiceType ='Chargeback') THEN '1'||AR.RK
                        WHEN (AR.operationtypeid = 20 AND AR.ServiceType ='Reapresentacao') THEN '2'||AR.RK
                        ELSE 'Erro_WTF' END AS servicetypeid_AR,
                        CAST(AR.RefDate AS STRING FORMAT 'YYYYMM') AS reference_month_ar
            FROM (
            SELECT A.*,
                RANK () OVER (PARTITION BY A.transactionkey, A.operationtypeid, A.servicetypeid, A.installmentnumber ORDER BY A.RefDate, A.movementid) AS RK
            FROM TMP_TRATAMENTO_AR A) AR)

            SELECT transactionkey,		
                    externalid,		
                    movementid,		
                    installmentnumber_AR,		
                    installmentquantity_AR,		
                    grossamount,
                    settlementcurrencycode,
                    currencycode,	
                    institutionid,		
                    operationtypeid,		
                    servicetypeid_AR,
                    servicetype_AR,
                    reference_month_ar,
                    reference_date,
                    '{{ ds }}' AS executionDate
            FROM FINAL;
            
        """,
    )

    cleanAP = MsSqlOperatorPYODBC(
        task_id="clean_analyze_chargeback_tratadoAP",
        mssql_conn_id="bw_azure",
        database="StoneDwv0",
        sql="""
           DELETE airflow_staging.movementTratadoAP WHERE executionDate = '{{ ds }}'
        """,
    )

    cleanAR = MsSqlOperatorPYODBC(
        task_id="clean_analyze_chargeback_tratadoAR",
        mssql_conn_id="bw_azure",
        database="StoneDwv0",
        sql="""
           DELETE airflow_staging.movementTratadoAR WHERE executionDate = '{{ ds }}'
        """,
    )

    loadAP = GCSToMssqlExtractOperator(
        task_id="load_analyze_chargeback_tratadoAP",
        database="StoneDwv0",
        dest_schema="airflow_staging",
        table_name="movementTratadoAP",
        source_file=f"airflow-files/_legacy/analyse_chargeback/movement_tratadoAP_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

    loadAR = GCSToMssqlExtractOperator(
        task_id="load_analyze_chargeback_tratadoAR",
        database="StoneDwv0",
        dest_schema="airflow_staging",
        table_name="movementTratadoAR",
        source_file=f"airflow-files/_legacy/analyse_chargeback/movement_tratadoAR_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

    (extractAP >> cleanAP >> loadAP)

    (extractAR >> cleanAR >> loadAR)

    # [extractAP, extractAR] >> [cleanAP, cleanAR] >> [loadAP, loadAR]
