from airflow import DAG
from _legacy.mis_extract import create_dags
from datetime import datetime

recents, backfill = create_dags(
    task_id="_legacy__mis_extract_cobranca_future_receivables",
    job_type="Cobranca_FutureReceivables",
    post_job="mis_extract/sql/load_cobranca_future_receivables.sql",
    dag_factory=lambda **kwargs: DAG(**kwargs),
    start_date=datetime(2020, 4, 26, 8, 0),
    version=2,
    database="DBMis",
    job_control_schema="etl",
    job_control_table="TbConfigEtl",
    only_latest=True,
    sensors_list=[
        {
            "dag_id": "_legacy__mis_extract_cobranca_merchant_v1_recents",
            "task_id": "control_job",
            "execution_delta": 240,
        }
    ],
)
