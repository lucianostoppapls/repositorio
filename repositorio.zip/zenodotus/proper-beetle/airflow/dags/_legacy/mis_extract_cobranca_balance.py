from airflow import DAG
from _legacy.mis_extract import create_dags
from datetime import datetime


recents, backfill = create_dags(
    task_id="_legacy__mis_extract_cobranca_balance",
    job_type="Cobranca_Balance",
    post_job="mis_extract/sql/load_cobranca_balance.sql",
    dag_factory=lambda **kwargs: DAG(**kwargs),
    start_date=datetime(2020, 4, 26, 8, 30),
    version=4,
    database="DBMis",
    job_control_schema="etl",
    job_control_table="TbConfigEtl",
    only_latest=True,
    sensors_list=[
        {
            "dag_id": "_legacy__mis_extract_cobranca_wallettype_v2_recents",
            "task_id": "control_job",
            "execution_delta": 270,
        },
        {
            "dag_id": "_legacy__mis_extract_cobranca_merchant_v1_recents",
            "task_id": "control_job",
            "execution_delta": 270,
        },
        {
            "dag_id": "_legacy__mis_extract_cobranca_merchant_status_v1_recents",
            "task_id": "control_job",
            "execution_delta": 270,
        },
        {
            "dag_id": "_legacy__mis_extract_cobranca_future_receivables_v2_recents",
            "task_id": "control_job",
            "execution_delta": 30,
        },
    ],
)
