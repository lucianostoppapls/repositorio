from datetime import datetime, timedelta
from airflow import DAG
from mssql_utils import MsSqlOperatorPYODBC
from plugins.mssql_utils import GCSToMssqlExtractOperator
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts
from airflow import configuration as conf
from plugins.gcp_utils import BigqueryToGCSOperator


default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "retries": 4,
    "retry_delay": timedelta(minutes=15),
    "autocommit": True,
    "google_cloud_storage_conn_id": "gcp_mis",
    "mssql_conn_id": "bw_azure",
    "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "on_failure_callback": PagerDutyAlerts.failure_incident,
    "on_success_callback": PagerDutyAlerts.resolve_incident,
}

dag = DAG(
    dag_id="_banking_from_lake_financial_accounts_rolling",
    default_args=default_args,
    schedule_interval="@monthly",
    start_date=datetime(2021, 12, 1, 8, 20),
)

with dag:
    extract30 = BigqueryToGCSOperator(
        task_id="extract_rolling_30",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/banking/active_accounts_rolling_30_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="SELECT * FROM dataplatform-prd.conta_stone_financial_kpis.active_accounts_rolling_30 where date(reference_date) >= date('2021-01-31')",
    )

    extract90 = BigqueryToGCSOperator(
        task_id="extract_rolling_90",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/banking/active_accounts_rolling_60_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="SELECT * FROM dataplatform-prd.conta_stone_financial_kpis.active_accounts_rolling_90 where date(reference_date) >= date('2021-01-31')",
    )

    clean30 = MsSqlOperatorPYODBC(
        task_id="clean_rolling_30",
        mssql_conn_id="bw_azure",
        database="StoneDwv0",
        sql="""
           TRUNCATE airflow_staging.rolling30
        """,
    )

    clean90 = MsSqlOperatorPYODBC(
        task_id="clean_rolling_90",
        mssql_conn_id="bw_azure",
        database="StoneDwv0",
        sql="""
            TRUNCATE airflow_staging.rolling90
        """,
    )

    load30 = GCSToMssqlExtractOperator(
        task_id="load_rolling_30",
        database="StoneDwv0",
        dest_schema="airflow_staging",
        table_name="rolling30",
        source_file=f"airflow-files/_legacy/banking/active_accounts_rolling_30_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

    load90 = GCSToMssqlExtractOperator(
        task_id="load_rolling_90",
        database="StoneDwv0",
        dest_schema="airflow_staging",
        table_name="rolling90",
        source_file=f"airflow-files/_legacy/banking/active_accounts_rolling_90_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

    (extract30 >> clean30 >> load30)

    (extract90 >> clean90 >> load90)
