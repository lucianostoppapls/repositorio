from airflow import DAG
from _legacy.mis_extract import create_dags
from datetime import datetime

recents, backfill = create_dags(
    task_id="_legacy__mis_extract_cobranca_wallettype",
    job_type="Cobranca_WalletType",
    post_job="mis_extract/sql/load_cobranca_wallettype.sql",
    dag_factory=lambda **kwargs: DAG(**kwargs),
    start_date=datetime(2020, 4, 26, 4, 0),
    version=2,
    database="DBMis",
    job_control_schema="etl",
    job_control_table="TbConfigEtl",
    only_latest=True,
)
