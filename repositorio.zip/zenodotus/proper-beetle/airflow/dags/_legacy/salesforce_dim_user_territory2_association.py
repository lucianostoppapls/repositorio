from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args, transfer_tasks


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_user_territory2_association_v2",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 6, 0),
    default_args=default_args,
)

transfer_tasks(
    dag=dag,
    repo_name="salesforce",
    table="DimUserTerritory2Association",
    database="StoneDWv0",
    column_types={
        "[UserTerritory2AssociationKey]": "[nvarchar](18) NULL",
        "[UserKey]": "[nvarchar](18) NULL",
        "[Territory2Key]": "[nvarchar](18) NULL",
        "[IsActive]": "[bit] NULL",
        "[RoleInTerritory2]": "[nvarchar](40) NULL",
        "[LastModifiedDate]": "[datetime] NULL",
        "[LastModifiedByKey]": "[nvarchar](18) NULL",
        "[SystemModstamp]": "[datetime] NULL",
    },
    prod_schema="dbo",
    date_column="LastUpdatedAt",
    external_dag_id="_legacy__salesforce_dim_user_v2",
)
