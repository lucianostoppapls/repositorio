from mssql_utils import MsSqlOperatorPYODBC
from mssql_utils import (
    CreatePrefixTableMsSqlOperator,
    DropPrefixTableMsSqlOperator,
)
from airflow.operators.dummy import DummyOperator
from airflow.sensors.external_task_sensor import ExternalTaskSensor
from datetime import timedelta
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts
from mssql_utils import GCSToMssqlExtractOperator
from airflow import configuration as conf
from plugins.postgres_utils import PostgresToGCSOperator


default_args = {
    "postgres_conn_id": "rcnoc",
    "mssql_conn_id": "bw_azure",
    "depends_on_past": False,
    "retries": 4,
    "retry_delay": timedelta(minutes=15),
    "autocommit": True,
    "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "google_cloud_storage_conn_id": "gcp_mis",
    "on_failure_callback": PagerDutyAlerts.failure_incident,
    "on_success_callback": PagerDutyAlerts.resolve_incident,
}


def transfer_tasks_upsert(
    dag,
    table,
    dest_schema,
    database,
    date_column,
    column_types,
    log_schema="airflow_staging",
    external_dag_id=None,
):

    gcs_file = f"airflow-files/_legacy//logistic/{table}-{{{{ ts }}}}.csv"
    source_sql = f"logistic_extract/sql/source_{table}.sql"
    dest_sql = f"logistic_extract/sql/dest_{table}.sql"

    with dag:
        if external_dag_id is not None:
            check_completion = ExternalTaskSensor(
                task_id="dag_init",
                external_dag_id=external_dag_id,
                external_task_id=None,
                allowed_states=["success"],
                priority_weight=0,
                check_existence=True,
            )
        else:
            check_completion = DummyOperator(task_id="dag_init")

        unload_task = PostgresToGCSOperator(
            task_id=f"unload_{table}",
            gcs_bucket=conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
            gcs_file=gcs_file,
            sql=source_sql,
            pool="rcnoc",
            cursor_type="client_side",
        )

        create_temp_table_task = CreatePrefixTableMsSqlOperator(
            task_id="create_table",
            schema=log_schema,
            database="StonecoODS",
            table_prefix=table,
            column_types=column_types,
            mssql_conn_id="bw_azure",
        )

        transfer_task = GCSToMssqlExtractOperator(
            task_id=f"load_{table}",
            database=database,
            dest_schema="{{ ti.xcom_pull('create_table').split('.')[0] }}",
            table_name="{{ ti.xcom_pull('create_table').split('.')[1] }}",
            source_file=gcs_file,
            truncate=False,
            gcs_data_delete=False,
            pool="bw_azure",
        )

        upsert_task = MsSqlOperatorPYODBC(
            task_id=f"upsert_{table}",
            database=database,
            sql=dest_sql,
            pool="bw_azure",
            mssql_conn_id="bw_azure",
        )

        drop_temp_table_task = DropPrefixTableMsSqlOperator(
            task_id="drop_table",
            database="StonecoODS",
            schema=log_schema,
            table_prefix=table,
            mssql_conn_id="bw_azure",
        )

        complete_task = DummyOperator(task_id="dag_complete")

    (
        check_completion
        >> unload_task
        >> create_temp_table_task
        >> transfer_task
        >> upsert_task
        >> drop_temp_table_task
        >> complete_task
    )
