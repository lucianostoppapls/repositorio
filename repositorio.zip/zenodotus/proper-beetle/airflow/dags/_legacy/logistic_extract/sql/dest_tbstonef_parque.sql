
BEGIN

	INSERT INTO [stone].[tbstonef_parque] (
		DS_SERIAL_NUMBER,
		DS_TERMINAL_STATUS,
		DS_CONTRACTOR,
		DS_TECHNOLOGY_TYPE,
		DS_MODEL,
		DS_PROVIDER,
		DS_CUSTOMER_STONE_CODE,
		DT_LAST_MODIFIED_DATE,
		DS_LOGISTICS_OPERATOR
	)

	SELECT
		A.serial_number,
		A.status,
		A.contractor,
		A.type,
		A.model,
		A.provider,
		NULLIF(A.customer,'None'),
		A.modification_date,
		A.logistic_operator
	FROM {{ ti.xcom_pull('create_table') }} A
	WHERE NOT EXISTS (SELECT TOP 1 1 FROM [stone].[tbstonef_parque] B  WHERE A.[serial_number] = B.[DS_SERIAL_NUMBER])


	UPDATE C
	SET
		C.DS_SERIAL_NUMBER = D.serial_number
		, C.DS_TERMINAL_STATUS = D.status
		, C.DS_CONTRACTOR = D.contractor
		, C.DS_TECHNOLOGY_TYPE = D."type"
		, C.DS_MODEL = D.model
		, C.DS_PROVIDER = D.provider
		, C.DS_CUSTOMER_STONE_CODE = NULLIF(D.customer,'None')
		, C.DT_LAST_MODIFIED_DATE = D.modification_date
		, C.DS_LOGISTICS_OPERATOR = D.logistic_operator
	FROM {{ ti.xcom_pull('create_table') }} D
	INNER JOIN [stone].[tbstonef_parque] C ON C.[DS_SERIAL_NUMBER] = D.[serial_number]

--------------------------------BEGIN BUILDING HISTORIC DATA----------------------------------------------

	IF OBJECT_ID('tempdb..#TempUpdateParque') IS NOT NULL
		DROP TABLE #TempUpdateParque

	SELECT
		parque.DS_SERIAL_NUMBER,
		parque.DS_TERMINAL_STATUS,
		parque.DS_CONTRACTOR,
		parque.DS_TECHNOLOGY_TYPE,
		parque.DS_MODEL,
		parque.DS_PROVIDER,
		parque.DS_CUSTOMER_STONE_CODE,
		parque.DT_LAST_MODIFIED_DATE,
		parque.DS_LOGISTICS_OPERATOR,
		CASE
			WHEN parque.DS_TECHNOLOGY_TYPE IN ('ETHERNET-BLUETOOTH','ETHERNET','GPRS','GPRS-WIFI') THEN 'POS'
			WHEN parque.DS_TECHNOLOGY_TYPE IN ('USB','SERIAL','BLUETOOTH','SERIAL-USB') THEN 'PINPAD'
			ELSE 'OUTROS'
		END as DS_EQUIPMENT_TYPE
	INTO #TempUpdateParque
	FROM [stone].[tbstonef_parque] parque
	WHERE NOT EXISTS (SELECT TOP 1 1
					FROM [stone].[TBSTONEF_PARQUE_HISTORICO_modification] parque_novo
					WHERE
						parque_novo.DS_SERIAL_NUMBER = parque.DS_SERIAL_NUMBER AND
						ISNULL(parque_novo.DS_TERMINAL_STATUS,'') = ISNULL(parque.DS_TERMINAL_STATUS,'') AND
						ISNULL(parque_novo.DS_CONTRACTOR,'') = ISNULL(parque.DS_CONTRACTOR,'') AND
						ISNULL(parque_novo.DS_TECHNOLOGY_TYPE,'') = ISNULL(parque.DS_TECHNOLOGY_TYPE,'') AND
						ISNULL(parque_novo.DS_MODEL,'') = ISNULL(parque.DS_MODEL,'') AND
						ISNULL(parque_novo.DS_PROVIDER,'') = ISNULL(parque.DS_PROVIDER,'') AND
						ISNULL(NULLIF(parque_novo.NR_CUSTOMER_STONE_CODE,'None'),'') = ISNULL(parque.DS_CUSTOMER_STONE_CODE,'') AND
						ISNULL(parque_novo.DT_BASE,'') = ISNULL(parque.DT_LAST_MODIFIED_DATE,'') AND
						ISNULL(parque_novo.DS_LOGISTICS_OPERATOR,'') = ISNULL(parque.DS_LOGISTICS_OPERATOR,''))


	INSERT INTO [stone].[TBSTONEF_PARQUE_HISTORICO_modification] (
		DS_SERIAL_NUMBER,
		DS_TERMINAL_STATUS,
		DS_CONTRACTOR,
		DS_TECHNOLOGY_TYPE,
		DS_MODEL,
		DS_PROVIDER,
		NR_CUSTOMER_STONE_CODE,
		DT_BASE,
		DS_LOGISTICS_OPERATOR,
		DS_EQUIPMENT_TYPE)
	SELECT
		TUP.DS_SERIAL_NUMBER,
		TUP.DS_TERMINAL_STATUS,
		TUP.DS_CONTRACTOR,
		TUP.DS_TECHNOLOGY_TYPE,
		TUP.DS_MODEL,
		TUP.DS_PROVIDER,
		TUP.DS_CUSTOMER_STONE_CODE,
		TUP.DT_LAST_MODIFIED_DATE,
		TUP.DS_LOGISTICS_OPERATOR,
		TUP.DS_EQUIPMENT_TYPE
	FROM #TempUpdateParque TUP

	DROP TABLE #TempUpdateParque
--------------------------------------END----------------------------------------------

END
