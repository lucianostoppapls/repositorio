DELETE 
FROM [stone].[tbstonef_om_logistica]
WHERE EXISTS (SELECT TOP 1 1 FROM {{ ti.xcom_pull('create_table') }} WHERE [order_number] = [NR_REQUISICAO] AND [model] = [DS_MODELO_TERMINAL])

INSERT  INTO [stone].[tbstonef_om_logistica] (
	NM_CONTRATANTE,
	DT_RECEBIMENTO,
	DT_TRANSITO,
	DS_DESTINO,
	DS_FALHA,
	DS_FATURA,
	NR_REQUISICAO,
	DS_OBSERVACAO,
	DS_ORIGEM,
	NR_QTD_REQUISICAO,
	DS_REFERENCIA,
	DS_STATUS,
	DS_TIPO_MOVIMENTO,
	DS_MODELO_TERMINAL,
	NR_QTD_ITEM,
	DT_CRIACAO,
	DT_ULTIMA_MODIF
)
SELECT 
	contractor,
	arrival_date,
	transit_date,
	destination,
	failure_reason,
	invoice_code,
	order_number,
	observation,
	origin,
	quantity_request,
	reference_code,
	"status",
	"type",
	model,
	quantity_request_item,
	created_date,
	last_modified_date
FROM {{ ti.xcom_pull('create_table') }}
