SELECT
	OM.contractor
	,NULLIF(OM.arrival_date, '0001-01-01 00:00:00') as arrival_date
	,NULLIF(OM.transit_date, '0001-01-01 00:00:00') as transit_date
	,OM.destination
	,OM.failure_reason
	,OM.invoice_code
	,OM.order_number
	,OM.observation
	,OM.origin
	,OM.quantity AS quantity_request
	,OM.reference_code
	,OM.status
	,OM.type
	,OMI.model
	,OMI.quantity_request_item
	,OM.created_date
	,OM.last_modified_date
FROM
	public.logistic_movement_orders OM
INNER JOIN (
	select
		order_number,
		model,
		count(serial_number) as quantity_request_item
	from public.logistic_movement_orders_items
	group by 1,2
) OMI ON OM.order_number = OMI.order_number
WHERE
    OM.last_modified_date >= '{{ ds }}' AND
    OM.last_modified_date < '{{ next_ds }}'