SELECT
    abono
    ,address_type
    ,NULLIF(arrival_date, '0001-01-01 00:00:00') as arrival_date
    ,attendance_remarks
    ,cancellation_reason
    ,city
    ,class
    ,complement
    ,completed_via_mobile
    ,contractor
    ,country
    ,country_state
    ,customer
    ,customer_contact
    ,customer_cpf_cnpj
    ,NULLIF(customer_deadline_date, '0001-01-01 00:00:00') as customer_deadline_date
    ,customer_group
    ,customer_name
    ,customer_type
    ,NULLIF(deadline_date, '0001-01-01 00:00:00') as deadline_date
    ,defect
    ,door_number
    ,installed_simcard
    ,installed_terminal_model
    ,installed_terminal_sak
    ,installed_terminal_serial_number
    ,installed_terminal_type
    ,kit_name
    ,kit_quantity
    ,last_modified_date
    ,logistic_operator
    ,neighborhood
    ,NULLIF(opening_date, '0001-01-01 00:00:00') as opening_date
    ,opening_remarks
    ,order_number
    ,phone_number
    ,postal_code
    ,project
    ,provider
    ,reference
    ,region
    ,remarks
    ,sale_origin
    ,service_group
    ,service_orders_history
    ,service_type
    ,solution
    ,status
    ,street
    ,technician_id
    ,technician_name
    ,total_visits
    ,uninstalled_simcard
    ,uninstalled_terminal_model
    ,uninstalled_terminal_sak
    ,uninstalled_terminal_serial_number
    ,uninstalled_terminal_type
    ,vendor
    ,visit_reason_1
    ,visit_reason_2
    ,working_days
    ,working_hours
FROM
    service_orders.orders
WHERE
    last_modified_date >= '{{ ds }}' AND
    last_modified_date < '{{ next_ds }}'
