SELECT
    serial_number,
    status,
    contractor,
    type,
    model,
    provider,
    customer,
    modification_date,
    logistic_operator
FROM
    public.logistic_terminal_stock
WHERE
    modification_date >= '{{ ds }}' AND
    modification_date < '{{ next_ds }}' AND
    serial_number IS NOT NULL
