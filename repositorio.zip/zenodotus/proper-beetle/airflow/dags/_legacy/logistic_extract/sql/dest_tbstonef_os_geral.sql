SET NOCOUNT ON;

delete ods
from
	stonecoods.stone.TBSTONEF_OS_GERAL ods
where exists (
	select top 1 1
	from
		{{ ti.xcom_pull('create_table') }} tmp
	where
		tmp.order_number = ods.NR_ORDER_NUMBER
		and tmp.last_modified_date >= ods.DT_ULTIMA_MODIFICACAO
)


insert into stonecoods.stone.TBSTONEF_OS_GERAL (
	IC_SLA_AJUSTADO
	,DS_TIPO_LOGRADOURO
	,DT_ARRIVAL
	,DS_SERVICE_REMARKS
	,DS_CANCELLATION_REASON
	,NM_CIDADE
	,DS_CLASS
	,DS_COMPLEMENTO
	,IC_COMPLETED_VIA_MOBILE
	,NM_CONTRACTOR
	,NM_PAIS
	,SG_UF
	,NR_STONECODE
	,NM_RESPONSAVEL
	,NR_CNPJ
	,DH_LIMIT
	,DS_CLIENT_GROUP
	,NM_CONTATO
	,DS_TIPO_CODUMENTO
	,DT_DEADLINE
	,DS_DEFECT
	,NR_LOGRADOURO
	,NR_INSTALLED_SIMCARD
	,DS_INSTALLED_MODEL
	,NR_INSTALLED_SALE_AFFILIATION_KEY
	,NR_INSTALLED_SERIAL
	,DS_INSTALLED_TECHNOLOGY_TYPE
	,DS_KIT_NAME
	,NR_KIT_QUANTIDADE
	,DT_ULTIMA_MODIFICACAO
	,DS_LOGISTICS_OPERATOR
	,NM_BAIRRO
	,DT_OPENING
	,DS_OPENING_REMARKS
	,NR_ORDER_NUMBER
	,NR_TELEFONE
	,NR_CEP
	,NM_PROJECT
	,DS_PROVIDER
	,NR_REFERENCE
	,DS_REGIAO
	,DS_REMARKS
	,DS_SALE_ORIGIN
	,NM_SERVICE_GROUP
	,DS_SERVICE_ORDERS_HISTORY
	,DS_SERVICE_TYPE
	,DS_SOLUTION
	,DS_STATUS
	,DS_LOGRADOURO
	,NR_DOCUMENTO_TECNICO
	,NM_TECNICO
	,NR_TOTAL_VISITS
	,NR_UNINSTALLED_SIMCARD
	,DS_UNINSTALLED_MODEL
	,NR_UNINSTALLED_SALE_AFFILIATION_KEY
	,NR_UNINSTALLED_SERIAL
	,DS_UNINSTALLED_TECHNOLOGY_TYPE
	,NM_VENDOR
	,DS_VISIT_REASON_1
	,DS_VISIT_REASON_2
	,DS_WORKING_DAYS
	,DS_WORKING_HOURS
	,NR_SERVICE_RESQUEST
)
select
	abono as IC_SLA_AJUSTADO
	,address_type as DS_TIPO_LOGRADOURO
	,arrival_date as DT_ARRIVAL
	,attendance_remarks as DS_SERVICE_REMARKS
	,cancellation_reason as DS_CANCELLATION_REASON
	,city as NM_CIDADE
	,class as DS_CLASS
	,complement as DS_COMPLEMENTO
	,completed_via_mobile as IC_COMPLETED_VIA_MOBILE
	,contractor as NM_CONTRACTOR
	,country as NM_PAIS
	,country_state as SG_UF
	,customer as NR_STONECODE
	,customer_contact as NM_RESPONSAVEL
	,customer_cpf_cnpj as NR_CNPJ
	,customer_deadline_date as DH_LIMIT
	,customer_group as DS_CLIENT_GROUP
	,customer_name as NM_CONTATO
	,customer_type as DS_TIPO_CODUMENTO
	,deadline_date as DT_DEADLINE
	,defect as DS_DEFECT
	,door_number as NR_LOGRADOURO
	,installed_simcard as NR_INSTALLED_SIMCARD
	,installed_terminal_model as DS_INSTALLED_MODEL
	,installed_terminal_sak as NR_INSTALLED_SALE_AFFILIATION_KEY
	,installed_terminal_serial_number as NR_INSTALLED_SERIAL
	,installed_terminal_type as DS_INSTALLED_TECHNOLOGY_TYPE
	,kit_name as DS_KIT_NAME
	,kit_quantity as NR_KIT_QUANTIDADE
	,last_modified_date as DT_ULTIMA_MODIFICACAO
	,logistic_operator as DS_LOGISTICS_OPERATOR
	,neighborhood as NM_BAIRRO
	,opening_date as DT_OPENING
	,opening_remarks as DS_OPENING_REMARKS
	,order_number as NR_ORDER_NUMBER
	,phone_number as NR_TELEFONE
	,postal_code as NR_CEP
	,project as NM_PROJECT
	,provider as DS_PROVIDER
	,reference as NR_REFERENCE
	,region as DS_REGIAO
	,remarks as DS_REMARKS
	,sale_origin as DS_SALE_ORIGIN
	,service_group as NM_SERVICE_GROUP
	,service_orders_history as DS_SERVICE_ORDERS_HISTORY
	,service_type as DS_SERVICE_TYPE
	,solution as DS_SOLUTION
	,status as DS_STATUS
	,street as DS_LOGRADOURO
	,technician_id as NR_DOCUMENTO_TECNICO
	,technician_name as NM_TECNICO
	,total_visits as NR_TOTAL_VISITS
	,uninstalled_simcard as NR_UNINSTALLED_SIMCARD
	,uninstalled_terminal_model as DS_UNINSTALLED_MODEL
	,uninstalled_terminal_sak as NR_UNINSTALLED_SALE_AFFILIATION_KEY
	,uninstalled_terminal_serial_number as NR_UNINSTALLED_SERIAL
	,uninstalled_terminal_type as DS_UNINSTALLED_TECHNOLOGY_TYPE
	,vendor as NM_VENDOR
	,visit_reason_1 as DS_VISIT_REASON_1
	,visit_reason_2 as DS_VISIT_REASON_2
	,working_days as DS_WORKING_DAYS
	,working_hours as DS_WORKING_HOURS
	,order_number as NR_SERVICE_RESQUEST
from {{ ti.xcom_pull('create_table') }} stg
where not exists(
	select top 1 1 from stonecoods.stone.tbstonef_os_geral prod
	where prod.NR_ORDER_NUMBER = stg.order_number
)

