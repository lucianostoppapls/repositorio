from airflow import DAG
from _legacy.mis_extract import create_dags
from datetime import datetime

recents, backfill = create_dags(
    task_id="_legacy__mis_extract_revenue_assurance_movement",
    job_type="RA_Movement",
    post_job="mis_extract/sql/load_revenue_assurance_movement.sql",
    dag_factory=lambda **kwargs: DAG(**kwargs),
    start_date=datetime(2020, 4, 26, 8, 30),
    version=1,
    database="DBMis",
    job_control_schema="etl",
    job_control_table="TbConfigEtl",
)
