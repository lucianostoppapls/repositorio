from mssql_utils import MsSqlOperatorPYODBC
from airflow.utils.decorators import apply_defaults


class CleanWindowOperator(MsSqlOperatorPYODBC):
    @apply_defaults
    def __init__(
        self,
        table,
        database,
        date_column,
        window_days=45,
        autocommit=True,
        *args,
        **kwargs
    ):
        self.autocommit = autocommit

        window_days = abs(window_days)
        kwargs.update(
            params={
                "table": table,
                "database": database,
                "date_column": date_column,
                "window_days": window_days,
            },
            sql="""
                delete from {{ params.database }}.{{ params.table }}
                where [{{ params.date_column }}] < cast('{{ next_ds }}' as DATE)
                and [{{ params.date_column }}] >= dateadd(day, -1 * {{ params.window_days }}, cast('{{ next_ds }}' as DATE))
            """,
        )
        super().__init__(autocommit=self.autocommit, *args, **kwargs)


class TruncateTableOperator(MsSqlOperatorPYODBC):
    @apply_defaults
    def __init__(self, table, database, autocommit=True, *args, **kwargs):
        self.autocommit = autocommit

        kwargs.update(
            params={"table": table, "database": database},
            sql="truncate table {{params.database}}.{{params.table}}",
        )
        super().__init__(autocommit=self.autocommit, *args, **kwargs)


class LogTaskOperator(MsSqlOperatorPYODBC):
    @apply_defaults
    def __init__(self, table, autocommit=True, *args, **kwargs):
        self.autocommit = autocommit

        kwargs.update(
            params={"table": table},
            sql="""
               INSERT INTO StoneCoODS.dbo.TBW_BUY4_CONTROL
               (NM_TABLE, IN_SUCESS, DH_TIMESTAMP)
               VALUES ('{{ params.table }}', 1, getdate())
            """,
        )
        super().__init__(autocommit=self.autocommit, *args, **kwargs)
