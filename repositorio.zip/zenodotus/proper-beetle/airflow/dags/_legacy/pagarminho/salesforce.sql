WITH numbered_salesforce AS (
    SELECT
        digital_accounts.id,
        SUBSTR(digital_accounts.name, 1, 95) AS `name`,
        SUBSTR(digital_accounts.affiliationid__c, 1, 45) AS client_identifier,
        CASE
        WHEN account_type.developername = 'PagarmeClient' THEN 'company_id'
        WHEN account_type.developername = 'MundiClient' THEN 'mundipagg_affiliation_id'
        WHEN account_type.developername IN ('StoneClient', 'Subacquirer') THEN 'stone_code'
        END AS client_identifier_type,
        CASE
        WHEN account_type.developername = 'PagarmeClient' THEN 'pagarme'
        WHEN account_type.developername = 'MundiClient' THEN 'mundipagg'
        WHEN account_type.developername = 'StoneClient' THEN 'stone'
        WHEN account_type.developername = 'Subacquirer' THEN 'subacquirer'
        END AS origin,
        SUBSTR(closers.name, 1, 95) AS closer_name,
        SUBSTR(digital_accounts.cnpj__c, 1, 45) AS cnpj,
        SUBSTR(partners.name, 1, 95) AS partner,
        ROW_NUMBER() OVER (PARTITION BY digital_accounts.id) AS precedence
    FROM dataplatform-prd.sop_salesforce.account AS digital_accounts
    LEFT JOIN dataplatform-prd.sop_salesforce.recordtype AS account_type ON account_type.id = digital_accounts.recordtypeid
    LEFT JOIN dataplatform-prd.sop_salesforce.user AS closers ON digital_accounts.closer__c = closers.id
    LEFT JOIN dataplatform-prd.sop_salesforce.account AS partners ON partners.id = digital_accounts.partneraccount__c AND partners.isdeleted = FALSE
    WHERE
        digital_accounts.isdeleted = FALSE
        AND account_type.developername IN ('MundiClient', 'PagarmeClient', 'StoneClient', 'Subacquirer')
)
SELECT
  id,
  name,
  client_identifier,
  client_identifier_type,
  origin,
  closer_name,
  cnpj,
  NULL AS close_date,
  NULL AS subchannel,
  partner
FROM numbered_salesforce WHERE precedence = 1
