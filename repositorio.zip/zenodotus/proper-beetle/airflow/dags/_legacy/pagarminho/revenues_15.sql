--revenues final table
DROP TABLE IF EXISTS airflow_staging.temp_revenues;

       SELECT
         convert_timezone(
           'America/Sao_Paulo', 'UTC', q.day
         ) AS DATE,
         q.company_id,
         q.origin_receivable,
         q.revenues_source,
         q.payment_method,
         q.card_brand,
         q.total_installments,
         SUM(q.tpv) AS tpv,
         SUM(q.credit_card_tpv) AS credit_card_tpv,
         SUM(q.debit_card_tpv) AS debit_card_tpv,
         SUM(q.boleto_tpv) AS boleto_tpv,
         SUM(q.anticipated_tpv) AS anticipated_tpv,
         SUM(q.rav) AS anticipation_fee,
         SUM(q.anticipation_cost) AS anticipation_cost,
         SUM(q.transaction_count) AS transaction_count,
         SUM(q.gateway_fee) AS gateway_fee,
         SUM(q.debit_card_fee) AS debit_card_fee,
         SUM(q.antifraud_cost) AS antifraud_cost,
         SUM(q.debit_card_cost) AS debit_card_cost,
         SUM(q.credit_card_fee) AS credit_card_fee,
         SUM(q.credit_card_cost) AS credit_card_cost,
         SUM(q.boleto_fee) AS boleto_fee,
         SUM(q.boleto_cost) AS boleto_cost,
         SUM(q.transfer_fee) AS transfer_fee,
         SUM(q.transfer_cost) AS transfer_cost,
         SUM(q.transfer_count) AS transfer_count,
         SUM(q.stone_credit_card_revenues) AS stone_credit_card_revenues,
         SUM(q.stone_credit_card_cost) AS stone_credit_card_cost,
         SUM(q.stone_debit_card_revenues) AS stone_debit_card_revenues,
         SUM(q.stone_debit_card_cost) AS stone_debit_card_cost,
         SUM(q.stone_credit_card_assessment) AS stone_credit_card_assessment,
         SUM(q.stone_debit_card_assessment) AS stone_debit_card_assessment,
         SUM(q.stone_credit_card_interchange) AS stone_credit_card_interchange,
         SUM(q.stone_debit_card_interchange) AS stone_debit_card_interchange,
         SUM(q.fraud_coverage_fee) as fraud_coverage_fee,
         SUM(q.fraud_coverage_transactions_count) AS fraud_coverage_transactions_count
       INTO airflow_staging.temp_revenues
       FROM
         (
           SELECT * FROM airflow_staging.temp_pagarme_transactional
           UNION ALL
           SELECT * FROM airflow_staging.temp_chargebacks
           UNION ALL
           SELECT * FROM airflow_staging.temp_chargeback_refunds
           UNION ALL
           SELECT * FROM airflow_staging.temp_gateway_fees
           UNION ALL
           SELECT * FROM airflow_staging.temp_gateway_only_tpv
           UNION ALL
           SELECT * FROM airflow_staging.temp_antifraud_costs
           UNION ALL
           SELECT * FROM airflow_staging.temp_transfer_costs
         ) q

       GROUP BY
         q.company_id,
         convert_timezone(
           'America/Sao_Paulo', 'UTC', q.day
         ),
         q.origin_receivable,
         q.revenues_source,
         q.payment_method,
         q.card_brand,
         q.total_installments
;