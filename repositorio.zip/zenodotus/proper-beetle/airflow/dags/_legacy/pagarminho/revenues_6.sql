--installments_with_prices
DROP TABLE IF EXISTS airflow_staging.temp_installments_with_prices;

  SELECT
    payables.day,
    payables.company_id,
    payables.payment_method,
    payables.type,
    payables.receivable_id,
    payables.installment,
    payables.transaction_id,
    payables.amount,
    payables.fee,
    payables.cost,
    payables.origin_acquirer,
    payables.total_installments,
    payables.card_brand,
    payables.mcc_category,
    payables.company_mcc,
    payables.amount * estimated_costs.interchange AS pagarme_estimated_cost,
    card_brand_fees.assessment_rate * payables.amount AS stone_card_brand_assessment,
    card_brand_fees.installment_clearing * payables.total_installments AS stone_card_brand_clearing,
    card_brand_fees.authorization_flat_fee AS stone_card_brand_flat_fee,
    CASE WHEN payables.installment = 1 THEN sign(payables.amount) ELSE 0 END AS first_installment_multiplier,
    COALESCE(interchanges.rate, default_interchanges.rate, 0) * payables.amount AS stone_interchange_amount,
    COALESCE(interchanges.flat_fee, default_interchanges.flat_fee, 0) AS stone_interchange_flat_fee,
    COALESCE(interchanges.ceiling, default_interchanges.ceiling) AS stone_interchange_ceiling,
    payables.fraud_coverage_fee
  INTO airflow_staging.temp_installments_with_prices
  FROM airflow_staging.temp_installments AS payables
  LEFT JOIN airflow_staging.temp_card_brand_fees card_brand_fees ON card_brand_fees.acquirer = 'stone'
    AND card_brand_fees.card_brand = payables.card_brand
    AND card_brand_fees.payment_method = payables.payment_method
    AND card_brand_fees.installments = payables.total_installments
    AND card_brand_fees.nationality = 'national'
  LEFT JOIN airflow_staging.temp_interchanges interchanges
    ON interchanges.acquirer = 'stone'
    AND interchanges.card_brand = payables.card_brand
    AND interchanges.payment_method = payables.payment_method
    AND interchanges.installments = payables.total_installments
    AND interchanges.mcc = payables.company_mcc
    AND interchanges.bin = payables.card_first_digits
  LEFT JOIN airflow_staging.temp_default_interchanges default_interchanges
    ON default_interchanges.acquirer = 'stone'
    AND default_interchanges.card_brand = payables.card_brand
    AND default_interchanges.payment_method = payables.payment_method
    AND default_interchanges.installments = payables.total_installments
    AND default_interchanges.mcc = payables.company_mcc
  LEFT JOIN pagarme_fees.acquirer_costs AS estimated_costs
    ON estimated_costs.card_brand = payables.card_brand
    AND estimated_costs.installments = payables.total_installments
    AND estimated_costs.payment_method = payables.payment_method
    AND estimated_costs.acquirer = payables.origin_acquirer
    AND estimated_costs.mcc_category = payables.mcc_category
    AND payables.day >= convert_timezone('UTC', 'America/Sao_Paulo', estimated_costs.start_date::TIMESTAMP)
    AND payables.day <= convert_timezone('UTC', 'America/Sao_Paulo', COALESCE(estimated_costs.end_date, CURRENT_TIMESTAMP)::TIMESTAMP)
    ;
