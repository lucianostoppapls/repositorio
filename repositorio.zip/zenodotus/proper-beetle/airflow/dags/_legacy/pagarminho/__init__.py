from _legacy.pagarminho.looker_tables import LookerTableLookup
from _legacy.pagarminho.mssql_utils import CleanWindowOperator, TruncateTableOperator
from airflow import configuration as conf
from airflow.operators.dummy import DummyOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts
from datetime import timedelta
from plugins.gcp_utils import BigqueryToGCSOperator
from plugins.mssql_utils import GCSToMssqlExtractOperator
from plugins.postgres_utils import PostgresToGCSOperator


default_args = {
    "postgres_conn_id": "datarock",
    "google_cloud_storage_conn_id": "gcp_mis",
    "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "mssql_conn_id": "bw_azure",
    "depends_on_past": False,
    "retries": 4,
    "retry_delay": timedelta(minutes=10),
    "on_failure_callback": PagerDutyAlerts.failure_incident,
    "on_success_callback": PagerDutyAlerts.resolve_incident,
}


def inject_tasks(
    etl_name,
    dag,
    looker_tables,
    source_sql,
    gcs_file,
    dest_database,
    dest_schema,
    dest_table,
    date_column,
    window_days=45,
):
    dest_schema_and_table = f"{dest_schema}.{dest_table}"

    with dag:
        looker_tasks = [LookerTableLookup(task_id=table) for table in looker_tables]
        dag_complete = DummyOperator(task_id="dag_complete")

        if etl_name == "salesforce":
            unload_task = BigqueryToGCSOperator(
                task_id=f"unload_{etl_name}",
                source_conn_id="gcp_mis_datalake",
                dest_conn_id="gcp_mis",
                gcs_file=gcs_file,
                gcs_bucket=conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
                sql=source_sql,
            )

        elif etl_name == "revenues":
            for i in range(1, 16):
                generate_table = PostgresOperator(
                    task_id=f"generate_table_{i}",
                    autocommit=True,
                    sql=f"pagarminho/revenues_{i}.sql",
                )
                if i == 1:
                    temp_tables = generate_table
                else:
                    temp_tables = temp_tables >> generate_table

                temp_tables >> dag_complete

            unload_task = PostgresToGCSOperator(
                task_id=f"unload_{etl_name}",
                gcs_bucket=conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
                gcs_file=gcs_file,
                sql=source_sql,
                cursor_type="server_side",
            )

            drop_temp_tables = PostgresOperator(
                task_id=f"drop_temp_tables",
                autocommit=True,
                sql="""
                    DROP TABLE IF EXISTS airflow_staging.temp_card_brand_fees;
                    DROP TABLE IF EXISTS airflow_staging.temp_interchanges;
                    DROP TABLE IF EXISTS airflow_staging.temp_default_interchanges;
                    DROP TABLE IF EXISTS airflow_staging.temp_payables;
                    DROP TABLE IF EXISTS airflow_staging.temp_installments;
                    DROP TABLE IF EXISTS airflow_staging.temp_installments_with_prices;
                    DROP TABLE IF EXISTS airflow_staging.temp_transaction_installments;
                    DROP TABLE IF EXISTS airflow_staging.temp_pagarme_transactional;
                    DROP TABLE IF EXISTS airflow_staging.temp_chargebacks;
                    DROP TABLE IF EXISTS airflow_staging.temp_chargeback_refunds;
                    DROP TABLE IF EXISTS airflow_staging.temp_gateway_fees;
                    DROP TABLE IF EXISTS airflow_staging.temp_gateway_only_tpv;
                    DROP TABLE IF EXISTS airflow_staging.temp_antifraud_costs;
                    DROP TABLE IF EXISTS airflow_staging.temp_transfer_costs;
                    DROP TABLE IF EXISTS airflow_staging.temp_revenues;
                """,
            )

            temp_tables >> unload_task >> drop_temp_tables

        else:
            unload_task = PostgresToGCSOperator(
                task_id=f"unload_{etl_name}",
                gcs_bucket=conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
                gcs_file=gcs_file,
                sql=source_sql,
                cursor_type="server_side",
            )

        if date_column is None:

            clean_task = TruncateTableOperator(
                task_id=f"clean_{etl_name}",
                database=dest_database,
                table=dest_schema_and_table,
                mssql_conn_id="bw_azure",
            )
        else:

            clean_task = CleanWindowOperator(
                task_id=f"clean_{etl_name}",
                database=dest_database,
                table=dest_schema_and_table,
                date_column=date_column,
                mssql_conn_id="bw_azure",
                window_days=window_days,
            )

        write_task = GCSToMssqlExtractOperator(
            task_id=f"write_{etl_name}",
            database=dest_database,
            dest_schema=dest_schema,
            table_name=dest_table,
            source_file=gcs_file,
            truncate=False,
            gcs_data_delete=False,
        )

        for task in looker_tasks:
            task >> unload_task

        unload_task >> clean_task >> write_task >> dag_complete
