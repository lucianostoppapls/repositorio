--interchanges
DROP TABLE IF EXISTS airflow_staging.temp_interchanges;

SELECT
  acquirers.name AS acquirer,
  CASE
    WHEN card_brands.name = 'master' THEN 'mastercard'
    WHEN card_brands.name = 'hiper' THEN 'hipercard'
    ELSE card_brands.name
  END AS card_brand,
  payment_strategy_descriptions.payment_method,
  payment_strategy_descriptions.installments,
  mcc_group_memberships.mcc,
  bins.bin,
  rate,
  flat_fee,
  ceiling
INTO airflow_staging.temp_interchanges
FROM pagarme_stone_fees.interchanges
LEFT JOIN pagarme_stone_fees.acquirers ON interchanges.acquirer_id = acquirers.id
LEFT JOIN pagarme_stone_fees.card_brands ON interchanges.card_brand_id = card_brands.id
LEFT JOIN pagarme_stone_fees.payment_strategy_descriptions ON interchanges.payment_strategy_id = payment_strategy_descriptions.payment_strategy_id
INNER JOIN pagarme_stone_fees.mcc_group_memberships ON interchanges.mcc_group_id = mcc_group_memberships.mcc_group_id
INNER JOIN pagarme_stone_fees.bins ON interchanges.card_group_id = bins.card_group_id
;
