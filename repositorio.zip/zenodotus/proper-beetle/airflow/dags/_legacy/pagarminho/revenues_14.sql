--transfer_costs
DROP TABLE IF EXISTS airflow_staging.temp_transfer_costs;

    SELECT
      convert_timezone('UTC', 'America/Sao_Paulo', t.created_at::TIMESTAMP)::DATE AS day,
      t.company_id,
      'N/A' origin_receivable,
      NULL AS payment_method,
      NULL AS card_brand,
      NULL::INT AS total_installments,
      0 AS transaction_count,
      0 AS tpv,
      0 AS credit_card_tpv,
      0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      0 AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      SUM(t.fee) / 100.0 AS transfer_fee,
      SUM(t.cost) / 100.0 AS transfer_cost,
      COUNT(id) AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      'transfer_costs' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO airflow_staging.temp_transfer_costs
    FROM
      pagarme_live.transfers t
    WHERE
      t.status != 'canceled'
    GROUP BY
      1,
      2
    UNION ALL
    SELECT
      convert_timezone('UTC', 'America/Sao_Paulo', settlements.created_at::TIMESTAMP) AS DAY,
      refunds.company_id,
      'N/A' origin_receivable,
      NULL AS payment_method,
      NULL AS card_brand,
      NULL::INT AS total_installments,
      0 AS transaction_count,
      0 AS tpv,
      0 AS credit_card_tpv,
      0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      0 AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      SUM(refunds.processing_fee) / 100.0 AS transfer_fee,
      SUM(settlements.cost) / 100.0 AS transfer_cost,
      COUNT(refunds.id) AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      'transfer_costs' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    FROM
      pagarme_live.refunds
      LEFT JOIN pagarme_live.settlements AS settlements ON settlements.id = refunds.settlement_id
    WHERE
      refunds.status = 'refunded'
      AND refunds."type" = 'boleto'
      AND settlements.id IS NOT NULL
    GROUP BY
      convert_timezone('UTC', 'America/Sao_Paulo', settlements.created_at :: TIMESTAMP),
      refunds.company_id
      ;
