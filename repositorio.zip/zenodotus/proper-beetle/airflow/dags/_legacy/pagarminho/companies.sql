SELECT DISTINCT
    'pagarme' AS origin,
    v_companies.id  AS company_id,
    REGEXP_REPLACE(v_companies.cnpj, '[^0-9]', '') AS cnpj,
    LEFT(v_companies.name, 90) AS name,
    DATE(convert_timezone('UTC', 'America/Sao_Paulo', v_companies.created_at::TIMESTAMP)) AS created_at,
    NULL AS first_production_date,
    NULL AS last_transaction,
    v_companies.mcc,
    NULL AS closer_name,
    LEFT(v_companies.full_name, 190) AS full_name,
    v_companies.status,
    REGEXP_REPLACE(f_json_extract(v_companies.address, 'zipcode'), '[^0-9]', '') AS zipcode,
    f_json_extract(v_companies.address, 'street') AS street,
    f_json_extract(v_companies.address, 'street_number') AS street_number,
    f_json_extract(v_companies.address, 'complementary') AS complementary,
    f_json_extract(v_companies.address, 'neighborhood') AS neighborhood,
    f_json_extract(v_companies.address, 'city') AS city,
    f_json_extract(v_companies.address, 'state') AS state,
    NULL AS closer_id,
    v_companies.seller_id,
    CASE
        WHEN v_companies.type = 'mei' THEN v_companies.created_at::TIMESTAMP
        ELSE globalevents.created_at::TIMESTAMP
    END AS affiliation_date,
    v_companies.type
FROM pagarme_mongo.v_companies AS v_companies
LEFT JOIN (
    SELECT
        company_id,
        MIN(created_at) AS created_at
    FROM
        pagarme_mongo.globalevents
    WHERE
        json_extract_path_text(payload, 'currentStatus', TRUE) = 'active'
    GROUP BY
        company_id
 ) globalevents ON
    globalevents.company_id = v_companies.id
