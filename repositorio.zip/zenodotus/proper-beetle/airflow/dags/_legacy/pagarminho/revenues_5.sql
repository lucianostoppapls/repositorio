--installments
DROP TABLE IF EXISTS airflow_staging.temp_installments;

  SELECT
    payables.day,
    payables.company_id,
    payables.payment_method,
    payables.type,
    payables.receivable_id,
    payables.installment,
    payables.transaction_id,
    payables.amount,
    payables.fee,
    receivables.cost / 100.0 AS cost,
    CASE
      WHEN receivables.origin IS NOT NULL THEN receivables.origin
      WHEN transactions.origin_acquirer ILIKE '%stone%' THEN 'stone'
      WHEN transactions.origin_acquirer ILIKE '%cielo%' THEN 'cielo'
      WHEN transactions.origin_acquirer ILIKE '%rede%' THEN 'rede'
    END AS origin_acquirer,
    transactions.installments AS total_installments,
    transactions.card_brand,
    CASE
      WHEN transactions.origin_acquirer_id ILIKE '%education%' THEN 'education'
      WHEN transactions.origin_acquirer_id = 'sub_cielo_magazine' THEN 'sub_cielo_magazine'
      WHEN transactions.origin_acquirer_id = 'sub_stone_mei' THEN 'sub_stone_mei'
      WHEN transactions.origin_acquirer_id = 'sub_rede_carrefour' THEN 'sub_rede_carrefour'
      WHEN transactions.origin_acquirer_id = 'sub_cielo_carrefour' THEN 'sub_cielo_carrefour'
      ELSE 'standard'
    END AS mcc_category,
    companies.mcc AS company_mcc,
    original_transactions.card_first_digits,
    payables.fraud_coverage_fee
  INTO airflow_staging.temp_installments
  FROM airflow_staging.temp_payables payables
  LEFT JOIN pagarme_live.receivables AS receivables ON payables.receivable_id = receivables.id
  LEFT JOIN pagarme_dw.dim_transactions AS transactions ON transactions.transaction_key = payables.transaction_id
  LEFT JOIN pagarme_live.transactions AS original_transactions ON original_transactions.id = payables.transaction_id
  LEFT JOIN pagarme_mongo.v_companies AS companies ON companies.id = payables.company_id
  ;
