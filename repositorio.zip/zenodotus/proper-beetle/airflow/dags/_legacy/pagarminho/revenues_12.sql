--gateway_only_tpv
DROP TABLE IF EXISTS airflow_staging.temp_gateway_only_tpv;

    -- nessa subquery trazemos apenas o tpv de gateway - o passado e alterado pois pegamos status = paid
    SELECT
      convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE AS DAY,
      tx.company_id,
      'gateway_' || tx.acquirer_name AS origin_receivable,
      tx.payment_method,
      tx.card_brand,
      tx.installments AS total_installments,
      count(*) AS transaction_count,
      SUM(tx.amount) / 100.0 AS tpv,
      SUM(
        CASE WHEN (
          tx.payment_method = 'credit_card'
        ) THEN stages.sign * tx.amount ELSE 0 END
      ) / 100.0 AS credit_card_tpv,
      SUM(
        CASE WHEN (tx.payment_method = 'debit_card') THEN stages.sign * tx.amount ELSE 0 END
      ) / 100.0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      0 AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      'gateway_only_tpv' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO airflow_staging.temp_gateway_only_tpv
    FROM
      pagarme_live.transactions tx
      -- For each transaction, we generate two possible stages in the cross join.
      -- This is so it's possible to filter the desired second stages in the where clause.
      CROSS JOIN (SELECT 'paid' AS name, 1 AS sign UNION ALL SELECT 'refunded' AS name, -1 AS sign) stages
    WHERE
      tx.acquirer_name != 'pagarme'
      AND convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '30 days'
      AND convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE < '{{ next_execution_date.isoformat() }}'::DATE
      AND tx.status IN ('paid', 'refunded')
      -- Similar to the gateway_fees query, here we get all the lines in the paid stage,
      -- but only the refunded transactions in the refunded stage lines
      AND (stages.name = 'paid' OR stages.name = 'refunded' AND tx.status = 'refunded')
    GROUP BY
      1,
      2,
      3,
      4,
      5,
      6
      ;
