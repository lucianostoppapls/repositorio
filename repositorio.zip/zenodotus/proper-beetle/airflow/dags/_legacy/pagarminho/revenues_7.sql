--transaction_installments
DROP TABLE IF EXISTS airflow_staging.temp_transaction_installments;

       SELECT
        day,
        company_id,
        payment_method,
        type,
        receivable_id,
        installment,
        transaction_id,
        amount,
        fee,
        COALESCE(cost, pagarme_estimated_cost) AS cost,
        origin_acquirer,
        total_installments,
        card_brand,
        mcc_category,
        CASE
          WHEN origin_acquirer = 'stone' THEN stone_card_brand_assessment + first_installment_multiplier * (stone_card_brand_clearing + stone_card_brand_flat_fee)
          ELSE 0
        END AS card_brand_fee,
        CASE
          WHEN origin_acquirer = 'stone' THEN
            CASE
              WHEN abs(stone_interchange_amount + first_installment_multiplier * stone_interchange_flat_fee) < COALESCE(stone_interchange_ceiling, 1000000) THEN stone_interchange_amount + first_installment_multiplier * stone_interchange_flat_fee
              ELSE sign(amount) * stone_interchange_ceiling
            END
          ELSE 0
        END AS bank_interchange,
        fraud_coverage_fee
       INTO airflow_staging.temp_transaction_installments
       FROM airflow_staging.temp_installments_with_prices
       ;
