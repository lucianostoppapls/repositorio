--antifraud_costs
DROP TABLE IF EXISTS airflow_staging.temp_antifraud_costs;

    -- custo de antifraud
    SELECT
      convert_timezone('UTC', 'America/Sao_Paulo', af.created_at::TIMESTAMP)::DATE AS day,
      company_id,
      CASE WHEN (r.origin) IN ('stone', 'bradesco') THEN r.origin ELSE 'cielo/rede' END AS origin_receivable,
      r.payment_method,
      r.card_brand,
      r.total_installments,
      0 AS transaction_count,
      0 AS tpv,
      0 AS credit_card_tpv,
      0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      SUM(af.cost) / 100.0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      0 AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      'antifraud_costs' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO airflow_staging.temp_antifraud_costs
    FROM
      pagarme_live.antifraudanalyses af
      LEFT JOIN (
        SELECT
          transaction_id,
          origin_acquirer AS origin,
          payment_method,
          card_brand,
          total_installments
        FROM
          airflow_staging.temp_transaction_installments
        GROUP BY
          transaction_id,
          origin_acquirer,
          payment_method,
          card_brand,
          total_installments
      ) AS r ON af.transaction_id = r.transaction_id
    GROUP BY
      1,
      2,
      3,
      4,
      5,
      6
      ;
