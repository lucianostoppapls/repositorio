--chargebacks
DROP TABLE IF EXISTS airflow_staging.temp_chargebacks;

    -- In this subquery, we pick up credit payables, then inner join with the
    -- first installment of the chargeback_payables (that have type = 'chargeback')
    -- within the same transaction. Then, we subtract the values of the credit
    -- payables in the dates the chargeback_payables were created. This is done
    -- in order to correctly subtract chargebacks of suspended payables, for
    -- which no actual chargeback payables are created. Therefore, their
    -- subtraction has to be infered from the first installment of chargebacks.

    SELECT
      chargeback_payables.day,
      p.company_id AS company_id,
      p.origin_acquirer AS origin_receivable,
      p.payment_method,
      p.card_brand,
      p.total_installments,
      -COUNT(DISTINCT p.transaction_id)  AS transaction_count,
      -SUM(p.amount) AS tpv,
      -SUM(CASE WHEN p.payment_method = 'credit_card' THEN p.amount ELSE 0 END) AS credit_card_tpv,
      -SUM(CASE WHEN p.payment_method = 'debit_card' THEN p.amount ELSE 0 END) AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      -SUM(CASE WHEN p.payment_method = 'debit_card' THEN p.fee ELSE 0 END) AS debit_card_fee,
      -SUM(
        CASE
          WHEN p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS debit_card_cost,
      -SUM(CASE WHEN p.payment_method = 'credit_card' THEN p.fee ELSE 0 END) AS credit_card_fee,
      -SUM(
        CASE
          WHEN p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      -SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_credit_card_revenues,
      -SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_cost,
      -SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_debit_card_revenues,
      -SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      -SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_interchange,
      -SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_interchange,
      'chargebacks' AS revenues_source,
      0 as fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO airflow_staging.temp_chargebacks
    FROM airflow_staging.temp_transaction_installments p
    INNER JOIN airflow_staging.temp_transaction_installments AS chargeback_payables
      ON chargeback_payables.transaction_id = p.transaction_id AND chargeback_payables.type = 'chargeback' AND chargeback_payables.installment = 1
    WHERE p."type" = 'credit'
    GROUP BY
      chargeback_payables.day,
      p.company_id,
      p.origin_acquirer,
      p.payment_method,
      p.card_brand,
      p.total_installments
      ;
