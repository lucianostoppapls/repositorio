--chargeback_refunds
DROP TABLE IF EXISTS airflow_staging.temp_chargeback_refunds;

    -- In this subquery, we pick credit payables, then match the first chargeback_refund of the same transaction.
    -- The idea is the same as in the chargebacks query. We do this in order to correctly credit the payables that were previously
    -- suspended due to the chargeback.
    SELECT
      chargeback_refund_payables.day AS day,
      p.company_id AS company_id,
      p.origin_acquirer AS origin_receivable,
      p.payment_method,
      p.card_brand,
      p.total_installments,
      COUNT(DISTINCT p.transaction_id) AS transaction_count,
      SUM(p.amount) AS tpv,
      SUM(CASE WHEN p.payment_method = 'credit_card' THEN p.amount ELSE 0 END) AS credit_card_tpv,
      SUM(CASE WHEN p.payment_method = 'debit_card' THEN p.amount ELSE 0 END) AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      SUM(CASE WHEN p.payment_method = 'debit_card' THEN p.fee ELSE 0 END) AS debit_card_fee,
      SUM(
        CASE
          WHEN p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS debit_card_cost,
      SUM(CASE WHEN p.payment_method = 'credit_card' THEN p.fee ELSE 0 END) AS credit_card_fee,
      SUM(
        CASE
          WHEN p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_credit_card_revenues,
      SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_cost,
      SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_debit_card_revenues,
      SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_interchange,
      SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_interchange,
      'chargeback_refunds' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO airflow_staging.temp_chargeback_refunds
    FROM airflow_staging.temp_transaction_installments p
    INNER JOIN airflow_staging.temp_transaction_installments AS chargeback_refund_payables
      ON chargeback_refund_payables.transaction_id = p.transaction_id AND chargeback_refund_payables.type = 'chargeback_refund' AND chargeback_refund_payables.installment = 1
    WHERE p."type" = 'credit'
    GROUP BY
      chargeback_refund_payables.day,
      p.company_id,
      p.origin_acquirer,
      p.payment_method,
      p.card_brand,
      p.total_installments
      ;
