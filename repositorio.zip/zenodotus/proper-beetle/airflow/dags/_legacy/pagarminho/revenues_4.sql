--payables
DROP TABLE IF EXISTS airflow_staging.temp_payables;

  SELECT
    convert_timezone('UTC', 'America/Sao_Paulo', created_at::TIMESTAMP)::DATE AS day,
    company_id,
    payment_method,
    type,
    receivable_id,
    installment,
    transaction_id,
    SUM(amount) / 100.0 AS amount,
    SUM(fee) / 100.0 AS fee,
    SUM(fraud_coverage_fee) / 100.0 AS fraud_coverage_fee
  INTO airflow_staging.temp_payables
  FROM pagarme_live.payables
  WHERE
    convert_timezone('UTC', 'America/Sao_Paulo', created_at::TIMESTAMP)::DATE >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '30 days'
    AND convert_timezone('UTC', 'America/Sao_Paulo', created_at::TIMESTAMP)::DATE < '{{ next_execution_date.isoformat() }}'::DATE
  GROUP BY
    convert_timezone('UTC', 'America/Sao_Paulo', created_at::TIMESTAMP)::DATE,
    company_id,
    payment_method,
    type,
    receivable_id,
    installment,
    transaction_id
    ;
