--card_brand_fees
DROP TABLE IF EXISTS airflow_staging.temp_card_brand_fees;

SELECT
  acquirers.name AS acquirer,
  CASE
    WHEN card_brands.name = 'master' THEN 'mastercard'
    WHEN card_brands.name = 'hiper' THEN 'hipercard'
    ELSE card_brands.name
  END AS card_brand,
  payment_strategy_descriptions.payment_method,
  payment_strategy_descriptions.installments,
  nationalities.name AS nationality,
  assessment_rate,
  installment_clearing,
  authorization_flat_fee
INTO airflow_staging.temp_card_brand_fees
FROM pagarme_stone_fees.card_brand_fees
LEFT JOIN pagarme_stone_fees.acquirers ON card_brand_fees.acquirer_id = acquirers.id
LEFT JOIN pagarme_stone_fees.card_brands ON card_brand_fees.card_brand_id = card_brands.id
LEFT JOIN pagarme_stone_fees.payment_strategy_descriptions ON card_brand_fees.payment_strategy_id = payment_strategy_descriptions.payment_strategy_id
LEFT JOIN pagarme_stone_fees.nationalities ON card_brand_fees.nationality_id = nationalities.id
;