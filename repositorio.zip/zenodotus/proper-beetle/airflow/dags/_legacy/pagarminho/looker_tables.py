from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.decorators import apply_defaults


date_column_lookup = {"revenues_table": "date"}


class LookerTableLookup(PythonOperator):
    @apply_defaults
    def __init__(self, postgres_conn_id, *args, **kwargs):
        super().__init__(*args, python_callable=self.operator, **kwargs)
        self.postgres_conn_id = postgres_conn_id

    def operator(self):
        self.log.info("Look for Looker tables based off task identifier")
        psql_hook = PostgresHook(postgres_conn_id=self.postgres_conn_id)
        task_id = self.task_id
        separator_position = task_id.find("_")
        view_name = task_id[:separator_position]
        date_column = date_column_lookup.get(task_id, "created_at")

        self.log.info(f"Using view name {view_name}")

        table_names_sql = f"""
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'looker' AND
            REGEXP_REPLACE(table_name, '^[^_]+_', '') = '{view_name}'
        """
        print(table_names_sql)
        table_names = [line[0] for line in psql_hook.get_records(table_names_sql)]

        print(f"Find most recent table using {date_column} column")
        partial_max_dates = [
            f"""
            SELECT
                '{table_name}' AS table_name,
                max({date_column}) AS max_date
            FROM looker.{table_name}
            """
            for table_name in table_names
        ]

        max_date_sql = "\n\t\t\tUNION ALL\n".join(partial_max_dates)

        most_recent_table_sql = f"""
            SELECT table_name
            FROM (
                {max_date_sql}
            ) max_dates
            ORDER BY max_date DESC
            LIMIT 1
        """

        print(most_recent_table_sql)
        result = psql_hook.get_first(most_recent_table_sql)[0]

        print(result)

        if not result:
            raise Exception("Looker table not found")

        self.log.info(f"Returning value {result}")

        return result
