SELECT
   p.company_id,
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', p.payment_date::TIMESTAMP)) AS payment_date,
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', bulk_anticipations.created_at::TIMESTAMP)) AS anticipation_date,
   transactions.payment_method,
   transactions.card_brand,
   CASE
      WHEN transactions.origin_acquirer LIKE '%stone%' THEN 'stone'
      WHEN transactions.origin_acquirer LIKE '%cielo%' THEN 'cielo'
      WHEN transactions.origin_acquirer LIKE '%rede%' THEN 'rede'
      ELSE transactions.origin_acquirer
   END AS origin_acquirer,
   SUM((p.amount - p.fee) / 100.0) AS total_anticipated_amount,
   SUM((p.amount - p.fee - p.anticipation_fee) / 100.0) AS net_anticipated_amount,
   SUM(p.anticipation_fee / 100.0) AS anticipation_fee,
   SUM(DATEDIFF(day, p.payment_date::TIMESTAMP, p.original_payment_date::TIMESTAMP) * (p.amount - p.fee) / 100.0) AS duration_numerator,
   bulk_anticipations.type AS anticipation_type
FROM pagarme_live.payables AS p
LEFT JOIN pagarme_live.bulkanticipations AS bulk_anticipations ON p.bulk_anticipation_id = bulk_anticipations.id
LEFT JOIN pagarme_dw.dim_transactions AS transactions ON p.transaction_id = transactions.transaction_key
WHERE 
   p.bulk_anticipation_id IS NOT NULL
   AND bulk_anticipations.status = 'approved'
   AND convert_timezone('UTC', 'America/Sao_Paulo', p.payment_date::TIMESTAMP) < '{{ next_execution_date.isoformat() }}'::DATE
   AND convert_timezone('UTC', 'America/Sao_Paulo', p.payment_date::TIMESTAMP) >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '45 days'
GROUP BY
   p.company_id,
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', p.payment_date::TIMESTAMP)),
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', bulk_anticipations.created_at::TIMESTAMP)),
   transactions.payment_method,
   transactions.card_brand,
   CASE
      WHEN transactions.origin_acquirer LIKE '%stone%' THEN 'stone'
      WHEN transactions.origin_acquirer LIKE '%cielo%' THEN 'cielo'
      WHEN transactions.origin_acquirer LIKE '%rede%' THEN 'rede'
      ELSE transactions.origin_acquirer
   END,
   bulk_anticipations.TYPE

   UNION ALL

   SELECT
   p.company_id,
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', p.payment_date::TIMESTAMP)) as payment_date,
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', anticipations.created_at::TIMESTAMP)) AS anticipation_date,
   transactions.payment_method,
   transactions.card_brand,
   CASE
      WHEN transactions.origin_acquirer LIKE '%stone%' THEN 'stone'
      WHEN transactions.origin_acquirer LIKE '%cielo%' THEN 'cielo'
      WHEN transactions.origin_acquirer LIKE '%rede%' THEN 'rede'
      ELSE transactions.origin_acquirer
   END AS origin_acquirer,
   SUM(((p.amount - p.fee) / 100.0)) AS total_anticipated_amount,
   SUM(((p.amount - p.fee - p.anticipation_fee) / 100.0)) AS net_anticipated_amount,
   SUM((p.anticipation_fee / 100.0)) AS anticipation_fee,
   SUM((DATEDIFF(day, p.payment_date::TIMESTAMP, p.original_payment_date::TIMESTAMP) * (p.amount - p.fee) / 100.0)) AS duration_numerator,
   anticipations.type AS anticipation_type
FROM pagarme_live.payables AS p
LEFT JOIN pagarme_live.anticipations AS anticipations ON p.anticipation_id = anticipations.id
LEFT JOIN pagarme_dw.dim_transactions AS transactions ON p.transaction_id = transactions.transaction_key
WHERE
   p.anticipation_id IS NOT NULL
   AND convert_timezone('UTC', 'America/Sao_Paulo', p.payment_date::TIMESTAMP) < '{{ next_execution_date.isoformat() }}'::DATE
   AND convert_timezone('UTC', 'America/Sao_Paulo', p.payment_date::TIMESTAMP) >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '45 days'
   --Don't get anticipations that were canceled in the same day that they were created.
   AND NOT (
      date_trunc('day', anticipations.created_at) = date_trunc('day', anticipations.updated_at)
      AND anticipations.status = 'canceled'
   )
GROUP BY
   p.company_id,
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', p.payment_date::TIMESTAMP)),
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', anticipations.created_at::TIMESTAMP)),
   transactions.payment_method,
   transactions.card_brand,
   CASE
      WHEN transactions.origin_acquirer LIKE '%stone%' THEN 'stone'
      WHEN transactions.origin_acquirer LIKE '%cielo%' THEN 'cielo'
      WHEN transactions.origin_acquirer LIKE '%rede%' THEN 'rede'
      ELSE transactions.origin_acquirer
   END,
   anticipations.TYPE

   UNION ALL

   SELECT
   p.company_id,
   --If status = canceled, we input the cancelation date as the payment_date
   date(convert_timezone('UTC', 'America/Sao_Paulo', anticipations.updated_at::TIMESTAMP)) as payment_date,
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', anticipations.created_at::TIMESTAMP)) AS anticipation_date,
   transactions.payment_method,
   transactions.card_brand,
   CASE
      WHEN transactions.origin_acquirer LIKE '%stone%' THEN 'stone'
      WHEN transactions.origin_acquirer LIKE '%cielo%' THEN 'cielo'
      WHEN transactions.origin_acquirer LIKE '%rede%' THEN 'rede'
      ELSE transactions.origin_acquirer
   END AS origin_acquirer,
   -1*SUM(((p.amount - p.fee) / 100.0)) AS total_anticipated_amount,
   -1*SUM(((p.amount - p.fee - p.anticipation_fee) / 100.0)) AS net_anticipated_amount,
   -1*SUM((p.anticipation_fee / 100.0)) AS anticipation_fee,
   0 AS duration_numerator,
   anticipations.type AS anticipation_type
FROM pagarme_live.payables AS p
LEFT JOIN pagarme_live.anticipations AS anticipations ON p.anticipation_id = anticipations.id
LEFT JOIN pagarme_dw.dim_transactions AS transactions ON p.transaction_id = transactions.transaction_key
WHERE
   p.anticipation_id IS NOT NULL
   AND convert_timezone('UTC', 'America/Sao_Paulo', anticipations.updated_at::TIMESTAMP) < '{{ next_execution_date.isoformat() }}'::DATE
   AND convert_timezone('UTC', 'America/Sao_Paulo', anticipations.updated_at::TIMESTAMP) >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '45 days'
   AND anticipations.status = 'canceled'
   --Don't get anticipations that were canceled in the same day that they were created.
   AND NOT (
      date_trunc('day', anticipations.created_at) = date_trunc('day', anticipations.updated_at)
      AND anticipations.status = 'canceled'
   )
GROUP BY
   p.company_id,
   date(convert_timezone('UTC', 'America/Sao_Paulo', anticipations.updated_at::TIMESTAMP)),
   DATE(convert_timezone('UTC', 'America/Sao_Paulo', anticipations.created_at::TIMESTAMP)),
   transactions.payment_method,
   transactions.card_brand,
   CASE
      WHEN transactions.origin_acquirer LIKE '%stone%' THEN 'stone'
      WHEN transactions.origin_acquirer LIKE '%cielo%' THEN 'cielo'
      WHEN transactions.origin_acquirer LIKE '%rede%' THEN 'rede'
      ELSE transactions.origin_acquirer
   END,
   anticipations.TYPE
