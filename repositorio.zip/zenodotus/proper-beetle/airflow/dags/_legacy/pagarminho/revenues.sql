--card_brand_fees
       SELECT
        acquirers.name AS acquirer,
        CASE WHEN card_brands.name = 'master' THEN 'mastercard'
        WHEN card_brands.name = 'hiper' THEN 'hipercard'
        ELSE card_brands.name END AS card_brand,
        payment_strategy_descriptions.payment_method,
        payment_strategy_descriptions.installments,
        nationalities.name AS nationality,
        assessment_rate,
        installment_clearing,
        authorization_flat_fee
      INTO TEMPORARY temp_card_brand_fees
      FROM pagarme_stone_fees.card_brand_fees
      LEFT JOIN pagarme_stone_fees.acquirers ON card_brand_fees.acquirer_id = acquirers.id
      LEFT JOIN pagarme_stone_fees.card_brands ON card_brand_fees.card_brand_id = card_brands.id
      LEFT JOIN pagarme_stone_fees.payment_strategy_descriptions ON card_brand_fees.payment_strategy_id = payment_strategy_descriptions.payment_strategy_id
      LEFT JOIN pagarme_stone_fees.nationalities ON card_brand_fees.nationality_id = nationalities.id
      ;

--interchanges
       SELECT
        acquirers.name AS acquirer,
        CASE WHEN card_brands.name = 'master' THEN 'mastercard'
        WHEN card_brands.name = 'hiper' THEN 'hipercard'
        ELSE card_brands.name END AS card_brand,
        payment_strategy_descriptions.payment_method,
        payment_strategy_descriptions.installments,
        mcc_group_memberships.mcc,
        bins.bin,
        rate,
        flat_fee,
        ceiling
      INTO TEMPORARY temp_interchanges
      FROM pagarme_stone_fees.interchanges
      LEFT JOIN pagarme_stone_fees.acquirers ON interchanges.acquirer_id = acquirers.id
      LEFT JOIN pagarme_stone_fees.card_brands ON interchanges.card_brand_id = card_brands.id
      LEFT JOIN pagarme_stone_fees.payment_strategy_descriptions ON interchanges.payment_strategy_id = payment_strategy_descriptions.payment_strategy_id
      INNER JOIN pagarme_stone_fees.mcc_group_memberships ON interchanges.mcc_group_id = mcc_group_memberships.mcc_group_id
      INNER JOIN pagarme_stone_fees.bins ON interchanges.card_group_id = bins.card_group_id
      ;

--default_interchanges
       SELECT
        acquirers.name AS acquirer,
        CASE WHEN card_brands.name = 'master' THEN 'mastercard'
        WHEN card_brands.name = 'hiper' THEN 'hipercard'
        ELSE card_brands.name END AS card_brand,
        payment_strategy_descriptions.payment_method,
        payment_strategy_descriptions.installments,
        mcc_group_memberships.mcc,
        rate,
        flat_fee,
        ceiling
      INTO TEMPORARY temp_default_interchanges
      FROM pagarme_stone_fees.card_brands
      LEFT JOIN pagarme_stone_fees.card_groups ON card_brands.id = card_groups.card_brand_id
      LEFT JOIN pagarme_stone_fees.acquirers ON acquirers.name = 'stone'
      CROSS JOIN pagarme_stone_fees.payment_strategy_descriptions
      LEFT JOIN pagarme_stone_fees.interchanges ON interchanges.acquirer_id = acquirers.id
      AND interchanges.card_brand_id = card_brands.id
      AND interchanges.card_group_id = card_groups.id
      AND interchanges.payment_strategy_id = payment_strategy_descriptions.payment_strategy_id
      INNER JOIN pagarme_stone_fees.mcc_group_memberships ON interchanges.mcc_group_id = mcc_group_memberships.mcc_group_id
      WHERE card_brands.name IN ('visa', 'master') AND card_groups.name = 'Platinum'
      OR card_brands.name = 'hiper' AND card_groups.name = 'Default'
      ;

--payables
  SELECT
    convert_timezone('UTC', 'America/Sao_Paulo', created_at::TIMESTAMP)::DATE AS day,
    company_id,
    payment_method,
    type,
    receivable_id,
    installment,
    transaction_id,
    SUM(amount) / 100.0 AS amount,
    SUM(fee) / 100.0 AS fee,
    SUM(fraud_coverage_fee) / 100.0 AS fraud_coverage_fee
  INTO TEMPORARY temp_payables
  FROM pagarme_live.payables
  WHERE
    convert_timezone('UTC', 'America/Sao_Paulo', created_at::TIMESTAMP)::DATE >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '30 days'
    AND convert_timezone('UTC', 'America/Sao_Paulo', created_at::TIMESTAMP)::DATE < '{{ next_execution_date.isoformat() }}'::DATE
  GROUP BY
    convert_timezone('UTC', 'America/Sao_Paulo', created_at::TIMESTAMP)::DATE,
    company_id,
    payment_method,
    type,
    receivable_id,
    installment,
    transaction_id
    ;

--installments
  SELECT
    payables.day,
    payables.company_id,
    payables.payment_method,
    payables.type,
    payables.receivable_id,
    payables.installment,
    payables.transaction_id,
    payables.amount,
    payables.fee,
    receivables.cost / 100.0 AS cost,
    CASE
      WHEN receivables.origin IS NOT NULL THEN receivables.origin
      WHEN transactions.origin_acquirer ILIKE '%stone%' THEN 'stone'
      WHEN transactions.origin_acquirer ILIKE '%cielo%' THEN 'cielo'
      WHEN transactions.origin_acquirer ILIKE '%rede%' THEN 'rede'
    END AS origin_acquirer,
    transactions.installments AS total_installments,
    transactions.card_brand,
    CASE
      WHEN transactions.origin_acquirer_id ILIKE '%education%' THEN 'education'
      WHEN transactions.origin_acquirer_id = 'sub_cielo_magazine' THEN 'sub_cielo_magazine'
      WHEN transactions.origin_acquirer_id = 'sub_stone_mei' THEN 'sub_stone_mei'
      WHEN transactions.origin_acquirer_id = 'sub_rede_carrefour' THEN 'sub_rede_carrefour'
      WHEN transactions.origin_acquirer_id = 'sub_cielo_carrefour' THEN 'sub_cielo_carrefour'
      ELSE 'standard'
    END AS mcc_category,
    companies.mcc AS company_mcc,
    original_transactions.card_first_digits,
    payables.fraud_coverage_fee
  INTO TEMPORARY temp_installments
  FROM temp_payables payables
  LEFT JOIN pagarme_live.receivables AS receivables ON payables.receivable_id = receivables.id
  LEFT JOIN pagarme_dw.dim_transactions AS transactions ON transactions.transaction_key = payables.transaction_id
  LEFT JOIN pagarme_live.transactions AS original_transactions ON original_transactions.id = payables.transaction_id
  LEFT JOIN pagarme_mongo.v_companies AS companies ON companies.id = payables.company_id
  ;

--installments_with_prices
  SELECT
    payables.day,
    payables.company_id,
    payables.payment_method,
    payables.type,
    payables.receivable_id,
    payables.installment,
    payables.transaction_id,
    payables.amount,
    payables.fee,
    payables.cost,
    payables.origin_acquirer,
    payables.total_installments,
    payables.card_brand,
    payables.mcc_category,
    payables.company_mcc,
    payables.amount * estimated_costs.interchange AS pagarme_estimated_cost,
    card_brand_fees.assessment_rate * payables.amount AS stone_card_brand_assessment,
    card_brand_fees.installment_clearing * payables.total_installments AS stone_card_brand_clearing,
    card_brand_fees.authorization_flat_fee AS stone_card_brand_flat_fee,
    CASE WHEN payables.installment = 1 THEN sign(payables.amount) ELSE 0 END AS first_installment_multiplier,
    COALESCE(interchanges.rate, default_interchanges.rate, 0) * payables.amount AS stone_interchange_amount,
    COALESCE(interchanges.flat_fee, default_interchanges.flat_fee, 0) AS stone_interchange_flat_fee,
    COALESCE(interchanges.ceiling, default_interchanges.ceiling) AS stone_interchange_ceiling,
    payables.fraud_coverage_fee
  INTO TEMPORARY temp_installments_with_prices
  FROM temp_installments AS payables
  LEFT JOIN temp_card_brand_fees card_brand_fees ON card_brand_fees.acquirer = 'stone'
    AND card_brand_fees.card_brand = payables.card_brand
    AND card_brand_fees.payment_method = payables.payment_method
    AND card_brand_fees.installments = payables.total_installments
    AND card_brand_fees.nationality = 'national'
  LEFT JOIN temp_interchanges interchanges
    ON interchanges.acquirer = 'stone'
    AND interchanges.card_brand = payables.card_brand
    AND interchanges.payment_method = payables.payment_method
    AND interchanges.installments = payables.total_installments
    AND interchanges.mcc = payables.company_mcc
    AND interchanges.bin = payables.card_first_digits
  LEFT JOIN temp_default_interchanges default_interchanges
    ON default_interchanges.acquirer = 'stone'
    AND default_interchanges.card_brand = payables.card_brand
    AND default_interchanges.payment_method = payables.payment_method
    AND default_interchanges.installments = payables.total_installments
    AND default_interchanges.mcc = payables.company_mcc
  LEFT JOIN pagarme_fees.acquirer_costs AS estimated_costs
    ON estimated_costs.card_brand = payables.card_brand
    AND estimated_costs.installments = payables.total_installments
    AND estimated_costs.payment_method = payables.payment_method
    AND estimated_costs.acquirer = payables.origin_acquirer
    AND estimated_costs.mcc_category = payables.mcc_category
    AND payables.day >= convert_timezone('UTC', 'America/Sao_Paulo', estimated_costs.start_date::TIMESTAMP)
    AND payables.day <= convert_timezone('UTC', 'America/Sao_Paulo', COALESCE(estimated_costs.end_date, CURRENT_TIMESTAMP)::TIMESTAMP)
    ;

--transaction_installments
       SELECT
        day,
        company_id,
        payment_method,
        type,
        receivable_id,
        installment,
        transaction_id,
        amount,
        fee,
        COALESCE(cost, pagarme_estimated_cost) AS cost,
        origin_acquirer,
        total_installments,
        card_brand,
        mcc_category,
        CASE
          WHEN origin_acquirer = 'stone' THEN stone_card_brand_assessment + first_installment_multiplier * (stone_card_brand_clearing + stone_card_brand_flat_fee)
          ELSE 0
        END AS card_brand_fee,
        CASE
          WHEN origin_acquirer = 'stone' THEN
            CASE
              WHEN abs(stone_interchange_amount + first_installment_multiplier * stone_interchange_flat_fee) < COALESCE(stone_interchange_ceiling, 1000000) THEN stone_interchange_amount + first_installment_multiplier * stone_interchange_flat_fee
              ELSE sign(amount) * stone_interchange_ceiling
            END
          ELSE 0
        END AS bank_interchange,
        fraud_coverage_fee
       INTO TEMPORARY temp_transaction_installments
       FROM temp_installments_with_prices
       ;

--pagarme_transactional
    -- In this subquery, we pick up transactions paid and refunded. Chargebacks are ignored, as they are handled separately in another query
    SELECT
      p.day AS day,
      p.company_id AS company_id,
      p.origin_acquirer AS origin_receivable,
      p.payment_method,
      p.card_brand,
      p.total_installments,
      COUNT(DISTINCT CASE WHEN p."type" IN ('credit', 'refund_reversal') THEN p.transaction_id END) - COUNT(DISTINCT CASE WHEN p."type" = 'refund' THEN p.transaction_id END) AS transaction_count,
      SUM(p.amount) AS tpv,
      SUM(
        CASE WHEN (p.payment_method = 'credit_card') THEN p.amount ELSE 0 END
      ) AS credit_card_tpv,
      SUM(
        CASE WHEN (p.payment_method = 'debit_card') THEN p.amount ELSE 0 END
      ) AS debit_card_tpv,
      SUM(
        CASE WHEN (p.payment_method = 'boleto') THEN p.amount ELSE 0 END
      ) AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      SUM(
        CASE WHEN (p.payment_method = 'debit_card') THEN p.fee ELSE 0 END
      ) AS debit_card_fee,
      SUM(
        CASE
          WHEN p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS debit_card_cost,
      SUM(
        CASE WHEN (p.payment_method = 'credit_card') THEN p.fee ELSE 0 END
      ) AS credit_card_fee,
      SUM(
        CASE
          WHEN p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS credit_card_cost,
      SUM(
        CASE WHEN (p.payment_method = 'boleto') THEN p.fee ELSE 0 END
      ) AS boleto_fee,
      SUM(
        CASE WHEN (p.payment_method = 'boleto') THEN p.cost ELSE 0 END
      ) AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_credit_card_revenues,
      SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.card_brand_fee + p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_cost,
      SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_debit_card_revenues,
      SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.card_brand_fee + p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_cost,
      SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.card_brand_fee ELSE 0 END
      ) AS stone_credit_card_assessment,
      SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.card_brand_fee ELSE 0 END
      ) AS stone_debit_card_assessment,
      SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_interchange,
      SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_interchange,
      'pagarme_transactional' AS revenues_source,
      SUM(p.fraud_coverage_fee) AS fraud_coverage_fee,
      COUNT(DISTINCT CASE WHEN p."type" IN ('credit', 'refund_reversal') AND p.fraud_coverage_fee <> 0 THEN p.transaction_id END) - COUNT(DISTINCT CASE WHEN p."type" = 'refund' AND p.fraud_coverage_fee <> 0 THEN p.transaction_id END) AS fraud_coverage_transactions_count
    INTO TEMPORARY temp_pagarme_transactional
    FROM temp_transaction_installments p
    -- We explicitly pick chargebacks in a separate query, so we ignore them here
    WHERE p."type" NOT IN ('chargeback', 'chargeback_refund')
    GROUP BY
      p.day,
      p.company_id,
      p.origin_acquirer,
      p.payment_method,
      p.card_brand,
      p.total_installments
      ;

--chargebacks
    -- In this subquery, we pick up credit payables, then inner join with the
    -- first installment of the chargeback_payables (that have type = 'chargeback')
    -- within the same transaction. Then, we subtract the values of the credit
    -- payables in the dates the chargeback_payables were created. This is done
    -- in order to correctly subtract chargebacks of suspended payables, for
    -- which no actual chargeback payables are created. Therefore, their
    -- subtraction has to be infered from the first installment of chargebacks.

    SELECT
      chargeback_payables.day,
      p.company_id AS company_id,
      p.origin_acquirer AS origin_receivable,
      p.payment_method,
      p.card_brand,
      p.total_installments,
      -COUNT(DISTINCT p.transaction_id)  AS transaction_count,
      -SUM(p.amount) AS tpv,
      -SUM(CASE WHEN p.payment_method = 'credit_card' THEN p.amount ELSE 0 END) AS credit_card_tpv,
      -SUM(CASE WHEN p.payment_method = 'debit_card' THEN p.amount ELSE 0 END) AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      -SUM(CASE WHEN p.payment_method = 'debit_card' THEN p.fee ELSE 0 END) AS debit_card_fee,
      -SUM(
        CASE
          WHEN p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS debit_card_cost,
      -SUM(CASE WHEN p.payment_method = 'credit_card' THEN p.fee ELSE 0 END) AS credit_card_fee,
      -SUM(
        CASE
          WHEN p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      -SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_credit_card_revenues,
      -SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_cost,
      -SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_debit_card_revenues,
      -SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      -SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_interchange,
      -SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_interchange,
      'chargebacks' AS revenues_source,
      0 as fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO TEMPORARY temp_chargebacks
    FROM temp_transaction_installments p
    INNER JOIN temp_transaction_installments AS chargeback_payables
      ON chargeback_payables.transaction_id = p.transaction_id AND chargeback_payables.type = 'chargeback' AND chargeback_payables.installment = 1
    WHERE p."type" = 'credit'
    GROUP BY
      chargeback_payables.day,
      p.company_id,
      p.origin_acquirer,
      p.payment_method,
      p.card_brand,
      p.total_installments
      ;


--chargeback_refunds
    -- In this subquery, we pick credit payables, then match the first chargeback_refund of the same transaction.
    -- The idea is the same as in the chargebacks query. We do this in order to correctly credit the payables that were previously
    -- suspended due to the chargeback.
    SELECT
      chargeback_refund_payables.day AS day,
      p.company_id AS company_id,
      p.origin_acquirer AS origin_receivable,
      p.payment_method,
      p.card_brand,
      p.total_installments,
      COUNT(DISTINCT p.transaction_id) AS transaction_count,
      SUM(p.amount) AS tpv,
      SUM(CASE WHEN p.payment_method = 'credit_card' THEN p.amount ELSE 0 END) AS credit_card_tpv,
      SUM(CASE WHEN p.payment_method = 'debit_card' THEN p.amount ELSE 0 END) AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      SUM(CASE WHEN p.payment_method = 'debit_card' THEN p.fee ELSE 0 END) AS debit_card_fee,
      SUM(
        CASE
          WHEN p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS debit_card_cost,
      SUM(CASE WHEN p.payment_method = 'credit_card' THEN p.fee ELSE 0 END) AS credit_card_fee,
      SUM(
        CASE
          WHEN p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'credit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_credit_card_revenues,
      SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_cost,
      SUM(
        CASE
          WHEN p.origin_acquirer = 'stone' AND p.payment_method = 'debit_card' THEN p.cost
          ELSE 0
        END
      ) AS stone_debit_card_revenues,
      SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      SUM(
        CASE WHEN (p.payment_method = 'credit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_credit_card_interchange,
      SUM(
        CASE WHEN (p.payment_method = 'debit_card' and p.origin_acquirer = 'stone') THEN p.bank_interchange ELSE 0 END
      ) AS stone_debit_card_interchange,
      'chargeback_refunds' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO TEMPORARY temp_chargeback_refunds
    FROM temp_transaction_installments p
    INNER JOIN temp_transaction_installments AS chargeback_refund_payables
      ON chargeback_refund_payables.transaction_id = p.transaction_id AND chargeback_refund_payables.type = 'chargeback_refund' AND chargeback_refund_payables.installment = 1
    WHERE p."type" = 'credit'
    GROUP BY
      chargeback_refund_payables.day,
      p.company_id,
      p.origin_acquirer,
      p.payment_method,
      p.card_brand,
      p.total_installments
      ;

--gateway_fees
      -- nessa subquery trazemos apenas o gateway fee - o passado e alterado pois a cada estorno o fee de gateway da transaciton e zerado
      -- Os ifs em gateway_fees,credit_card_fees e revenues_source são para ajustar o processo do cliente Visto Americano, dado que seu mdr entra como gateway_fee e não como credit_card_fee
    SELECT
      CASE
        WHEN stages.name = 'paid' THEN convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at :: TIMESTAMP)::DATE
        -- We assume the date the transaction was refunded is the date it was last updated,
        -- as gateway transactions are updated only to be refunded
        WHEN stages.name = 'refunded' THEN convert_timezone('UTC', 'America/Sao_Paulo', tx.updated_at :: TIMESTAMP)::DATE
      END AS day,
      tx.company_id,
      CASE WHEN (r.origin) IN ('stone') THEN r.origin ELSE 'gateway_' || tx.acquirer_name END AS origin_receivable,
      tx.payment_method,
      tx.card_brand,
      tx.installments AS total_installments,
      0 AS transaction_count,
      0 AS tpv,
      0 AS credit_card_tpv,
      0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      case
        when company_id = '5ab5234c23b1f0c70814950c' and origin_receivable <> 'gateway_pagarme' then 0
        else SUM(
          CASE
            WHEN tx.cost > 0 THEN stages.sign * tx.cost
            ELSE stages.sign * (
              f_json_extract(companies.transaction_cost, tx.payment_method)
              + f_json_extract(companies.transaction_spread, tx.payment_method) * tx.amount
            )
          END
        ) / 100.0
      end AS gateway_fee,
      0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      case
        when company_id = '5ab5234c23b1f0c70814950c' and origin_receivable <> 'gateway_pagarme' then SUM(
          CASE
            WHEN tx.cost > 0 THEN stages.sign * tx.cost
            ELSE stages.sign * (
              f_json_extract(companies.transaction_cost, tx.payment_method)
              + f_json_extract(companies.transaction_spread, tx.payment_method) * tx.amount
            )
          END
        ) / 100.0
        else 0
      end AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      case
        when company_id = '5ab5234c23b1f0c70814950c' and origin_receivable <> 'gateway_pagarme' then 'pagarme_transactional'
        else 'gateway_fees'
      end AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO TEMPORARY temp_gateway_fees
    FROM
      pagarme_live.transactions tx
      -- The intent of the following cross join is to expend all rows in to possibly two.
      -- This is so that, when the status of the transaction is refunded, we can use the last updated
      -- date of the transaction
      CROSS JOIN (SELECT 'paid' AS name, 1 AS sign UNION ALL SELECT 'refunded' AS name, -1 AS sign) stages
      LEFT JOIN pagarme_mongo.v_companies AS companies ON companies.id = tx.id
      LEFT JOIN (
        SELECT
          transaction_id,
          origin
        FROM
          pagarme_live.receivables
        GROUP BY
          1,
          2
      ) AS r ON tx.id = r.transaction_id
    WHERE
      tx.payment_method in ('credit_card', 'debit_card')
      AND convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '30 days'
      AND convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE < '{{ next_execution_date.isoformat() }}'::DATE
      -- We want rows in the 'paid' stage, bug only refunded transactions in the 'refunded' stage
      -- This is so that rows correctly return gateway fees (transaction costs) in the correct dates
      AND tx.status IN ('paid', 'refunded')
      AND (stages.name = 'paid' OR stages.name = 'refunded' AND tx.status = 'refunded')
    GROUP BY
      1,
      2,
      3,
      4,
      5,
      6
      ;

--gateway_only_tpv
    -- nessa subquery trazemos apenas o tpv de gateway - o passado e alterado pois pegamos status = paid
    SELECT
      convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE AS DAY,
      tx.company_id,
      'gateway_' || tx.acquirer_name AS origin_receivable,
      tx.payment_method,
      tx.card_brand,
      tx.installments AS total_installments,
      count(*) AS transaction_count,
      SUM(tx.amount) / 100.0 AS tpv,
      SUM(
        CASE WHEN (
          tx.payment_method = 'credit_card'
        ) THEN stages.sign * tx.amount ELSE 0 END
      ) / 100.0 AS credit_card_tpv,
      SUM(
        CASE WHEN (tx.payment_method = 'debit_card') THEN stages.sign * tx.amount ELSE 0 END
      ) / 100.0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      0 AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      'gateway_only_tpv' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO TEMPORARY temp_gateway_only_tpv
    FROM
      pagarme_live.transactions tx
      -- For each transaction, we generate two possible stages in the cross join.
      -- This is so it's possible to filter the desired second stages in the where clause.
      CROSS JOIN (SELECT 'paid' AS name, 1 AS sign UNION ALL SELECT 'refunded' AS name, -1 AS sign) stages
    WHERE
      tx.acquirer_name != 'pagarme'
      AND convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '30 days'
      AND convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE < '{{ next_execution_date.isoformat() }}'::DATE
      AND tx.status IN ('paid', 'refunded')
      -- Similar to the gateway_fees query, here we get all the lines in the paid stage,
      -- but only the refunded transactions in the refunded stage lines
      AND (stages.name = 'paid' OR stages.name = 'refunded' AND tx.status = 'refunded')
    GROUP BY
      1,
      2,
      3,
      4,
      5,
      6
      ;

--antifraud_costs
    -- custo de antifraud
    SELECT
      convert_timezone('UTC', 'America/Sao_Paulo', af.created_at::TIMESTAMP)::DATE AS day,
      company_id,
      CASE WHEN (r.origin) IN ('stone', 'bradesco') THEN r.origin ELSE 'cielo/rede' END AS origin_receivable,
      r.payment_method,
      r.card_brand,
      r.total_installments,
      0 AS transaction_count,
      0 AS tpv,
      0 AS credit_card_tpv,
      0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      SUM(af.cost) / 100.0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      0 AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      'antifraud_costs' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO TEMPORARY temp_antifraud_costs
    FROM
      pagarme_live.antifraudanalyses af
      LEFT JOIN (
        SELECT
          transaction_id,
          origin_acquirer AS origin,
          payment_method,
          card_brand,
          total_installments
        FROM
          temp_transaction_installments
        GROUP BY
          transaction_id,
          origin_acquirer,
          payment_method,
          card_brand,
          total_installments
      ) AS r ON af.transaction_id = r.transaction_id
    GROUP BY
      1,
      2,
      3,
      4,
      5,
      6
      ;

--transfer_costs
    SELECT
      convert_timezone('UTC', 'America/Sao_Paulo', t.created_at::TIMESTAMP)::DATE AS day,
      t.company_id,
      'N/A' origin_receivable,
      NULL AS payment_method,
      NULL AS card_brand,
      NULL::INT AS total_installments,
      0 AS transaction_count,
      0 AS tpv,
      0 AS credit_card_tpv,
      0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      0 AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      SUM(t.fee) / 100.0 AS transfer_fee,
      SUM(t.cost) / 100.0 AS transfer_cost,
      COUNT(id) AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      'transfer_costs' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO TEMPORARY temp_transfer_costs
    FROM
      pagarme_live.transfers t
    WHERE
      t.status != 'canceled'
    GROUP BY
      1,
      2
    UNION ALL
    SELECT
      convert_timezone('UTC', 'America/Sao_Paulo', settlements.created_at::TIMESTAMP) AS DAY,
      refunds.company_id,
      'N/A' origin_receivable,
      NULL AS payment_method,
      NULL AS card_brand,
      NULL::INT AS total_installments,
      0 AS transaction_count,
      0 AS tpv,
      0 AS credit_card_tpv,
      0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      0 AS gateway_fee,
      0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      0 AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      SUM(refunds.processing_fee) / 100.0 AS transfer_fee,
      SUM(settlements.cost) / 100.0 AS transfer_cost,
      COUNT(refunds.id) AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      'transfer_costs' AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    FROM
      pagarme_live.refunds
      LEFT JOIN pagarme_live.settlements AS settlements ON settlements.id = refunds.settlement_id
    WHERE
      refunds.status = 'refunded'
      AND refunds."type" = 'boleto'
      AND settlements.id IS NOT NULL
    GROUP BY
      convert_timezone('UTC', 'America/Sao_Paulo', settlements.created_at :: TIMESTAMP),
      refunds.company_id
      ;

with revenues AS (
       SELECT
         convert_timezone(
           'America/Sao_Paulo', 'UTC', q.day
         ) AS DATE,
         q.company_id,
         q.origin_receivable,
         q.revenues_source,
         q.payment_method,
         q.card_brand,
         q.total_installments,
         SUM(q.tpv) AS tpv,
         SUM(q.credit_card_tpv) AS credit_card_tpv,
         SUM(q.debit_card_tpv) AS debit_card_tpv,
         SUM(q.boleto_tpv) AS boleto_tpv,
         SUM(q.anticipated_tpv) AS anticipated_tpv,
         SUM(q.rav) AS anticipation_fee,
         SUM(q.anticipation_cost) AS anticipation_cost,
         SUM(q.transaction_count) AS transaction_count,
         SUM(q.gateway_fee) AS gateway_fee,
         SUM(q.debit_card_fee) AS debit_card_fee,
         SUM(q.antifraud_cost) AS antifraud_cost,
         SUM(q.debit_card_cost) AS debit_card_cost,
         SUM(q.credit_card_fee) AS credit_card_fee,
         SUM(q.credit_card_cost) AS credit_card_cost,
         SUM(q.boleto_fee) AS boleto_fee,
         SUM(q.boleto_cost) AS boleto_cost,
         SUM(q.transfer_fee) AS transfer_fee,
         SUM(q.transfer_cost) AS transfer_cost,
         SUM(q.transfer_count) AS transfer_count,
         SUM(q.stone_credit_card_revenues) AS stone_credit_card_revenues,
         SUM(q.stone_credit_card_cost) AS stone_credit_card_cost,
         SUM(q.stone_debit_card_revenues) AS stone_debit_card_revenues,
         SUM(q.stone_debit_card_cost) AS stone_debit_card_cost,
         SUM(q.stone_credit_card_assessment) AS stone_credit_card_assessment,
         SUM(q.stone_debit_card_assessment) AS stone_debit_card_assessment,
         SUM(q.stone_credit_card_interchange) AS stone_credit_card_interchange,
         SUM(q.stone_debit_card_interchange) AS stone_debit_card_interchange,
         SUM(q.fraud_coverage_fee) as fraud_coverage_fee,
         SUM(q.fraud_coverage_transactions_count) AS fraud_coverage_transactions_count
       FROM
         (
           SELECT * FROM temp_pagarme_transactional
           UNION ALL
           SELECT * FROM temp_chargebacks
           UNION ALL
           SELECT * FROM temp_chargeback_refunds
           UNION ALL
           SELECT * FROM temp_gateway_fees
           UNION ALL
           SELECT * FROM temp_gateway_only_tpv
           UNION ALL
           SELECT * FROM temp_antifraud_costs
           UNION ALL
           SELECT * FROM temp_transfer_costs
         ) q

       GROUP BY
         q.company_id,
         convert_timezone(
           'America/Sao_Paulo', 'UTC', q.day
         ),
         q.origin_receivable,
         q.revenues_source,
         q.payment_method,
         q.card_brand,
         q.total_installments
)

SELECT convert_timezone('UTC','America/Sao_Paulo',date::timestamp) AS date,
       company_id,
       origin_receivable,
       tpv,
       credit_card_tpv,
       debit_card_tpv,
       boleto_tpv,
       anticipated_tpv,
       anticipation_fee,
       anticipation_cost,
       transaction_count,
       gateway_fee,
       debit_card_fee,
       antifraud_cost,
       debit_card_cost,
       credit_card_fee,
       credit_card_cost,
       boleto_fee,
       boleto_cost,
       transfer_fee,
       transfer_cost,
       transfer_count,
       stone_credit_card_revenues,
       stone_credit_card_cost,
       stone_debit_card_revenues,
       stone_debit_card_cost,
       stone_credit_card_assessment,
       stone_debit_card_assessment,
       stone_credit_card_interchange,
       stone_debit_card_interchange,
       revenues_source,
       payment_method,
       card_brand,
       total_installments,
       fraud_coverage_fee,
       fraud_coverage_transactions_count
FROM revenues
WHERE convert_timezone('UTC','America/Sao_Paulo',date::timestamp) >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '20 days'
AND convert_timezone('UTC','America/Sao_Paulo',date::timestamp) < '{{ next_execution_date.isoformat() }}'::DATE
