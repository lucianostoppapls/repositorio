--default_interchanges
DROP TABLE IF EXISTS airflow_staging.temp_default_interchanges;

SELECT
  acquirers.name AS acquirer,
  CASE
    WHEN card_brands.name = 'master' THEN 'mastercard'
    WHEN card_brands.name = 'hiper' THEN 'hipercard'
    ELSE card_brands.name
  END AS card_brand,
  payment_strategy_descriptions.payment_method,
  payment_strategy_descriptions.installments,
  mcc_group_memberships.mcc,
  rate,
  flat_fee,
  ceiling
INTO airflow_staging.temp_default_interchanges
FROM pagarme_stone_fees.card_brands
LEFT JOIN pagarme_stone_fees.card_groups ON card_brands.id = card_groups.card_brand_id
LEFT JOIN pagarme_stone_fees.acquirers ON acquirers.name = 'stone'
CROSS JOIN pagarme_stone_fees.payment_strategy_descriptions
LEFT JOIN pagarme_stone_fees.interchanges ON
  interchanges.acquirer_id = acquirers.id
  AND interchanges.card_brand_id = card_brands.id
  AND interchanges.card_group_id = card_groups.id
  AND interchanges.payment_strategy_id = payment_strategy_descriptions.payment_strategy_id
INNER JOIN pagarme_stone_fees.mcc_group_memberships ON interchanges.mcc_group_id = mcc_group_memberships.mcc_group_id
WHERE
  card_brands.name IN ('visa', 'master')
  AND card_groups.name = 'Platinum'
  OR card_brands.name = 'hiper'
  AND card_groups.name = 'Default'
;
