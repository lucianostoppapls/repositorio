--gateway_fees
DROP TABLE IF EXISTS airflow_staging.temp_gateway_fees;

      -- nessa subquery trazemos apenas o gateway fee - o passado e alterado pois a cada estorno o fee de gateway da transaciton e zerado
      -- Os ifs em gateway_fees,credit_card_fees e revenues_source são para ajustar o processo do cliente Visto Americano, dado que seu mdr entra como gateway_fee e não como credit_card_fee
    SELECT
      CASE
        WHEN stages.name = 'paid' THEN convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at :: TIMESTAMP)::DATE
        -- We assume the date the transaction was refunded is the date it was last updated,
        -- as gateway transactions are updated only to be refunded
        WHEN stages.name = 'refunded' THEN convert_timezone('UTC', 'America/Sao_Paulo', tx.updated_at :: TIMESTAMP)::DATE
      END AS day,
      tx.company_id,
      CASE WHEN (r.origin) IN ('stone') THEN r.origin ELSE 'gateway_' || tx.acquirer_name END AS origin_receivable,
      tx.payment_method,
      tx.card_brand,
      tx.installments AS total_installments,
      0 AS transaction_count,
      0 AS tpv,
      0 AS credit_card_tpv,
      0 AS debit_card_tpv,
      0 AS boleto_tpv,
      0 AS anticipated_tpv,
      0 AS rav,
      case
        when company_id = '5ab5234c23b1f0c70814950c' and origin_receivable <> 'gateway_pagarme' then 0
        else SUM(
          CASE
            WHEN tx.cost > 0 THEN stages.sign * tx.cost
            ELSE stages.sign * (
              f_json_extract(companies.transaction_cost, tx.payment_method)
              + f_json_extract(companies.transaction_spread, tx.payment_method) * tx.amount
            )
          END
        ) / 100.0
      end AS gateway_fee,
      0 AS antifraud_cost,
      0 AS debit_card_fee,
      0 AS debit_card_cost,
      case
        when company_id = '5ab5234c23b1f0c70814950c' and origin_receivable <> 'gateway_pagarme' then SUM(
          CASE
            WHEN tx.cost > 0 THEN stages.sign * tx.cost
            ELSE stages.sign * (
              f_json_extract(companies.transaction_cost, tx.payment_method)
              + f_json_extract(companies.transaction_spread, tx.payment_method) * tx.amount
            )
          END
        ) / 100.0
        else 0
      end AS credit_card_fee,
      0 AS credit_card_cost,
      0 AS boleto_fee,
      0 AS boleto_cost,
      0 AS anticipation_cost,
      0 AS transfer_fee,
      0 AS transfer_cost,
      0 AS transfer_count,
      0 AS stone_credit_card_revenues,
      0 AS stone_credit_card_cost,
      0 AS stone_debit_card_revenues,
      0 AS stone_debit_card_cost,
      0 AS stone_credit_card_assessment,
      0 AS stone_debit_card_assessment,
      0 AS stone_credit_card_interchange,
      0 AS stone_debit_card_interchange,
      case
        when company_id = '5ab5234c23b1f0c70814950c' and origin_receivable <> 'gateway_pagarme' then 'pagarme_transactional'
        else 'gateway_fees'
      end AS revenues_source,
      0 AS fraud_coverage_fee,
      0 AS fraud_coverage_transactions_count
    INTO airflow_staging.temp_gateway_fees
    FROM
      pagarme_live.transactions tx
      -- The intent of the following cross join is to expend all rows in to possibly two.
      -- This is so that, when the status of the transaction is refunded, we can use the last updated
      -- date of the transaction
      CROSS JOIN (SELECT 'paid' AS name, 1 AS sign UNION ALL SELECT 'refunded' AS name, -1 AS sign) stages
      LEFT JOIN pagarme_mongo.v_companies AS companies ON companies.id = tx.id
      LEFT JOIN (
        SELECT
          transaction_id,
          origin
        FROM
          pagarme_live.receivables
        GROUP BY
          1,
          2
      ) AS r ON tx.id = r.transaction_id
    WHERE
      tx.payment_method in ('credit_card', 'debit_card')
      AND convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE >= '{{ next_execution_date.isoformat() }}'::DATE - INTERVAL '30 days'
      AND convert_timezone('UTC', 'America/Sao_Paulo', tx.created_at::TIMESTAMP)::DATE < '{{ next_execution_date.isoformat() }}'::DATE
      -- We want rows in the 'paid' stage, bug only refunded transactions in the 'refunded' stage
      -- This is so that rows correctly return gateway fees (transaction costs) in the correct dates
      AND tx.status IN ('paid', 'refunded')
      AND (stages.name = 'paid' OR stages.name = 'refunded' AND tx.status = 'refunded')
    GROUP BY
      1,
      2,
      3,
      4,
      5,
      6
      ;
