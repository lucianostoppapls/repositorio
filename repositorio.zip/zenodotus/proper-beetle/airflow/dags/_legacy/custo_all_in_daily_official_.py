from airflow import DAG
from datetime import datetime, timedelta
from helpers.datalake import default_args, transfer_tasks
from dags.utils.airflow_utils import make_backfill_dags, with_dags
from airflow import configuration as conf
from plugins.gdrive_utils import GoogleDriveHook
from plugins.gdrive_test import GdriveToGCSOperator


file_name = "bi_stage/Projeto_Indicadores/Custo_ALL_IN_Daily_Official.xlsm"
temp_gcs_file_name = "bi_stage/Projeto_Indicadores/custo_all_in_daily_official_{{ execution_date.strftime('%Y_%m_%d') }}.csv"


dag = DAG(
    dag_id="_test__custo_all_in_daily_official",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2022, 1, 20, 0, 0),
    default_args={
        "autocommit": True,
        "retries": 4,
        "retry_delay": timedelta(minutes=15),
        "google_cloud_storage_conn_id": "gcp_mis",
        "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
        "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    },
)

with dag:
    convert_excel_to_csv = GdriveToGCSOperator(
        task_id="convert_excel_to_csv",
        source_database=None,
        source_schema=file_name,
        source_table=None,
        source_incremental_columns_list=[],
        non_replicated_columns_list=[],
        load_type="full_dump",
        google_cloud_storage_conn_id="gcp_mis",
        gcs_bucket_name=conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
        source_conn_id="gcp_mis",
        gcs_file_name=temp_gcs_file_name,
    )

convert_excel_to_csv
