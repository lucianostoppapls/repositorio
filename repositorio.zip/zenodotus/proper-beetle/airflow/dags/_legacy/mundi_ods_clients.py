from datetime import datetime, timedelta
from airflow import DAG
from mssql_utils import MsSqlOperatorPYODBC
from plugins.mssql_utils import GCSToMssqlExtractOperator
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts
from airflow import configuration as conf
from plugins.gcp_utils import BigqueryToGCSOperator


default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "retries": 4,
    "retry_delay": timedelta(minutes=15),
    "autocommit": True,
    "google_cloud_storage_conn_id": "gcp_mis",
    "mssql_conn_id": "bw_azure",
    "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "on_failure_callback": PagerDutyAlerts.failure_incident,
    "on_success_callback": PagerDutyAlerts.resolve_incident,
}

dag = DAG(
    dag_id="_legacy__mundi_ods_clients",
    default_args=default_args,
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 8, 20),
)

with dag:
    extract = BigqueryToGCSOperator(
        task_id="extract_mundi_clients",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/mundi_ods/clients_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="""
            with billingv1 as (
                SELECT
                    'MundiPagg' AS origin,
                    c.customerkey as customerkey,
                    c.documentnumber AS cnpj,
                    c.name as name,
                    CAST(c.createdate AS DATE) AS createdat,
                    CAST(ad.affiliateddate AS DATE) AS affiliateddate,
                    fadpc.firstactivationdate,
                    CAST(lod.lastorderdate AS DATE) AS lasttransaction,
                    concat(concat(sp.firstname, ' '),sp.lastname) as closername,
                    --cast(null as date) as canceledat,
                    c.corporatename AS fullname,
                    /*CASE
                        WHEN (c.currentstatus = 3) THEN 'PreAffiliated'::CHARACTER varying
                        WHEN (c.currentstatus = 1) THEN 'Cancelled'::CHARACTER varying
                        WHEN (c.currentstatus = 2) THEN 'Frozen'::CHARACTER varying
                        WHEN ((fadpc.firstactivationdate IS NOT NULL)
                            AND (lod.lastorderdate >= date_add(('DAY'::CHARACTER varying)::text, (-10)::bigint, (('now'::CHARACTER varying)::date)::TIMESTAMP WITHOUT TIME ZONE))) THEN 'Active'::CHARACTER varying
                        WHEN ((fadpc.firstactivationdate IS NOT NULL)
                            AND ((lod.lastorderdate >= date_add(('DAY'::CHARACTER varying)::text, (-90)::bigint, (('now'::CHARACTER varying)::date)::TIMESTAMP WITHOUT TIME ZONE))
                                    AND (lod.lastorderdate <= date_add(('DAY'::CHARACTER varying)::text, (-10)::bigint, (('now'::CHARACTER varying)::date)::TIMESTAMP WITHOUT TIME ZONE)))) THEN 'Inactive'::CHARACTER varying
                        WHEN (fadpc.firstactivationdate IS NOT NULL) THEN 'Churn'::CHARACTER varying
                        ELSE 'Affiliated'::CHARACTER varying
                    END as status,*/
                    'Cancelled' AS status,
                    a.postalcode AS zipcode,
                    a.street as street,
                    a.number AS streetnumber,
                    a.complement AS complementary,
                    a.district AS neighborhood,
                    a.city as city,
                    a.state as state
                    --sp.salesforceuserid as closerid,
                    --null as closeremail
                    FROM dataplatform-prd.mundi_billingdb.customer c
                    LEFT JOIN dataplatform-prd.mundi_billingdb.salesperson sp ON c.salespersonid = sp.salespersonid
                    LEFT JOIN dataplatform-prd.mundi_billingdb.address a ON c.billingaddressid = a.addressid
                    LEFT JOIN (
                        SELECT
                            c.customerkey,
                            c.customerid,
                            MAX(mo.createdate) AS lastorderdate
                        FROM dataplatform-prd.mundi_mundipaggdb.vw_merchantorder mo
                        INNER JOIN dataplatform-prd.mundi_mundipaggdb.merchant m ON mo.merchantid = m.merchantid
                        INNER JOIN dataplatform-prd.mundi_mundipaggdb.vw_customer c ON m.customerid = c.customerid
                        GROUP BY
                            c.customerkey,
                            c.customerid
                    ) lod ON cast(lod.customerkey AS STRING) = cast(c.customerkey AS STRING)
                    LEFT JOIN (
                        SELECT 
                            tdtpv.customerkey,
                            tdtpv.customerid,
                            MIN(tdtpv.day) AS firstactivationdate
                        FROM (
                            SELECT 
                                d.customerkey,
                                d.customerid,
                                d.day,
                                (
                                    SELECT 
                                        sum(subd.tpv) AS `SUM`
                                    FROM (
                                        SELECT
                                            c.customerkey,
                                            c.customerid,
                                            DATE_TRUNC(CAST(cct.captureddate AS DATE), DAY) AS `day`,
                                            SUM(cct.capturedamountincents) AS tpv
                                        FROM dataplatform-prd.mundi_mundipaggdb.vw_creditcardtransaction cct
                                        INNER JOIN dataplatform-prd.mundi_mundipaggdb.merchantacquireragreement maa ON cct.merchantacquireragreementid = maa.merchantacquireragreementid
                                        INNER JOIN dataplatform-prd.mundi_mundipaggdb.paymentmethod pm ON (
                                            maa.paymentmethodid = pm.paymentmethodid
                                            AND pm.isstagingagreement = CAST(0 AS BOOLEAN)
                                        )
                                        INNER JOIN dataplatform-prd.mundi_mundipaggdb.merchant m ON maa.merchantid = m.merchantid
                                        INNER JOIN dataplatform-prd.mundi_mundipaggdb.vw_customer c ON m.customerid = c.customerid
                                        GROUP BY
                                            c.customerkey,
                                            c.customerid,
                                            DATE_TRUNC(CAST(cct.captureddate AS DATE), DAY)
                                    ) subd
                                    WHERE
                                        d.customerid = subd.customerid
                                        AND subd.`day` >= DATE_ADD(d.`day`, INTERVAL -30 DAY)
                                        AND subd.`day` <= d.`day`
                                )/ 100.0 AS thirtydaystpv
                            FROM (
                                SELECT
                                    c.customerkey,
                                    c.customerid,
                                    DATE_TRUNC(CAST(cct.captureddate AS DATE), DAY) AS `day`,
                                    SUM(cct.capturedamountincents) AS tpv
                                FROM dataplatform-prd.mundi_mundipaggdb.vw_creditcardtransaction cct
                                INNER JOIN dataplatform-prd.mundi_mundipaggdb.merchantacquireragreement maa ON cct.merchantacquireragreementid = maa.merchantacquireragreementid
                                INNER JOIN dataplatform-prd.mundi_mundipaggdb.paymentmethod pm ON 
                                    maa.paymentmethodid = pm.paymentmethodid
                                    AND pm.isstagingagreement = CAST(0 AS BOOLEAN)
                                INNER JOIN dataplatform-prd.mundi_mundipaggdb.merchant m ON maa.merchantid = m.merchantid
                                INNER JOIN dataplatform-prd.mundi_mundipaggdb.vw_customer c ON m.customerid = c.customerid
                                GROUP BY
                                    c.customerkey,
                                    c.customerid,
                                    DATE_TRUNC(CAST(cct.captureddate AS DATE), DAY)
                            ) d
                        ) tdtpv
                        WHERE
                            tdtpv.thirtydaystpv >= 500.0
                        GROUP BY
                            tdtpv.customerkey,
                            tdtpv.customerid
                    ) fadpc ON CAST(fadpc.customerkey AS STRING) = CAST(c.customerkey AS STRING)
                    LEFT JOIN (
                        SELECT
                            c.customerkey,
                            MIN(csh.datechange) AS affiliateddate
                        FROM dataplatform-prd.mundi_billingdb.customer c
                        LEFT JOIN dataplatform-prd.mundi_billingdb.customerstatushistory csh ON c.customerid = csh.customerid
                        WHERE csh.customerstatusenum = 0
                        GROUP BY
                            c.customerkey
                    ) ad ON CAST(ad.customerkey AS STRING) = CAST(c.customerkey AS STRING)
            ),
            billingv2 as (
                SELECT DISTINCT
                    'MundiPagg' AS origin,
                    --billingv2_customer.externalid,
                    account.customerkey as customerkey,
                    billingv2_customer.document AS cnpj,
                    billingv2_customer.name as name,
                    COALESCE(opportunity.wondate, CAST(bc.createdate AS DATE), CAST(billingv2_subscription.createdat AS DATE)) as createdat,--uso primeiro a data do SF, caso não tenha (clientes pré 2017.2), uso data cadastrada no billing antigo.
                    cast(null as date) as affiliateddate,
                    cast(null as date) as firstactivationdate,
                    cast(null as date) as lasttransaction,
                    COALESCE(opportunity.vendorname,concat(CONCAT(sp.firstname, ' '),sp.lastname)) as closername,
                    /*case
                        when billingv2_subscription.status = 'Cancelled' then billingv2_subscription.canceledat 
                        else null
                    end as canceledat,*/--Uso a data de cancelamento da última subscription ativa que o cliente tinha. Não existe ainda um fluxo de cancelamento no SF.
                    billingv2_customer.name as fullname,
                    billingv2_subscription.status AS status,
                    billingv2_address.zipcode AS zipcode,
                    billingv2_address.street,
                    billingv2_address.number AS streetnumber,
                    billingv2_address.complement AS complementary,
                    billingv2_address.neighborhood AS neighborhood,
                    billingv2_address.city as city,
                    billingv2_address.state as state
                    --COALESCE(opportunity.vendorid,  sp.salesforceuserid) as closerid,
                    --opportunity.vendoremail as closeremail
                FROM dataplatform-prd.mundi_mark1db.customer AS billingv2_customer
                LEFT JOIN dataplatform-prd.mundi_mark1db.address as billingv2_address ON billingv2_customer.addressid = billingv2_address.id
                LEFT JOIN (--vejo se o cliente tem pelo menos uma subscription ativa. Se sim, o cliente está ativo.
                    SELECT
                        id,
                        customerid,
                        accountid,
                        case
                            when SUM(case when status = 'active' then 1 else 0 end) over (partition by customerid) > 0 then 'Active'
                            else 'Cancelled'
                        end as status,
                        MAX(canceledat) over (partition by customerid) as canceledat,
                        MIN(createdat) over (partition by customerid) as createdat
                    FROM dataplatform-prd.mundi_mark1db.subscription
                ) AS billingv2_subscription ON billingv2_subscription.CUSTOMERID = billingv2_customer.ID
                LEFT JOIN dataplatform-prd.mundi_mark1db.account  AS billingv2_account ON billingv2_subscription.ACCOUNTID = billingv2_account.ID
                LEFT JOIN dataplatform-prd.mundi_mark1db.merchant  AS billingv2_merchant ON billingv2_account.MERCHANTID = billingv2_merchant.ID
                LEFT JOIN (--alguns clientes possuem mais de uma customerkey cadastrada no SF, por isso faço o max.
                    SELECT
                        fromopportunity__c as OpportunityId
                        , MAX(affiliationid__c) as CustomerKey
                        , customerservicekey__c as BillingKey
                    FROM dataplatform-prd.sop_salesforce.account
                    WHERE customerservicekey__c is not null
                    GROUP BY 1,3
                ) as account on account.BillingKey = billingv2_customer.externalid
                LEFT JOIN (--Dado o fluxo implementado em 2017.2, quem fecha a oportunidade é o vendedor e a data de fechamento é o kickoff
                    SELECT
                        o.id as OpportunityId,
                        o.closedate as WonDate,
                        u.id as VendorId,
                        u.name as VendorName,
                        u.email as VendorEmail
                    FROM dataplatform-prd.sop_salesforce.opportunity o
                    LEFT JOIN dataplatform-prd.sop_salesforce.user u on o.ownerid = u.id
                ) as opportunity on opportunity.opportunityid = account.opportunityid
                LEFT JOIN dataplatform-prd.mundi_billingdb.customer bc on bc.customerkey=account.customerkey
                LEFT JOIN dataplatform-prd.mundi_billingdb.salesperson sp on sp.salespersonid = bc.salespersonid
                WHERE
                    billingv2_merchant.NAME = 'Billing Service' 
                    AND billingv2_account.PUBLICKEY = 'pk_PBWZ3dVHbIBbjOJL'
                    AND account.customerkey is not null
            )

            select * from billingv2
            UNION DISTINCT
            select * from billingv1 where not exists (select 1 from billingv2 where upper(billingv2.customerkey) = upper(billingv1.customerkey) limit 1)
        """,
    )

    clean = MsSqlOperatorPYODBC(
        task_id="clean_mundi_clients",
        mssql_conn_id="bw_azure",
        database="StoneCoODS",
        sql="""
           TRUNCATE TABLE mundi.tbmundid_client
        """,
    )

    load = GCSToMssqlExtractOperator(
        task_id="load_mundi_clients",
        database="StoneCoODS",
        dest_schema="mundi",
        table_name="tbmundid_client",
        source_file=f"airflow-files/_legacy/mundi_ods/clients_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

extract >> clean >> load
