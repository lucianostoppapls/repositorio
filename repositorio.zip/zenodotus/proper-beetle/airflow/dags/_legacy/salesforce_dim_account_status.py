from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args, transfer_tasks


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_account_status",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 10, 0),
    default_args=default_args,
)

transfer_tasks(
    dag=dag,
    repo_name="salesforce",
    table="DimAccountStatus",
    database="StoneDWv0",
    column_types={
        "[AccountStatusKey]": "[nvarchar](18) NOT NULL",
        "[OwnerKey]": "[varchar](18) NULL",
        "[IsDeleted]": "[bit] NULL",
        "[Name]": "[nvarchar](80) NOT NULL",
        "[CreatedDate]": "[varchar](8) NOT NULL",
        "[CreatedById]": "[nvarchar](18) NOT NULL",
        "[LastModifiedDate]": "[varchar](8) NOT NULL",
        "[AccountKey]": "[nvarchar](18) NOT NULL",
        "[Type]": "[nvarchar](255) NOT NULL",
        "[ClientAlternateKey]": "[nvarchar](2000) NOT NULL",
    },
    prod_schema="dbo",
    date_column="LastUpdatedAt",
)
