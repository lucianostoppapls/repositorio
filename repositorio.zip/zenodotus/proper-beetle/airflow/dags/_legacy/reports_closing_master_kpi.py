from mssql_utils import MsSqlOperatorPYODBC
from redshift_utils import RedshiftToMSSQLOperator
from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python_operator import ShortCircuitOperator
from date import get_business_day
from plugins.gcp_utils import BigqueryToGCSOperator
from mssql_utils import GCSToMssqlExtractOperator
from airflow import configuration as conf
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts

dag = DAG(
    dag_id="_legacy__reports_closing_master_kpi",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 0, 0),
    default_args={
        "autocommit": True,
        "retries": 4,
        "retry_delay": timedelta(minutes=15),
        "google_cloud_storage_conn_id": "gcp_mis",
        "mssql_conn_id": "bw_azure",
        "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
        "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
        "on_failure_callback": PagerDutyAlerts.failure_incident,
        "on_success_callback": PagerDutyAlerts.resolve_incident,
    },
)

ds = "{{ds}}"
with dag:
    is_4th_business_day = ShortCircuitOperator(
        task_id="is_4th_business_day",
        provide_context=True,
        python_callable=lambda *args, **kwargs: kwargs["ds"]
        == get_business_day(4).strftime("%Y-%m-%d"),
    )

    clean = MsSqlOperatorPYODBC(
        task_id="clean",
        database="StoneDwv0",
        sql=f"DELETE FROM kpi.ClosingMasterKPI WHERE execution_date = '{ds}'",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv = MsSqlOperatorPYODBC(
        task_id="tpv",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/tpv.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv_adquirentes = MsSqlOperatorPYODBC(
        task_id="tpv_adquirentes",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/tpv_adquirentes.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv_top10Client = MsSqlOperatorPYODBC(
        task_id="tpv_top10Client",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/tpv_top10Client.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )
    tpv_receita = MsSqlOperatorPYODBC(
        task_id="tpv_receita",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/tpv_receita.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    smr_base_ativa_adquirencia = MsSqlOperatorPYODBC(
        task_id="smr_base_ativa_adquirencia",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/smr_base_ativa_adquirencia.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv_top10Market = MsSqlOperatorPYODBC(
        task_id="tpv_top10Market",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/tpv_top10Market.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv_receita_mkt_pagarm = MsSqlOperatorPYODBC(
        task_id="tpv_receita_mkt_pagarm",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/tpv_receita_mkt_pagarm.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv_Base_ativa_Payments = MsSqlOperatorPYODBC(
        task_id="tpv_Base_ativa_Payments",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/tpv_Base_ativa_Payments.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv_Base_Ativa_Hubs_Rollng30 = MsSqlOperatorPYODBC(
        task_id="tpv_Base_Ativa_Hubs_Rollng30",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/tpv_Base_Ativa_Hubs_Rollng30.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    tpv_smr_safra_m1 = MsSqlOperatorPYODBC(
        task_id="tpv_smr_safra_m1",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/tpv_smr_safra_m1.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    rav = MsSqlOperatorPYODBC(
        task_id="rav",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/rav.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    rav_pagarme_cdi = MsSqlOperatorPYODBC(
        task_id="rav_pagarme_cdi",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/rav_pagarme_cdi.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    rav_credenciamento = MsSqlOperatorPYODBC(
        task_id="rav_credenciamento",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/rav_credenciamento.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    rental = MsSqlOperatorPYODBC(
        task_id="rental",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/rental.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    rental_credenciamento = MsSqlOperatorPYODBC(
        task_id="rental_credenciamento",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/rental_credenciamento.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    novos_ativos = MsSqlOperatorPYODBC(
        task_id="novos_ativos",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/novos_ativos.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    rav_duration_smb = MsSqlOperatorPYODBC(
        task_id="rav_duration_smb",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/rav_duration_smb.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    other_revenues = MsSqlOperatorPYODBC(
        task_id="other_revenues",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/other_revenues.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    other_kpis = MsSqlOperatorPYODBC(
        task_id="other_kpis",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/other_kpis.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    other_kpis_remaining = MsSqlOperatorPYODBC(
        task_id="other_kpis_remaining",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/other_kpis_remaining.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    active_base_90d = MsSqlOperatorPYODBC(
        task_id="active_base_90d",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/active_base_90d.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    kpi_4020_4021_4022 = MsSqlOperatorPYODBC(
        task_id="kpi_4020_4021_4022",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/kpi_4020_4021_4022.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    kpi_4017_x = MsSqlOperatorPYODBC(
        task_id="kpi_4017_x",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/kpi_4017_x.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    extract_total_investimento_4115 = BigqueryToGCSOperator(
        task_id="extract_total_investimento_4115",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/closing_master_kpi/total_investimento_4115_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="/reports/closing_master_kpi/extract_smr_4115_smb_total_investimento.sql",
    )

    extract_cpa_4013 = BigqueryToGCSOperator(
        task_id="extract_cpa_4013",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/closing_master_kpi/cpa_4013_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="/reports/closing_master_kpi/extract_smr_4013_smb_cpa.sql",
    )

    extract_kpi_4096_1 = BigqueryToGCSOperator(
        task_id="extract_kpi_4096_1",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/closing_master_kpi/kpi_4096_1_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="/reports/closing_master_kpi/extract_kpi_4096_1.sql",
    )

    extract_smr_4518_1_pagarme_tpv_pix_dinamico_total = BigqueryToGCSOperator(
        task_id="extract_smr_4518_1_pagarme_tpv_pix_dinamico_total",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/closing_master_kpi/extract_smr_4518_1_pagarme_tpv_pix_dinamico_total_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="/reports/closing_master_kpi/extract_smr_4518_1_pagarme_tpv_pix_dinamico_total.sql",
    )

    extract_pagarme_fact_base_ativa_4507 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_base_ativa_4507",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_base_ativa_4507.sql",
        mssql_temp_table_prefix="pagarme_fact_base_ativa_4507_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_base_ativa_4505 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_base_ativa_4505",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_base_ativa_4505.sql",
        mssql_temp_table_prefix="pagarme_fact_base_ativa_4505_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_tpv_4528 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_tpv_4528",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_tpv_4528.sql",
        mssql_temp_table_prefix="pagarme_fact_tpv_4528_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_credenciamento_4506 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_credenciamento_4506",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_credenciamento_4506.sql",
        mssql_temp_table_prefix="pagarme_fact_credenciamento_4506_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_card_transactions_and_retries_4519 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_card_transactions_and_retries_4519",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_card_transactions_and_retries_4519.sql",
        mssql_temp_table_prefix="pagarme_fact_card_transactions_and_retries_4519_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_base_ativa_4529 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_base_ativa_4529",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_base_ativa_4529.sql",
        mssql_temp_table_prefix="pagarme_fact_base_ativa_4529_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_base_ativa_4543 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_base_ativa_4543",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_base_ativa_4543.sql",
        mssql_temp_table_prefix="pagarme_fact_base_ativa_4543_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_tpv_4551 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_tpv_4551",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_tpv_4551.sql",
        mssql_temp_table_prefix="pagarme_fact_tpv_4551_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_credenciamento_4559 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_credenciamento_4559",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_credenciamento_4559.sql",
        mssql_temp_table_prefix="pagarme_fact_credenciamento_4559_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_base_ativa_4585_1 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_base_ativa_4585_1",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_base_ativa_4585.1.sql",
        mssql_temp_table_prefix="pagarme_fact_base_ativa_4585_1_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_tpv_4621 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_tpv_4621",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_tpv_4621.sql",
        mssql_temp_table_prefix="extract_pagarme_fact_tpv_4621_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_tpv_4634_1 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_tpv_4634_1",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_tpv_4634_1.sql",
        mssql_temp_table_prefix="extract_pagarme_fact_tpv_4634_1_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_tpv_4532 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_tpv_4532",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_tpv_4532.sql",
        mssql_temp_table_prefix="extract_pagarme_fact_tpv_4532_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_tpv_4558_2 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_tpv_4558_2",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_tpv_4558.2.sql",
        mssql_temp_table_prefix="pagarme_fact_tpv_4585_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_tpv_4558_1 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_tpv_4558_1",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_tpv_4558.1.sql",
        mssql_temp_table_prefix="pagarme_fact_tpv_4585_1_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_base_ativa_4589 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_base_ativa_4589",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_base_ativa_4589.sql",
        mssql_temp_table_prefix="pagarme_fact_base_ativa_4589_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_fact_base_ativa_4590 = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_fact_base_ativa_4590",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_fact_base_ativa_4590.sql",
        mssql_temp_table_prefix="pagarme_fact_base_ativa_4590_",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    load_total_investimento_4115 = GCSToMssqlExtractOperator(
        task_id="load_total_investimento_4115",
        database="StoneDwv0",
        dest_schema="kpi",
        table_name="ClosingMasterKPI",
        source_file=f"airflow-files/_legacy/closing_master_kpi/total_investimento_4115_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

    load_cpa_4013 = GCSToMssqlExtractOperator(
        task_id="load_cpa_4013",
        database="StoneDwv0",
        dest_schema="kpi",
        table_name="ClosingMasterKPI",
        source_file=f"airflow-files/_legacy/closing_master_kpi/cpa_4013_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

    load_kpi_4096_1 = GCSToMssqlExtractOperator(
        task_id="load_kpi_4096_1",
        database="StoneDwv0",
        dest_schema="kpi",
        table_name="ClosingMasterKPI",
        source_file=f"airflow-files/_legacy/closing_master_kpi/kpi_4096_1_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

    load_smr_4518_1_pagarme_tpv_pix_dinamico_total = GCSToMssqlExtractOperator(
        task_id="load_smr_4518_1_pagarme_tpv_pix_dinamico_total",
        database="StoneDwv0",
        dest_schema="kpi",
        table_name="ClosingMasterKPI",
        source_file=f"airflow-files/_legacy/closing_master_kpi/extract_smr_4518_1_pagarme_tpv_pix_dinamico_total_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

    load_pagarme_fact_base_ativa_4507 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_base_ativa_4507",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_base_ativa_4507.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_base_ativa_4505 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_base_ativa_4505",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_base_ativa_4505.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_tpv_4528 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_base_fact_tpv_4528",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_tpv_4528.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_credenciamento_4506 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_base_fact_credenciamento_4506",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_credenciamento_4506.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_card_transactions_and_retries_4519 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_card_transactions_and_retries_4519",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_card_transactions_and_retries_4519.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_base_ativa_4529 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_base_ativa_4529",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_base_ativa_4529.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_base_ativa_4529_1 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_base_ativa_4529_1",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_base_ativa_4529.1.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_base_ativa_4543 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_base_ativa_4543",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_base_ativa_4543.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_tpv_4551 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_tpv_4551",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_tpv_4551.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    top_clients_4554 = MsSqlOperatorPYODBC(
        task_id="top_clients_4554",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/top_clients_4554.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_credenciamento_4559 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_credenciamento_4559",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_credenciamento_4559.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_base_ativa_4585_1 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_base_ativa_4585_1",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_base_ativa_4585.1.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_tpv_4634_1 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_tpv_4634_1",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_tpv_4634_1.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_tpv_4558_2 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_tpv_4558_2",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_tpv_4558.2.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_tpv_4558_1 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_tpv_4558_1",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_tpv_4558.1.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_tpv_4532 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_tpv_4532",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_tpv_4532.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_tpv_4621 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_tpv_4621",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_tpv_4621.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_base_ativa_4589 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_base_ativa_4589",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_base_ativa_4589.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    load_pagarme_fact_base_ativa_4590 = MsSqlOperatorPYODBC(
        task_id="load_pagarme_fact_base_ativa_4590",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/load_pagarme_fact_base_ativa_4590.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    extract_ton_active_base_90d = RedshiftToMSSQLOperator(
        task_id="extract_ton_active_base_90d",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_ton_active_base_90d.sql",
        mssql_temp_table_prefix="ton_ba",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    extract_pagarme_active_base_90d = RedshiftToMSSQLOperator(
        task_id="extract_pagarme_active_base_90d",
        mssql_conn_id="bw_azure",
        redshift_conn_id="datarock",
        sql="/reports/closing_master_kpi/extract_pagarme_active_base_90d.sql",
        mssql_temp_table_prefix="pagarme_ba",
        mssql_temp_table_schema="airflow_staging",
        mssql_temp_table_database="StoneDWv0",
    )

    consolidate_ton_active_base_90d = MsSqlOperatorPYODBC(
        task_id="consolidate_ton_active_base_90d",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/ton_active_base_90d.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    consolidate_pagarme_active_base_90d = MsSqlOperatorPYODBC(
        task_id="consolidate_pagarme_active_base_90d",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/pagarme_active_base_90d.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    smr_novos_ativos = MsSqlOperatorPYODBC(
        task_id="smr_novos_ativos",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/smr_novos_ativos.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    smr_tpv_antecipado = MsSqlOperatorPYODBC(
        task_id="smr_tpv_antecipado",
        database="StoneDwv0",
        sql="/reports/closing_master_kpi/smr_tpv_antecipado.sql",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    drop_ton_temp_table = MsSqlOperatorPYODBC(
        task_id="drop_ton_temp_table",
        database="StoneDwv0",
        sql="DROP TABLE {{ ti.xcom_pull('extract_ton_active_base_90d') }};",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    drop_pagarme_temp_table = MsSqlOperatorPYODBC(
        task_id="drop_pagarme_temp_table",
        database="StoneDwv0",
        sql="DROP TABLE {{ ti.xcom_pull('extract_pagarme_active_base_90d') }};",
        mssql_conn_id="bw_azure",
        pool="bw_azure",
    )

    (
        is_4th_business_day
        >> clean
        >> tpv
        >> tpv_adquirentes
        >> tpv_smr_safra_m1
        >> rav
        >> rav_credenciamento
        >> rav_pagarme_cdi
        >> rental
        >> rental_credenciamento
        >> smr_novos_ativos
        >> smr_base_ativa_adquirencia
        >> novos_ativos
        >> smr_tpv_antecipado
        >> rav_duration_smb
        >> top_clients_4554
        >> other_revenues
        >> other_kpis
        >> other_kpis_remaining
        >> active_base_90d
        >> tpv_top10Client
        >> tpv_top10Market
        >> tpv_receita
        >> tpv_receita_mkt_pagarm
        >> extract_cpa_4013
        >> load_cpa_4013
        >> extract_total_investimento_4115
        >> load_total_investimento_4115
        >> tpv_Base_Ativa_Hubs_Rollng30
        >> tpv_Base_ativa_Payments
        >> kpi_4020_4021_4022
        >> extract_kpi_4096_1
        >> load_kpi_4096_1
        >> kpi_4017_x
    )

    (
        is_4th_business_day
        >> clean
        >> extract_smr_4518_1_pagarme_tpv_pix_dinamico_total
        >> load_smr_4518_1_pagarme_tpv_pix_dinamico_total
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_tpv_4532
        >> load_pagarme_fact_tpv_4532
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_tpv_4634_1
        >> load_pagarme_fact_tpv_4634_1
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_tpv_4621
        >> load_pagarme_fact_tpv_4621
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_base_ativa_4507
        >> load_pagarme_fact_base_ativa_4507
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_base_ativa_4505
        >> load_pagarme_fact_base_ativa_4505
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_tpv_4528
        >> load_pagarme_fact_tpv_4528
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_credenciamento_4506
        >> load_pagarme_fact_credenciamento_4506
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_card_transactions_and_retries_4519
        >> load_pagarme_fact_card_transactions_and_retries_4519
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_base_ativa_4529
        >> [load_pagarme_fact_base_ativa_4529, load_pagarme_fact_base_ativa_4529_1]
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_base_ativa_4543
        >> load_pagarme_fact_base_ativa_4543
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_base_ativa_4585_1
        >> load_pagarme_fact_base_ativa_4585_1
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_tpv_4558_2
        >> load_pagarme_fact_tpv_4558_2
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_tpv_4558_1
        >> load_pagarme_fact_tpv_4558_1
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_base_ativa_4589
        >> load_pagarme_fact_base_ativa_4589
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_base_ativa_4590
        >> load_pagarme_fact_base_ativa_4590
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_tpv_4551
        >> load_pagarme_fact_tpv_4551
    )

    (
        is_4th_business_day
        >> clean
        >> extract_pagarme_fact_credenciamento_4559
        >> load_pagarme_fact_credenciamento_4559
    )

    (
        is_4th_business_day
        >> [
            extract_ton_active_base_90d,
            extract_pagarme_active_base_90d,
        ]
        >> consolidate_ton_active_base_90d
        >> consolidate_pagarme_active_base_90d
        >> [
            drop_ton_temp_table,
            drop_pagarme_temp_table,
        ]
    )
