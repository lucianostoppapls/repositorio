from airflow import DAG
from _legacy.airflow_utils import make_backfill_dags, with_dags
from _legacy.logistic_extract import default_args, transfer_tasks_upsert
from datetime import datetime, timedelta

recents, backfill = make_backfill_dags(
    task_id="_legacy__logistic_extract_terminal_stock",
    version=2,
    recents_start_date=datetime(2020, 4, 26, 3, 20),
    backfill_expected_start_date=datetime(2014, 1, 1),
    recents_schedule_interval=timedelta(days=1),
    dag_factory=lambda **kwargs: DAG(**kwargs),
    default_args=default_args,
)

for dag in with_dags(recents, backfill):
    transfer_tasks_upsert(
        dag=dag,
        table="tbstonef_parque",
        dest_schema="stone",
        database="StoneCoODS",
        column_types={
            "serial_number": "[nvarchar](100) NOT NULL",
            "model": "[nvarchar](100) NULL",
            "type": "[nvarchar](100) NULL",
            "status": "[nvarchar](300) NULL",
            "logistic_operator": "[nvarchar](300) NULL",
            "provider": "[nvarchar](500) NULL",
            "modification_date": "DATE NULL",
            "contractor": "[nvarchar](300) NULL",
            "customer": "[nvarchar](100) NULL",
        },
        date_column="modification_date",
    )
