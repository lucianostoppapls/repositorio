from datetime import datetime, timedelta
from airflow import DAG
from _legacy.airflow_utils import make_backfill_dags, with_dags
from _legacy.pagarminho import default_args, inject_tasks


recents, backfill = make_backfill_dags(
    task_id="_legacy__pagarminho_anticipations",
    version=5,
    recents_start_date=datetime(2021, 7, 8, 6, 0),
    backfill_expected_start_date=datetime(2014, 1, 1, 8, 0),
    recents_schedule_interval=timedelta(days=1),
    backfill_schedule_interval=timedelta(days=40),
    dag_factory=lambda **kwargs: DAG(**kwargs),
    default_args=default_args,
    max_active_runs=1,
)

for dag in with_dags(recents, backfill):
    inject_tasks(
        dag=dag,
        etl_name="anticipations",
        looker_tables=[],
        source_sql="pagarminho/anticipations.sql",
        gcs_file="airflow-files/_legacy/pagarminho/{{ ds }}-anticipations.csv",
        dest_database="StoneCoODS",
        dest_schema="pagarme",
        dest_table="anticipation",
        date_column="payment_date",
    )
