from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args, transfer_tasks


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_flag_status_v2",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 6, 0),
    default_args=default_args,
)

transfer_tasks(
    dag=dag,
    repo_name="salesforce",
    table="DimFlagStatus",
    database="StoneDWv0",
    prod_schema="dbo",
    column_types={
        "[FlagStatusKey]": "[nvarchar](18) NOT NULL",
        "[Flag]": "[nvarchar](100) NULL",
        "[StatusDate]": "[varchar](8) NULL",
        "[IsDeleted]": "[bit] NULL",
        "[LastModifiedDate]": "[varchar](8) NULL",
        "[LastViewedDate]": "[varchar](8) NULL",
        "[Status]": "[nvarchar](100) NULL",
        "[Name]": "[nvarchar](80) NULL",
        "[ClientAlternateKey]": "[nvarchar](20) NULL",
    },
    date_column="LastUpdatedAt",
)
