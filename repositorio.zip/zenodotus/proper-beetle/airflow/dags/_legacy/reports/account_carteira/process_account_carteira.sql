TRUNCATE TABLE StoneDWv0.kpi.AccountCarteiraReport;

INSERT INTO StoneDWv0.kpi.AccountCarteiraReport

SELECT
	 A.Id
	,CASE WHEN C.CompanyKey IN (1,2) THEN C.ClientAlternateKey ELSE NULL END AS Stonecode__c
	,CAST(S.SalesStructureNameLevel1 AS VARCHAR(50)) AS Canal__c
	,CAST(S.SalesStructureNameLevel2 AS VARCHAR(50)) AS SubCanal__c
	,CAST(S.SalesStructureNameLevel3 AS VARCHAR(50)) AS Grupo1__c
	,CAST(S.SalesStructureNameLevel4 AS VARCHAR(50)) AS Grupo2__c
	,CAST(S.SalesStructureNameLevel5 AS VARCHAR(50)) AS Grupo3__c
	,CAST(CASE WHEN COALESCE(V2.EmailAddress,V.EmailAddress,'') NOT LIKE '%_@__%.__%' THEN '' ELSE COALESCE(V2.EmailAddress,V.EmailAddress,'') END AS VARCHAR(50)) AS Email_Owner_Carteira__c
	,CAST(
			CASE
				WHEN TPV.TPVLast7 <> 0 AND TPV.TPV8_14 = 0 THEN 'Transações Intermitentes'
				WHEN ISNULL(TPV.TPVLAST7/NULLIF(TPV.TPV8_14,0)-1,0) <=-0.5  THEN 'Queda Maior que 50%'
				WHEN ISNULL(TPV.TPVLAST7/NULLIF(TPV.TPV8_14,0)-1,0) <=-0.2  THEN 'Queda ente 20% e 50%'
				WHEN ISNULL(TPV.TPVLAST7/NULLIF(TPV.TPV8_14,0)-1,0) <0  THEN 'Queda menor que 20%'
				WHEN ISNULL(TPV.TPVLAST7/NULLIF(TPV.TPV8_14,0)-1,0) >=0.5  THEN 'Aumento Maior que 50%'
				WHEN ISNULL(TPV.TPVLAST7/NULLIF(TPV.TPV8_14,0)-1,0) >=0.2  THEN 'Aumento ente 20% e 50%'
				WHEN ISNULL(TPV.TPVLAST7/NULLIF(TPV.TPV8_14,0)-1,0) >0 THEN 'Aumento menor que 20%'
				WHEN ISNULL(TPV.TPVLAST7/NULLIF(TPV.TPV8_14,0),0) = 1 THEN 'Volume mantido'
				ELSE 'Churn/Inativo'
			END
	 AS VARCHAR(50)) AS farol__c,
	 CAST(
		 ISNULL(C.PartnerName
			, '')
	 AS VARCHAR(50))AS Parceiro__c
	 ,CASE WHEN C.CompanyKey IN (3) THEN C.ClientAlternateKey ELSE NULL END AS [Affiliation_Id__c]
	 ,CASE WHEN C.CompanyKey IN (5) THEN C.ClientAlternateKey ELSE NULL END AS [Customer_Id__c]
	 ,c.ClientName as Nome__c
FROM StoneDWv0.dbo.[DimAffiliation] C 
LEFT JOIN {{ ti.xcom_pull('create_account_carteira_table') }} A ON COALESCE(A.Stonecode__c,A.[Affiliation_Id__c],A.[Customer_Id__c]) = C.ClientAlternateKey
LEFT JOIN StoneDWv0.dbo.DimSalesStructure S ON C.SalesStructureKey = S.SalesStructureKey
LEFT JOIN StoneDWv0.dbo.DimVendor V 
	   ON       V.VendorKey = C.VendorKey
LEFT JOIN StoneDWv0.dbo.DimVendor V2 
	   ON       V2.VendorName = S.SalesStructureNameLevel4
			and S.SalesStructureNameLevel2 in ('Large','Very Large')
			and V2.EmailAddress is not null
LEFT JOIN (
	   SELECT
			 T.[AffiliationKey],
			 SUM(CASE WHEN TransactionDate BETWEEN CONVERT (INT, CONVERT(CHAR(8),CAST(GETDATE()-7 AS DATE),112)) AND CONVERT (INT, CONVERT(CHAR(8),CAST(GETDATE()-1 AS DATE),112)) THEN TPV ELSE 0 END) AS TPVLast7,
			 SUM(CASE WHEN TransactionDate BETWEEN CONVERT (INT, CONVERT(CHAR(8),CAST(GETDATE()-14 AS DATE),112)) AND CONVERT (INT, CONVERT(CHAR(8),CAST(GETDATE()-8 AS DATE),112)) THEN TPV ELSE 0 END) AS TPV8_14
	   FROM StoneDWv0.dbo.FactTPV t 
	   WHERE TransactionDate >= CONVERT (INT, CONVERT(CHAR(8),CAST(GETDATE()-14 AS DATE),112))
		 AND TransactionDate < CONVERT (INT, CONVERT(CHAR(8),CAST(GETDATE() AS DATE),112))
	   GROUP BY T.[AffiliationKey]
) TPV
	   ON C.[AffiliationKey] = TPV.[AffiliationKey]
WHERE C.ClientAlternateKey IS NOT NULL AND C.ClientCNPJorCPF IS NOT NULL AND C.ClientCNPJorCPF<>'0' AND C.COMPANYKEY IN (1,2,3,4,5);
