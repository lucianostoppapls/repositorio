SELECT  Stonecode__c,
        Canal__c,
        SubCanal__c,
        Grupo1__c,
        Grupo2__c,
        Grupo3__c,
        Email_Owner_Carteira__c,
        farol__c,
        Parceiro__c,
        Affiliation_Id__c,
        Customer_Id__c,
        Nome__c
FROM StoneDWv0.kpi.AccountCarteiraReport
WHERE Id IS NULL
