SELECT  a.Id,
        a.Stonecode__c,
        a.Canal__c,
        a.SubCanal__c,
        a.Grupo1__c,
        a.Grupo2__c,
        a.Grupo3__c,
        a.Email_Owner_Carteira__c,
        a.farol__c,
        a.Parceiro__c,
        a.Affiliation_Id__c,
        a.Customer_Id__c,
        a.Nome__c
FROM StoneDWv0.kpi.AccountCarteiraRepORt a
JOIN {{ ti.xcom_pull('create_account_carteira_table') }} b ON a.Id = b.Id
WHERE (
        COALESCE(a.Stonecode__c,'') <> COALESCE(b.Stonecode__c,'') OR
        COALESCE(a.Canal__c,'') <> COALESCE(b.Canal__c,'') OR
        COALESCE(a.SubCanal__c,'') <> COALESCE(b.SubCanal__c,'') OR
        COALESCE(a.Grupo1__c,'') <> COALESCE(b.Grupo1__c,'') OR
        COALESCE(a.Grupo2__c,'') <> COALESCE(b.Grupo2__c,'') OR
        COALESCE(a.Grupo3__c,'') <> COALESCE(b.Grupo3__c,'') OR
        COALESCE(a.Email_Owner_Carteira__c,'') <> COALESCE(b.Email_Owner_Carteira__c,'') OR
        COALESCE(a.farol__c,'') <> COALESCE(b.farol__c,'') OR
        COALESCE(a.Parceiro__c,'') <> COALESCE(b.Parceiro__c,'') OR
        COALESCE(a.Affiliation_Id__c,'') <> COALESCE(b.Affiliation_Id__c,'') OR
        COALESCE(a.Customer_Id__c,'') <> COALESCE(b.Customer_Id__c,'') OR
        COALESCE(a.Nome__c,'') <> COALESCE(b.Nome__c,'')
)
AND a.Id IS NOT NULL
