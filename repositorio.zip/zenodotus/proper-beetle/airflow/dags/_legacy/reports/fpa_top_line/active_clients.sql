delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'Active Clients';

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select  eomonth('{{ ds }}') reference_date,
			null breakdown,
			'Active Clients' kpi,
			count(distinct ClientCNPJorCPF) value
	from StoneDWv0.dbo.DimAffiliation  affiliation
	join StoneDWv0.dbo.FactTPV  tpv on affiliation.AffiliationKey = tpv.AffiliationKey
	join StoneDWv0.dbo.DimDate  dt on tpv.TransactionDate = dt.DateKey
	join StoneDWv0.dbo.DimType  tp on tpv.TypeKey = tp.TypeKey
	where dt.FullDate between dateadd(day,-89,eomonth('{{ ds }}')) and eomonth('{{ ds }}')
			and tp.typename = 'capturado'
			and affiliation.CompanyKey in (1,2)
	having sum(tpv.Transactions) >= 1
