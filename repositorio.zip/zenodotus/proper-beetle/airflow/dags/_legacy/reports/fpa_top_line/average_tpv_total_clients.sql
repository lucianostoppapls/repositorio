delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'Average TPV of Total Clients';

select distinct ClientCNPJorCPF
into #total_clients
from StoneDWv0.dbo.DimAffiliation affiliation
join StoneDWv0.dbo.FactTPV tpv on affiliation.AffiliationKey = tpv.AffiliationKey
join StoneDWv0.dbo.DimDate dt on tpv.TransactionDate = dt.DateKey
join StoneDWv0.dbo.DimType tp on tpv.TypeKey = tp.TypeKey
where eomonth(dt.FullDate) between dateadd(day,-89,eomonth('{{ ds }}')) and eomonth('{{ ds }}')
		and tp.typename = 'capturado'
		and affiliation.CompanyKey in (1,2)
group by ClientCNPJorCPF
having sum(tpv.Transactions) >= 1


select case when fulldate between dateadd(day,-29,eomonth('{{ ds }}')) and eomonth('{{ ds }}') then 1
                    when fulldate between dateadd(day,-59,eomonth('{{ ds }}')) and dateadd(day,-30,eomonth('{{ ds }}')) then 2
                    when fulldate between dateadd(day,-89,eomonth('{{ ds }}')) and dateadd(day,-60,eomonth('{{ ds }}')) then 3
                    else 4 end as classification,
        #total_clients.ClientCNPJorCPF,
        sum(tpv) as tpv
        into #partitioned_tpv
from StoneDWv0.dbo.VwFactProcessedTPV  tpv
left join StoneDWv0.dbo.DimAffiliation  affiliation on tpv.affiliationkey = affiliation.AffiliationKey
left join StoneDWv0.dbo.DimDate  dt on dt.datekey = tpv.transactiondate
join #total_clients on affiliation.ClientCNPJorCPF = #total_clients.ClientCNPJorCPF
where tpv.CompanyKey in (1,2)
        and fulldate between dateadd(day,-89,eomonth('{{ ds }}')) and eomonth('{{ ds }}')
group by case when fulldate between dateadd(day,-29,eomonth('{{ ds }}')) and eomonth('{{ ds }}') then 1
                    when fulldate between dateadd(day,-59,eomonth('{{ ds }}')) and dateadd(day,-30,eomonth('{{ ds }}')) then 2
                    when fulldate between dateadd(day,-89,eomonth('{{ ds }}')) and dateadd(day,-60,eomonth('{{ ds }}')) then 3
                    else 4 end,
        #total_clients.ClientCNPJorCPF

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select eomonth('{{ ds }}') as reference_date,
			null as breakdown,
			'Average TPV of Total Clients' as kpi,
			sum(partitioned_tpv.tpv)/cast(count(distinct partitioned_tpv.ClientCNPJorCPF) as float) as value
    from (
        select ClientCNPJorCPF,
                avg(tpv) tpv
        from #partitioned_tpv
        group by ClientCNPJorCPF
    ) partitioned_tpv
