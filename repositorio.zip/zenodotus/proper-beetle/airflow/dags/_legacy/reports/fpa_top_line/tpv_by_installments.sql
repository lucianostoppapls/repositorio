delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'Breakdown of TPV between up to 30 days term and more than 30 days';

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select eomonth('{{ ds }}') as reference_date,
			case when installment.Installmentname = 'debito' then 'TPV up to 30 days'
				when installment.Installmentname in ('credito a vista','credito lojista 2-6','credito admnistradora 2-6','credito administradora 7-12') 
				then 'TPV 1-6 installments'
				when installment.Installmentname in ('credito lojista 7-12','credito lojista > 12','credito administradora 7-12','credito administradora > 12')
				then 'TPV > 7 installments'
				else 'Others' end,
			'Breakdown of TPV between up to 30 days term and more than 30 days' kpi,
			sum(tpv) as tpv
	from StoneDWv0.dbo.VwFactProcessedTPV  tpv
	left join StoneDWv0.dbo.DimInstallment  installment on tpv.installmentkey = installment.installmentkey
	left join StoneDWv0.dbo.DimDate  dt on tpv.TransactionDate = dt.DateKey
	where eomonth(fulldate) = eomonth('{{ ds }}')
	group by case when installment.Installmentname = 'debito' then 'TPV up to 30 days'
				when installment.Installmentname in ('credito a vista','credito lojista 2-6','credito admnistradora 2-6','credito administradora 7-12') 
				then 'TPV 1-6 installments'
				when installment.Installmentname in ('credito lojista 7-12','credito lojista > 12','credito administradora 7-12','credito administradora > 12')
				then 'TPV > 7 installments'
				else 'Others' end;
