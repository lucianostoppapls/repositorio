delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'Revenue Retention Cohorts';

select ClientCNPJorCPF,
		cast(min(eomonth(fulldate)) as varchar(50)) as cred_date
		into #cred_date
from StoneDWv0.dbo.DimAffiliation  affiliation
join StoneDWv0.dbo.DimDate  dt on affiliation.CreateDate = dt.datekey
where companykey in (1,2)
group by ClientCNPJorCPF

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select eomonth('{{ ds }}') as reference_date,
			cred_date as breakdown,
			'Revenue Retention Cohorts' kpi,
			sum(TotalRevenue) as TotalRevenue
	from StoneDWv0.dbo.VwFactTotalRevenue  revenue
	left join StoneDWv0.dbo.DimDate  dt on revenue.DateKey = dt.DateKey
	left join StoneDWv0.dbo.DimAffiliation  affiliation on revenue.affiliationkey = affiliation.affiliationkey
	left join #cred_date cred_date on affiliation.ClientCNPJorCPF = cred_date.ClientCNPJorCPF
	where eomonth(fulldate) = eomonth('{{ ds }}')
			and affiliation.companykey in (1,2)
	group by cred_date;
