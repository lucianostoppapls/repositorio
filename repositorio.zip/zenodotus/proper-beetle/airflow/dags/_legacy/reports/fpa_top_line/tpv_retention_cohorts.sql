delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'TPV Retention Cohorts';

select ClientCNPJorCPF,
		cast(min(eomonth(fulldate)) as varchar(50)) as cred_date
		into #cred_date
from StoneDWv0.dbo.DimAffiliation  affiliation
join StoneDWv0.dbo.DimDate  dt on affiliation.CreateDate = dt.datekey
where affiliation.companykey in (1,2)
group by ClientCNPJorCPF

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select eomonth('{{ ds }}') as reference_date,
			cred_date as breakdown,
			'TPV Retention Cohorts' kpi,
			sum(tpv) as value
	from StoneDWv0.dbo.VwFactProcessedTPV  tpv
	left join StoneDWv0.dbo.DimDate  dt on tpv.TransactionDate = dt.DateKey
	left join StoneDWv0.dbo.DimAffiliation  affiliation on tpv.affiliationkey = affiliation.affiliationkey
	left join #cred_date cred_date on affiliation.ClientCNPJorCPF = cred_date.ClientCNPJorCPF
	where eomonth(fulldate) = eomonth('{{ ds }}')
	and affiliation.companykey in (1,2)
	and tpv.companykey in (1,2)
	group by cred_date;
