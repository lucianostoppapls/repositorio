delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'Churn TPV';

select  distinct ClientCNPJorCPF
    into #active_base_m1
from StoneDWv0.dbo.DimAffiliation  affiliation
join StoneDWv0.dbo.FactTPV  tpv on affiliation.AffiliationKey = tpv.AffiliationKey
join StoneDWv0.dbo.DimDate  dt on tpv.TransactionDate = dt.DateKey
join StoneDWv0.dbo.DimType  tp on tpv.TypeKey = tp.TypeKey
where dt.FullDate between dateadd(day,-179,eomonth('{{ ds }}')) and dateadd(day,-90,eomonth('{{ ds }}'))
		and tp.typename = 'capturado'
		and affiliation.CompanyKey in (1,2)
group by ClientCNPJorCPF
having sum(tpv.Transactions) >= 1

select  distinct ClientCNPJorCPF
    into #active_base_m0
from StoneDWv0.dbo.DimAffiliation  affiliation
join StoneDWv0.dbo.FactTPV  tpv on affiliation.AffiliationKey = tpv.AffiliationKey
join StoneDWv0.dbo.DimDate  dt on tpv.TransactionDate = dt.DateKey
join StoneDWv0.dbo.DimType  tp on tpv.TypeKey = tp.TypeKey
where dt.FullDate between dateadd(day,-89,eomonth('{{ ds }}')) and eomonth('{{ ds }}')
		and tp.typename = 'capturado'
		and affiliation.CompanyKey in (1,2)
group by ClientCNPJorCPF
having sum(tpv.Transactions) >= 1

select ClientCNPJorCPF
    into #churn_ec
from StoneDWv0.dbo.DimAffiliation  affiliation
where not exists (
    select top 1 1
    from #active_base_m0 where affiliation.ClientCNPJorCPF = #active_base_m0.ClientCNPJorCPF
)
and exists (
    select top 1 1
    from #active_base_m1 where affiliation.ClientCNPJorCPF = #active_base_m1.ClientCNPJorCPF
)
and affiliation.CompanyKey in (1,2)

select case when fulldate between dateadd(day,-119,eomonth('{{ ds }}')) and dateadd(day,-90,eomonth('{{ ds }}')) then 1
                    when fulldate between dateadd(day,-149,eomonth('{{ ds }}')) and dateadd(day,-120,eomonth('{{ ds }}')) then 2
                    when fulldate between dateadd(day,-179,eomonth('{{ ds }}')) and dateadd(day,-150,eomonth('{{ ds }}')) then 3
                    else 4 end as classification,
        #churn_ec.ClientCNPJorCPF,
        sum(tpv) as tpv
        into #partitioned_tpv
from StoneDWv0.dbo.VwFactProcessedTPV  tpv
left join StoneDWv0.dbo.DimAffiliation  affiliation on tpv.affiliationkey = affiliation.AffiliationKey
left join StoneDWv0.dbo.DimDate  dt on dt.datekey = tpv.transactiondate
join #churn_ec on affiliation.ClientCNPJorCPF = #churn_ec.ClientCNPJorCPF
where tpv.CompanyKey in (1,2)
        and fulldate between dateadd(day,-179,eomonth('{{ ds }}')) and dateadd(day,-90,eomonth('{{ ds }}'))
group by case when fulldate between dateadd(day,-119,eomonth('{{ ds }}')) and dateadd(day,-90,eomonth('{{ ds }}')) then 1
                    when fulldate between dateadd(day,-149,eomonth('{{ ds }}')) and dateadd(day,-120,eomonth('{{ ds }}')) then 2
                    when fulldate between dateadd(day,-179,eomonth('{{ ds }}')) and dateadd(day,-150,eomonth('{{ ds }}')) then 3
                    else 4 end,
        #churn_ec.ClientCNPJorCPF

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select eomonth('{{ ds }}') as reference_date,
			null as breakdown,
			'Churn TPV' as kpi,
			sum(partitioned_tpv.tpv) as value
    from (
        select ClientCNPJorCPF,
                avg(tpv) tpv
        from #partitioned_tpv
        group by ClientCNPJorCPF
    ) partitioned_tpv
