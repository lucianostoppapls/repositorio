delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'Average rent per POS and Pinpad Charged Terminal';

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select eomonth('{{ ds }}') reference_date,
			null as breakdown,
			'Average rent per POS and Pinpad Charged Terminal' kpi,
			sum(chargedrent)/sum(nullif(coalesce(totalpos,0) + coalesce(totalpinpad,0),0)) value
	from StoneDWv0.dbo.FactRental  rental
	left join StoneDWv0.dbo.DimDate  dt on rental.datekey = dt.datekey
	where eomonth(fulldate) = eomonth('{{ ds }}');
