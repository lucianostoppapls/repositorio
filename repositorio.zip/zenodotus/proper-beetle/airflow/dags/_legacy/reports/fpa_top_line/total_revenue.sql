delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'Total Revenue';

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select eomonth('{{ ds }}') as reference_date,
			null as breakdown,
			'Total Revenue' kpi,
			sum(TotalRevenue) as TotalRevenue
	from StoneDWv0.dbo.VwFactTotalRevenue  revenue
	left join StoneDWv0.dbo.DimDate  dt on revenue.DateKey = dt.DateKey
	left join StoneDWv0.dbo.DimAffiliation  affiliation on revenue.affiliationkey = affiliation.affiliationkey
	where eomonth(fulldate) = eomonth('{{ ds }}')
			and affiliation.clientkey <> 3626;
