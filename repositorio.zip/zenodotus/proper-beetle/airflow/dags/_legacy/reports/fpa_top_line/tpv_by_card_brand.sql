delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'Breakdown of TPV by Card Brand';

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select eomonth('{{ ds }}') as reference_date,
			flag.FlagName as breakdown,
			'Breakdown of TPV by Card Brand' kpi,
			sum(tpv) as tpv
	from StoneDWv0.dbo.VwFactProcessedTPV  tpv
	left join StoneDWv0.dbo.DimFlag  flag on tpv.FlagKey = flag.FlagKey
	left join StoneDWv0.dbo.DimDate  dt on tpv.TransactionDate = dt.DateKey
	where eomonth(fulldate) = eomonth('{{ ds }}')
    group by flag.FlagName;
