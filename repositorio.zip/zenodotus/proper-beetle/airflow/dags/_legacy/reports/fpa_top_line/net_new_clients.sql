delete from StoneDWv0.kpi.FPATopLineReport where eomonth(reference_date) = eomonth('{{ ds }}') and kpi = 'Net New Clients';

insert into StoneDWv0.kpi.FPATopLineReport (
	reference_date,
	breakdown,
	kpi,
	value
)
	select eomonth('{{ ds }}') reference_date,
			null breakdown,
			'Net New Clients' kpi,
			active_base_m0 - active_base_m1 as value
	from (
		select  count(distinct ClientCNPJorCPF) active_base_m0
		from StoneDWv0.dbo.DimAffiliation affiliation
		join StoneDWv0.dbo.FactTPV tpv on affiliation.AffiliationKey = tpv.AffiliationKey
		join StoneDWv0.dbo.DimDate dt on tpv.TransactionDate = dt.DateKey
		join StoneDWv0.dbo.DimType tp on tpv.TypeKey = tp.TypeKey
		where eomonth(dt.FullDate) between dateadd(day,-89,eomonth('{{ ds }}')) and eomonth('{{ ds }}')
				and tp.typename = 'capturado'
				and affiliation.CompanyKey in (1,2)
		having sum(tpv.Transactions) >= 1
	) active_base_m0
	cross join (
		select  count(distinct ClientCNPJorCPF) active_base_m1
		from StoneDWv0.dbo.DimAffiliation affiliation
		join StoneDWv0.dbo.FactTPV tpv on affiliation.AffiliationKey = tpv.AffiliationKey
		join StoneDWv0.dbo.DimDate dt on tpv.TransactionDate = dt.DateKey
		join StoneDWv0.dbo.DimType tp on tpv.TypeKey = tp.TypeKey
		where eomonth(dt.FullDate) between dateadd(day,-90,eomonth('{{ ds }}')) and dateadd(day,-179,eomonth('{{ ds }}'))
				and tp.typename = 'capturado'
				and affiliation.CompanyKey in (1,2)
		having sum(tpv.Transactions) >= 1
	) active_base_m1
