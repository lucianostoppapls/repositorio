SELECT ownerid,
        stonecode_cnpj,
        nome_fantasia,
        [data],
        cred_ati_apurado__c,
        cred_auto_apurado__c,
        rec_alu_apurado__c,
        rec_mdr_apurado__c,
        tpv_apurado__c,
        dt_ref,
        primeira_transacao
FROM StoneDWv0.kpi.VwHubVendorsClientsOfficialReport;
