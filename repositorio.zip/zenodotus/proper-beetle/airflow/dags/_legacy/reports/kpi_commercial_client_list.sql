DECLARE @dtbase DATE = '{{ds}}'

INSERT INTO StoneDWv0.kpi.CommercialClientList (
		cnpj_cpf
		,afiliacoes_consideradas
		,nome_fantasia
		,razao_social
		,canal
		,subcanal
		,grupo1
		,grupo2
		,grupo3
		,grupo4
		,status
		,vendedor
		,data_de_credenciamento
		,empresa
		,dias_sem_transacionar
		,ultima_transacao
		,cadastro_rav_do_cliente
		,tpv_m_0
		,tpv_m_1
		,tpv_m_1_td
		,tpv_m_0_cred
		,tpv_m_1_cred
		,tpv_m_1_td_cred
		,net_mdr_m_0
		,net_mdr_m_1
		,net_mdr_m_1_td
		,perc_net_mdr_m_0
		,perc_net_mdr_m_1
		,perc_net_mdr_m_1_td
		,tpv_d1
		,tpv_d2
		,tpv_d3
		,tpv_d4
		,tpv_d5
		,tpv_d6
		,tpv_d7
		,tpv_d8
		,tpv_d9
		,tpv_d10
		,tpv_d11
		,tpv_d12
		,tpv_d13
		,tpv_d14
		,tpv_d15
		,tpv_d16
		,tpv_d17
		,tpv_d18
		,tpv_d19
		,tpv_d20
		,tpv_d21
		,tpv_d22
		,tpv_d23
		,tpv_d24
		,tpv_d25
		,tpv_d26
		,tpv_d27
		,tpv_d28
		,tpv_d29
		,tpv_d30
		,tpv_d31
		,rav_m_0
		,rav_m_1
		,rav_m_1_td
		,volume_antecipado_m_0
		,volume_antecipado_m_1
		,volume_antecipado_m_1_td
		,volume_antecipado_m_0_aut
		,volume_antecipado_m_1_aut
		,volume_antecipado_m_1_td_aut
		,duration_atual
		,agenda_disp
		,aluguel_m_1
		,outras_receitas_m_0
		,outras_receitas_m_1
		,outras_receitas_m_1_td
		,receita_bruta_m0
		,receita_bruta_m1
		,churn_30d
		,ownerid
		,clientkey
		,email
		,salesforcename
		,data_da_primeira_transacao
		,mcc
		,tpv_estimado
		,receita_bruta_m1_td
		,data_da_ultima_transacao
		,migracao
		,data_da_ultima_antecipacao
		,tpv_medio_cluster
		,plano
		,dt_ultima_atualizacao
		,email_owner_grupo3
		,email_owner_grupo2
		,email_owner_grupo1
		,email_owner_subcanal
)


--INFOS CADASTRAIS
SELECT a.[ClientCNPJorCPF] as cnpj_cpf
	  ,SUBSTRING(stonecodes.Afiliações,1,len(stonecodes.Afiliações)-1) as afiliacoes_consideradas
	  ,replace(replace(replace(b.ClientName, CHAR(13), ''), char(10), ''),'"','') as nome_fantasia --ok
	  ,b.ClientLegalName as razao_social --ok
	  ,c.SalesStructureNameLevel1 as canal --ok
	  ,c.SalesStructureNameLevel2 as subcanal --ok
	  ,c.SalesStructureNameLevel3 as grupo1 --ok
	  ,c.SalesStructureNameLevel4 as grupo2 --ok
	  ,c.SalesStructureNameLevel5 as grupo3 --ok
	  ,c.SalesStructureNameLevel6 as grupo4 --ok
	  ,d.ClientStatusDesc as [status] --ok
	  ,e.VendorName as vendedor --ok
	  ,f.FullDate as data_de_credenciamento --ok
	  ,g.CompanyName as empresa --ok

	  ,datediff(day,j.FullDate,@dtbase) dias_sem_transacionar --ok

	  ,clientdatadate.FullDate ultima_transacao --ok
	  ,iif(clientdata.ChannelTypeKey=1,'Automatica','Pontual') cadastro_rav_do_cliente --ok

	  --TPV
	  ,isnull([TPV M-0]								   ,0) as tpv_m_0 --ok
	  ,isnull([TPV M-1]								   ,0) as tpv_m_1 --ok
	  ,isnull([TPV M-1 (TD)]						   ,0) as tpv_m_1_td --ok

	  ,isnull([TPV M-0 Cred]						   ,0) as tpv_m_0_cred --ok
	  ,isnull([TPV M-1 Cred]						   ,0) as tpv_m_1_cred --ok
	  ,isnull([TPV M-1 (TD) Cred]					   ,0) as tpv_m_1_td_cred --ok

	  ,isnull([NET MDR M-0]							   ,0) as net_mdr_m_0 --ok
	  ,isnull([NET MDR M-1]							   ,0) as net_mdr_m_1 --ok
	  ,isnull([NET MDR M-1 (TD)]					   ,0) as net_mdr_m_1_td --ok

	  ,isnull([NET MDR M-0]/nullif([TPV M-0],0),0)         as perc_net_mdr_m_0 --ok
	  ,isnull([NET MDR M-1]/nullif([TPV M-1],0),0)         as perc_net_mdr_m_1 --ok
	  ,isnull([NET MDR M-1 (TD)]/nullif([TPV M-1 (TD)],0),0)    as perc_net_mdr_m_1_td --ok

	  ,isnull([TPV D1]								   ,0) as tpv_d1
	  ,isnull([TPV D2]								   ,0) as tpv_d2
	  ,isnull([TPV D3]								   ,0) as tpv_d3
	  ,isnull([TPV D4]								   ,0) as tpv_d4
	  ,isnull([TPV D5]								   ,0) as tpv_d5
	  ,isnull([TPV D6]								   ,0) as tpv_d6
	  ,isnull([TPV D7]								   ,0) as tpv_d7
	  ,isnull([TPV D8]								   ,0) as tpv_d8
	  ,isnull([TPV D9]								   ,0) as tpv_d9
	  ,isnull([TPV D10]								   ,0) as tpv_d10
	  ,isnull([TPV D11]								   ,0) as tpv_d11
	  ,isnull([TPV D12]								   ,0) as tpv_d12
	  ,isnull([TPV D13]								   ,0) as tpv_d13
	  ,isnull([TPV D14]								   ,0) as tpv_d14
	  ,isnull([TPV D15]								   ,0) as tpv_d15
	  ,isnull([TPV D16]								   ,0) as tpv_d16
	  ,isnull([TPV D17]								   ,0) as tpv_d17
	  ,isnull([TPV D18]								   ,0) as tpv_d18
	  ,isnull([TPV D19]								   ,0) as tpv_d19
	  ,isnull([TPV D20]								   ,0) as tpv_d20
	  ,isnull([TPV D21]								   ,0) as tpv_d21
	  ,isnull([TPV D22]								   ,0) as tpv_d22
	  ,isnull([TPV D23]								   ,0) as tpv_d23
	  ,isnull([TPV D24]								   ,0) as tpv_d24
	  ,isnull([TPV D25]								   ,0) as tpv_d25
	  ,isnull([TPV D26]								   ,0) as tpv_d26
	  ,isnull([TPV D27]								   ,0) as tpv_d27
	  ,isnull([TPV D28]								   ,0) as tpv_d28
	  ,isnull([TPV D29]								   ,0) as tpv_d29
	  ,isnull([TPV D30]								   ,0) as tpv_d30
	  ,isnull([TPV D31]								   ,0) as tpv_d31

	  --RAV
	  ,isnull([RAV M-0]								   ,0) as rav_m_0 --ok
	  ,isnull([RAV M-1]								   ,0) as rav_m_1 --ok
	  ,isnull([RAV M-1 (TD)]						   ,0) as rav_m_1_td --ok

	  ,isnull([Volume Antecipado M-0]				   ,0) as volume_antecipado_m_0 --ok
	  ,isnull([Volume Antecipado M-1]				   ,0) as volume_antecipado_m_1 --ok
	  ,isnull([Volume Antecipado M-1 (TD)]			   ,0) as volume_antecipado_m_1_td --ok

	  ,isnull([Volume Antecipado M-0 Aut]			   ,0) as volume_antecipado_m_0_aut --ok
	  ,isnull([Volume Antecipado M-1 Aut]			   ,0) as volume_antecipado_m_1_aut --ok
	  ,isnull([Volume Antecipado M-1 (TD) Aut]		   ,0) as volume_antecipado_m_1_td_aut --ok

	  ,isnull([Duration Atual]                         ,0) as duration_atual --ok

	  --AGENDA
	  ,isnull([Agenda Disp.]			               ,0) as agenda_disp --ok

	  --ALUGUEL
	  ,isnull([Aluguel M-1]							   ,0) as aluguel_m_1 --ok

	  --OUTRAS RECEITAS
	  ,isnull([Outras Receitas M-0]                    ,0) as outras_receitas_m_0 --ok
	  ,isnull([Outras Receitas M-1]                    ,0) as outras_receitas_m_1 --ok
	  ,isnull([Outras Receitas M-1 (TD)]               ,0) as outras_receitas_m_1_td --ok

	  ,isnull([NET MDR M-0],0)+isnull([RAV M-0],0)+isnull([Outras Receitas M-0],0) as receita_bruta_m0 --ok
	  ,isnull([NET MDR M-1],0)+isnull([RAV M-1],0)+isnull([Aluguel M-1],0)+isnull([Outras Receitas M-1],0) receita_bruta_m1 --ok

	  ,iif(isnull(rolling.Churn30D,0)=1,'True','False') as churn_30d --ok

	  ,ownerrelation.Userkey ownerid

	  ,isnull(a.ClientKey,0) as clientkey --ok

	  ,e.EmailAddress email
	  ,e.Salesforcename salesforcename

	  ,i.fulldate data_da_primeira_transacao

	  ,b.MccKey mcc
	  ,h.TPVEstimate tpv_estimado
	  ,isnull([NET MDR M-1 (TD)],0.00) + isnull([RAV M-1 (TD)],0) + isnull([Outras Receitas M-1 (TD)],0) receita_bruta_m1_td
      ,j.fulldate data_da_ultima_transacao
	  ,cast(h.ExpectedMigration/1.00 as float) migracao
	  ,l.FullDate data_da_ultima_antecipacao

	  ,avg_tpv.TPVClusterTarget as tpv_medio_cluster
	  ,pl.StonePlan as plano
	  ,getdate() as dt_ultima_atualizacao

	  ,polo_owner.email as email_owner_grupo3
	  ,distrito_owner.email as email_owner_grupo2
	  ,null as email_owner_grupo1
	  ,null as email_owner_subcanal

  FROM [StoneDWv0].[dbo].[VwFactCountClient]  a
  left join StoneDWv0..DimClient  b on a.clientkey=b.ClientKey
  left join StoneDWv0..DimSalesStructure  c on b.SalesStructureKey=c.SalesStructureKey
  left join StoneDWv0.[dbo].[DimClientStatus]  d on a.ClientStatusKey=d.ClientStatusKey
  left join StoneDWv0..DimVendor  e on b.VendorKey=e.VendorKey
  left join StoneDWv0..DimDate  f on a.CreateDate=f.DateKey
  left join StoneDWv0..DimCompany  g on a.CompanyKey=g.CompanyKey
  left join [StoneDWv0].[dbo].[VWDimClientData]  h on a.clientkey=h.clientkey
  left join [StoneDWv0].[dbo].[DimDate]  i on h.[FirstTransactionDate]=i.datekey
  left join [StoneDWv0].[dbo].[DimDate]  j on h.LastTransactionDate=j.datekey
  left join StoneDWv0.dbo.DimDate  l on h.LastAnticipationDate = l.DateKey

  left join (
				--TPV
			  select c.ClientKey
					,sum(case when eomonth(d.fulldate)=eomonth(@dtbase) then tpv else 0 end) [TPV M-0]
					,sum(case when eomonth(d.fulldate)=eomonth(@dtbase,-1) then tpv else 0 end) [TPV M-1]
					,sum(case when fulldate between dateadd(day,1,eomonth(@dtbase,-2)) and dateadd(month,-1,convert(date,@dtbase)) then tpv else 0 end) [TPV M-1 (TD)]

					,sum(case when eomonth(d.fulldate)=eomonth(@dtbase) then dia else 0 end) [NET MDR M-0]
					,sum(case when eomonth(d.fulldate)=eomonth(@dtbase,-1) then dia else 0 end) [NET MDR M-1]
					,sum(case when fulldate between dateadd(day,1,eomonth(@dtbase,-2)) and dateadd(month,-1,convert(date,@dtbase)) then dia else 0 end) [NET MDR M-1 (TD)]

					,sum(case when eomonth(d.fulldate)=eomonth(@dtbase) and ProductKey=2 then tpv else 0 end) [TPV M-0 Cred]
					,sum(case when eomonth(d.fulldate)=eomonth(@dtbase,-1) and ProductKey=2 then tpv else 0 end) [TPV M-1 Cred]
					,sum(case when fulldate between dateadd(day,1,eomonth(@dtbase,-2)) and dateadd(month,-1,convert(date,@dtbase)) and ProductKey=2 then tpv else 0 end) [TPV M-1 (TD) Cred]

					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=1 then tpv else 0 end) [TPV D1]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=2 then tpv else 0 end) [TPV D2]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=3 then tpv else 0 end) [TPV D3]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=4 then tpv else 0 end) [TPV D4]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=5 then tpv else 0 end) [TPV D5]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=6 then tpv else 0 end) [TPV D6]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=7 then tpv else 0 end) [TPV D7]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=8 then tpv else 0 end) [TPV D8]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=9 then tpv else 0 end) [TPV D9]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=10 then tpv else 0 end) [TPV D10]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=11 then tpv else 0 end) [TPV D11]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=12 then tpv else 0 end) [TPV D12]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=13 then tpv else 0 end) [TPV D13]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=14 then tpv else 0 end) [TPV D14]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=15 then tpv else 0 end) [TPV D15]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=16 then tpv else 0 end) [TPV D16]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=17 then tpv else 0 end) [TPV D17]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=18 then tpv else 0 end) [TPV D18]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=19 then tpv else 0 end) [TPV D19]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=20 then tpv else 0 end) [TPV D20]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=21 then tpv else 0 end) [TPV D21]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=22 then tpv else 0 end) [TPV D22]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=23 then tpv else 0 end) [TPV D23]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=24 then tpv else 0 end) [TPV D24]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=25 then tpv else 0 end) [TPV D25]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=26 then tpv else 0 end) [TPV D26]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=27 then tpv else 0 end) [TPV D27]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=28 then tpv else 0 end) [TPV D28]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=29 then tpv else 0 end) [TPV D29]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=30 then tpv else 0 end) [TPV D30]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and d.[DayOfMonth]=31 then tpv else 0 end) [TPV D31]

			  FROM [StoneDWv0].[dbo].[FactTPV]  a
			  join StoneDWv0..DimAffiliation  b on a.AffiliationKey=b.AffiliationKey
			  join StoneDWv0..DimClient  c on b.ClientKey=c.ClientKey
			  join StoneDWv0..DimDate  d on a.TransactionDate=d.DateKey
			  where eomonth(fulldate)>=eomonth(@dtbase,-1) and b.ClientKey<>3626 AND AcquirerKey in (1,11) AND TypeKey in (0,1,3,9,10) AND A.COMPANYKEY <> 5 and a.productkey<>4
			  group by c.ClientKey

		) tpvdiario on a.ClientKey=tpvdiario.ClientKey

	left join (
			--RAV
			select c.ClientKey
					,sum(case when eomonth(fulldate)=eomonth(@dtbase) then Revenue else 0 end) [RAV M-0]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase,-1) then Revenue else 0 end) [RAV M-1]
					,sum(case when FullDate between dateadd(day,1,eomonth(@dtbase,-2)) and dateadd(month,-1,convert(date,@dtbase)) then Revenue else 0 end) [RAV M-1 (TD)]

					,sum(case when eomonth(fulldate)=eomonth(@dtbase) then GrossValue else 0 end) [Volume Antecipado M-0]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase,-1) then GrossValue else 0 end) [Volume Antecipado M-1]
					,sum(case when FullDate between dateadd(day,1,eomonth(@dtbase,-2)) and dateadd(month,-1,convert(date,@dtbase)) then GrossValue else 0 end) [Volume Antecipado M-1 (TD)]

					,sum(case when eomonth(fulldate)=eomonth(@dtbase) and RavTypeKey=1 then GrossValue else 0 end) [Volume Antecipado M-0 Aut]
					,sum(case when eomonth(fulldate)=eomonth(@dtbase,-1) and RavTypeKey=1 then GrossValue else 0 end) [Volume Antecipado M-1 Aut]
					,sum(case when FullDate between dateadd(day,1,eomonth(@dtbase,-2)) and dateadd(month,-1,convert(date,@dtbase)) and RavTypeKey=1 then GrossValue else 0 end) [Volume Antecipado M-1 (TD) Aut]

					,sum(case when eomonth(fulldate)=eomonth(@dtbase) then DurationWD*GrossValue else 0 end)/nullif(sum(case when eomonth(fulldate)=eomonth(@dtbase) then GrossValue else 0 end),0) [Duration Atual]

			from StoneDWv0..FactRav  a
			join StoneDWv0..DimAffiliation  b on a.AffiliationKey=b.AffiliationKey
			join StoneDWv0..DimClient  c on b.ClientKey=c.ClientKey
			join StoneDWv0..DimDate  d on a.ContractDate=d.DateKey
			where eomonth(fulldate)>=eomonth(@dtbase,-1) and c.ClientKey<>3626
			group by c.ClientKey

	) rav on a.ClientKey=rav.ClientKey

	left join (

			--ALUGUEL
			select c.ClientKey
					,sum(case when eomonth(fulldate)=eomonth(@dtbase,-1) then a.ChargedRent else 0 end) [Aluguel M-1]

			from StoneDWv0..FactRental  a
			join StoneDWv0..DimAffiliation  b on a.AffiliationKey=b.AffiliationKey
			join StoneDWv0..DimClient  c on b.ClientKey=c.ClientKey
			join StoneDWv0..DimDate  d on a.DateKey=d.DateKey
			where eomonth(fulldate)=eomonth(@dtbase,-1)
			group by c.ClientKey

	) aluguel on a.ClientKey=aluguel.ClientKey

	left join [StoneDWv0].[dbo].[VwFactChurnRolling]  rolling on a.ClientKey=rolling.ClientKey

	cross apply (

			select cast(ClientAlternateKey as varchar)+'/'
			from StoneDWv0..DimAffiliation  p2
			where a.ClientKey=p2.ClientKey
			order by ClientAlternateKey
			for xml path('')

	) stonecodes (Afiliações)

	left join StoneDWv0..VwDimClientData  clientdata on a.ClientKey=clientdata.ClientKey
	left join StoneDWv0..DimDate  clientdatadate on clientdata.LastTransactionDate=clientdatadate.DateKey

	left join (

		select c.ClientKey
				,sum(a.ReceivableValue) as [Agenda Disp.]
		from StoneDWv0..FactAgenda  a
		join StoneDWv0..DimAffiliation  b on a.AffiliationKey=b.AffiliationKey
		join StoneDWv0..DimClient  c on b.ClientKey=c.ClientKey
		join StoneDWv0..DimDate  d on a.DueDate=d.DateKey
		where d.FullDate = cast(@dtbase as  date)
		group by c.ClientKey

	) agenda on a.ClientKey=agenda.ClientKey

	left join (

		select c.ClientKey
				,sum(case when eomonth(fulldate)=eomonth(@dtbase) then Revenue else 0 end) [Outras Receitas M-0]
				,sum(case when eomonth(fulldate)=eomonth(@dtbase,-1) then Revenue else 0 end) [Outras Receitas M-1]
				,sum(case when fulldate between dateadd(day,1,eomonth(@dtbase,-2)) and dateadd(month,-1,convert(date,@dtbase)) then Revenue else 0 end) [Outras Receitas M-1 (TD)]

		from StoneDWv0..FactOtherRevenues  a
		join StoneDWv0..DimAffiliation  b on a.AffiliationKey=b.AffiliationKey
		join StoneDWv0..DimClient  c on b.ClientKey=c.ClientKey
		join StoneDWv0..DimDate  d on a.DateKey=d.DateKey
		where eomonth(fulldate)>=eomonth(@dtbase,-1)
		group by c.ClientKey

	) outrasreceitas on a.ClientKey=outrasreceitas.ClientKey

    left join kpi.SalesStructureOwnerRelation ownerrelation on b.SalesStructureKey = ownerrelation.SalesStructureKey

	left join (
		select SalesStructureKey,
				sum(TPVClusterTarget) TPVClusterTarget
		from dbo.DimTarget tg
		join dbo.DimDate dt on tg.referencedate = dt.datekey
		where eomonth(dt.fulldate) = eomonth(@dtbase)
		group by SalesStructureKey
	) avg_tpv on b.SalesStructureKey = avg_tpv.SalesStructureKey

	left join (
		select af.ClientKey
			,max([StonePlan]) StonePlan
		from [StoneDWv0].[dbo].[VwDimPlan] pl
		join StoneDWv0.dbo.DimAffiliation af on pl.AffiliationKey = af.AffiliationKey
		group by af.ClientKey
	) pl on a.ClientKey = pl.ClientKey

	left join (
		select a.Name,
				min(a.Email) Email
		from (
			select b.Name,
					c.Email,
					row_number() over (partition by b.Name order by a.LastModifiedDate desc) as rw
			FROM StoneDWv0.dbo.DimUserTerritory2Association a
			join StoneDWv0.dbo.DimTerritory2 b on a.Territory2Key = b.Territory2Key
			join StoneDWv0.dbo.DimUser c on a.UserKey = c.UserKey
			where a.IsActive=1
		) a
		where a.rw=1
		group by a.Name
	) polo_owner on polo_owner.Name = c.SalesStructureNameLevel5

	left join (
		select a.Name,
				min(a.Email) Email
		from (
			select b.Name,
					c.Email,
					row_number() over (partition by b.Name order by a.LastModifiedDate desc) as rw
			FROM StoneDWv0.dbo.DimUserTerritory2Association a
			join StoneDWv0.dbo.DimTerritory2 b on a.Territory2Key = b.Territory2Key
			join StoneDWv0.dbo.DimUser c on a.UserKey = c.UserKey
			where a.IsActive=1
		) a
		where a.rw=1
		group by a.Name
	) distrito_owner on distrito_owner.Name = c.SalesStructureNameLevel4
