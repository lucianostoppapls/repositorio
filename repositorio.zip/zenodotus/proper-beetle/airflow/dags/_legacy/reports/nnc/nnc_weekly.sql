IF OBJECT_ID('tempdb..#dates') IS NOT NULL
			DROP TABLE #dates

create table #dates (week int
					, reference_date date
					, baseline_months_for_Reactivations int
					, baseline_for_Reactivations date)

TRUNCATE TABLE StoneDWv0.kpi.NetNewClients



-------------------------------------------------------------------------------------------------------------------------

DECLARE @CONT INT = 12
DECLARE @week_temp int = 1
DECLARE @reference_date_temp date = dateadd(week, -1*(@week_temp -1), dateadd(day, -DATEPART(weekday, getdate()), getdate()));
DECLARE @baseline_months_for_Reactivations_temp int = 24
DECLARE @baseline_for_Reactivations_temp date = dateadd(day, -1*(@baseline_months_for_Reactivations_temp *30 -1), @reference_date_temp);
 
WHILE @CONT > 0
 
 
BEGIN
 
INSERT INTO #dates
select @week_temp, @reference_date_temp, @baseline_months_for_Reactivations_temp, @baseline_for_Reactivations_temp
 
SET @CONT = @CONT - 1
SET @reference_date_temp = DATEADD(DAY, -7, @reference_date_temp)
SET @baseline_for_Reactivations_temp = dateadd(day, -1*(@baseline_months_for_Reactivations_temp*30 -1), @reference_date_temp)
END


-------------------------------------------------------------------------------------------------------------------------

DECLARE @reference_date_tpv date = (SELECT MAX(reference_date) FROM #dates)
DECLARE @baseline_for_Reactivations_tpv date = (SELECT MIN(baseline_for_Reactivations) FROM #dates)


IF OBJECT_ID('tempdb..#daily_tpv') IS NOT NULL
			DROP TABLE #daily_tpv

--with daily_tpv as (
	select
		client.ClientKey as clientkey,
		dt.FullDate as fulldate,
		sum(tpv.tpv) as tpv
	into #daily_tpv
	from StoneDWv0.dbo.DimAffiliation affiliation
	join StoneDWv0.dbo.FactTPV tpv on affiliation.AffiliationKey = tpv.AffiliationKey
	join StoneDWv0.dbo.DimClient client on affiliation.ClientKey = client.ClientKey
	join StoneDWv0.dbo.DimSalesStructure ss on client.SalesStructureKey = ss.SalesStructureKey
	join StoneDWv0.dbo.DimDate dt on tpv.TransactionDate = dt.DateKey
	where
		dt.FullDate between @baseline_for_Reactivations_tpv and @reference_date_tpv
		and client.ClientKey <> 3626
		and ss.SalesStructureNameLevel1 <> 'STONE MAIS'
	group by
		client.ClientKey,
		dt.FullDate
--),

create index fulldate on #daily_tpv (fulldate)
create index clientkey on #daily_tpv (clientkey)


-------------------------------------------------------------------------------------------------------------------------
SET NOCOUNT ON;   
 
DECLARE @week int
DECLARE @reference_date date 
DECLARE @baseline_months_for_Reactivations int 
DECLARE @baseline_for_Reactivations date
 
DECLARE NNC CURSOR FAST_FORWARD FOR
 
SELECT week
	, reference_date
	, baseline_months_for_Reactivations
	, baseline_for_Reactivations
FROM #DATES
 
 
OPEN NNC    
 
FETCH NEXT FROM NNC      
            INTO @week
				, @reference_date
				, @baseline_months_for_Reactivations
				, @baseline_for_Reactivations
 
 
WHILE @@FETCH_STATUS = 0  
      BEGIN   
	  
IF OBJECT_ID('tempdb..#end_of_periods') IS NOT NULL
			DROP TABLE #end_of_periods

--end_of_periods as (
	select
		dd.FullDate as end_of_period
	into #end_of_periods
	from StoneDWv0.dbo.DimDate dd
	where
		datediff(day, @reference_date, dd.FullDate)%30 = 0
		and dd.fulldate between @baseline_for_Reactivations and @reference_date
--),

create index end_of_period on #end_of_periods (end_of_period)


IF OBJECT_ID('tempdb..#tpv_per_client_per_period') IS NOT NULL
			DROP TABLE #tpv_per_client_per_period

--tpv_per_client_per_period as (
	select
		eop.end_of_period as end_of_period,
		#daily_tpv.clientkey,
		sum(#daily_tpv.tpv) as tpv
	into #tpv_per_client_per_period
	from #daily_tpv
	inner join #end_of_periods eop on #daily_tpv.fulldate between dateadd(day, -29, eop.end_of_period) and eop.end_of_period
	group by
		eop.end_of_period,
		#daily_tpv.clientkey
--),


IF OBJECT_ID('tempdb..#reference_date_Churned_clients') IS NOT NULL
			DROP TABLE #reference_date_Churned_clients

--reference_date_Churned_clients as (
	select
		tpcpp_last.clientkey,
		tpcpp_last.tpv as tpv
	into #reference_date_Churned_clients
	from #tpv_per_client_per_period tpcpp_last
	left join #tpv_per_client_per_period tpcpp_current on tpcpp_current.clientkey = tpcpp_last.clientkey and tpcpp_current.end_of_period = @reference_date
	where
		coalesce(tpcpp_current.tpv, 0) <= 1
		and tpcpp_last.tpv > 1
		and tpcpp_last.end_of_period = DATEADD(day, -30, @reference_date)
--),


IF OBJECT_ID('tempdb..#reference_date_Reactivations') IS NOT NULL
			DROP TABLE #reference_date_Reactivations

--reference_date_Reactivations as (
	select
		distinct(tpcpp_h.clientkey) as clientkey
	into #reference_date_Reactivations
	from #tpv_per_client_per_period tpcpp_h
	inner join #tpv_per_client_per_period tpcpp_current on tpcpp_current.clientkey = tpcpp_h.clientkey and tpcpp_current.end_of_period = @reference_date and tpcpp_current.tpv > 1
	left join #tpv_per_client_per_period tpcpp_last on tpcpp_current.clientkey = tpcpp_last.clientkey and tpcpp_last.end_of_period = DATEADD(day, -30, @reference_date)
	where
		tpcpp_h.tpv > 1
		and coalesce(tpcpp_last.tpv, 0) <= 1
		and tpcpp_h.end_of_period < DATEADD(day, -30, @reference_date)
--),

IF OBJECT_ID('tempdb..#reference_date_new_activations') IS NOT NULL
			DROP TABLE #reference_date_new_activations

--reference_date_new_activations as (
	select
		tpcpp_current.clientkey
	into #reference_date_new_activations
	from #tpv_per_client_per_period tpcpp_current
	where
		tpcpp_current.end_of_period = @reference_date
		and tpcpp_current.tpv > 1
		and not exists (
			select top 1
				1
			from #tpv_per_client_per_period tpcpp_h
			where
				tpcpp_h.clientkey = tpcpp_current.clientkey
				and tpcpp_h.tpv > 1
				and tpcpp_h.end_of_period < @reference_date
		)
--)


insert into StoneDWv0.kpi.NetNewClients

select
	@reference_date as reference_date,
	'Churn' as kpi_name,
	count(*) as kpi_value,
	'Stone Co' as breakdown
from #reference_date_Churned_clients
union
select
	@reference_date as reference_date,
	'Reactivations' as kpi_name,
	count(*) as kpi_value,
	'Stone Co' as breakdown
from #reference_date_Reactivations
union
select
	@reference_date as reference_date,
	'New Active Clients' as kpi_name,
	count(*) as kpi_value,
	'Stone Co' as breakdown
from #reference_date_new_activations
union
select
	@reference_date as reference_date,
	'Active Clients' as kpi_name,
	count(*) as kpi_value,
	'Stone Co' as breakdown
from #tpv_per_client_per_period tpcpp
where
	tpcpp.end_of_period = @reference_date
	and tpcpp.tpv > 1
union
select
	@reference_date as reference_date,
	'% Churn TPV' as kpi_name,
	(select sum(tpv) from #reference_date_Churned_clients)/(select sum(tpv) from #tpv_per_client_per_period tpcpp where tpcpp.end_of_period = dateadd(day, -30, @reference_date)) as kpi_value,
	'Stone Co' as breakdown
union
select
	@reference_date as reference_date,
	'% Churn EC' as kpi_name,
	(select cast(count(*) as float) from #reference_date_Churned_clients)/(select cast(count(*) as float) from #tpv_per_client_per_period tpcpp where tpcpp.end_of_period = dateadd(day, -30, @reference_date) and tpcpp.tpv > 1) as kpi_value,
	'Stone Co' as breakdown
union
select
	@reference_date as reference_date,
	'% Churn TPV' as kpi_name,
	(select sum(rdcc.tpv)
		from #reference_date_Churned_clients rdcc
		inner join StoneDWv0.dbo.DimClient c on rdcc.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'POLOS')/
	(
		select sum(tpcpp.tpv) from #tpv_per_client_per_period tpcpp
		inner join StoneDWv0.dbo.DimClient c on tpcpp.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'POLOS'
		where
			tpcpp.end_of_period = dateadd(day, -30, @reference_date)
	) as kpi_value,
	'Hubs' as breakdown
union
select
	@reference_date as reference_date,
	'% Churn EC' as kpi_name,
	(select cast(count(rdcc.clientkey) as float)
		from #reference_date_Churned_clients rdcc
		inner join StoneDWv0.dbo.DimClient c on rdcc.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'POLOS')/
	(
		select cast(count(tpcpp.clientkey) as float) from #tpv_per_client_per_period tpcpp
		inner join StoneDWv0.dbo.DimClient c on tpcpp.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'POLOS'
		where
			tpcpp.end_of_period = dateadd(day, -30, @reference_date)
			and tpcpp.tpv > 1
	) as kpi_value,
	'Hubs' as breakdown
union
select
	@reference_date as reference_date,
	'% Churn TPV' as kpi_name,
	(select sum(rdcc.tpv)
		from #reference_date_Churned_clients rdcc
		inner join StoneDWv0.dbo.DimClient c on rdcc.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'DIGITAL')/
	(
		select sum(tpcpp.tpv) from #tpv_per_client_per_period tpcpp
		inner join StoneDWv0.dbo.DimClient c on tpcpp.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'DIGITAL'
		where
			tpcpp.end_of_period = dateadd(day, -30, @reference_date)
	) as kpi_value,
	'Digital' as breakdown
union
select
	@reference_date as reference_date,
	'% Churn EC' as kpi_name,
	(select cast(count(rdcc.clientkey) as float)
		from #reference_date_Churned_clients rdcc
		inner join StoneDWv0.dbo.DimClient c on rdcc.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'DIGITAL')/
	(
		select cast(count(tpcpp.clientkey) as float) from #tpv_per_client_per_period tpcpp
		inner join StoneDWv0.dbo.DimClient c on tpcpp.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'DIGITAL'
		where
			tpcpp.end_of_period = dateadd(day, -30, @reference_date)
			and tpcpp.tpv > 1
	) as kpi_value,
	'Digital' as breakdown
union
select
	@reference_date as reference_date,
	'% Churn TPV' as kpi_name,
	(select sum(rdcc.tpv)
		from #reference_date_Churned_clients rdcc
		inner join StoneDWv0.dbo.DimClient c on rdcc.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'INT PARTNERSHIPS')/
	(
		select sum(tpcpp.tpv) from #tpv_per_client_per_period tpcpp
		inner join StoneDWv0.dbo.DimClient c on tpcpp.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'INT PARTNERSHIPS'
		where
			tpcpp.end_of_period = dateadd(day, -30, @reference_date)
	) as kpi_value,
	'IP' as breakdown
union
select
	@reference_date as reference_date,
	'% Churn EC' as kpi_name,
	(select cast(count(rdcc.clientkey) as float)
		from #reference_date_Churned_clients rdcc
		inner join StoneDWv0.dbo.DimClient c on rdcc.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'INT PARTNERSHIPS')/
	(
		select cast(count(tpcpp.clientkey) as float) from #tpv_per_client_per_period tpcpp
		inner join StoneDWv0.dbo.DimClient c on tpcpp.clientkey = c.ClientKey
		inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'INT PARTNERSHIPS'
		where
			tpcpp.end_of_period = dateadd(day, -30, @reference_date)
			and tpcpp.tpv > 1
	) as kpi_value,
	'IP' as breakdown
union
select
	@reference_date as reference_date,
	'Churn' as kpi_name,
	count(rdcc.clientkey) as kpi_value,
	case when ss.SalesStructureNameLevel1 = 'POLOS' then 'Hubs' else ss.SalesStructureNameLevel1 end as breakdown
from #reference_date_Churned_clients rdcc
inner join StoneDWv0.dbo.DimClient c on rdcc.clientkey = c.ClientKey
inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey
group by
	case when ss.SalesStructureNameLevel1 = 'POLOS' then 'Hubs' else ss.SalesStructureNameLevel1 end
union
select
	@reference_date as reference_date,
	'Reactivations' as kpi_name,
	count(rdr.clientkey) as kpi_value,
	case when ss.SalesStructureNameLevel1 = 'POLOS' then 'Hubs' else ss.SalesStructureNameLevel1 end as breakdown
from #reference_date_Reactivations rdr
inner join StoneDWv0.dbo.DimClient c on rdr.clientkey = c.ClientKey
inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey
group by
	case when ss.SalesStructureNameLevel1 = 'POLOS' then 'Hubs' else ss.SalesStructureNameLevel1 end
union
select
	@reference_date as reference_date,
	'New Active Clients' as kpi_name,
	count(rdna.clientkey) as kpi_value,
	case when ss.SalesStructureNameLevel1 = 'POLOS' then 'Hubs' else ss.SalesStructureNameLevel1 end as breakdown
from #reference_date_new_activations rdna
inner join StoneDWv0.dbo.DimClient c on rdna.clientkey = c.ClientKey
inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey
group by
	case when ss.SalesStructureNameLevel1 = 'POLOS' then 'Hubs' else ss.SalesStructureNameLevel1 end
union
select
	@reference_date as reference_date,
	'Active Clients' as kpi_name,
	count(*) as kpi_value,
	case when ss.SalesStructureNameLevel1 = 'POLOS' then 'Hubs' else ss.SalesStructureNameLevel1 end as breakdown
from #tpv_per_client_per_period tpcpp
inner join StoneDWv0.dbo.DimClient c on tpcpp.clientkey = c.ClientKey
inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey
where
	tpcpp.end_of_period = @reference_date
	and tpcpp.tpv > 1
group by
	case when ss.SalesStructureNameLevel1 = 'POLOS' then 'Hubs' else ss.SalesStructureNameLevel1 end
union
select
	@reference_date as reference_date,
	'New Active Clients' as kpi_name,
	count(rdna.clientkey) as kpi_value,
	'Hubs - ' + v.SalesForceName as breakdown
from #reference_date_new_activations rdna
inner join StoneDWv0.dbo.DimClient c on rdna.clientkey = c.ClientKey
inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'POLOS'
left join StoneDWv0.dbo.DimVendor v on c.VendorKey = v.VendorKey
group by
	'Hubs - ' + v.SalesForceName
union
select
	@reference_date as reference_date,
	'Active Clients' as kpi_name,
	count(*) as kpi_value,
	'Hubs - ' + ss.SalesStructureNameLevel2 as breakdown
from #tpv_per_client_per_period tpcpp
inner join StoneDWv0.dbo.DimClient c on tpcpp.clientkey = c.ClientKey
inner join StoneDWv0.dbo.DimSalesStructure ss on c.SalesStructureKey = ss.SalesStructureKey and ss.SalesStructureNameLevel1 = 'POLOS'
where
	tpcpp.end_of_period = @reference_date
	and tpcpp.tpv > 1
group by 	'Hubs - ' + ss.SalesStructureNameLevel2


FETCH NEXT FROM NNC          
                  INTO @week
						, @reference_date
						, @baseline_months_for_Reactivations
						, @baseline_for_Reactivations
                 
            END   
 
SET NOCOUNT OFF   
 
CLOSE NNC   
DEALLOCATE NNC              
