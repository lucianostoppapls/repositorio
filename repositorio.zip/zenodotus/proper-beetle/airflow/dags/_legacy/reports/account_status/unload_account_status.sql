Select Id, OwnerId, IsDeleted, Name, CreatedDate, CreatedById, LastModifiedDate, Account__c, Type__c, Stonecode__c FROM Account_Status__c WHERE IsDeleted = false
