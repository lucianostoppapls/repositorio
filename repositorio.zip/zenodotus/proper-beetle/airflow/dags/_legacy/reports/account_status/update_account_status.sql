SELECT DISTINCT [AccountStatusKey] AS [Id]
    , [SubType] AS [SubType__c]
    , [Type] AS [Type__c]
    , [ClientAlternateKey] AS [Stonecode__c]
FROM StoneDWv0..DimAccountStatusSF
WHERE AccountStatusKey IS NOT NULL
