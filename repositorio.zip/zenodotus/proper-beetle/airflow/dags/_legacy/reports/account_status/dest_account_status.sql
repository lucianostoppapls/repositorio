TRUNCATE TABLE [dbo].[DimAccountStatus]

INSERT INTO [dbo].[DimAccountStatus] ([AccountStatusKey]
, [OwnerKey]
, [IsDeleted]
, [Name]
, [CreatedDate]
, [CreatedById]
, [LastModifiedDate]
, [AccountKey]
, [Type]
, [ClientAlternateKey]
, [LastUpdatedAt])

SELECT DISTINCT [Id]
, [OwnerId]
, CASE WHEN [IsDeleted] = 'true' THEN 1
    WHEN [IsDeleted] = 'false' THEN 0 END
, [Name]
, REPLACE(LEFT(CreatedDate,10), '-', '')
, [CreatedById]
, REPLACE(LEFT(LastModifiedDate,10), '-', '')
, [Account__c]
, [Type__c]
, [Stonecode__c]
, REPLACE(CONVERT(DATE, '{{ ds_nodash }}'), '-', '')
FROM {{ ti.xcom_pull('create_account_status_table') }}
