SELECT DISTINCT A.[AccountStatusKey] AS [Id]
FROM StoneDWv0..DimAccountStatus A
WHERE NOT EXISTS (SELECT TOP 1 1
                    FROM StoneDWv0..DimAccountStatusSF B
                    WHERE A.[AccountStatusKey] = B.[AccountStatusKey]
                    AND B.AccountStatusKey IS NOT NULL)
AND A.[AccountStatusKey] IS NOT NULL
