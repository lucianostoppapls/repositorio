INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	kpi_value
)
	SELECT 
		'{{ ds }}',
		'0022',
		'Base Ativa de Clientes',
		eomonth(dt.FullDate),
		company.CompanyName,
		ss.SalesStructureNameLevel1,
		ss.SalesStructureNameLevel2,
		count(distinct affiliation.ClientCNPJorCPF)
	FROM dbo.FactMonthlyTPV tpv
	JOIN dbo.DimAffiliation affiliation ON affiliation.AffiliationKey = tpv.AffiliationKey
	JOIN dbo.DimDate dt ON tpv.TransactionDate = dt.DateKey
	JOIN dbo.DimAffiliationSalesStructureHist assh on assh.AffiliationKey = affiliation.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
	JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
	JOIN dbo.DimCompany company ON affiliation.CompanyKey = company.CompanyKey
	where tpv.tpv > 1
	GROUP BY eomonth(dt.FullDate),
		company.CompanyName,
		ss.SalesStructureNameLevel1,
		ss.SalesStructureNameLevel2

	UNION ALL

	SELECT 
		'{{ ds }}',
		'0005',
		'Receita Total',
		eomonth(dt.FullDate),
		company.CompanyName,
		ss.SalesStructureNameLevel1,
		ss.SalesStructureNameLevel2,
		sum(TotalRevenue)
	FROM dbo.VwFactTotalRevenue revenue
	JOIN dbo.DimAffiliation affiliation ON revenue.AffiliationKey = affiliation.AffiliationKey
	JOIN dbo.DimDate dt ON revenue.DateKey = dt.DateKey
	JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
	JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
	JOIN dbo.DimCompany company ON affiliation.CompanyKey = company.CompanyKey
	GROUP BY eomonth(dt.FullDate),
		company.CompanyName,
		ss.SalesStructureNameLevel1,
		ss.SalesStructureNameLevel2

	UNION ALL

	SELECT
		'{{ ds }}',
		'0047',
		'Base Ativa M1',
		eomonth(dt.FullDate),
		company.CompanyName,
		ss.SalesStructureNameLevel1,
		ss.SalesStructureNameLevel2,
		count(distinct affiliation.ClientCNPJorCPF)
	FROM stonedwv0.dbo.FactMonthlyTPV tpv
	JOIN stonedwv0.dbo.DimAffiliation affiliation ON affiliation.AffiliationKey = tpv.AffiliationKey
	JOIN stonedwv0.dbo.DimClient client ON affiliation.ClientKey = client.ClientKey
	JOIN stonedwv0.dbo.DimDate dt ON tpv.TransactionDate = dt.DateKey
	JOIN stonedwv0.dbo.DimAffiliationSalesStructureHist assh on assh.AffiliationKey = affiliation.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
	JOIN stonedwv0.dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
	JOIN stonedwv0.dbo.DimCompany company ON affiliation.CompanyKey = company.CompanyKey
	WHERE
		tpv.tpv > 1
		and eomonth(convert(varchar, client.createdate)) = eomonth(FullDate, -1)
	GROUP BY
		eomonth(dt.FullDate),
		company.CompanyName,
		ss.SalesStructureNameLevel1,
		ss.SalesStructureNameLevel2
