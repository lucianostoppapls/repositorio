--SCRIPT KPI 4096.1 R$ CBK Hubs
with aux_dt_tratamento as(
SELECT
      distinct(cast(DataRef as date)) as dt,
      cast(date_trunc(dataref, month) as date) as mes
FROM `dataplatform-prd.risk_metrics.perdas_stone_aging_30`)
, aux_dt_maximo as (
select
  distinct(max(dt)over(partition by mes)) as dt_max
from aux_dt_tratamento)

SELECT 
	'{{ ds }}' as execution_date,
	'4096.1' as kpi_index,
	'R$ CBK Hubs' as kpi_name,
	dt_max as reference_date,
	'STONE' as company,
	'POLOS' as sales_channel,
	'NAO SE APLICA' as sales_subchannel,
	'NAO SE APLICA' as card_brand,
	'NAO SE APLICA' as product,
	'NAO SE APLICA' as installments,
	'NAO SE APLICA' as acquirer,
	'NAO SE APLICA' as rav_type,
    sum(Delta)* -1 as kpi_value
FROM aux_dt_maximo a1 
left join `dataplatform-prd.risk_metrics.perdas_stone_aging_30` a2
  on a1.dt_max = cast(a2.DataRef as date)
left join `dataplatform-prd.client_affiliation_open.vw_merchant` a3
  on cast(a2.Stonecode as string) = a3.AffiliationCode
left join `dataplatform-prd.risk_metrics.casos_especiais_registradora_v2` cr
  on cast(cr.int64_field_0 as string) = cast(a2.Stonecode as string)
where DATE(DataRef) >= '2021-01-01'
     and DATE(DataRef) < '{{ ds }}'
	 AND a2.Canal not in ('PAGARME - SMB', 'PAGARME - GRANDES CONTAS')
	 AND cr.int64_field_0 is null
group by reference_date
order by reference_date
