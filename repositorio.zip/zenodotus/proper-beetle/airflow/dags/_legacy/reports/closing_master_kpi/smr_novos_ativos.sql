use StoneDWv0

--exclui tabelas temporárias
IF Object_id('tempdb..#AUXNormal_MGMT_NOVO') IS NOT NULL DROP TABLE #AUXNormal_MGMT_NOVO 
IF Object_id('tempdb..#TPV_CNPJ_MGMT_NOVO') IS NOT NULL DROP TABLE #TPV_CNPJ_MGMT_NOVO 
IF Object_id('tempdb..#TPV2_MGMT_NOVO') IS NOT NULL DROP TABLE #TPV2_MGMT_NOVO 
IF Object_id('tempdb..#TPVFINAL_MGMT_NOVO') IS NOT NULL DROP TABLE #TPVFINAL_MGMT_NOVO
IF Object_id('tempdb..#TV_MGMT_novo') IS NOT NULL DROP TABLE #TV_MGMT_novo
IF Object_id('tempdb..#TVFINAL_MGMT_NOVO') IS NOT NULL DROP TABLE #TVFINAL_MGMT_NOVO
IF Object_id('tempdb..#NA_MGMT_NOVO') IS NOT NULL DROP TABLE #NA_MGMT_NOVO
IF Object_id('tempdb..#REFTABLE_MGMT_NOVO') IS NOT NULL DROP TABLE #REFTABLE_MGMT_NOVO

--seleciona publico 
SELECT 
X.ClientCNPJorCPF, 
X.SalesStructureNameLevel1 ,
CASE
		WHEN X.SalesStructureNameLevel1 <> 'POLOS' THEN X.SalesStructureNameLevel1
		WHEN X.SalesForceName in ('INBOUND','OUTBOUND') OR X.VendorKey = 40047 THEN 'INBOUND'
		WHEN X.SalesForceName in ('FRANQUIA') OR X.EmailAddress like '%@querostone%' THEN 'FRANQUIA'
		WHEN X.SalesForceName in ('POLO PROPRIO','ESPECIALISTA','POLO TERCEIRO') THEN 'POLO PROPRIO'
		WHEN X.SalesStructureNameLevel2 = 'FRANQUIA' THEN 'FRANQUIA'
		WHEN X.SalesStructureNameLevel2 = 'VAREJO' THEN 'INBOUND'
		WHEN X.SalesStructureNameLevel2 in ('POLO PROPRIO','POLO TERCEIRO') THEN 'POLO PROPRIO'
		ELSE 'ND'
	END SalesForceReNameN
	,CASE
		WHEN SalesStructureNameLevel1 in ('DIGITAL','INT PARTNERSHIPS','PAGARME - KEY ACCOUNTS','PAGARME - SMB','PAGARME - GRANDES CONTAS') OR CompanyKey = 3 THEN 'PAGARME'
		WHEN SalesStructureNameLevel1 = 'POLOS' AND SalesStructureNameLevel2='VAREJO' THEN 'POLO PROPRIO'
		WHEN SalesStructureNameLevel1 = 'POLOS' THEN SalesStructureNameLevel2
		WHEN SalesStructureNameLevel1 = 'PAGARME - PARCEIROS' THEN 'PARCEIROS'
		ELSE 'OUTROS'
	END AS SalesStructureRename
INTO #AUXNormal_MGMT_NOVO 
FROM ( 
SELECT 
A.ClientCNPJorCPF, 
S.SalesStructureNameLevel1, SalesStructureNameLevel2,a.SalesForceName,v.VendorKey,v.EmailAddress,CompanyKey,
ROW_NUMBER() OVER (PARTITION BY A.ClientCNPJorCPF ORDER BY D.FullDate ASC) RW 
FROM [StoneDWv0].[dbo].[DimAffiliation] A 
LEFT JOIN StoneDWv0..DimVendor V ON V.VendorKey = A.VendorKey 
LEFT JOIN StoneDWv0..DimSalesStructure S ON S.SalesStructureKey = A.SalesStructureKey 
LEFT JOIN StoneDWv0..DimDate D ON D.DateKey = A.CreateDate 
WHERE 1=1 
AND A.CompanyKey in (1,2,3) 
AND S.SalesStructureNameLevel1 IN ('PAGARME - SMB', 'POLOS') 
) X 
WHERE RW = 1 


--busca todas as transações do publico para determinar se é novo ativo ou se é uma reativação
SELECT ClientCNPJorCPF 
,CAST(CAST(Transactiondate as varchar)as date) as Transactiondate 
,CAST(CAST(MIN(Transactiondate) OVER(PARTITION BY ClientCNPJorCPF) as varchar)as date) as data_ativação 
INTO #TPV_CNPJ_MGMT_NOVO 
FROM StoneDWv0.dbo.DimAffiliation da 
LEFT JOIN StoneDWv0.dbo.FactTPV ft on da.AffiliationKey=ft.AffiliationKey 
LEFT JOIN StoneDWv0.dbo.DimSalesStructure dss on da.salesstructurekey=dss.salesstructurekey 
Where exists (SELECT ClientCNPJorCPF FROM #AUXNormal_MGMT_NOVO t where t.ClientCNPJorCPF = da.ClientCNPJorCPF) 
AND fT.TypeKey = 1 
--AND fT.Transactions >= 1 
AND ft.tpv > 1 --Alteração de conceito para ativos com TPV maior que 1
AND da.CompanyKey in (1,2,3) 
AND dss.SalesStructureNameLevel1 IN ('PAGARME - SMB', 'POLOS') 
GROUP BY ClientCNPJorCPF,TransactionDate

--constroi uma nova data de ativação quando há mais de 30 dias entre as transações
Select ClientCNPJorCPF, 
TransactionDate, 
data_ativação, 
CASE WHEN DATEDIFF(day,LAG(TransactionDate) OVER (Partition BY ClientCNPJorCPF Order by TransactionDate), TransactionDate ) >=30 THEN Transactiondate ELSE data_ativação END as data_ativação2 -- CRIANDO UMA NOVA DATA DE REATIVAÇAO 
INTO #TPV2_MGMT_NOVO 
FROM #TPV_CNPJ_MGMT_NOVO 
ORDER BY ClientCNPJorCPF,Transactiondate 

--Cria nova data de ativação para os reativados
SELECT ClientCNPJorCPF 
,CAST(TransactionDate as date) as TransactionDate 
,data_ativação as data_ativação_original 
,MAX(data_ativação2) OVER(Partition By ClientCNPJorCPF Order BY TransactionDate ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as data_ativação--OBTENDO A DATA DE REATIVAçÂo Correta correspondente a cada transação 
INTO #TPVFINAL_MGMT_NOVO 
FROM #TPV2_MGMT_NOVO 
WHERE DATEDIFF(day,(CAST(CAST(TransactionDate as varchar) as date)),('{{ ds }}'))>=1 --FILTRANDO OS DADOS DE TRANSAÇÕES ATÉ 1 dia atrás 


--cria a chave única de CNPF CNPJ + Data da ativação e cria indicador dos reativados
SELECT  CAST(ClientCNPJorCPF as varchar)+CAST(data_ativação as varchar) as newkey,
	ClientCNPJorCPF
	,data_ativação_original
	,data_ativação
	,CASE WHEN DATEDIFF(day,data_ativação_original,data_ativação)>0 THEN 1 ELSE 0 END as ind_reativacao
INTO #TV_MGMT_novo
FROM #TPVFINAL_MGMT_NOVO
WHERE  DATEDIFF(day,(data_ativação) , ('{{ ds }}'))>1 --Clientes que ativaram a mais de um dia
GROUP BY ClientCNPJorCPF,data_ativação,data_ativação_original
ORDER BY ClientCNPJorCPF,data_ativação,data_ativação_original



--prepara tabela para contagem de novos ativos
SELECT tv.ClientCNPJorCPF
	,newkey
	,tv.data_ativação_original
	,tv.data_ativação
	,tv.ind_reativacao
	,aux.SalesStructureNameLevel1
	,aux.SalesForceReNameN
INTO #TVFINAL_MGMT_NOVO
FROM #TV_MGMT_novo tv
LEFT JOIN #AUXNormal_MGMT_NOVO aux ON tv.ClientCNPJorCPF=aux.ClientCNPJorCPF
WHERE 1=1
	AND data_ativação<DATEADD(day,-1,'{{ ds }}')

--cria tabela de com a contagem de novos ativos por Força de venda tratado
SELECT data_ativação, SalesForceReNameN, COUNT(newkey) as novos_ativos
INTO #NA_MGMT_NOVO
FROM #TVFINAL_MGMT_NOVO
WHERE ind_reativacao=0
	AND data_ativação<DATEADD(day,-1,'{{ ds }}')
	and eomonth(data_ativação) >='2020-01-31'
GROUP BY data_ativação,SalesForceReNameN
ORDER BY data_ativação,SalesForceReNameN


--cria tabela de datas para utilizar como referencia 
SELECT Fulldate, CalendarQuarter,CalendarYearQtr,SalesForceReNameN,CASE WHEN IsNationalHoliday=1 AND DayOfWeek BETWEEN 2 AND 6 THEN 1 ELSE 0 END as Feriado_du
INTO #REFTABLE_MGMT_NOVO
FROM StoneDWv0.dbo.dimDate dd
CROSS JOIN (SELECT distinct SalesForceReNameN FROM #TVFINAL_MGMT_NOVO ) t1 
WHERE FullDate BETWEEN '2013-01-01' AND DATEADD(day,-2,'{{ ds }}')
	AND SalesForceReNameN <> 'ND'

--Insere registros na tabela de KPIs

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	kpi_value
	)
SELECT 
	'{{ ds }}'
	,'4014'
	,'Novos Ativos Pagarme'
	,EOMONTH(Fulldate)
	,'STONE'
	,'NAO SE APLICA'
	,'NAO SE APLICA'
	,'NAO SE APLICA'
	,SUM (CASE WHEN FullDate<DATEADD(day,-1,CAST(GETDATE() as DATE)) THEN COALESCE(novos_ativos,0) ELSE NULL END) 
FROM #REFTABLE_MGMT_NOVO r
LEFT JOIN #NA_MGMT_NOVO na ON r.FullDate=na.data_ativação AND r.SalesForceReNameN=na.SalesForceReNameN
WHERE fulldate >= cast('2020-01-01' as date) and
		EOMONTH(Fulldate)<=EOMONTH('{{ ds }}',-1) and 
		r.SalesForceReNameN = 'PAGARME - SMB'
GROUP BY EOMONTH(Fulldate)
ORDER BY EOMONTH(Fulldate)
	

--select EOMONTH(getdate(),-1)