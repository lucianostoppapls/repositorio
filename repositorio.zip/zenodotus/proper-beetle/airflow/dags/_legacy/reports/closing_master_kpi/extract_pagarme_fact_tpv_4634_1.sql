-- STNE Management Report - Pagarme - Churn liq de reat EC PERC PARTNERSHIPS - 4634 PERC -
-- STNE Management Report - Pagarme - Base ativa
with base as
( select
    date_trunc('month', dimension_date)::date     as mes,
    sum(case when status = 'churn_m1' then 1 else 0 end) as is_churn,
    count(distinct encarteiramento_atual.internal_affiliation_id) as all_ffs,
    count(distinct encarteiramento_atual.group_3) as n_afiliacoes_churn_m0,
   encarteiramento_atual.group_3
  from
    digital_dataops.fact_base_ativa
      inner join digital_dataops.dim_base_ativa_status as base_ativa_gmv
                 on fact_base_ativa.gmv_total_base_ativa_status_key = base_ativa_gmv.base_ativa_status_key
      inner join digital_dataops.dim_affiliation
                 using (affiliation_key)
      inner join digital_dataops.dim_date
                 using (date_key)
      left join digital_dataops.encarteiramento_atual
                on dim_affiliation.internal_affiliation_id = encarteiramento_atual.internal_affiliation_id
  where
    date_key >= 20200101
    -- remove mei/ton
    and dim_affiliation.affiliation_type != 'mei'
    -- filtra apenas os seguintes encarteiramentos pagarme no fechamento de cada mes
    and encarteiramento_atual.channel in (
                                              'PAGARME - PARCEIROS'
    )
    and encarteiramento_atual.sub_channel in (
                                                  'PARTNER PROGRAM', 'MARKETPLACES', 'PARCEIROS'
    )
  and is_churn != 0
  group by
    date_trunc('month', dimension_date)::date,
    encarteiramento_atual.group_3

  order by
    mes
   ),
     churn_grupo_3 as (
select
      mes,
      count (distinct group_3) as n_churns
from base
where is_churn = all_ffs
group by mes
order by mes),
  base_ativa as (
    select
      date_trunc('month', dimension_date)::date                                                            as mes,
      count(distinct case when base_ativa_gmv.is_base_ativa = true then encarteiramento_atual.group_3 end) as n_afiliacoes_ativas_gmv
    from
      digital_dataops.fact_base_ativa
        inner join digital_dataops.dim_base_ativa_status as base_ativa_gmv
                   on fact_base_ativa.gmv_total_base_ativa_status_key = base_ativa_gmv.base_ativa_status_key
        inner join digital_dataops.dim_affiliation
                   using (affiliation_key)
        inner join digital_dataops.dim_date
                   using (date_key)
        left join digital_dataops.encarteiramento_atual
                  on dim_affiliation.internal_affiliation_id = encarteiramento_atual.internal_affiliation_id
    where
      date_key >= 20191201
      -- remove mei/ton
      and dim_affiliation.affiliation_type != 'mei'
      -- filtra apenas os seguintes encarteiramentos pagarme no fechamento de cada mes
    and encarteiramento_atual.channel in (
                                              'PAGARME - PARCEIROS'
    )
    and encarteiramento_atual.sub_channel in (
                                                  'PARTNER PROGRAM', 'MARKETPLACES', 'PARCEIROS'
    )
    group by
      date_trunc('month', dimension_date)::date
    order by
      mes
    )
select
  mes,
  -- mes atual
  n_afiliacoes_ativas_gmv,
  n_churns,
  round(n_churns::float / n_afiliacoes_ativas_gmv::float, 2) as perc_churn
from
  base_ativa
    full outer join churn_grupo_3
                    using (mes)
order by
  mes;