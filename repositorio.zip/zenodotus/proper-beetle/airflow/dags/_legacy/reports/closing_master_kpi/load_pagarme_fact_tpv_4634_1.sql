INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value	
	)
select '{{ ds }}'
		,'4634.1' kpi_index
		,'Churn Bruto (#) Stone Pagarme' kpi_name
		, EOMONTH(mes) reference_date
		, 'Nao se aplica' company
		, 'Nao se aplica' sales_channel
		, 'Nao se aplica' sales_subchannel
		, 'Nao se aplica' card_brand
		, 'Nao se aplica' product
		, 'Nao se aplica' installments
		, 'Nao se aplica' acquirer
		, 'Nao se aplica' rav_type
		, n_churns as kpi_value
from {{ ti.xcom_pull(task_ids='extract_pagarme_fact_tpv_4634_1') }} 