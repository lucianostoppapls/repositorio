select
  date_trunc('month', dimension_date)::date                                                  as mes,
  -- net tpv total para o conjunto (tpv capturado - cancelado - chargeback)
  round(sum(net_tpv)::float / 100., 0)                                                     as net_tpv_capturado_reais
from
  digital_dataops.fact_tpv
    inner join digital_dataops.dim_affiliation
               using (affiliation_key)
    inner join digital_dataops.dim_service
               using (service_key)
    inner join digital_dataops.dim_date
               using (date_key)
    inner join digital_dataops.dim_payment
               using (payment_key)
    left join digital_dataops.encarteiramento_atual
              on dim_affiliation.internal_affiliation_id = encarteiramento_atual.internal_affiliation_id
where
  -- seleciona os produtos considerados, psp e adquirencia
  product_name in ('psp', 'acquirer')
  and payment_method in ('pix')
  -- filtra o periodo
  --and date_key >= date_trunc('month', current_date) - interval '1 month'
  and date_key >= 20200101
  -- remove mei/ton
  and dim_affiliation.affiliation_type != 'mei'
  -- filtra apenas os seguintes encarteiramentos pagarme no fechamento de cada mes
  and encarteiramento_atual.channel in ( 'PAGARME - GRANDES CONTAS', 'GRANDES CONTAS', 'PAGARME - PARCEIROS')
group by
  date_trunc('month', dimension_date)::date
order by
  mes
;
