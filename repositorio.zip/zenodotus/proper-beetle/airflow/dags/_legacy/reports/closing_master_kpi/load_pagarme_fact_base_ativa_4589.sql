insert into StoneDWv0.kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value
	)
SELECT '{{ ds }}',
	'4589' as kpi_index,
	'# Parceiros Ativos - Marketplaces' as kpi_name,
	mes as reference_date,
	'Pagar.me' as company,
	'PAGARME - PARCEIROS' as sales_channel,
	'MARKETPLACES' as sales_subchannel,
	'Não se aplica' as card_brand,
	'Não se aplica' as product,
	'Não se aplica' as installments,
	'Não se aplica' as acquirer,
	'Não se aplica' as rav_type,
	n_afiliacoes_ativas_gmv as kpi_value
from {{ ti.xcom_pull(task_ids='extract_pagarme_fact_base_ativa_4589') }} 