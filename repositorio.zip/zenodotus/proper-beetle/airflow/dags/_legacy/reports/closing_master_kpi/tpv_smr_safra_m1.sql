use StoneDWv0

--exclui tabelas temporárias
IF Object_id('tempdb..#BASE_EC_VALIDACAO') IS NOT NULL DROP TABLE #BASE_EC_VALIDACAO
IF Object_id('tempdb..#TPV_PROCESSADO_VALIDACAO') IS NOT NULL DROP TABLE #TPV_PROCESSADO_VALIDACAO
IF Object_id('tempdb..#RECEITA_RAV_VALIDACAO') IS NOT NULL DROP TABLE #RECEITA_RAV_VALIDACAO
IF Object_id('tempdb..#RECEITA_MENSALIDADE_VALIDACAO') IS NOT NULL DROP TABLE #RECEITA_MENSALIDADE_VALIDACAO
IF Object_id('tempdb..#BASE_ATIVA_VALIDACAO') IS NOT NULL DROP TABLE #BASE_ATIVA_VALIDACAO

--#Seleciona Publico 
SELECT ClientKey,
	NewCreatedDate as Data_de_Credenciamento,
	NewSalesForceRename,
	SalesStructureNameLevel1,
	SalesStructureNameLevel2,
	SalesStructureNameLevel3,
	SalesStructureNameLevel4,
	SalesStructureNameLevel5
INTO #BASE_EC_VALIDACAO
FROM StoneDWv0.kpi.ClientListHubs (nolock) A
/*WHERE 1 = 1
AND eomonth(NewCreatedDate) >= eomonth(eomonth(getdate()),-20) -- Filtro para selecionar safra(s)
*/

----------------------------------------------------------------------------------------------------------------------------

-- Busca TPV

SELECT A.ClientKey as ClientKey,
	SUM(ISNULL(TPV,0)) as TPV_Processado,
	SUM(ISNULL(DIA,0)) as Receita_MDR
INTO #TPV_PROCESSADO_VALIDACAO
FROM StoneDWv0.dbo.DimAffiliation (nolock) A
	LEFT JOIN StoneDWv0.dbo.FactMonthlyTPV (nolock) B ON A.AffiliationKey = B.AffiliationKey
	LEFT JOIN StoneDWv0.dbo.DimDate (nolock) C ON B.TransactionDate = C.DateKey
	LEFT JOIN #BASE_EC_VALIDACAO (nolock) E ON A.ClientKey = E.ClientKey
WHERE 1 = 1
	AND eomonth(FullDate) >= eomonth(Data_de_Credenciamento,1)
	AND eomonth(FullDate) < eomonth(Data_de_Credenciamento,2)
GROUP BY A.ClientKey

----------------------------------------------------------------------------------------------------------------------------

--#Busca Receita

SELECT A.ClientKey as ClientKey,
	SUM(ISNULL(Revenue,0)) as Receita_RAV
INTO #RECEITA_RAV_VALIDACAO
FROM StoneDWv0.dbo.DimAffiliation (nolock) A
	LEFT JOIN StoneDWv0.dbo.FactMonthlyRAV (nolock) B ON A.AffiliationKey = B.AffiliationKey
	LEFT JOIN StoneDWv0.dbo.DimDate (nolock) C ON B.ContractDate = C.DateKey
	LEFT JOIN #BASE_EC_VALIDACAO (nolock) E ON A.ClientKey = E.ClientKey
WHERE 1 = 1
	AND eomonth(FullDate) >= eomonth(Data_de_Credenciamento,1)
	AND eomonth(FullDate) < eomonth(Data_de_Credenciamento,2)
GROUP BY A.ClientKey

----------------------------------------------------------------------------------------------------------------------------

--# Busca receita mensalidade

SELECT A.ClientKey as ClientKey,
	SUM(ISNULL(ChargedRent,0)) as Receita_MENSALIDADE
INTO #RECEITA_MENSALIDADE_VALIDACAO
FROM StoneDWv0.dbo.DimAffiliation (nolock) A
	LEFT JOIN StoneDWv0.dbo.FactRental (nolock) B ON A.AffiliationKey = B.AffiliationKey
	LEFT JOIN StoneDWv0.dbo.DimDate (nolock) C ON B.DateKey = C.DateKey
	LEFT JOIN #BASE_EC_VALIDACAO (nolock) E ON A.ClientKey = E.ClientKey
WHERE 1 = 1
	AND eomonth(FullDate) >= eomonth(Data_de_Credenciamento,1)
	AND eomonth(FullDate) < eomonth(Data_de_Credenciamento,2)
GROUP BY A.ClientKey

----------------------------------------------------------------------------------------------------------------------------

--#Busca base ativa

SELECT A.ClientKey as ClientKey,
	CASE WHEN TPV_Processado > 1 THEN 1 ELSE 0 END as Base_Ativa
INTO #BASE_ATIVA_VALIDACAO
FROM #TPV_PROCESSADO_VALIDACAO (nolock) A
WHERE 1 = 1

--------------------------------------------------------------------------------------------------------------

--Insere TPV MÉDIO E RECEITA M1 POR SAFRA  na tabela de KPIs

INSERT INTO kpi.ClosingMasterKpi
	(
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	kpi_value
	)
	SELECT -- KPI 4027
		'{{ ds }}'
	, '4027'
	, 'TPV médio das safras novas'
	, EOMONTH(Data_de_Credenciamento)
	, 'STONE'
	, 'NAO SE APLICA'
	, 'NAO SE APLICA'
	, 'NAO SE APLICA'
	, SUM(ISNULL(TPV_Processado,0))/SUM(ISNULL(Base_Ativa,0)) as [TPV MÉDIO M1]
	FROM #BASE_EC_VALIDACAO (nolock) A
		LEFT JOIN #TPV_PROCESSADO_VALIDACAO TPV ON A.Clientkey = TPV.ClientKey
		LEFT JOIN #RECEITA_RAV_VALIDACAO RAV ON A.ClientKey = RAV.ClientKey
		LEFT JOIN #RECEITA_MENSALIDADE_VALIDACAO MEN ON A.ClientKey = MEN.ClientKey
		LEFT JOIN #BASE_ATIVA_VALIDACAO BA ON A.ClientKey = BA.ClientKey
	WHERE 1 = 1
		AND SalesStructureNameLevel1 = 'POLOS'
		AND EOMONTH(Data_de_Credenciamento) < EOMONTH('{{ ds }}')
	GROUP BY EOMONTH(Data_de_Credenciamento)
	having SUM(ISNULL(Base_Ativa,0))>0
	--ORDER BY EOMONTH(Data_de_Credenciamento)
UNION ALL
	SELECT -- KPI - 4028
		'{{ ds }}'
	, '4028'
	, 'Receita por cliente das safra m1'
	, EOMONTH(Data_de_Credenciamento)
	, 'STONE'
	, 'NAO SE APLICA'
	, 'NAO SE APLICA'
	, 'NAO SE APLICA'
	, (SUM(ISNULL(Receita_MDR,0))+SUM(ISNULL(Receita_RAV,0))+SUM(ISNULL(Receita_MENSALIDADE,0)))/SUM(ISNULL(Base_Ativa,0)) as [RECEITA MÉDIA M1]
	FROM #BASE_EC_VALIDACAO (nolock) A
		LEFT JOIN #TPV_PROCESSADO_VALIDACAO TPV ON A.Clientkey = TPV.ClientKey
		LEFT JOIN #RECEITA_RAV_VALIDACAO RAV ON A.ClientKey = RAV.ClientKey
		LEFT JOIN #RECEITA_MENSALIDADE_VALIDACAO MEN ON A.ClientKey = MEN.ClientKey
		LEFT JOIN #BASE_ATIVA_VALIDACAO BA ON A.ClientKey = BA.ClientKey
	WHERE 1 = 1
		AND SalesStructureNameLevel1 = 'POLOS'
		AND EOMONTH(Data_de_Credenciamento) < EOMONTH('{{ ds }}')
	GROUP BY EOMONTH(Data_de_Credenciamento)
	having SUM(ISNULL(Base_Ativa,0))>0
--ORDER BY EOMONTH(Data_de_Credenciamento)

--------------------------------------------------------------------------------------------------------------

