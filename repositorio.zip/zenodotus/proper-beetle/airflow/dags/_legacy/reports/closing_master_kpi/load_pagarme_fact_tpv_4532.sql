insert into StoneDWv0.kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value
	)
SELECT '{{ ds }}',
	'4532' as kpi_index,
	'Base ativa (Grupo Econômico)' as kpi_name,
	mes as reference_date,
	'Pagar.me' as company,
	'PAGARME - GRANDES CONTAS' as sales_channel,
	'KEY ACCOUNTS, MEDIUM, GRANDES CONTAS' as sales_subchannel,
	'Não se aplica' as card_brand,
	'Não se aplica' as product,
	'Não se aplica' as installments,
	'Não se aplica' as acquirer,
	'Não se aplica' as rav_type,
	n_afiliacoes_ativas_gmv as kpi_value
from {{ ti.xcom_pull(task_ids='extract_pagarme_fact_tpv_4532') }} 