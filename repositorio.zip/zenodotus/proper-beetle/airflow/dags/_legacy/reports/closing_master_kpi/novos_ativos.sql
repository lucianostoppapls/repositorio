
-- DECLARE @StartDate DATE = DATEADD(DAY,1,EOMONTH('{{ ds }}', -1));
-- DECLARE @EndDate DATE = EOMONTH('{{ ds }}');

IF OBJECT_ID('tempdb..#novosativos') IS NOT NULL
			DROP TABLE #novosativos

select CASE WHEN NewSalesForceReName = 'ESPECIALISTA' THEN 'POLO PROPRIO' ELSE NewSalesForceReName END as ForcaDeVendas,
	eomonth(newactivationdate) as reference_date,
	'Não se aplica' as company,
	SalesStructureNameLevel1 as sales_channel,
	SalesStructureNameLevel2 as sales_subchannel,
	'Não se aplica' as card_brand,
	'Não se aplica' as product,
	'Não se aplica' as installments,
	'Não se aplica' as acquirer,
	RAVChannelType as rav_type,
	count(clientkey) as kpi_value
into #novosativos
from stonedwv0.kpi.clientlisthubs
where /* newactivationdate between @StartDate and @EndDate -- (A pedido de BI - Juliana Terumi)
	And */ NewSalesForceReName in ('POLO PROPRIO', 'ESPECIALISTA','INBOUND','FRANQUIA') AND newactivationdate <= dateadd(mm, -1, eomonth('{{ ds }}' ))
group by CASE WHEN NewSalesForceReName = 'ESPECIALISTA' THEN 'POLO PROPRIO' ELSE NewSalesForceReName END,
		eomonth(newactivationdate),
		SalesStructureNameLevel1,
		SalesStructureNameLevel2,
		RAVChannelType

insert into StoneDWv0.kpi.ClosingMasterKpi
	(
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value
	)
	SELECT '{{ ds }}',
		4006 as kpi_index, --(A pedido de BI foi trocado de 1403 para 4006)
		'Novos ativos polo' as kpi_name,
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		rav_type,
		kpi_value
	from #novosativos
	where ForcaDeVendas = 'POLO PROPRIO'

union

	SELECT '{{ ds }}',
		4009 as kpi_index, -- (A pedido de BI foi trocado de 1404 para 4009)
		'Novos ativos franquia' as kpi_name,
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		rav_type,
		kpi_value
	from #novosativos
	where ForcaDeVendas = 'FRANQUIA'

union

	SELECT '{{ ds }}',
		4012 as kpi_index, -- (A pedido de BI foi trocado de 1405 para 4012)
		'Novos ativos inbound' as kpi_name,
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		rav_type,
		kpi_value
	from #novosativos
	where ForcaDeVendas = 'INBOUND'

union

	select '{{ ds }}'
		, '4005' kpi_index
		, 'Novos Ativos Payments' kpi_name
		, reference_date
		, 'Stone' company
		, sales_channel
		, sales_subchannel
		, card_brand
		, product
		, installments
		, acquirer
		, rav_type
		, sum(kpi_value) kpi_value
	from StoneDWv0.kpi.ClosingMasterKpi
	where kpi_index in ('4006' /*POLOS*/
					,'4009' /*Franquia*/
					,'4012' /*INBOUND*/ 
					,'4014' /*PAGARME*/)-- (1403,1404,1405,4014) 
		and execution_date between dateadd(mm, -1,dateadd(dd, +1, eomonth('{{ ds }}'))) AND eomonth('{{ ds }}')
	--and reference_date = '2021-10-31'
	group by   reference_date
		 , sales_channel
		 , sales_subchannel
		 , card_brand
		 , product
		 , installments
		 , acquirer
		 , rav_type