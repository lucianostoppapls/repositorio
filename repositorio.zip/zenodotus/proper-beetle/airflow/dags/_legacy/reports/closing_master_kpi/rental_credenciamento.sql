SELECT
	eomonth(FullDate) AS reference_date,
	CompanyName AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	ss.SalesStructureNameLevel2 AS sales_subchannel,
	sum(rental.ChargedRent) charged_rent,
	sum(rental.TotalPOS) total_pos
INTO #rental_m0
FROM stonedwv0.dbo.FactRental rental
JOIN stonedwv0.dbo.DimDate dt ON rental.DateKey = dt.DateKey
JOIN stonedwv0.dbo.DimCompany company ON rental.CompanyKey = company.CompanyKey
JOIN stonedwv0.dbo.DimAffiliation affiliation ON rental.AffiliationKey = affiliation.AffiliationKey
JOIN stonedwv0.dbo.DimClient client ON affiliation.ClientKey = client.ClientKey
JOIN stonedwv0.dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN stonedwv0.dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
WHERE
	eomonth(convert(varchar, client.createdate)) = eomonth(FullDate)
GROUP BY
	eomonth(FullDate),
	CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2;


INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	kpi_value
)
	SELECT
		'{{ ds }}',
		'0346',
		'Receita Aluguel M0',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		sum(charged_rent)
	FROM
		#rental_m0
	WHERE
		reference_date <= eomonth('{{ ds }}', -1)
	GROUP BY
		reference_date,
		company,
		sales_channel,
		sales_subchannel