-- SCRIPT PARA KPI 4619.1 - Receita nMDR Marketplace - Suporte ID 4619

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	kpi_value
	)
 
SELECT '{{ ds }}',
	'4619.1',
	'Receita nMDR Marketplace',
	reference_date,
	company,
  sales_channel,
	sales_subchannel,
	rav_type,
	SUM(kpi_value) AS ReceitaDIA
FROM [StoneDWv0].[kpi].[ClosingMasterKpi]
WHERE kpi_index = '0006'
AND sales_channel = 'PAGARME - PARCEIROS'
AND sales_subchannel = 'MARKETPLACES'
AND execution_date between dateadd(mm, -1,dateadd(dd, +1, eomonth('{{ ds }}'))) AND eomonth('{{ ds }}')
GROUP BY
reference_date,
company,
sales_channel,
sales_subchannel,
rav_type
