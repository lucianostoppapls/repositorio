-- STNE Management Report - Pagarme - TPV
select
  date_trunc('month', dimension_date)::date                                        as mes,
  -- tpv total para o conjunto
  sum(tpv)::float / 100                                                         as tpv_capturado_reais,
  -- tpv apenas para psp
  sum(case when product_name = 'psp' then tpv else 0 end)::float / 100          as tpv_capturado_psp_reais,
  -- tpv apenas para adquirente
  sum(case when product_name = 'acquirer' then tpv else 0 end)::float / 100     as tpv_capturado_adquirencia_reais,
  -- net tpv total para o conjunto (tpv capturado - cancelado - chargeback)
  sum(net_tpv)::float / 100                                                     as net_tpv_capturado_reais,
  -- net tpv para psp
  sum(case when product_name = 'psp' then net_tpv else 0 end)::float / 100      as net_tpv_capturado_psp_reais,
  -- net tpv para adquirencia
  sum(case when product_name = 'acquirer' then net_tpv else 0 end)::float / 100 as net_tpv_capturado_adquirencia_reais
from
  digital_dataops.fact_tpv
    inner join digital_dataops.dim_affiliation
               using (affiliation_key)
    inner join digital_dataops.dim_service
               using (service_key)
    inner join digital_dataops.dim_date
               using (date_key)

    left join digital_dataops.encarteiramento_historico
              on dim_affiliation.internal_affiliation_id = encarteiramento_historico.internal_affiliation_id and
                date_trunc('month', dim_date.dimension_date)::date = encarteiramento_historico.mes_enc
where
  -- seleciona os produtos considerados, psp e adquirencia
  product_name in ('psp', 'acquirer')
  -- filtra o periodo
  and date_key >= date_trunc('month', current_date) - interval '1 month'
  -- remove mei/ton
  and dim_affiliation.affiliation_type != 'mei'
  -- filtra apenas os seguintes encarteiramentos pagarme no fechamento de cada mes
  and encarteiramento_historico.channel in (
                                            'DIGITAL',
                                            'Digital',
                                            'INT PARTNERSHIPS',
                                            'PAGARME - GRANDES CONTAS',
                                            'PAGARME - KEY ACCOUNTS',
                                            'PAGARME - PARCEIROS',
                                            'PAGARME - SMB')
group by
  date_trunc('month', dimension_date)::date
order by mes
;
