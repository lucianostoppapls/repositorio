with daily_transactions as (
    select
        date_trunc('day', gop.created_at::timestamp with time zone at time zone 'America/Sao_Paulo')::date as "day",
        c.cnpj as document,
        count(gop.id) as transactions
    from pagarme_live.gatewayoperations gop
    inner join pagarme_mongo.v_companies c on gop.company_id = c.id
--    inner join pagarme_mongo.companies c on gop.company_id = c.id
    where
        date_trunc('day', gop.created_at::timestamp with time zone at time zone 'America/Sao_Paulo')::date >= '2021-04-01'::date
        and gop.model = 'transaction'
        and gop.status = 'success'
        and gop."type" = 'capture'
        and gop.processor = 'stone'
        and c."type" = 'mei'
        and c.id not in (
            '5ad0fa5f14604ca94154f4b2','5ad10c670969b06c247969ea', '5ad59211466d81740ff71108', '5ad8c5e922dc361071eca529', '5afb2cc874766e3a055374d0', '5ac85e0c70dd1bdc02253bc8',
            '5acbd1d6adcb30f16e40be84', '5ad594e10176cec40f29f48f', '5af5a5666d16d0260b080bc0', '5b16ae98f6e99a064e6f8408', '5ad0f946489ff57c20d3b13e', '5af9a95ede4831fb3cde7138',
            '5ad10d2c0969b06c247969f0', '5af50950eae1713847b5c5d9', '58c162edfdc8066f788ce7b7', '5ad10d2e1e60585909ab917d', '5af13faa86209a183dd44b58', '5ac6b3aa355646261df5630e',
            '5ad656015e7efbdf53760f4a', '5b071d46a03da65c4b91dbb2', '5ad59469686674b5727bf52c', '5af1454791e832a53d0f4ac6', '5b06e9f28417e5924f13c3ca', '5ad10d2f1e7439c821ea269a',
            '5ad667d125e71d485a607d94', '5af58678f6dd371e35a38e96', '5b0dc293f87b8ff80f4faa31', '5ad10c590969b06c247969d6'
        )
        group by
                date_trunc('day', gop.created_at::timestamp with time zone at time zone 'America/Sao_Paulo')::date,
                c.cnpj
        order by
                date_trunc('day', gop.created_at::timestamp with time zone at time zone 'America/Sao_Paulo')::date
),
--select created_at, created_at::timestamp with time zone at time zone 'America/Sao_Paulo', date_trunc('day', gop.created_at::timestamp with time zone at time zone 'America/Sao_Paulo')::date, last_day(date_trunc('day', gop.created_at::timestamp with time zone at time zone 'America/Sao_Paulo')::date) from pagarme_live.gatewayoperations gop limit 1

all_documents_all_months as (
    select distinct
        m."month",
        dt.document
    from daily_transactions dt
    cross join (
        select distinct
            last_day(dt."day")::date as "month"
        from daily_transactions dt
    ) m
),

ninety_days_measures as (
    select
        adam."month",
        adam.document,
        coalesce(sum(dt.transactions), 0) as transactions
    from all_documents_all_months adam
    left join daily_transactions dt on dt.document = adam.document and dt."day" between (adam."month" - interval '89 day')::date and adam."month" -- - interval '75 day')
    group by
        adam."month",
        adam.document
)

select
    ndm."month" as fulldate,
    ndm."document" as document,
    ndm."transactions" as transactions
from ninety_days_measures ndm