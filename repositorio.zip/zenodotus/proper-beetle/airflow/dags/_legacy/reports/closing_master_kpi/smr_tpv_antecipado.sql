use stonedwv0

select REFERENCE_DATE,
	SALES_CHANNEL,
	company,
	sales_subchannel,
	card_brand,
	product,
	installments,
	'NAO SE APLICA' AS ACQUIRER,
	'NAO SE APLICA' AS RAV_TYPE,
	SUM(KPI_VALUE) KPI_VALUE
into #antecipado
from kpi.closingmasterkpi
where eomonth(reference_date) >= '2016-01-31'
	and execution_date between DATEADD(month, DATEDIFF(month, 0, '{{ ds }}'), 0) AND eomonth('{{ ds }}')
	and kpi_index = '0200'
	and sales_channel in ('POLOS','PAGARME - SMB')
group by REFERENCE_DATE,
		SALES_CHANNEL,
		company,
		sales_subchannel,
		card_brand,
		product,
		installments
;

insert into kpi.ClosingMasterKpi
	(
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value
	)
	select '{{ ds }}',
		'4046.2' as kpi_index,
		'R$ TPV Antecipado Polos' as kpi_name,
		ant.reference_date,
		ant.company,
		ant.sales_channel,
		ant.sales_subchannel,
		ant.card_brand,
		ant.product,
		ant.installments,
		ant.ACQUIRER,
		ant.RAV_TYPE,
		SUM(ant.kpi_value) kpi_value
	from #antecipado ant
	where ant.sales_channel = 'POLOS'
	group by ant.reference_date,
	ant.company,
	ant.sales_channel,
	ant.sales_subchannel,
	ant.card_brand,
	ant.product,
	ant.installments,
	ant.ACQUIRER,
	ant.RAV_TYPE

UNION ALL

	select '{{ ds }}',
		'4046.3' as kpi_index,
		'R$ TPV Antecipado Pagar.me - SMB' as kpi_name,
		ant.reference_date,
		ant.company,
		ant.sales_channel,
		ant.sales_subchannel,
		ant.card_brand,
		ant.product,
		ant.installments,
		ant.ACQUIRER,
		ant.RAV_TYPE,
		SUM(ant.kpi_value) kpi_value
	from #antecipado ant
	where ant.sales_channel = 'PAGARME - SMB'
	group by ant.reference_date,
	ant.company,
	ant.sales_channel,
	ant.sales_subchannel,
	ant.card_brand,
	ant.product,
	ant.installments,
	ant.ACQUIRER,
	ant.RAV_TYPE

UNION ALL

	select '{{ ds }}',
		'4046.1' as kpi_index,
		'R$ TPV Antecipado' as kpi_name,
		ant.reference_date,
		ant.company,
		ant.sales_channel,
		ant.sales_subchannel,
		ant.card_brand,
		ant.product,
		ant.installments,
		ant.ACQUIRER,
		ant.RAV_TYPE,
		SUM(ant.kpi_value) kpi_value
	from #antecipado ant
	group by ant.reference_date,
	ant.company,
	ant.sales_channel,
	ant.sales_subchannel,
	ant.card_brand,
	ant.product,
	ant.installments,
	ant.ACQUIRER,
	ant.RAV_TYPE
;