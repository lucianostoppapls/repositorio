INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	kpi_value
	)
SELECT '{{ ds }}',
	'1401',
	'Número de Credenciamentos',
	eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	count(DISTINCT ClientKey)
FROM (
	select
		assh.SalesStructureKey as SalesStructureKey,
		assh.ClientKey,
		min(a.CreateDate) as CreateDate,
		min(a.CompanyKey) as CompanyKey
	from dbo.DimAffiliationSalesStructureHist assh
	inner join dbo.DimAffiliation a on assh.AffiliationKey = a.AffiliationKey
	where
		assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
	group by
		assh.SalesStructureKey,
		assh.ClientKey
) client
JOIN dbo.DimDate dt ON client.CreateDate = dt.DateKey
JOIN dbo.DimSalesStructure ss ON client.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimCompany company ON client.CompanyKey = company.CompanyKey
GROUP BY eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2

UNION ALL

SELECT '{{ ds }}',
	'0115',
	'Número de Propostas Credenciamento',
	eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	count(DISTINCT ClientAlternateKey)
FROM dbo.DimAffiliation affiliation
JOIN dbo.DimDate dt ON affiliation.CreateDate = dt.DateKey
join dbo.DimAffiliationSalesStructureHist assh on assh.AffiliationKey = affiliation.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimCompany company ON affiliation.CompanyKey = company.CompanyKey
WHERE affiliation.CompanyKey IN (1, 2)
GROUP BY eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2

UNION ALL

SELECT '{{ ds }}',
	'1402',
	'Churn EC',
	eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	count(distinct churn.clientkey)
FROM dbo.FactChurnHistory churn
join dbo.DimAffiliation a on churn.AffiliationKey = a.AffiliationKey
join dbo.DimAffiliationSalesStructureHist assh on a.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimDate dt ON churn.TransactionDate = dt.DateKey
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimCompany company ON a.CompanyKey = company.CompanyKey
where
	churn = 1 and flagchurn = 1
GROUP BY eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2

UNION ALL

SELECT '{{ ds }}',
	'0023',
	'Ativados M0',
	eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	count(distinct activebase.clientkey)
FROM dbo.FactActiveBaseHistory activebase
JOIN (
	select
		assh.SalesStructureKey as SalesStructureKey,
		assh.AffiliationKey as AffiliationKey,
		assh.ClientKey,
		min(a.CreateDate) as CreateDate,
		min(a.CompanyKey) as CompanyKey
	from dbo.DimAffiliationSalesStructureHist assh
	inner join dbo.DimAffiliation a on assh.AffiliationKey = a.AffiliationKey
	where
		assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
	group by
		assh.SalesStructureKey,
		assh.AffiliationKey,
		assh.ClientKey
) client ON activebase.AffiliationKey = client.AffiliationKey
JOIN dbo.DimDate dt ON activebase.TransactionDate = dt.DateKey
JOIN dbo.DimDate dt_cred ON client.CreateDate = dt_cred.DateKey
JOIN dbo.DimSalesStructure ss ON client.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimCompany company ON client.CompanyKey = company.CompanyKey
WHERE
	EOMONTH(dt.FullDate) = eomonth(dt_cred.FullDate)
	and activebase.FlagActiveBase = 1
GROUP BY eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2

UNION ALL

SELECT '{{ ds }}',
	'0024',
	'Clientes Reativados',
	eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	count(distinct reactivation.clientkey)
FROM dbo.FactReactivationHistory  reactivation
JOIN (
	select
		assh.SalesStructureKey as SalesStructureKey,
		assh.AffiliationKey as AffiliationKey,
		assh.ClientKey,
		min(a.CreateDate) as CreateDate,
		min(a.CompanyKey) as CompanyKey
	from dbo.DimAffiliationSalesStructureHist assh
	inner join dbo.DimAffiliation a on assh.AffiliationKey = a.AffiliationKey
	where
		assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
	group by
		assh.SalesStructureKey,
		assh.AffiliationKey,
		assh.ClientKey
) client ON reactivation.AffiliationKey = client.AffiliationKey
JOIN dbo.DimDate dt ON reactivation.TransactionDate = dt.DateKey
JOIN dbo.DimSalesStructure ss ON client.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimCompany company ON client.CompanyKey = company.CompanyKey
where
	reactivation.Reactivation = 1
GROUP BY eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2

UNION ALL

SELECT '{{ ds }}' execution_date,
	'0049' ,
	'Ativados Tardios' ,
	eomonth(B.FirstActivation) ,
	A.CompanyName,
	C.SalesStructureNameLevel1,
	C.SalesStructureNameLevel2,
	count(DISTINCT A.ClientKey) 
FROM (
		SELECT A.AffiliationKey
			, MIN(D.FullDate) CreateDate
			, C.SalesStructureKey
			, E.CompanyName
			, C.ClientKey
		FROM DimAffiliation A
			JOIN DimClient B
				ON A.ClientKey = B.ClientKey
			JOIN DimAffiliationSalesStructureHist C
				ON A.AffiliationKey = C.AffiliationKey
				AND C.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
			JOIN DimDate D
				ON B.CreateDate = D.DateKey
			JOIN DimCompany E
				ON A.CompanyKey = E.CompanyKey
		GROUP BY A.AffiliationKey
			, C.SalesStructureKey
			, E.CompanyName
			, C.ClientKey) A
	JOIN (
			SELECT A.AffiliationKey
				, MIN(FullDate) FirstActivation
			FROM FactActiveBaseHistory A
				JOIN DimDate B
					ON A.TransactionDate = B.DateKey
			WHERE FlagActiveBase = 1
			GROUP BY A.AffiliationKey) B
		ON A.AffiliationKey = B.AffiliationKey
	JOIN DimSalesStructure C
		ON A.SalesStructureKey = C.SalesStructureKey
WHERE B.FirstActivation > EOMONTH(A.CreateDate)
GROUP BY EOMONTH(B.FirstActivation) ,
	A.CompanyName,
	C.SalesStructureNameLevel1,
	C.SalesStructureNameLevel2

UNION ALL

SELECT '{{ ds }}',
	'0404',
	'Churn TPV',
	eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	sum(ChurnTPV)
FROM dbo.FactChurnHistory churn
join dbo.DimAffiliation a on churn.AffiliationKey = a.AffiliationKey
join dbo.DimAffiliationSalesStructureHist assh on a.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimDate dt ON churn.TransactionDate = dt.DateKey
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimCompany company ON a.CompanyKey = company.CompanyKey
where
	churn = 1 and flagchurn = 1
GROUP BY eomonth(dt.FullDate),
	company.CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2
