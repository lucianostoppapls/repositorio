DROP TABLE IF EXISTS #DataReferencia;

SELECT CAST(EOMONTH(fulldate)AS DATE) AS DataFim
INTO #DataReferencia
FROM StoneDWv0.dbo.dimdate
WHERE EOMONTH(fulldate)>= EOMONTH(GETDATE(),-24)
	AND EOMONTH(fulldate)<= EOMONTH(GETDATE())
GROUP BY CAST(eomonth(fulldate)AS DATE);

DROP TABLE IF EXISTS #BaseAtivaAdquirencia;

SELECT
	EOMONTH(GETDATE()) AS execution_date
	, dt.DataFim AS reference_date	
	, DC.CompanyName AS company
	, C.SalesStructureNameLevel1 AS sales_channel
	, C.SalesStructureNameLevel2 AS sales_subchannel
	, COUNT(DISTINCT RTrim(ClientCNPJorCPF)) AS kpi_value
	, CASE When ClientCNPJorCPF IS NOT NULL
		THEN 'A' ELSE '' END product
INTO #BaseAtivaAdquirencia
FROM [Stonedwv0].[dbo].[FactTPV] AS A
	JOIN [Stonedwv0].[dbo].[DimAffiliation]	AS B ON A.AffiliationKey = B.AffiliationKey
	JOIN [Stonedwv0].[dbo].[DimSalesStructure] AS C ON B.SalesStructureKey = C.SalesStructureKey
	JOIN [Stonedwv0].[dbo].[DimDate] AS D ON A.TransactionDate = D.DateKey
	JOIN #DataReferencia AS dt ON D.FullDate >= dateadd(day, -29, dt.DataFim) AND D.FullDate <= dt.DataFim
	JOIN [Stonedwv0].[dbo].[DimCompany]		AS DC ON A.CompanyKey = DC.CompanyKey
WHERE  A.TypeKey = 1
	AND A.Transactions >= 1
	AND SalesStructureNameLevel1 = 'POLOS'
	AND B.CompanyKey in (1,2)
	AND A.TransactionDate <= CONVERT(VARCHAR, EOMONTH('{{ ds }}', -1), 112)
GROUP BY DC.CompanyName
	, C.SalesStructureNameLevel1
	, C.SalesStructureNameLevel2
	, dt.DataFim
	, CASE WHEN ClientCNPJorCPF IS NOT NULL THEN 'A'
		ELSE '' END
;

INSERT INTO kpi.ClosingMasterKpi
	(
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value )
select '{{ ds }}'
		, '4003.2' kpi_index
		, 'Base Ativa Hubs rolling 30' kpi_name
		, reference_date
		, company
		, sales_channel
		, sales_subchannel
		, 'Não se aplica' card_brand
		, product
		, 'Não se aplica' installments
		, 'Não se aplica' acquirer
		, 'Não se aplica' rav_type
		, sum(kpi_value) as kpi_value

from #BaseAtivaAdquirencia
group by  execution_date
		, reference_date
		, company
		, sales_channel
		, sales_subchannel
		, product