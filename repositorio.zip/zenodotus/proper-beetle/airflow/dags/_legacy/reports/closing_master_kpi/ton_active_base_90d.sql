DECLARE @StartDate DATE = EOMONTH('{{ ds }}', -1);
DECLARE @EndDate DATE = EOMONTH('{{ ds }}', -1);;
DECLARE @MostRecentDateAtMasterKPI DATE = '{{ ds }}';

DELETE FROM StoneDWv0.kpi.FPATopLineReport WHERE reference_date = @EndDate and kpi in ('Active Clients Stone e Stone +', 'Active Clients Stone+');

WITH DailyMeasures AS (
    SELECT
        DD.FullDate AS [Day],
        DC.ClientCNPJorCPF AS [ClientDocument],
        SUM(CASE WHEN DT.TypeName = 'Capturado' THEN fT.Transactions ELSE 0 END) AS [Transactions]
    FROM StoneDWv0.dbo.FactTPV  fT
    INNER JOIN StoneDWv0.dbo.DimDate DD ON DD.DateKey = fT.TransactionDate
    INNER JOIN StoneDWv0.dbo.DimAffiliation DA ON DA.AffiliationKey = fT.AffiliationKey
    INNER JOIN StoneDWv0.dbo.DimClient DC ON DC.ClientKey = DA.ClientKey
    INNER JOIN StoneDWv0.dbo.DimType DT ON DT.TypeKey = fT.TypeKey
    INNER JOIN StoneDWv0.dbo.DimProduct DP ON DP.ProductKey = fT.ProductKey
    WHERE
        DD.FullDate BETWEEN DATEADD(DAY, -89, @StartDate) AND EOMONTH(@EndDate)
        AND fT.CompanyKey IN (1, 2)
        AND DT.TypeName <> 'Gateway'
        AND DP.ProductName <> 'Boleto'
    GROUP BY
        DD.FullDate,
        DC.ClientCNPJorCPF
),

AllDocumentsAllMonths AS (
    SELECT DISTINCT
        EOMONTH([DD].[FullDate]) AS [Month],
        [DC].[ClientCNPJorCPF] AS [ClientDocument]
    FROM StoneDWv0.dbo.[DimClient] DC
    CROSS JOIN StoneDWv0.dbo.[DimDate] DD
    WHERE
        [DD].[FullDate] BETWEEN DATEADD(DAY, -89, @StartDate) AND EOMONTH(@EndDate)
        AND [DC].[CompanyKey] IN (1, 2)
    GROUP BY
        [DD].[FullDate],
        [DC].[ClientCNPJorCPF]
),

AllExtractTon90d AS (
        SELECT *
        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d')}} 
--        UNION ALL
--        SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part2')}}
--        UNION ALL
--        SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part3')}}        
--        UNION ALL
--        SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part4')}}       
--        UNION ALL
--       SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part5')}}       
--        UNION ALL
--        SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part6')}}                               
),

NinetyDaysMeasures AS (
    SELECT
        [ADAM].[Month],
        [ADAM].[ClientDocument],
        SUM([DM].[Transactions]) AS [NinetyDaysTransactions]
    FROM AllDocumentsAllMonths ADAM
    LEFT JOIN [DailyMeasures] DM ON [ADAM].[ClientDocument] = [DM].[ClientDocument] AND [DM].[Day] BETWEEN DATEADD(day, -89, [ADAM].[Month]) AND [ADAM].[Month]
    GROUP BY
        [ADAM].[Month],
        [ADAM].[ClientDocument]
),

augmented_ninety_days_measures AS (
    select
        coalesce(ndm.[Month], sm.fulldate) as [Month],
        coalesce(ndm.[ClientDocument], sm.document) as [ClientDocument],
        coalesce(ndm.[NinetyDaysTransactions], 0) + coalesce(sm.transactions, 0) as [NinetyDaysTransactions]
    from NinetyDaysMeasures ndm
    full outer join AllExtractTon90d sm on ndm.ClientDocument = sm.document and ndm.[Month] = sm.fulldate
)


INSERT INTO StoneDWv0.kpi.FPATopLineReport (
    reference_date,
    breakdown,
    kpi,
    [value]
)
SELECT
    NDM.[Month],
    NULL,
    'Active Clients Stone e Stone +',
    SUM(CASE WHEN COALESCE([NDM].[NinetyDaysTransactions], 0) > 0 THEN 1 ELSE 0 END) AS [ClientCount90Days]
FROM augmented_ninety_days_measures NDM
WHERE
    NDM.[Month] between @StartDate AND @EndDate
GROUP BY
    NDM.[Month]
ORDER BY
    NDM.[Month] ASC;

INSERT INTO StoneDWv0.kpi.FPATopLineReport (
    reference_date,
    breakdown,
    kpi,
    [value]
)
SELECT
    fulldate,
    NULL,
    'Active Clients Stone+',
    count(distinct document)
FROM {{ ti.xcom_pull(task_ids='extract_ton_active_base_90d') }}
WHERE
    fulldate between @StartDate AND @EndDate
    and transactions > 0
GROUP BY
    fulldate;


DELETE FROM StoneDWv0.kpi.ClosingMasterKPI
WHERE
    execution_date = @MostRecentDateAtMasterKPI
    AND kpi_index in ('0057', '0058');


INSERT INTO [kpi].[ClosingMasterKpi](
    [execution_date],
    [kpi_index],
    [kpi_name],
    [reference_date],
    [kpi_value]
)
SELECT
    @MostRecentDateAtMasterKPI,
    '0057',
    'Base Ativa 90D Stone Mais',
    reference_date,
    value
FROM StoneDWv0.kpi.fpatoplinereport
WHERE
    kpi = 'Active Clients Stone+'
UNION ALL
SELECT
    @MostRecentDateAtMasterKPI,
    '0058',
    'Base Ativa 90D Stone e Stone Mais',
    reference_date,
    value
FROM StoneDWv0.kpi.fpatoplinereport
WHERE
    kpi = 'Active Clients Stone e Stone +'
ORDER BY
    reference_date;
