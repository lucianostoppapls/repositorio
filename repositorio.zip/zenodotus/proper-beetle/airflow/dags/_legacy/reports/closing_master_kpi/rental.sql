SELECT eomonth(FullDate) AS reference_date,
	CompanyName AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	ss.SalesStructureNameLevel2 AS sales_subchannel,
	sum(rental.ChargedRent) charged_rent,
	sum(rental.TotalPOS) total_pos
INTO #rental
FROM [dbo].FactRental rental
JOIN dbo.DimDate dt ON rental.DateKey = dt.DateKey
JOIN dbo.DimCompany company ON rental.CompanyKey = company.CompanyKey
JOIN dbo.DimAffiliation affiliation ON rental.AffiliationKey = affiliation.AffiliationKey
JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
GROUP BY eomonth(FullDate),
	CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2;

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	kpi_value
	)
SELECT '{{ ds }}',
	'0301',
	'Aluguel Médio',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	sum(charged_rent) / nullif(sum(total_pos), 0)
FROM #rental
WHERE reference_date <= eomonth('{{ ds }}', -1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel

UNION ALL

SELECT '{{ ds }}',
	'0347',
	'Parque Cobrado Total',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	sum(total_pos)
FROM #rental
WHERE reference_date <= eomonth('{{ ds }}', -1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel

UNION ALL

SELECT '{{ ds }}',
	'0302',
	'Receita de Aluguel',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	sum(charged_rent)
FROM #rental
WHERE reference_date <= eomonth('{{ ds }}', -1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel