select distinct
	TransactionDate,
	AffiliationKey
into #tpv
from StoneDWv0.dbo.FactTPV
where
	TypeKey = 1
	and Transactions > 0
	and CompanyKey in (1, 2)
;
CREATE NONCLUSTERED INDEX cx_temptpv ON #tpv (TransactionDate);
CREATE NONCLUSTERED INDEX cx_temptpv_aff ON #tpv (AffiliationKey);


select distinct
	eomonth(FullDate) as FullDate
into #date
from StoneDWv0.dbo.DimDate
where FullDate >= '2012-01-01' and Fulldate <= eomonth('{{ ds }}', -1)
;
CREATE CLUSTERED INDEX cx_tempdate ON #date (FullDate);


INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	kpi_value
)
	SELECT
		'{{ ds }}' as execution_date,
		'0055' as kpi_index,
		'Base Ativa 90D Stone' as kpi_name,
		eomonth(dt.FullDate) as reference_date,
		'Stone' as company,
		null as sales_channel,
		null as sales_subchannel,
		count(distinct affiliation.ClientCNPJorCPF) as kpi_value
	from StoneDWv0.dbo.DimAffiliation  affiliation
	join #tpv tpv on affiliation.AffiliationKey = tpv.AffiliationKey
	cross join #date dt
	where
		 convert(varchar,tpv.TransactionDate) between DATEADD(day, -89, dt.FullDate) and dt.FullDate
	group by
		eomonth(dt.FullDate)

	UNION ALL

	SELECT
		'{{ ds }}' as execution_date,
		'0056' as kpi_index,
		'Base Ativa 90D BU' as kpi_name,
		eomonth(dt.FullDate) as reference_date,
		'Stone' as company,
		ss.SalesStructureNameLevel1 as sales_channel,
		null as sales_subchannel,
		count(distinct affiliation.ClientCNPJorCPF) as kpi_value
	from StoneDWv0.dbo.DimAffiliation  affiliation
	join StoneDWv0.dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
	join StoneDWv0.dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey	
	join #tpv tpv on affiliation.AffiliationKey = tpv.AffiliationKey
	cross join #date dt
	where
		 convert(varchar,tpv.TransactionDate) between DATEADD(day, -89, dt.FullDate) and dt.FullDate
	group by
		eomonth(dt.FullDate),
		ss.SalesStructureNameLevel1
	;
