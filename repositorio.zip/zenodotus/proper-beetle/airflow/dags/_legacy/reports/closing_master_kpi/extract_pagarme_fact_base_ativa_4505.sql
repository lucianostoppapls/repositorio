-- STNE Management Report - Pagarme - Base ativa
select
  date_trunc('month', dimension_date)::date                                                                      as mes,
  count(distinct case when base_ativa_gmv.is_base_ativa = true then encarteiramento_atual.group_3 end) as n_grupo3_ativas_gmv
from
  digital_dataops.fact_base_ativa
    inner join digital_dataops.dim_base_ativa_status as base_ativa_gmv
               on fact_base_ativa.gmv_total_base_ativa_status_key = base_ativa_gmv.base_ativa_status_key
    inner join digital_dataops.dim_affiliation
               using (affiliation_key)
    inner join digital_dataops.dim_date
               using (date_key)
    left join digital_dataops.encarteiramento_atual
              on dim_affiliation.internal_affiliation_id = encarteiramento_atual.internal_affiliation_id
where
  date_key >= date_trunc('month', current_date) - interval '1 month'
  -- remove mei/ton
  and dim_affiliation.affiliation_type != 'mei'
  -- filtra apenas os seguintes encarteiramentos pagarme no fechamento de cada mes
  and encarteiramento_atual.channel in (
                                            'PAGARME - GRANDES CONTAS',
                                            'PAGARME - PARCEIROS')
group by
  date_trunc('month', dimension_date)::date
order by
  mes
;