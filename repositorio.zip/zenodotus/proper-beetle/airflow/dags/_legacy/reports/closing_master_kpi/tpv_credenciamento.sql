SELECT
	eomonth(FullDate) AS reference_date,
	CompanyName AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	ss.SalesStructureNameLevel2 AS sales_subchannel,
	flag.FlagName AS card_brand,
	product.ProductName AS product,
	installment.InstallmentName AS installments,
	acquirer.AcquirerName AS acquirer,
	tpv.TypeKey AS type_key,
	sum(tpv) tpv,
	sum(Transactions) transactions,
	sum(MDR) MDR,
	sum(Dia) Dia
INTO #tpv_m0
FROM stonedwv0.dbo.FactTPV tpv
JOIN stonedwv0.dbo.DimDate dt ON tpv.TransactionDate = dt.DateKey
JOIN stonedwv0.dbo.DimCompany company ON tpv.CompanyKey = company.CompanyKey
JOIN stonedwv0.dbo.DimAffiliation affiliation ON tpv.AffiliationKey = affiliation.AffiliationKey
JOIN stonedwv0.dbo.DimClient client ON affiliation.ClientKey = client.ClientKey
JOIN stonedwv0.dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN stonedwv0.dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN stonedwv0.dbo.DimFlag flag ON tpv.FlagKey = flag.Flagkey
JOIN stonedwv0.dbo.DimProduct product ON tpv.ProductKey = product.ProductKey
JOIN stonedwv0.dbo.DimInstallment installment ON tpv.InstallmentKey = installment.InstallmentKey
JOIN stonedwv0.dbo.Dimacquirer acquirer ON tpv.AcquirerKey = acquirer.AcquirerKey
WHERE
	eomonth(convert(varchar, client.createdate)) = eomonth(FullDate)
GROUP BY
	eomonth(FullDate),
	CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	flag.FlagName,
	product.ProductName,
	installment.InstallmentName,
	acquirer.AcquirerName,
	tpv.TypeKey

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	kpi_value
)
	SELECT
		'{{ ds }}',
		'0040',
		'TPV Processado M0',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		sum(tpv)
	FROM
		#tpv_m0
	WHERE
		reference_date BETWEEN '2016-01-01' AND eomonth('{{ ds }}', - 1)
		AND acquirer IN ('Stone', 'Elavon')
		AND type_key IN (0, 1, 3, 9, 10)
		AND company <> 'MundiPagg'
		AND product <> 'Boleto'
	GROUP BY
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer

	UNION ALL

	SELECT
		'{{ ds }}',
		'0033',
		'DIA M0',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		sum(dia)
	FROM
		#tpv_m0
	WHERE
		reference_date BETWEEN '2016-01-01' AND eomonth('{{ ds }}', - 1)
		AND acquirer IN ('Stone', 'Elavon')
		AND type_key IN (0, 1, 3, 9, 10)
		AND company <> 'MundiPagg'
		AND product <> 'Boleto'
	GROUP BY
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer
;


SELECT
	eomonth(FullDate) AS reference_date,
	CompanyName AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	ss.SalesStructureNameLevel2 AS sales_subchannel,
	flag.FlagName AS card_brand,
	product.ProductName AS product,
	installment.InstallmentName AS installments,
	acquirer.AcquirerName AS acquirer,
	tpv.TypeKey AS type_key,
	sum(tpv) tpv,
	sum(Transactions) transactions,
	sum(MDR) MDR,
	sum(Dia) Dia
INTO #tpv_m1
FROM stonedwv0.dbo.FactTPV tpv
JOIN stonedwv0.dbo.DimDate dt ON tpv.TransactionDate = dt.DateKey
JOIN stonedwv0.dbo.DimCompany company ON tpv.CompanyKey = company.CompanyKey
JOIN stonedwv0.dbo.DimAffiliation affiliation ON tpv.AffiliationKey = affiliation.AffiliationKey
JOIN stonedwv0.dbo.DimClient client ON affiliation.ClientKey = client.ClientKey
JOIN stonedwv0.dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN stonedwv0.dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN stonedwv0.dbo.DimFlag flag ON tpv.FlagKey = flag.Flagkey
JOIN stonedwv0.dbo.DimProduct product ON tpv.ProductKey = product.ProductKey
JOIN stonedwv0.dbo.DimInstallment installment ON tpv.InstallmentKey = installment.InstallmentKey
JOIN stonedwv0.dbo.Dimacquirer acquirer ON tpv.AcquirerKey = acquirer.AcquirerKey
WHERE
	eomonth(convert(varchar, client.createdate)) = eomonth(FullDate, -1)
GROUP BY
	eomonth(FullDate),
	CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	flag.FlagName,
	product.ProductName,
	installment.InstallmentName,
	acquirer.AcquirerName,
	tpv.TypeKey

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	kpi_value
)
	SELECT
		'{{ ds }}',
		'0048',
		'TPV Processado M1',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		sum(tpv)
	FROM
		#tpv_m1
	WHERE
		reference_date BETWEEN '2016-01-01' AND eomonth('{{ ds }}', - 1)
		AND acquirer IN ('Stone', 'Elavon')
		AND type_key IN (0, 1, 3, 9, 10)
		AND company <> 'MundiPagg'
		AND product <> 'Boleto'
	GROUP BY
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer
;
