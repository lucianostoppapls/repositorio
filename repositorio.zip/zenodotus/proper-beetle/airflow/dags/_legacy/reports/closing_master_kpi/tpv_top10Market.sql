-- SCRIPT PARA KPI 4602 - Concentração da carteira (TOP 10 clients) - Marketplaces
--GERA PUBLICO TOP10
DROP TABLE IF EXISTS #PublicoTopDezMarketplaces
SELECT A.FullDate,
	   A.canal,
	   A.subcanal,
	   A.grupo1,
	   A.grupo2,
	   A.grupo3,
	   A.grupo4,
	   A.TPV_DIGITAL,
	   ROW_NUMBER () OVER (PARTITION BY A.FullDate, A.canal, A.subcanal ORDER BY A.TPV_DIGITAL DESC) AS TOP_10
into #PublicoTopDezMarketplaces
from ( 
SELECT  eomonth(dt.FullDate) as FullDate,
		ss.SalesStructureNameLevel1 as canal,
		ss.SalesStructureNameLevel2 as subcanal,
		ss.SalesStructureNameLevel3 as grupo1,
		ss.SalesStructureNameLevel4 as grupo2,
		ss.SalesStructureNameLevel5 as grupo3,
		ss.SalesStructureNameLevel6 as grupo4,
		SUM(TPV.TPV) as TPV_DIGITAL
FROM dbo.FactTPV TPV
JOIN dbo.DimDate dt ON TPV.TransactionDate = dt.DateKey
JOIN dbo.DimCompany company ON TPV.CompanyKey = company.CompanyKey
JOIN dbo.DimAffiliation affiliation ON TPV.AffiliationKey = affiliation.AffiliationKey
JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey 
										and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimProduct prd ON TPV.ProductKey = prd.ProductKey
where 
dt.FullDate >='2016-01-01' and
dt.FullDate <= EOMONTH('{{ ds }}',-1) and
ss.SalesStructureNameLevel1 IN ('PAGARME - PARCEIROS') AND
ss.SalesStructureNameLevel2 IN ('MARKETPLACES') AND
--NOVOS
company.CompanyName <> 'MundiPagg' and
prd.ProductName <> 'Boleto' AND
TPV.TypeKey <> 2
GROUP BY eomonth(dt.FullDate), 
ss.SalesStructureNameLevel1, 
ss.SalesStructureNameLevel2,
ss.SalesStructureNameLevel3,
ss.SalesStructureNameLevel4, 
ss.SalesStructureNameLevel5,
ss.SalesStructureNameLevel6) A;

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	kpi_value
	)
SELECT 
		'{{ ds }}'
		,'4602.1'
		,'Concentração da carteira (TOP 10 clients) - MARKETPLACES'
		,FullDate
		,'STONE'
	    ,canal
	    ,subcanal
		,'NAO SE APLICA' AS rav_type
		,SUM(TPV_DIGITAL)
FROM #PublicoTopDezMarketplaces where 
FullDate >='01/01/2016' and
FullDate <= EOMONTH('{{ ds }}',-1) and
TOP_10 <= 10
group by FullDate, canal, subcanal;