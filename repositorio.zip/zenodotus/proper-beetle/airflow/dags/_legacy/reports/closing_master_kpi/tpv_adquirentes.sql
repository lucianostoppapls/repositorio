SELECT REFERENCE_DATE,
	SALES_CHANNEL,
	company,
	sales_subchannel,
	card_brand,
	product,
	installments,
	'NAO SE APLICA' AS ACQUIRER,
	'NAO SE APLICA' AS RAV_TYPE,
	SUM(KPI_VALUE) KPI_VALUE
INTO #TPVPROCESSADO
FROM StoneDWv0.KPI.CLOSINGMASTERKPI
WHERE EXECUTION_DATE between DATEADD(month, DATEDIFF(month, 0, '{{ ds }}'), 0) AND eomonth('{{ ds }}')
	AND KPI_INDEX = '0001'
	AND SALES_CHANNEL IN ('POLOS','PAGARME - SMB')
GROUP BY REFERENCE_DATE,
		SALES_CHANNEL,
		company,
		sales_subchannel,
		card_brand,
		product,
		installments


SELECT REFERENCE_DATE,
	SALES_CHANNEL,
	company,
	sales_subchannel,
	card_brand,
	product,
	installments,
	'NAO SE APLICA' AS ACQUIRER,
	'NAO SE APLICA' AS RAV_TYPE,
	SUM(KPI_VALUE) KPI_VALUE
INTO #TPVOUTRASADQUIRENTES
FROM StoneDWv0.KPI.CLOSINGMASTERKPI
WHERE EXECUTION_DATE between DATEADD(month, DATEDIFF(month, 0, '{{ ds }}'), 0) AND eomonth('{{ ds }}')
	AND KPI_INDEX = '0050'
	AND SALES_CHANNEL IN ('POLOS','PAGARME - SMB')
GROUP BY REFERENCE_DATE,
		SALES_CHANNEL,
		company,
		sales_subchannel,
	card_brand,
	product,
	installments


INSERT INTO kpi.ClosingMasterKpi
	(
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value
	)
	SELECT '{{ ds }}',
		'4550',
		'TPV Digital - Pagarme Merchants',
		reference_date,
		'STONE',
		sales_channel,
		'NAO SE APLICA',
		NULL,
		NULL,
		NULL,
		NULL,
		'NAO SE APLICA',
		TPV_DIGITAL
	FROM (SELECT reference_date
, execution_date
, sales_channel
, SUM(kpi_value) AS TPV_DIGITAL
		FROM [StoneDWv0].[kpi].[ClosingMasterKpi]
		WHERE kpi_index IN ('0001','0050')
			AND sales_channel IN ('PAGARME - GRANDES CONTAS')
			AND execution_date between dateadd(mm, -1,dateadd(dd, +1, eomonth('{{ ds }}'))) AND eomonth('{{ ds }}')
		GROUP BY
reference_date
, execution_date
,sales_channel) as X
	WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}',-1)

UNION ALL

	SELECT '{{ ds }}',
		'4573.1',
		'Receita nMDR - Pagarme Total',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		NULL,
		NULL,
		NULL,
		NULL,
		rav_type,
		SUM(kpi_value) AS ReceitaDIA
	FROM [StoneDWv0].[kpi].[ClosingMasterKpi]
	WHERE kpi_index = '0006'
		AND sales_channel = 'PAGARME - GRANDES CONTAS'
		AND execution_date between dateadd(mm, -1,dateadd(dd, +1, eomonth('{{ ds }}'))) AND eomonth('{{ ds }}')
	GROUP BY
reference_date,
company,
sales_channel,
sales_subchannel,
rav_type

UNION ALL

	SELECT '{{ ds }}',
		'4045.2' as kpi_index,
		'R$ TPV Crédito Polos' as kpi_name,
		isnull(tpc.reference_date,toa.reference_date) reference_date,
		isnull(tpc.company,toa.company) as company,
		isnull(tpc.sales_channel,toa.sales_channel) as sales_channel,
		isnull(tpc.sales_subchannel, toa.sales_subchannel) as sales_subchannel,
		isnull(tpc.card_brand, toa.card_brand) as card_brand,
		isnull(tpc.product, toa.product) as product,
		isnull(tpc.installments, toa.installments) as installments,
		isnull(tpc.acquirer,toa.acquirer) as acquirer,
		isnull(tpc.rav_type,toa.rav_type) as rav_type,
		sum(case when tpc.reference_date < '2021-01-01' then isnull(tpc.kpi_value,0) else isnull(tpc.kpi_value,0) + isnull(toa.kpi_value,0) end) as kpi_value
	from #TPVPROCESSADO TPC
		full outer JOIN #TPVOUTRASADQUIRENTES TOA ON TPC.reference_date = TOA.reference_date
			AND TPC.sales_channel = TOA.sales_channel
			AND tpc.company = TOA.company
			AND tpc.sales_subchannel = TOA.sales_subchannel
			AND tpc.card_brand = TOA.card_brand
			AND tpc.product = TOA.product
			AND tpc.installments = TOA.installments
			AND tpc.acquirer = TOA.acquirer
	where	isnull(tpc.sales_channel,toa.sales_channel) = 'POLOS'
		AND isnull(tpc.PRODUCT,toa.product) = 'Crédito'
	group by isnull(tpc.reference_date,toa.reference_date) ,
	isnull(tpc.company,toa.company) ,
	isnull(tpc.sales_channel,toa.sales_channel) ,
	isnull(tpc.sales_subchannel, toa.sales_subchannel) ,
	isnull(tpc.card_brand, toa.card_brand) ,
	isnull(tpc.product, toa.product),
	isnull(tpc.installments, toa.installments) ,
	isnull(tpc.acquirer,toa.acquirer) ,
	isnull(tpc.rav_type,toa.rav_type)


UNION ALL

	SELECT '{{ ds }}',
		'4045.3' as kpi_index,
		'R$ TPV Crédito Pagar.me - SMB' as kpi_name,
		isnull(tpc.reference_date,toa.reference_date) reference_date,
		isnull(tpc.company,toa.company) as company,
		isnull(tpc.sales_channel,toa.sales_channel) as sales_channel,
		isnull(tpc.sales_subchannel, toa.sales_subchannel) as sales_subchannel,
		isnull(tpc.card_brand, toa.card_brand) as card_brand,
		isnull(tpc.product, toa.product) as product,
		isnull(tpc.installments, toa.installments) as installments,
		isnull(tpc.acquirer,toa.acquirer) as acquirer,
		isnull(tpc.rav_type,toa.rav_type) as rav_type,
		sum(case when tpc.reference_date < '2021-01-01' then isnull(tpc.kpi_value,0) else isnull(tpc.kpi_value,0) + isnull(toa.kpi_value,0) end) as kpi_value
	from #TPVPROCESSADO TPC
		full outer JOIN #TPVOUTRASADQUIRENTES TOA ON TPC.reference_date = TOA.reference_date
			AND TPC.sales_channel = TOA.sales_channel
			AND tpc.company = TOA.company
			AND tpc.sales_subchannel = TOA.sales_subchannel
			AND tpc.card_brand = TOA.card_brand
			AND tpc.product = TOA.product
			AND tpc.installments = TOA.installments
			AND tpc.acquirer = TOA.acquirer
	where	isnull(tpc.sales_channel,toa.sales_channel) = 'PAGARME - SMB'
		AND isnull(tpc.PRODUCT,toa.product) = 'Crédito'
	group by isnull(tpc.reference_date,toa.reference_date) ,
	isnull(tpc.company,toa.company) ,
	isnull(tpc.sales_channel,toa.sales_channel) ,
	isnull(tpc.sales_subchannel, toa.sales_subchannel) ,
	isnull(tpc.card_brand, toa.card_brand) ,
	isnull(tpc.product, toa.product),
	isnull(tpc.installments, toa.installments) ,
	isnull(tpc.acquirer,toa.acquirer) ,
	isnull(tpc.rav_type,toa.rav_type)


UNION ALL

	SELECT '{{ ds }}',
		'4045.1' as kpi_index,
		'R$ TPV Crédito - SMB' as kpi_name,
		isnull(tpc.reference_date,toa.reference_date) reference_date,
		isnull(tpc.company,toa.company) as company,
		isnull(tpc.sales_channel,toa.sales_channel) as sales_channel,
		isnull(tpc.sales_subchannel, toa.sales_subchannel) as sales_subchannel,
		isnull(tpc.card_brand, toa.card_brand) as card_brand,
		isnull(tpc.product, toa.product) as product,
		isnull(tpc.installments, toa.installments) as installments,
		isnull(tpc.acquirer,toa.acquirer) as acquirer,
		isnull(tpc.rav_type,toa.rav_type) as rav_type,
		sum(case when tpc.reference_date < '2021-01-01' then isnull(tpc.kpi_value,0) else isnull(tpc.kpi_value,0) + isnull(toa.kpi_value,0) end) as kpi_value
	from #TPVPROCESSADO TPC
		full outer JOIN #TPVOUTRASADQUIRENTES TOA ON TPC.reference_date = TOA.reference_date
			AND TPC.sales_channel = TOA.sales_channel
			AND tpc.company = TOA.company
			AND tpc.sales_subchannel = TOA.sales_subchannel
			AND tpc.card_brand = TOA.card_brand
			AND tpc.product = TOA.product
			AND tpc.installments = TOA.installments
			AND tpc.acquirer = TOA.acquirer
	where isnull(tpc.PRODUCT,toa.product) = 'Crédito'
	group by isnull(tpc.reference_date,toa.reference_date) ,
	isnull(tpc.company,toa.company) ,
	isnull(tpc.sales_channel,toa.sales_channel) ,
	isnull(tpc.sales_subchannel, toa.sales_subchannel) ,
	isnull(tpc.card_brand, toa.card_brand) ,
	isnull(tpc.product, toa.product),
	isnull(tpc.installments, toa.installments) ,
	isnull(tpc.acquirer,toa.acquirer) ,
	isnull(tpc.rav_type,toa.rav_type)

UNION ALL

	SELECT '{{ ds }}'
		, '4510'
		, 'TPV Digital - Pagarme Total'
		, reference_date
		, company
		, sales_channel
		, sales_subchannel
		, NULL
		, NULL
		, NULL
		, NULL
		, 'NAO SE APLICA'
		, SUM(kpi_value) AS TPV_DIGITAL
	FROM [StoneDWv0].[kpi].[ClosingMasterKpi]
	WHERE kpi_index IN ('0001','0050')
		AND sales_channel IN ('PAGARME - PARCEIROS','PAGARME - GRANDES CONTAS')
		AND execution_date between dateadd(mm, -1,dateadd(dd, +1, eomonth('{{ ds }}'))) AND eomonth('{{ ds }}')
	GROUP BY
		reference_date
		,company
		,sales_channel
		,sales_subchannel

UNION ALL

	SELECT '{{ ds }}',
		'4132.1' as kpi_index,
		'TPV Polos + Franquias +Inbound' as kpi_name,
		isnull(tpc.reference_date,toa.reference_date) reference_date,
		isnull(tpc.company,toa.company) as company,
		isnull(tpc.sales_channel,toa.sales_channel) as sales_channel,
		isnull(tpc.sales_subchannel, toa.sales_subchannel) as sales_subchannel,
		isnull(tpc.card_brand, toa.card_brand) as card_brand,
		isnull(tpc.product, toa.product) as product,
		isnull(tpc.installments, toa.installments) as installments,
		isnull(tpc.acquirer,toa.acquirer) as acquirer,
		isnull(tpc.rav_type,toa.rav_type) as rav_type,
		sum(case when tpc.reference_date < '2021-01-01' then isnull(tpc.kpi_value,0) else isnull(tpc.kpi_value,0) + isnull(toa.kpi_value,0) end) as kpi_value
	from #TPVPROCESSADO TPC
		full outer JOIN #TPVOUTRASADQUIRENTES TOA ON TPC.reference_date = TOA.reference_date
			AND TPC.sales_channel = TOA.sales_channel
			AND tpc.company = TOA.company
			AND tpc.sales_subchannel = TOA.sales_subchannel
			AND tpc.card_brand = TOA.card_brand
			AND tpc.product = TOA.product
			AND tpc.installments = TOA.installments
			AND tpc.acquirer = TOA.acquirer
	where	isnull(tpc.sales_channel,toa.sales_channel) = 'POLOS'
	group by isnull(tpc.reference_date,toa.reference_date) ,
	isnull(tpc.company,toa.company) ,
	isnull(tpc.sales_channel,toa.sales_channel) ,
	isnull(tpc.sales_subchannel, toa.sales_subchannel) ,
	isnull(tpc.card_brand, toa.card_brand) ,
	isnull(tpc.product, toa.product),
	isnull(tpc.installments, toa.installments) ,
	isnull(tpc.acquirer,toa.acquirer) ,
	isnull(tpc.rav_type,toa.rav_type)

UNION ALL

	SELECT '{{ ds }}',
		'4132.2' as kpi_index,
		'TPV Pagarme - SMB' as kpi_name,
		isnull(tpc.reference_date,toa.reference_date) reference_date,
		isnull(tpc.company,toa.company) as company,
		isnull(tpc.sales_channel,toa.sales_channel) as sales_channel,
		isnull(tpc.sales_subchannel, toa.sales_subchannel) as sales_subchannel,
		isnull(tpc.card_brand, toa.card_brand) as card_brand,
		isnull(tpc.product, toa.product) as product,
		isnull(tpc.installments, toa.installments) as installments,
		isnull(tpc.acquirer,toa.acquirer) as acquirer,
		isnull(tpc.rav_type,toa.rav_type) as rav_type,
		sum(case when tpc.reference_date < '2021-01-01' then isnull(tpc.kpi_value,0) else isnull(tpc.kpi_value,0) + isnull(toa.kpi_value,0) end) as kpi_value
	from #TPVPROCESSADO TPC
		full outer JOIN #TPVOUTRASADQUIRENTES TOA ON TPC.reference_date = TOA.reference_date
			AND TPC.sales_channel = TOA.sales_channel
			AND tpc.company = TOA.company
			AND tpc.sales_subchannel = TOA.sales_subchannel
			AND tpc.card_brand = TOA.card_brand
			AND tpc.product = TOA.product
			AND tpc.installments = TOA.installments
			AND tpc.acquirer = TOA.acquirer
	where	isnull(tpc.sales_channel,toa.sales_channel) = 'PAGARME - SMB'
	group by isnull(tpc.reference_date,toa.reference_date) ,
	isnull(tpc.company,toa.company) ,
	isnull(tpc.sales_channel,toa.sales_channel) ,
	isnull(tpc.sales_subchannel, toa.sales_subchannel) ,
	isnull(tpc.card_brand, toa.card_brand) ,
	isnull(tpc.product, toa.product),
	isnull(tpc.installments, toa.installments) ,
	isnull(tpc.acquirer,toa.acquirer) ,
	isnull(tpc.rav_type,toa.rav_type)

UNION ALL

	SELECT '{{ ds }}',
		'4132' as kpi_index,
		'TPV' as kpi_name,
		isnull(tpc.reference_date,toa.reference_date) reference_date,
		isnull(tpc.company,toa.company) as company,
		isnull(tpc.sales_channel,toa.sales_channel) as sales_channel,
		isnull(tpc.sales_subchannel, toa.sales_subchannel) as sales_subchannel,
		isnull(tpc.card_brand, toa.card_brand) as card_brand,
		isnull(tpc.product, toa.product) as product,
		isnull(tpc.installments, toa.installments) as installments,
		isnull(tpc.acquirer,toa.acquirer) as acquirer,
		isnull(tpc.rav_type,toa.rav_type) as rav_type,
		sum(case when tpc.reference_date < '2021-01-01' then isnull(tpc.kpi_value,0) else isnull(tpc.kpi_value,0) + isnull(toa.kpi_value,0) end) as kpi_value
	from #TPVPROCESSADO TPC
		full outer JOIN #TPVOUTRASADQUIRENTES TOA ON TPC.reference_date = TOA.reference_date
			AND TPC.sales_channel = TOA.sales_channel
			AND tpc.company = TOA.company
			AND tpc.sales_subchannel = TOA.sales_subchannel
			AND tpc.card_brand = TOA.card_brand
			AND tpc.product = TOA.product
			AND tpc.installments = TOA.installments
			AND tpc.acquirer = TOA.acquirer
	group by isnull(tpc.reference_date,toa.reference_date) ,
	isnull(tpc.company,toa.company) ,
	isnull(tpc.sales_channel,toa.sales_channel) ,
	isnull(tpc.sales_subchannel, toa.sales_subchannel) ,
	isnull(tpc.card_brand, toa.card_brand) ,
	isnull(tpc.product, toa.product),
	isnull(tpc.installments, toa.installments) ,
	isnull(tpc.acquirer,toa.acquirer) ,
	isnull(tpc.rav_type,toa.rav_type)



