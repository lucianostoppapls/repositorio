SELECT eomonth(FullDate) AS reference_date,
	CompanyName AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	ss.SalesStructureNameLevel2 AS sales_subchannel,
	rav_type.RavTypeName rav_type,
	sum(rav.Revenue) revenue,
	sum(rav.GrossValue) gross_value,
	sum(rav.Duration * rav.GrossValue) AS dx,
	sum(rav.DurationWD * rav.GrossValue) AS dx_du,
	sum(rav.GrossValue * rav.DurationWD * RateOverDI) AS dx_rate,
	POWER(sum(rav.GrossValue) / nullif(sum(rav.GrossValue - rav.Revenue), 0), (21 / nullif(sum(DurationWD), 0))) - 1 AS rav_du_fee
INTO #rav
FROM [dbo].FactRav rav
JOIN dbo.DimDate dt ON rav.ContractDate = dt.DateKey
JOIN dbo.DimCompany company ON rav.CompanyKey = company.CompanyKey
JOIN dbo.DimAffiliation affiliation ON rav.AffiliationKey = affiliation.AffiliationKey
JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimRavType rav_type ON rav.RavTypeKey = rav_type.RavTypeKey
GROUP BY eomonth(FullDate),
	CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	rav_type.RavTypeName

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	kpi_value
	)
SELECT '{{ ds }}',
	'0200',
	'TPV antecipado (Bruto)',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	sum(gross_value)
FROM #rav
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type

UNION ALL

SELECT '{{ ds }}',
	'0201',
	'Receita RAV',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	sum(revenue)
FROM #rav
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type

UNION ALL

SELECT '{{ ds }}',
	'0202',
	'% CDI',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	sum(dx_rate) / nullif(sum(dx_du), 0)
FROM #rav
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type

UNION ALL

SELECT '{{ ds }}',
	'0204',
	'Taxa Efetiva RAV DU',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	sum(rav_du_fee)
FROM #rav
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type

UNION ALL

SELECT '{{ ds }}',
	'0203',
	'Taxa Efetiva RAV DC',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	30 * sum(revenue) / nullif(sum(dx), 0)
FROM #rav
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type

UNION ALL

SELECT '{{ ds }}',
	'0205',
	'Duration RAV (DC)',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	sum(dx) / nullif(sum(gross_value), 0)
FROM #rav
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type

UNION ALL

SELECT '{{ ds }}',
	'0206',
	'Duration RAV (DU)',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	sum(dx_du) / nullif(sum(gross_value), 0)
FROM #rav
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type

UNION ALL

SELECT '{{ ds }}',
	'0214',
	'DX DC',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	sum(dx)
FROM #rav
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type
