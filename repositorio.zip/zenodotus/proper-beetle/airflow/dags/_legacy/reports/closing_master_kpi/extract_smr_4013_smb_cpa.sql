--script KPI 4013 CPA - Razão entre investimentos em marketing de performance e vendas (Stone + Ton)
--EXECUTAR QUERY NO GCP

select
    '{{ ds }}' as execution_date,
    '4013' as kpi_index,
    'CPA - Razão entre investimentos em marketing de performance e vendas (Stone + Ton)' as kpi_name,
    date_trunc(A.DATE,MONTH) AS reference_date,
    'STONE' as company,
    'NAO SE APLICA' as sales_channel,
    'NAO SE APLICA' as sales_subchannel,
    'NAO SE APLICA' as card_brand,
    'NAO SE APLICA' as product,
    'NAO SE APLICA' as installments,
    'NAO SE APLICA' as acquirer,
    'NAO SE APLICA' as rav_type,
    safe_divide(sum(IFNULL(Total_Investment,0)),(sum(IFNULL(Credenciamentos_STN,0)+IFNULL(Ton_Pedidos_Pagos,0)))) as kpi_value
from `analytics
-254117.Inbound.Consolidado_Inv_Inbound` A
where A.date >= '2020-01-01' AND date_trunc
(A.date, month) < date_trunc
('{{ ds }}', month)
group by KPI_INDEX, kpi_name, reference_date
order by reference_date