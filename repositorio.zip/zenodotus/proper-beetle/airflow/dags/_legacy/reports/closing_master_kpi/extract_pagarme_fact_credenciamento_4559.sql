-- STNE Management Report - Pagarme - Credenciamentos Ativados GMV -- 4559

with active as
  (
    select
      date_trunc('month', dimension_date)::date as mes,
      encarteiramento_atual.group_3
    from
      digital_dataops.fact_credenciamento
        inner join digital_dataops.dim_date_classification
                   using (date_classification_key)
        inner join digital_dataops.dim_date
                   using (date_key)
        left join digital_dataops.encarteiramento_atual
                  on fact_credenciamento.internal_affiliation_id = encarteiramento_atual.internal_affiliation_id
    where
      -- seleciona a data de ativacao por gmv
      date_classification = 'credenciamento_ativado'
      and date_key >= 20180101
      -- remove mei/ton
      and fact_credenciamento.internal_affiliation_id in (
      select distinct
        internal_affiliation_id
      from
        digital_dataops.dim_affiliation
      where
        affiliation_type != 'mei'
      )
      -- filtra apenas os seguintes encarteiramentos pagarme no fechamento de cada mes
      and encarteiramento_atual.channel in (
                                                'PAGARME - GRANDES CONTAS'
      )
      and encarteiramento_atual.sub_channel in (
                                                    'KEY ACCOUNTS', 'MEDIUM', 'GRANDES CONTAS', 'MERCHANTS'
      )
    group by
      date_trunc('month', dimension_date)::date,
      group_3
    order by
      mes
    ), min_active as (
  select
    min(mes) as mes_first_active,
    group_3
  from
    active
  group by
    group_3
  )
select
  mes_first_active,
  count(group_3) as n_group_3
from min_active
where mes_first_active >= '2020-01-01'::date
group by mes_first_active
order by mes_first_active
;