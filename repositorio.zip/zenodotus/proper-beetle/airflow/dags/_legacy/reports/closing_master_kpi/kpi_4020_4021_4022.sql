--KPI'S 4020, 4021, 4022 insert ClosingMasterKPI
use StoneDWv0

--exclui tabelas temporárias
IF Object_id('tempdb..#AUXNormal_MGMT_NOVO') IS NOT NULL DROP TABLE #AUXNormal_MGMT_NOVO 
IF Object_id('tempdb..#TPV_CNPJ_MGMT_NOVO') IS NOT NULL DROP TABLE #TPV_CNPJ_MGMT_NOVO 
IF Object_id('tempdb..#TPV2_MGMT_NOVO') IS NOT NULL DROP TABLE #TPV2_MGMT_NOVO 
IF Object_id('tempdb..#TPVFINAL_MGMT_NOVO') IS NOT NULL DROP TABLE #TPVFINAL_MGMT_NOVO
IF Object_id('tempdb..#TV_MGMT_novo') IS NOT NULL DROP TABLE #TV_MGMT_novo
IF Object_id('tempdb..#TVFINAL_MGMT_NOVO') IS NOT NULL DROP TABLE #TVFINAL_MGMT_NOVO
IF Object_id('tempdb..#NA_MGMT_NOVO') IS NOT NULL DROP TABLE #NA_MGMT_NOVO
IF Object_id('tempdb..#REFTABLE_MGMT_NOVO') IS NOT NULL DROP TABLE #REFTABLE_MGMT_NOVO

--seleciona publico 
SELECT 
X.ClientCNPJorCPF, 
X.SalesStructureNameLevel1 ,
CASE
		WHEN X.SalesStructureNameLevel1 <> 'POLOS' THEN X.SalesStructureNameLevel1
		WHEN X.SalesForceName in ('INBOUND','OUTBOUND') OR X.VendorKey = 40047 THEN 'INBOUND'
		WHEN X.SalesForceName in ('FRANQUIA') OR X.EmailAddress like '%@querostone%' THEN 'FRANQUIA'
		WHEN X.SalesForceName in ('POLO PROPRIO','ESPECIALISTA','POLO TERCEIRO') THEN 'POLO PROPRIO'
		WHEN X.SalesStructureNameLevel2 = 'FRANQUIA' THEN 'FRANQUIA'
		WHEN X.SalesStructureNameLevel2 = 'VAREJO' THEN 'INBOUND'
		WHEN X.SalesStructureNameLevel2 in ('POLO PROPRIO','POLO TERCEIRO') THEN 'POLO PROPRIO'
		ELSE 'ND'
	END SalesForceReNameN
	,CASE
		WHEN SalesStructureNameLevel1 in ('DIGITAL','INT PARTNERSHIPS','PAGARME - KEY ACCOUNTS','PAGARME - SMB','PAGARME - GRANDES CONTAS') OR CompanyKey = 3 THEN 'PAGARME'
		WHEN SalesStructureNameLevel1 = 'POLOS' AND SalesStructureNameLevel2='VAREJO' THEN 'POLO PROPRIO'
		WHEN SalesStructureNameLevel1 = 'POLOS' THEN SalesStructureNameLevel2
		WHEN SalesStructureNameLevel1 = 'PAGARME - PARCEIROS' THEN 'PARCEIROS'
		ELSE 'OUTROS'
	END AS SalesStructureRename
INTO #AUXNormal_MGMT_NOVO 
FROM ( 
SELECT 
A.ClientCNPJorCPF, 
S.SalesStructureNameLevel1, SalesStructureNameLevel2,a.SalesForceName,v.VendorKey,v.EmailAddress,CompanyKey,
ROW_NUMBER() OVER (PARTITION BY A.ClientCNPJorCPF ORDER BY D.FullDate ASC) RW 
FROM [StoneDWv0].[dbo].[DimAffiliation] A 
LEFT JOIN StoneDWv0..DimVendor V ON V.VendorKey = A.VendorKey 
LEFT JOIN StoneDWv0..DimSalesStructure S ON S.SalesStructureKey = A.SalesStructureKey 
LEFT JOIN StoneDWv0..DimDate D ON D.DateKey = A.CreateDate 
WHERE 1=1 
AND A.CompanyKey in (1,2,3) 
AND S.SalesStructureNameLevel1 IN ('PAGARME - SMB', 'POLOS') 
) X 
WHERE RW = 1 


--busca todas as transações do publico para determinar se é novo ativo ou se é uma reativação
SELECT ClientCNPJorCPF 
,CAST(CAST(Transactiondate as varchar)as date) as Transactiondate 
,CAST(CAST(MIN(Transactiondate) OVER(PARTITION BY ClientCNPJorCPF) as varchar)as date) as data_ativação 
INTO #TPV_CNPJ_MGMT_NOVO 
FROM StoneDWv0.dbo.DimAffiliation da 
LEFT JOIN StoneDWv0.dbo.FactTPV ft on da.AffiliationKey=ft.AffiliationKey 
LEFT JOIN StoneDWv0.dbo.DimSalesStructure dss on da.salesstructurekey=dss.salesstructurekey 
Where exists (SELECT ClientCNPJorCPF FROM #AUXNormal_MGMT_NOVO t where t.ClientCNPJorCPF = da.ClientCNPJorCPF) 
AND fT.TypeKey = 1 
--AND fT.Transactions >= 1 
AND ft.tpv > 1 --Alteração de conceito para ativos com TPV maior que 1
AND da.CompanyKey in (1,2,3) 
AND dss.SalesStructureNameLevel1 IN ('PAGARME - SMB', 'POLOS') 
GROUP BY ClientCNPJorCPF,TransactionDate

--constroi uma nova data de ativação quando há mais de 30 dias entre as transações
Select ClientCNPJorCPF, 
TransactionDate, 
data_ativação, 
CASE WHEN DATEDIFF(day,LAG(TransactionDate) OVER (Partition BY ClientCNPJorCPF Order by TransactionDate), TransactionDate ) >=30 THEN Transactiondate ELSE data_ativação END as data_ativação2 -- CRIANDO UMA NOVA DATA DE REATIVAÇAO 
INTO #TPV2_MGMT_NOVO 
FROM #TPV_CNPJ_MGMT_NOVO 
ORDER BY ClientCNPJorCPF,Transactiondate 

--Cria nova data de ativação para os reativados
SELECT ClientCNPJorCPF 
,CAST(TransactionDate as date) as TransactionDate 
,data_ativação as data_ativação_original 
,MAX(data_ativação2) OVER(Partition By ClientCNPJorCPF Order BY TransactionDate ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) as data_ativação--OBTENDO A DATA DE REATIVAçÂo Correta correspondente a cada transação 
INTO #TPVFINAL_MGMT_NOVO 
FROM #TPV2_MGMT_NOVO 
WHERE DATEDIFF(day,(CAST(CAST(TransactionDate as varchar) as date)),('{{ ds }}'))>=1 --FILTRANDO OS DADOS DE TRANSAÇÕES ATÉ 1 dia atrás 


--cria a chave única de CNPF CNPJ + Data da ativação e cria indicador dos reativados
SELECT  CAST(ClientCNPJorCPF as varchar)+CAST(data_ativação as varchar) as newkey,
	ClientCNPJorCPF
	,data_ativação_original
	,data_ativação
	,CASE WHEN DATEDIFF(day,data_ativação_original,data_ativação)>0 THEN 1 ELSE 0 END as ind_reativacao
	,DATEADD(day,30, MAX(TransactionDate)) as Churn_Date
INTO #TV_MGMT_novo
FROM #TPVFINAL_MGMT_NOVO
WHERE  DATEDIFF(day,(data_ativação) , ('{{ ds }}'))>1 --Clientes que ativaram a mais de um dia
GROUP BY ClientCNPJorCPF,data_ativação,data_ativação_original
ORDER BY ClientCNPJorCPF,data_ativação,data_ativação_original



--prepara tabela para contagem de novos ativos
SELECT tv.ClientCNPJorCPF
	,newkey
	,tv.data_ativação_original
	,tv.data_ativação
	,tv.ind_reativacao
	,aux.SalesStructureNameLevel1
	,aux.SalesForceReNameN
	,tv.Churn_Date as Churn_projected_date
	,CASE WHEN tv.Churn_Date<DATEADD(day,-1,CAST(GETDATE() as DATE)) THEN tv.Churn_Date 
			ELSE NULL END as Churn_consolidado_date
	,CASE WHEN DATEDIFF(day,data_ativação,Churn_Date) <=180 Then 1 
			ELSE 0 END as Early_Churn
    ,CASE WHEN DATEDIFF(day,LAG(data_ativação) OVER (PARTITION BY tv.ClientCNPJorCPF ORDER BY data_ativação), data_ativação)<=180 THEN 1
			ELSE 0 END as Early_reactivation
INTO #TVFINAL_MGMT_NOVO
FROM #TV_MGMT_novo tv
LEFT JOIN #AUXNormal_MGMT_NOVO aux ON tv.ClientCNPJorCPF=aux.ClientCNPJorCPF
WHERE 1=1
	AND data_ativação<DATEADD(day,-1,'{{ ds }}')

--cria tabela de com a contagem de novos ativos por Força de venda tratado
SELECT data_ativação, SalesForceReNameN, COUNT(newkey) as novos_ativos
INTO #NA_MGMT_NOVO
FROM #TVFINAL_MGMT_NOVO
WHERE ind_reativacao=0
	AND data_ativação<DATEADD(day,-1,'{{ ds }}')
	and eomonth(data_ativação) >='2020-01-31'
GROUP BY data_ativação, SalesForceReNameN
ORDER BY data_ativação, SalesForceReNameN

--cria tabela de com a contagem de Churn_early 
IF Object_id('tempdb..#CH_MGMT_early') IS NOT NULL DROP TABLE #CH_MGMT_early
SELECT Churn_consolidado_date, SalesStructureNameLevel1, SalesForceReNameN, COUNT(newkey) as Churn_early
INTO #CH_MGMT_early
FROM #TVFINAL_MGMT_NOVO
WHERE Churn_consolidado_date<DATEADD(day, -1, CAST(GETDATE() as DATE))
AND Early_Churn=1
GROUP BY Churn_consolidado_date, SalesStructureNameLevel1, SalesForceReNameN
ORDER BY Churn_consolidado_date, SalesStructureNameLevel1, SalesForceReNameN

--reativacoes EARLY
IF Object_id('tempdb..#RA_MGMT_early') IS NOT NULL DROP TABLE #RA_MGMT_early
SELECT data_ativação,  SalesStructureNameLevel1, SalesForceReNameN, COUNT(newkey) as reativacoes_early
INTO #RA_MGMT_early
FROM #TVFINAL_MGMT_NOVO
WHERE ind_reativacao=1
AND data_ativação<DATEADD(day, -1, CAST(GETDATE() as DATE))
AND Early_reactivation=1
GROUP BY data_ativação, SalesStructureNameLevel1, SalesForceReNameN
ORDER BY data_ativação, SalesStructureNameLevel1, SalesForceReNameN

--reativacao LATE
IF Object_id('tempdb..#RA_MGMT_late') IS NOT NULL DROP TABLE #RA_MGMT_late
SELECT data_ativação, SalesStructureNameLevel1, SalesForceReNameN, COUNT(newkey) as reativacoes_late
INTO #RA_MGMT_late
FROM #TVFINAL_MGMT_NOVO
WHERE ind_reativacao=1
AND data_ativação<DATEADD(day,-1,CAST(GETDATE() as DATE))
AND Early_reactivation=0
GROUP BY data_ativação, SalesStructureNameLevel1, SalesForceReNameN
ORDER BY data_ativação, SalesStructureNameLevel1, SalesForceReNameN

--CHURN LATE
IF Object_id('tempdb..#CH_MGMT_late') IS NOT NULL DROP TABLE #CH_MGMT_late
SELECT Churn_consolidado_date, SalesStructureNameLevel1, SalesForceReNameN, COUNT(newkey) as Churn_late
INTO #CH_MGMT_late
FROM #TVFINAL_MGMT_NOVO
WHERE Churn_consolidado_date<DATEADD(day,-1,CAST(GETDATE() as DATE))
AND Early_Churn=0
GROUP BY Churn_consolidado_date, SalesStructureNameLevel1,SalesForceReNameN
ORDER BY Churn_consolidado_date, SalesStructureNameLevel1,SalesForceReNameN

--REATIVACOES TOTAL
IF Object_id('tempdb..#RA_MGMT') IS NOT NULL DROP TABLE #RA_MGMT
SELECT data_ativação, SalesStructureNameLevel1, SalesForceReNameN, COUNT(newkey) as reativacoes
INTO #RA_MGMT
FROM #TVFINAL_MGMT_NOVO
WHERE ind_reativacao=1
AND data_ativação<DATEADD(day,-1,CAST(GETDATE() as DATE))
GROUP BY data_ativação, SalesStructureNameLevel1,SalesForceReNameN
ORDER BY data_ativação, SalesStructureNameLevel1,SalesForceReNameN

--CHURN GERAL
IF Object_id('tempdb..#CH_MGMT') IS NOT NULL DROP TABLE #CH_MGMT
SELECT Churn_consolidado_date, SalesStructureNameLevel1, SalesForceReNameN, COUNT(newkey) as Churn
INTO #CH_MGMT
FROM #TVFINAL_MGMT_NOVO
WHERE Churn_consolidado_date<DATEADD(day,-1,CAST(GETDATE() as DATE))
GROUP BY Churn_consolidado_date, SalesStructureNameLevel1,SalesForceReNameN
ORDER BY Churn_consolidado_date, SalesStructureNameLevel1,SalesForceReNameN

--cria tabela de datas para utilizar como referencia 
SELECT Fulldate, CalendarQuarter,CalendarYearQtr,SalesForceReNameN,CASE WHEN IsNationalHoliday=1 AND DayOfWeek BETWEEN 2 AND 6 THEN 1 ELSE 0 END as Feriado_du
INTO #REFTABLE_MGMT_NOVO
FROM StoneDWv0.dbo.dimDate dd
CROSS JOIN (SELECT distinct SalesForceReNameN FROM #TVFINAL_MGMT_NOVO ) t1 
WHERE FullDate BETWEEN '2013-01-01' AND DATEADD(day,-2,'{{ ds }}')
	AND SalesForceReNameN <> 'ND'

IF Object_id('tempdb..#TPV_MGMT') IS NOT NULL DROP TABLE #TPV_MGMT
--- QUERY  BASE ATIVA
SELECT EOMONTH(CAST(CAST(TransactionDate as varchar) as date)) as mes,
dss.SalesStructureNameLevel1,
COUNT(DISTINCT(ClientCNPJorCPF)) as n_clientes_ativos
--SUM(CASE WHEN ProductKey=2 THEN TPV ELSE 0 END) AS TPV_credito, 
--SalesStructureNameLevel1 AS Canal
INTO #TPV_MGMT
FROM StoneDWv0.dbo.factTPV ft
LEFT JOIN StoneDWv0.dbo.DimAffiliation da ON ft.AffiliationKey=da.affiliationKey
LEFT JOIN StoneDWv0.dbo.DimSalesStructure dss ON da.SalesStructureKey=dss.SalesStructureKey
WHERE 1=1
and ft.AcquirerKey in (1, 11) --Apenas Stone e Elavon
and ft.TypeKey in (0, 1, 3, 9, 10)
and ft.CompanyKey <> 5 
and ft.ProductKey <> 4 --Retirando TPV de boletos
and ft.TPV > 1
AND da.CompanyKey in (1,2,3)
AND dss.SalesStructureNameLevel1 IN ('PAGARME - SMB', 'POLOS') 
AND TransactionDate >= 20191201
GROUP BY EOMONTH(CAST(CAST(TransactionDate as varchar) as date)), SalesStructureNameLevel1
ORDER BY EOMONTH(CAST(CAST(TransactionDate as varchar) as date))


--Insere registros na tabela de KPIs CHURN_EARLY/ CHURNA_LATE/ CHURN 

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value
	)

--query kpi 4020
select final.execution_date, final.kpi_index, final.kpi_name, final.reference_date, final.company, final.sales_channel, final.sales_subchannel, 
final.card_brand, final.product, final.installments, final.acquirer, final.rav_type,
(convert(decimal(18,5),sum(final.Churn_early-final.reativacoes_early)) / convert(decimal(18,5),(sum(final.base_ativa)))) as kpi_value
from 
(SELECT 
	'{{ ds }}' as execution_date
	,'4020' as kpi_index
	,'Early Churn Liquido (0-6m) Payments Stone %' as kpi_name
	,EOMONTH(Fulldate) as reference_date
	,'STONE' as company
	,na.SalesStructureNameLevel1 as sales_channel
	,'NAO SE APLICA' as sales_subchannel
	,'NAO SE APLICA' as card_brand
	,'NAO SE APLICA' as product
	,'NAO SE APLICA' as installments
	,'NAO SE APLICA' as acquirer
	,'NAO SE APLICA' as rav_type
	,ba.n_clientes_ativos as base_ativa
	,SUM (CASE WHEN FullDate<DATEADD(day, -1, CAST(GETDATE() as DATE)) THEN COALESCE(Churn_early, 0) ELSE NULL END) AS Churn_early
	,SUM (CASE WHEN FullDate<DATEADD(day,-1,CAST(GETDATE() as DATE)) THEN COALESCE(reativacoes_early,0) ELSE NULL END) as reativacoes_early
FROM #REFTABLE_MGMT_NOVO r
JOIN #CH_MGMT_early na ON r.FullDate=na.Churn_consolidado_date AND r.SalesForceReNameN=na.SalesForceReNameN
join #RA_MGMT_early ra on na.Churn_consolidado_date = ra.data_ativação AND na.SalesStructureNameLevel1 = ra.SalesStructureNameLevel1 and na.SalesForceReNameN=ra.SalesForceReNameN
JOIN (SELECT *, EOMONTH(mes, +1) as mes_join FROM #TPV_MGMT) ba on EOMONTH(na.Churn_consolidado_date) = eomonth(ba.mes_join) and ra.SalesStructureNameLevel1=ba.SalesStructureNameLevel1
WHERE fulldate >= cast('2020-01-01' as date) and
		EOMONTH(Fulldate) <= EOMONTH('{{ ds }}',-1) and 
		na.SalesStructureNameLevel1 = 'POLOS'
GROUP BY EOMONTH(Fulldate), na.SalesStructureNameLevel1, ba.n_clientes_ativos) final
group by final.execution_date, final.kpi_index, final.kpi_name, final.reference_date, final.company, final.sales_channel, final.sales_subchannel, final.card_brand, final.product, final.installments, final.acquirer, final.rav_type

union all 

--query kpi 4021
select final.execution_date, final.kpi_index, final.kpi_name, final.reference_date, final.company, final.sales_channel, final.sales_subchannel, 
final.card_brand, final.product, final.installments, final.acquirer, final.rav_type,
(convert(decimal(18,5),sum(final.Churn_late-final.reativacoes_late)) / convert(decimal(18,5),(sum(final.base_ativa)))) as kpi_value
from 
(SELECT 
	'{{ ds }}' as execution_date
	,'4021' as kpi_index
	,'Churn Liquido (6m+) Payments Stone %' as kpi_name
	,EOMONTH(Fulldate) as reference_date
	,'STONE' as company
	,na.SalesStructureNameLevel1 as sales_channel
	,'NAO SE APLICA' as sales_subchannel
	,'NAO SE APLICA' as card_brand
	,'NAO SE APLICA' as product
	,'NAO SE APLICA' as installments
	,'NAO SE APLICA' as acquirer
	,'NAO SE APLICA' as rav_type
	,ba.n_clientes_ativos as base_ativa
	,SUM (CASE WHEN FullDate<DATEADD(day,-1,CAST(GETDATE() as DATE)) THEN COALESCE(Churn_late,0) ELSE NULL END) as Churn_late
	,SUM (CASE WHEN FullDate<DATEADD(day,-1,CAST(GETDATE() as DATE)) THEN COALESCE(reativacoes_late,0) ELSE NULL END) as reativacoes_late
FROM #REFTABLE_MGMT_NOVO r
JOIN #CH_MGMT_late na ON r.FullDate=na.Churn_consolidado_date AND r.SalesForceReNameN=na.SalesForceReNameN
join #RA_MGMT_late ra on na.Churn_consolidado_date = ra.data_ativação AND na.SalesStructureNameLevel1 = ra.SalesStructureNameLevel1 and na.SalesForceReNameN=ra.SalesForceReNameN
JOIN (SELECT *, EOMONTH(mes, +1) as mes_join FROM #TPV_MGMT) ba on EOMONTH(na.Churn_consolidado_date) = eomonth(ba.mes_join) and ra.SalesStructureNameLevel1=ba.SalesStructureNameLevel1
WHERE fulldate >= cast('2020-01-01' as date) and
		EOMONTH(Fulldate) <= EOMONTH('{{ ds }}',-1) and 
		na.SalesStructureNameLevel1 = 'POLOS'
GROUP BY EOMONTH(Fulldate), na.SalesStructureNameLevel1, ba.n_clientes_ativos) final
group by final.execution_date, final.kpi_index, final.kpi_name, final.reference_date, final.company, final.sales_channel, final.sales_subchannel, final.card_brand, final.product, final.installments, final.acquirer, final.rav_type

union all 

--query kpi 4022
select final.execution_date, final.kpi_index, final.kpi_name, final.reference_date, final.company, final.sales_channel, final.sales_subchannel, 
final.card_brand, final.product, final.installments, final.acquirer, final.rav_type,
(convert(decimal(18,5),sum(final.Churn-final.reativacoes)) / convert(decimal(18,5),(sum(final.base_ativa)))) as kpi_value
from 
(SELECT 
	'{{ ds }}' as execution_date
	,'4022' as kpi_index
	,'Churn Liquido Payments Pagarme %' as kpi_name
	,EOMONTH(Fulldate) as reference_date
	,'STONE' as company
	,na.SalesStructureNameLevel1 as sales_channel
	,'NAO SE APLICA' as sales_subchannel
	,'NAO SE APLICA' as card_brand
	,'NAO SE APLICA' as product
	,'NAO SE APLICA' as installments
	,'NAO SE APLICA' as acquirer
	,'NAO SE APLICA' as rav_type
	,ba.n_clientes_ativos as base_ativa
	,SUM (CASE WHEN FullDate<DATEADD(day,-1,CAST(GETDATE() as DATE)) THEN COALESCE(Churn,0) ELSE NULL END) as Churn
	,SUM (CASE WHEN FullDate<DATEADD(day,-1,CAST(GETDATE() as DATE)) THEN COALESCE(reativacoes,0) ELSE NULL END) as reativacoes
FROM #REFTABLE_MGMT_NOVO r
JOIN #CH_MGMT na ON r.FullDate=na.Churn_consolidado_date AND r.SalesForceReNameN=na.SalesForceReNameN
join #RA_MGMT ra on na.Churn_consolidado_date = ra.data_ativação AND na.SalesStructureNameLevel1 = ra.SalesStructureNameLevel1 and na.SalesForceReNameN=ra.SalesForceReNameN
JOIN (SELECT mes, EOMONTH(mes, +1) as mes_join, SalesStructureNameLevel1, sum(n_clientes_ativos) as n_clientes_ativos FROM #TPV_MGMT WHERE SalesStructureNameLevel1 = 'PAGARME - SMB'
		group by mes, EOMONTH(mes, +1), SalesStructureNameLevel1) ba on EOMONTH(na.Churn_consolidado_date) = eomonth(ba.mes_join) and ra.SalesStructureNameLevel1 = ba.SalesStructureNameLevel1
WHERE fulldate >= cast('2020-01-01' as date) and
		EOMONTH(Fulldate) <= EOMONTH('{{ ds }}',-1) and
		na.SalesStructureNameLevel1 = 'PAGARME - SMB'
GROUP BY EOMONTH(Fulldate), na.SalesStructureNameLevel1, ba.n_clientes_ativos) final
group by final.execution_date, final.kpi_index, final.kpi_name, final.reference_date, final.company, final.sales_channel, final.sales_subchannel, final.card_brand, final.product, final.installments, final.acquirer, final.rav_type