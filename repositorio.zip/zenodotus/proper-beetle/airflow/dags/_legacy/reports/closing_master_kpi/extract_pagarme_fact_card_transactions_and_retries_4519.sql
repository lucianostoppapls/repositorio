-- STNE Management Report - Pagarme - TPV AF - Month
with trxs_with_antifraud as (
  select
    transaction_id,
    -- considera o dia em que teve a primeira análise
    min(date_key)           as date_key,
    -- considera o maior montante, embora isso não devesse mudar
    max(transaction_amount) as transaction_amount
  from
    digital_dataops.fact_card_transactions_and_retries
      inner join digital_dataops.dim_operation_status
                 using (operation_status_key)
      inner join digital_dataops.dim_affiliation
                 using (affiliation_key)
      inner join digital_dataops.dim_date
                 using (date_key)
      inner join digital_dataops.dim_payment
                 using (payment_key)
        inner join digital_dataops.dim_service
               using (service_key)
      left join digital_dataops.encarteiramento_atual
                on dim_affiliation.internal_affiliation_id = encarteiramento_atual.internal_affiliation_id
  where
    date_key >= date_trunc('month', current_date) - interval '1 month'
    and payment_method in ( 'credit_card')
    and product_name in ('psp')
    and operation_status in ('antifraud_analysis_refused',
                             'antifraud_analysis_successful',
                             'antifraud_analysis_deferred',
                             'antifraud_analysis_not_found',
                             'antifraud_pending_analysis')
    and dim_affiliation.affiliation_type != 'mei'
    and encarteiramento_atual.channel in (

                                              'PAGARME - GRANDES CONTAS',
                                              'PAGARME - PARCEIROS')
  group by
    transaction_id
  )
select
  date_trunc('month', dim_date.dimension_date)::date as mes,

  round(sum(transaction_amount)::float / 100., 0) as tpv_cartao_analisado_af_reais
from
  trxs_with_antifraud
    inner join digital_dataops.dim_date
               using (date_key)
group by
  mes
order by
  mes;




