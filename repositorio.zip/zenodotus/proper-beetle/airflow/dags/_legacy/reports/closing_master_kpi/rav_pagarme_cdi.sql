-- SCRIPT PARA KPI 4569.2 - Preço RAV CDI - Suporte ID 4569 - PAGARME Merchants
drop table if exists #CDI_RAV_GRANDE_CONTAS
SELECT eomonth(dt.FullDate) AS reference_date,
	'STONE' AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	'NAO SE APLICA' AS sales_subchannel,
	'NAO SE APLICA' rav_type,
	sum(rav.WeightedRateOverDI) / sum(rav.DXWD) AS CDI
INTO #CDI_RAV_GRANDE_CONTAS
FROM [dbo].FactRav rav
JOIN dbo.DimDate dt ON rav.ContractDate = dt.DateKey
JOIN dbo.DimCompany company ON rav.CompanyKey = company.CompanyKey
JOIN dbo.DimAffiliation affiliation ON rav.AffiliationKey = affiliation.AffiliationKey
JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimRavType rav_type ON rav.RavTypeKey = rav_type.RavTypeKey
WHERE 
ss.SalesStructureNameLevel1 IN ('PAGARME - GRANDES CONTAS')
GROUP BY eomonth(dt.FullDate), ss.SalesStructureNameLevel1

-- SCRIPT PARA KPI 4513.2 - Preço RAV CDI - Suporte ID 4513 - PAGARME TOTAL
drop table if exists #CDI_RAV_PAGARME_TOTAL
SELECT eomonth(dt.FullDate) AS reference_date,
	'STONE' AS company,
	'NAO SE APLICA' AS sales_channel,
	'NAO SE APLICA' AS sales_subchannel,
	'NAO SE APLICA' rav_type,
	sum(rav.WeightedRateOverDI) / sum(rav.DXWD) AS CDI
INTO #CDI_RAV_PAGARME_TOTAL
FROM [dbo].FactRav rav
JOIN dbo.DimDate dt ON rav.ContractDate = dt.DateKey
JOIN dbo.DimCompany company ON rav.CompanyKey = company.CompanyKey
JOIN dbo.DimAffiliation affiliation ON rav.AffiliationKey = affiliation.AffiliationKey
JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimRavType rav_type ON rav.RavTypeKey = rav_type.RavTypeKey
WHERE 
ss.SalesStructureNameLevel1 IN ('PAGARME - PARCEIROS','PAGARME - GRANDES CONTAS')
GROUP BY eomonth(dt.FullDate), ss.SalesStructureNameLevel1

-- SCRIPT PARA KPI 4615.2 - Preço RAV CDI - Suporte ID 4615 - PAGARME Partnerships
drop table if exists #CDI_RAV_PARCEIROS
SELECT eomonth(dt.FullDate) AS reference_date,
	'STONE' AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	'NAO SE APLICA' AS sales_subchannel,
	'NAO SE APLICA' rav_type,
	sum(rav.WeightedRateOverDI) / sum(rav.DXWD) AS CDI
INTO #CDI_RAV_PARCEIROS
FROM [dbo].FactRav rav
JOIN dbo.DimDate dt ON rav.ContractDate = dt.DateKey
JOIN dbo.DimCompany company ON rav.CompanyKey = company.CompanyKey
JOIN dbo.DimAffiliation affiliation ON rav.AffiliationKey = affiliation.AffiliationKey
JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimRavType rav_type ON rav.RavTypeKey = rav_type.RavTypeKey
WHERE 
ss.SalesStructureNameLevel1 IN ('PAGARME - PARCEIROS') and
ss.SalesStructureNameLevel2 IN ('PARTNER PROGRAM','MARKETPLACES')
GROUP BY eomonth(dt.FullDate), ss.SalesStructureNameLevel1


-- SCRIPT PARA KPI 4647.2 - Preço RAV CDI - Suporte ID 4647 - PAGARME Subs
drop table if exists #CDI_RAV_SUBS
SELECT eomonth(dt.FullDate) AS reference_date,
	'STONE' AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	ss.SalesStructureNameLevel2 AS sales_subchannel,
	'NAO SE APLICA' rav_type,
	sum(rav.WeightedRateOverDI) / sum(rav.DXWD) AS CDI
INTO #CDI_RAV_SUBS
FROM [dbo].FactRav rav
JOIN dbo.DimDate dt ON rav.ContractDate = dt.DateKey
JOIN dbo.DimCompany company ON rav.CompanyKey = company.CompanyKey
JOIN dbo.DimAffiliation affiliation ON rav.AffiliationKey = affiliation.AffiliationKey
JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimRavType rav_type ON rav.RavTypeKey = rav_type.RavTypeKey
WHERE 
ss.SalesStructureNameLevel1 in ('PAGARME - PARCEIROS')
and ss.SalesStructureNameLevel2 in ('SUBADQUIRENTES')
GROUP BY eomonth(dt.FullDate), ss.SalesStructureNameLevel1, ss.SalesStructureNameLevel2

INSERT INTO kpi.ClosingMasterKpi
	(
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	kpi_value
	)
SELECT '{{ ds }}'
		,'4569.5'
		,'Preço RAV CDI - PAGARME Merchants'
		,reference_date
		,company
		,sales_channel
		,sales_subchannel
		,rav_type
		,SUM(CDI) AS CDI
    FROM #CDI_RAV_GRANDE_CONTAS
    WHERE reference_date BETWEEN '2016-01-01'
	  AND eomonth('{{ ds }}',-1)
    GROUP BY
		reference_date
		,company
		,sales_channel
		,sales_subchannel
		,rav_type
		
UNION ALL

SELECT '{{ ds }}'
		,'4513.5'
		,'Preço RAV CDI - PAGARME TOTAL'
		,reference_date
		,company
		,sales_channel
		,sales_subchannel
		,rav_type
		,SUM(CDI) AS CDI
    FROM #CDI_RAV_PAGARME_TOTAL
    WHERE reference_date BETWEEN '2016-01-01'
	  AND eomonth('{{ ds }}',-1)
    GROUP BY
		reference_date
		,company
		,sales_channel
		,sales_subchannel
		,rav_type

UNION ALL

SELECT '{{ ds }}'
		,'4615.5'
		,'Preço RAV CDI - PAGARME Partnerships'
		,reference_date
		,company
		,sales_channel
		,sales_subchannel
		,rav_type
		,SUM(CDI) AS CDI
FROM #CDI_RAV_PARCEIROS
WHERE reference_date BETWEEN '2016-01-01'
	  AND eomonth('{{ ds }}',-1)
GROUP BY
		reference_date
		,company
		,sales_channel
		,sales_subchannel
		,rav_type

UNION ALL

SELECT '{{ ds }}'
		,'4647.5'
		,'Preço RAV CDI - PAGARME SUBADQUIRENTES'
		,reference_date
		,company
		,sales_channel
		,sales_subchannel
		,rav_type
		,SUM(CDI) AS CDI
FROM #CDI_RAV_SUBS
WHERE reference_date BETWEEN '2016-01-01'
	  AND eomonth('{{ ds }}',-1)
GROUP BY
		reference_date
		,company
		,sales_channel
		,sales_subchannel
		,rav_type