DECLARE @StartDate DATE = EOMONTH('{{ ds }}', -1);
DECLARE @EndDate DATE = EOMONTH('{{ ds }}', -1);;
DECLARE @MostRecentDateAtMasterKPI DATE = '{{ ds }}';
declare @StartDate90 date = DATEADD(DAY, -89, @StartDate); 
​
DELETE FROM StoneDWv0.kpi.FPATopLineReport WHERE reference_date = @EndDate and kpi in ('Active Clients Stone e Pagarme', 'Active Clients Stone, Pagarme e Stone+');
​
WITH DailyMeasures AS (
    SELECT
        DD.FullDate AS [Day],
        DC.ClientCNPJorCPF AS [ClientDocument],
        SUM(CASE WHEN DT.TypeName = 'Capturado' THEN fT.Transactions ELSE 0 END) AS [Transactions]
    FROM StoneDWv0.dbo.FactTPV  fT
    INNER JOIN StoneDWv0.dbo.DimDate DD ON DD.DateKey = fT.TransactionDate
    INNER JOIN StoneDWv0.dbo.DimAffiliation DA ON DA.AffiliationKey = fT.AffiliationKey
    INNER JOIN StoneDWv0.dbo.DimClient DC ON DC.ClientKey = DA.ClientKey
    INNER JOIN StoneDWv0.dbo.DimType DT ON DT.TypeKey = fT.TypeKey
    INNER JOIN StoneDWv0.dbo.DimProduct DP ON DP.ProductKey = fT.ProductKey
    WHERE
        DD.FullDate BETWEEN @StartDate90 AND @EndDate
        AND fT.CompanyKey IN (1, 2)
        AND DT.TypeName <> 'Gateway'
        AND DP.ProductName <> 'Boleto'
    GROUP BY
        DD.FullDate,
        DC.ClientCNPJorCPF
),
​
AllDocumentsAllMonths AS (
    SELECT DISTINCT
        EOMONTH([DD].[FullDate]) AS [Month],
        [DC].[ClientCNPJorCPF] AS [ClientDocument]
    FROM StoneDWv0.dbo.[DimClient] DC
    CROSS JOIN StoneDWv0.dbo.[DimDate] DD
    WHERE
        [DD].[FullDate] BETWEEN @StartDate90 AND @EndDate
        AND [DC].[CompanyKey] IN (1, 2)
    GROUP BY
        [DD].[FullDate],
        [DC].[ClientCNPJorCPF]
),

NinetyDaysMeasures AS (
    SELECT
        [ADAM].[Month],
        [ADAM].[ClientDocument],
        SUM([DM].[Transactions]) AS [NinetyDaysTransactions]
    FROM AllDocumentsAllMonths ADAM
    LEFT JOIN [DailyMeasures] DM ON [ADAM].[ClientDocument] = [DM].[ClientDocument] AND [DM].[Day] BETWEEN @StartDate90 AND [ADAM].[Month]
    GROUP BY
        [ADAM].[Month],
        [ADAM].[ClientDocument]
),
pagarme_augmented_ninety_days_measures AS (
    select
        coalesce(ndm.[Month], pg.fulldate) as [Month],
        coalesce(ndm.[ClientDocument], pg.document) as [ClientDocument],
        coalesce(ndm.[NinetyDaysTransactions], 0) + coalesce(pg.transactions, 0) as [NinetyDaysTransactions]
    from NinetyDaysMeasures ndm
    full outer join {{ ti.xcom_pull(task_ids='extract_pagarme_active_base_90d') }} pg on ndm.ClientDocument = pg.document and ndm.[Month] = pg.fulldate
)
​
INSERT INTO StoneDWv0.kpi.FPATopLineReport (
    reference_date,
    breakdown,
    kpi,
    [value]
)
SELECT
    PNDM.[Month],
    NULL,
    'Active Clients Stone e Pagarme',
    SUM(CASE WHEN COALESCE([PNDM].[NinetyDaysTransactions], 0) > 0 THEN 1 ELSE 0 END) AS [ClientCount90Days]
FROM pagarme_augmented_ninety_days_measures PNDM
WHERE
    PNDM.[Month] between @StartDate AND @EndDate
GROUP BY
    PNDM.[Month]
ORDER BY
    PNDM.[Month] ASC;
WITH DailyMeasures AS (
    SELECT
        DD.FullDate AS [Day],
        DC.ClientCNPJorCPF AS [ClientDocument],
        SUM(CASE WHEN DT.TypeName = 'Capturado' THEN fT.Transactions ELSE 0 END) AS [Transactions]
    FROM StoneDWv0.dbo.FactTPV  fT
    INNER JOIN StoneDWv0.dbo.DimDate DD ON DD.DateKey = fT.TransactionDate
    INNER JOIN StoneDWv0.dbo.DimAffiliation DA ON DA.AffiliationKey = fT.AffiliationKey
    INNER JOIN StoneDWv0.dbo.DimClient DC ON DC.ClientKey = DA.ClientKey
    INNER JOIN StoneDWv0.dbo.DimType DT ON DT.TypeKey = fT.TypeKey
    INNER JOIN StoneDWv0.dbo.DimProduct DP ON DP.ProductKey = fT.ProductKey
    WHERE
        DD.FullDate BETWEEN @StartDate90 AND @EndDate
        AND fT.CompanyKey IN (1, 2)
        AND DT.TypeName <> 'Gateway'
        AND DP.ProductName <> 'Boleto'
    GROUP BY
        DD.FullDate,
        DC.ClientCNPJorCPF
),
​
AllDocumentsAllMonths AS (
    SELECT DISTINCT
        EOMONTH([DD].[FullDate]) AS [Month],
        [DC].[ClientCNPJorCPF] AS [ClientDocument]
    FROM StoneDWv0.dbo.[DimClient] DC
    CROSS JOIN StoneDWv0.dbo.[DimDate] DD
    WHERE
        [DD].[FullDate] BETWEEN @StartDate90 AND @EndDate
        AND [DC].[CompanyKey] IN (1, 2)
    GROUP BY
        [DD].[FullDate],
        [DC].[ClientCNPJorCPF]
),

AllExtractTon90d AS (
        SELECT *
        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d')}} 
--        UNION ALL
--        SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part2')}}
--        UNION ALL
--        SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part3')}}
--        UNION ALL
--        SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part4')}}       
--        UNION ALL
--        SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part5')}}       
--        UNION ALL
--        SELECT *
--        FROM {{ti.xcom_pull(task_ids='extract_ton_active_base_90d_part6')}}                               
),
​
NinetyDaysMeasures AS (
    SELECT
        [ADAM].[Month],
        [ADAM].[ClientDocument],
        SUM([DM].[Transactions]) AS [NinetyDaysTransactions]
    FROM AllDocumentsAllMonths ADAM
    LEFT JOIN [DailyMeasures] DM ON [ADAM].[ClientDocument] = [DM].[ClientDocument] AND [DM].[Day] BETWEEN @StartDate90 AND [ADAM].[Month]
    GROUP BY
        [ADAM].[Month],
        [ADAM].[ClientDocument]
),
all_augmented_ninety_days_measures AS (
    select
        coalesce(ndm.[Month], sm.fulldate, pg.fulldate) as [Month],
        coalesce(ndm.[ClientDocument], sm.document, pg.document) as [ClientDocument],
        coalesce(ndm.[NinetyDaysTransactions], 0) + coalesce(sm.transactions, 0) + coalesce(pg.transactions, 0) as [NinetyDaysTransactions]
    from NinetyDaysMeasures ndm
    full outer join AllExtractTon90d sm on ndm.ClientDocument = sm.document and ndm.[Month] = sm.fulldate
    full outer join {{ ti.xcom_pull(task_ids='extract_pagarme_active_base_90d') }} pg on ndm.ClientDocument = pg.document and ndm.[Month] = pg.fulldate
)
INSERT INTO StoneDWv0.kpi.FPATopLineReport (
    reference_date,
    breakdown,
    kpi,
    [value]
)
SELECT
    ANDM.[Month],
    NULL,
    'Active Clients Stone, Pagarme e Stone+',
    SUM(CASE WHEN COALESCE([ANDM].[NinetyDaysTransactions], 0) > 0 THEN 1 ELSE 0 END) AS [ClientCount90Days]
FROM all_augmented_ninety_days_measures ANDM
WHERE
    ANDM.[Month] between @StartDate AND @EndDate
GROUP BY
    ANDM.[Month]
ORDER BY
    ANDM.[Month] ASC;
​
​
DELETE FROM StoneDWv0.kpi.ClosingMasterKPI
WHERE
    execution_date = @MostRecentDateAtMasterKPI
    AND kpi_index in ('0580', '0581');
​
​
INSERT INTO [kpi].[ClosingMasterKpi](
    [execution_date],
    [kpi_index],
    [kpi_name],
    [reference_date],
    [kpi_value]
)
SELECT
    @MostRecentDateAtMasterKPI,
    '0580',
    'Base Ativa 90D Stone e Pagarme',
    reference_date,
    value
FROM StoneDWv0.kpi.fpatoplinereport
WHERE
    kpi = 'Active Clients Stone e Pagarme'
UNION ALL
SELECT
    @MostRecentDateAtMasterKPI,
    '0581',
    'Base Ativa 90D Stone, Pagarme e Stone Mais',
    reference_date,
    value
FROM StoneDWv0.kpi.fpatoplinereport
WHERE
    kpi = 'Active Clients Stone, Pagarme e Stone+'
ORDER BY
    reference_date;
