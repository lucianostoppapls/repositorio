drop table if exists #rav_duration
SELECT eomonth(dt.FullDate) AS reference_date,
	'STONE' AS company,
	'NAO SE APLICA' AS sales_channel,
	'NAO SE APLICA' AS sales_subchannel,
	'NAO SE APLICA' rav_type,
	sum(rav.GrossValue) gross_value,
	sum(rav.Duration * rav.GrossValue) AS dx
INTO #rav_duration
FROM [dbo].FactRav rav
JOIN dbo.DimDate dt ON rav.ContractDate = dt.DateKey
JOIN dbo.DimCompany company ON rav.CompanyKey = company.CompanyKey
JOIN dbo.DimAffiliation affiliation ON rav.AffiliationKey = affiliation.AffiliationKey
JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
JOIN dbo.DimRavType rav_type ON rav.RavTypeKey = rav_type.RavTypeKey
WHERE 
--dt.FullDate between dateadd(mm, -1,dateadd(dd, +1, eomonth('{{ ds }}',-1))) AND eomonth('{{ ds }}', - 1) AND --RETIRADA DO FILTRO
ss.SalesStructureNameLevel1 IN ('PAGARME - SMB','POLOS')
GROUP BY eomonth(dt.FullDate)

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	rav_type,
	kpi_value
	)
SELECT '{{ ds }}',
	'4102',
	'Duration SMB',
	reference_date,
	'STONE',
	sales_channel,
	sales_subchannel,
	rav_type,
	sum(dx) / nullif(sum(gross_value), 0)
FROM #rav_duration
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}',-1)
GROUP BY reference_date,
	sales_channel,
	sales_subchannel,
	rav_type

	
