-- STNE Management Report - Pagarme - Merchants (grandes contas) - % TOP TPV 4554
-- TODO: considerar o tpv digital (psp + stone adquirência) SEM PIX E SEM BOLETO
-- TODO: USAR O ENCARTEIRAMENTO ATUAL
with base_tpvs as
  (
    select
      date_trunc('month', dimension_date)::date as mes,
      dim_affiliation.internal_affiliation_id,
      -- net tpv total para o conjunto (tpv capturado - cancelado - chargeback)
      round(sum(net_tpv)::float / 100., 0)    as net_tpv_capturado_reais
    from
      digital_dataops.fact_tpv
        inner join digital_dataops.dim_affiliation
                   using (affiliation_key)
        inner join digital_dataops.dim_service
                   using (service_key)
        inner join digital_dataops.dim_date
                   using (date_key)
        inner join digital_dataops.dim_payment
                   using (payment_key)
        left join digital_dataops.encarteiramento_atual
                  on dim_affiliation.internal_affiliation_id = encarteiramento_atual.internal_affiliation_id
    where
      -- seleciona os produtos considerados, psp e adquirencia
      product_name in ('psp', 'acquirer')
      and payment_method in ('credit_card', 'debit_card')
      -- filtra o periodo
      and date_key >= date_trunc('month', current_date) - interval '1 month'
      -- remove mei/ton
      and dim_affiliation.affiliation_type != 'mei'
      -- filtra apenas os seguintes encarteiramentos no fechamento de cada mes
      --  ref: https://pagarme.slack.com/archives/C01U840M7GC/p1631123731008400?thread_ts=1630957504.007200&cid=C01U840M7GC
      and encarteiramento_atual.channel in (
                                                'PAGARME - GRANDES CONTAS', 'PAGARME - KEY ACCOUNTS', 'INT PARTNERSHIPS', 'PAGARME - KEY ACCOUNTS'
      )
      and encarteiramento_atual.sub_channel in (
                                                    'KEY ACCOUNTS', 'MEDIUM', 'GRANDES CONTAS', 'MERCHANTS'
      )
    group by
      date_trunc('month', dimension_date)::date,
      dim_affiliation.internal_affiliation_id
    order by
      net_tpv_capturado_reais,
      mes
    ),
  top_tpvs as (
    select
      row_number() over (partition by mes order by net_tpv_capturado_reais desc) as top_n,
      *
    from
      base_tpvs
    ),
  tops as (
    select
      mes,
      sum(net_tpv_capturado_reais) as net_tpv_capturado_reais
    from
      top_tpvs
    where
      top_n <= 10
    group by
      mes
    order by
      mes
    ),
  full_tpv as (
    select
      mes,
      sum(net_tpv_capturado_reais) as net_tpv_capturado_reais
    from
      base_tpvs
    group by
      mes
    )
select
  mes,
  round(tops.net_tpv_capturado_reais / full_tpv.net_tpv_capturado_reais::float, 2) as perc
from
  tops
    full outer join full_tpv
                    using (mes)
order by mes
;