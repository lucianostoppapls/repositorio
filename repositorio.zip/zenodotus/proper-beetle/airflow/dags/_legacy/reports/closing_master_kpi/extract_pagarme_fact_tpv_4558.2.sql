  -- STNE Management Report - Pagarme - Partnerships - TPV MARKETPLACES
select
  date_trunc('month', dimension_date)::date as mes,
  round(sum(net_tpv)::float / 100., 0)    as net_tpv_capturado_reais

from
  digital_dataops.fact_tpv
    inner join digital_dataops.dim_affiliation
               using (affiliation_key)
    inner join digital_dataops.dim_service
               using (service_key)
    inner join digital_dataops.dim_date
               using (date_key)
        inner join digital_dataops.dim_payment
               using (payment_key)
    left join digital_dataops.encarteiramento_atual
              on dim_affiliation.internal_affiliation_id = encarteiramento_atual.internal_affiliation_id
where
  -- seleciona os produtos considerados, psp e adquirencia
  product_name in ('psp', 'acquirer')
  -- filtra o periodo
  --and date_key >= date_trunc('month', current_date) - interval '1 month'
  and date_key >= 20200101
  and payment_method in ('pix')
  -- remove mei/ton
  and dim_affiliation.affiliation_type != 'mei'
  -- filtra apenas os seguintes encarteiramentos no fechamento de cada mes
  --  ref: https://pagarme.slack.com/archives/C01U840M7GC/p1631123731008400?thread_ts=1630957504.007200&cid=C01U840M7GC
  and encarteiramento_atual.channel in (
                                            'PAGARME - PARCEIROS'
  )
  and encarteiramento_atual.sub_channel in (
                                                'PARTNER PROGRAM'
  )
group by
  date_trunc('month', dimension_date)::date

order by
  mes
;