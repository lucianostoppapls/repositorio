SELECT eomonth(FullDate) AS reference_date,
	CompanyName AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	ss.SalesStructureNameLevel2 AS sales_subchannel,
	flag.FlagName AS card_brand,
	product.ProductName AS product,
	installment.InstallmentName AS installments,
	acquirer.AcquirerName AS acquirer,
	tpv.TypeKey AS type_key,
	sum(tpv) tpv,
	sum(Transactions) transactions,
	sum(MDR) MDR,
	sum(Dia) Dia
INTO #tpv
FROM [dbo].FactTPV tpv
	JOIN dbo.DimDate dt ON tpv.TransactionDate = dt.DateKey
	JOIN dbo.DimCompany company ON tpv.CompanyKey = company.CompanyKey
	JOIN dbo.DimAffiliation affiliation ON tpv.AffiliationKey = affiliation.AffiliationKey
	JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
	JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
	JOIN dbo.DimFlag flag ON tpv.FlagKey = flag.Flagkey
	JOIN dbo.DimProduct product ON tpv.ProductKey = product.ProductKey
	JOIN dbo.DimInstallment installment ON tpv.InstallmentKey = installment.InstallmentKey
	JOIN dbo.Dimacquirer acquirer ON tpv.AcquirerKey = acquirer.AcquirerKey
GROUP BY eomonth(FullDate),
	CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	flag.FlagName,
	product.ProductName,
	installment.InstallmentName,
	acquirer.AcquirerName,
	tpv.TypeKey

INSERT INTO kpi.ClosingMasterKpi
	(
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value
	)
	SELECT '{{ ds }}',
		'0001',
		'TPV Processado',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		NULL,
		sum(tpv)
	FROM #tpv
	WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
		AND acquirer IN ('Stone', 'Elavon')
		AND type_key IN (0, 1, 3, 9, 10)
		AND company <> 'MundiPagg'
		AND product <> 'Boleto'
	GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer

UNION ALL

	SELECT '{{ ds }}',
		'0050',
		'TPV Pagarme em outras Adquirentes',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		NULL,
		sum(tpv)
	FROM #tpv
	WHERE
	reference_date BETWEEN '2016-01-01' AND eomonth('{{ ds }}', - 1)
		AND acquirer NOT IN ('Stone', 'Elavon')
		AND company = 'Pagar.me'
		AND product <> 'Boleto'
		AND type_key <> 2
	--gateway
	GROUP BY
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer

UNION ALL

	SELECT '{{ ds }}',
		'0002',
		'Número de Transações',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		NULL,
		sum(transactions)
	FROM #tpv
	WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
		AND acquirer IN ('Stone', 'Elavon')
		AND type_key = 1
		AND company <> 'MundiPagg'
		AND product <> 'Boleto'
	GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer

UNION ALL

	SELECT '{{ ds }}',
		'0003',
		'Número de Transações Gateway',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		NULL,
		sum(transactions)
	FROM #tpv
	WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
		AND type_key = 2
	GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer

UNION ALL

	SELECT '{{ ds }}',
		'0004',
		'Boletos Pagos',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		NULL,
		sum(transactions)
	FROM #tpv
	WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
		AND product = 'Boleto'
	GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer

UNION ALL

	SELECT '{{ ds }}',
		'0006',
		'Receita DIA',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		NULL,
		sum(dia)
	FROM #tpv
	WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
		AND acquirer IN ('Stone', 'Elavon')
		AND type_key IN (0, 1, 3, 9, 10)
		AND company <> 'MundiPagg'
		AND product <> 'Boleto'
	GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer

UNION ALL

	SELECT '{{ ds }}',
		'0052',
		'Receita de MDR',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		NULL,
		sum(mdr)
	FROM #tpv
	WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
		AND acquirer IN ('Stone', 'Elavon')
		AND type_key IN (0, 1, 3, 9, 10)
		AND company <> 'MundiPagg'
		AND product <> 'Boleto'
	GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer

UNION ALL

	SELECT '{{ ds }}',
		'0010',
		'Net MDR (%)',
		reference_date,
		company,
		sales_channel,
		sales_subchannel,
		card_brand,
		product,
		installments,
		acquirer,
		NULL,
		sum(dia) / nullif(sum(tpv), 0)
	FROM #tpv
	WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
		AND acquirer IN ('Stone', 'Elavon')
		AND type_key IN (0, 1, 3, 9, 10)
		AND company <> 'MundiPagg'
		AND product <> 'Boleto'
	GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer