SELECT CURRENT_DATE AT TIME ZONE 'UTC' AT TIME ZONE 'America/Sao_Paulo' AS execution_date,
	'' AS kpi_index,
	'Número de transações de antifraude' AS kpi_name,
	date_trunc('month', ("full_orders".order_date AT TIME ZONE 'UTC' AT TIME ZONE 'America/Sao_Paulo')) reference_date,
	null as company,
	null as sales_channel,
	null as sales_subchannel,
	null as card_brand,
	null as product,
	null as installments,
	null as acquirer,
	null as rav_type,
	COUNT(*) AS kpi_value
FROM full_orders
JOIN full_clients ON full_orders.client_id = full_clients.client_id
WHERE ("full_orders".order_date AT TIME ZONE 'UTC' AT TIME ZONE 'America/Sao_Paulo') >= '2018-01-01'
	AND ("full_orders".order_date AT TIME ZONE 'UTC' AT TIME ZONE 'America/Sao_Paulo') < date_trunc('month', "{{ ds }}")
GROUP BY reference_date
