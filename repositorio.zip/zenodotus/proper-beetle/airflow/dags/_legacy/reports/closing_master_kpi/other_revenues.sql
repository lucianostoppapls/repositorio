SELECT eomonth(FullDate) AS reference_date,
	CompanyName AS company,
	ss.SalesStructureNameLevel1 AS sales_channel,
	ss.SalesStructureNameLevel2 AS sales_subchannel,
	revenue.RevenueTypeKey revenue_type_key,
	sum(revenue.Revenue) revenue
INTO #other_revenues
FROM [dbo].FactOtherRevenues revenue
JOIN dbo.DimDate dt ON revenue.DateKey = dt.DateKey
JOIN dbo.DimCompany company ON revenue.CompanyKey = company.CompanyKey
JOIN dbo.DimAffiliation affiliation ON revenue.AffiliationKey = affiliation.AffiliationKey
JOIN dbo.DimAffiliationSalesStructureHist assh on affiliation.AffiliationKey = assh.AffiliationKey and assh.DateKey = CAST(FORMAT(EOMONTH('{{ ds }}', -1),'yyyyMMdd') AS INT)
JOIN dbo.DimSalesStructure ss ON assh.SalesStructureKey = ss.SalesStructureKey
GROUP BY eomonth(FullDate),
	CompanyName,
	ss.SalesStructureNameLevel1,
	ss.SalesStructureNameLevel2,
	revenue.RevenueTypeKey

INSERT INTO kpi.ClosingMasterKpi (
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	kpi_value
	)
SELECT '{{ ds }}',
	'0007',
	'Receita de Boleto',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	sum(revenue)
FROM #other_revenues
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
	AND revenue_type_key IN (13, 21)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel

UNION ALL

SELECT '{{ ds }}',
	'0008',
	'Receita de Gateway',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	sum(revenue)
FROM #other_revenues
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
	AND revenue_type_key = 26
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel

UNION ALL

SELECT '{{ ds }}',
	'0009',
	'Outras Receitas',
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	sum(revenue)
FROM #other_revenues
WHERE reference_date BETWEEN '2016-01-01'
		AND eomonth('{{ ds }}', - 1)
	AND revenue_type_key IN (9, 28)
GROUP BY reference_date,
	company,
	sales_channel,
	sales_subchannel