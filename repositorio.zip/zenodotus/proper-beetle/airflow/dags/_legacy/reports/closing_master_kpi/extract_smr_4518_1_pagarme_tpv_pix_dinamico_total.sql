with 
accounts_summary_partner as (
    select distinct
        a.*
    from
        `dataplatform-prd.conta_stone_analytics.accounts_summary` a
    where
        a.client_group in ('KeyAccount', 'PicPay','StoneCo')
)
select
    '{{ ds }}' as execution_date,
    '4518.1' as kpi_index,
    'TPV PIX Dinâmico - PAGARME TOTAL' as kpi_name,
    date_trunc(reference_date, month) as reference_date,
	'STONE' as company,
    'PAGARME - PARCEIROS /PAGARME - GRANDES CONTAS' as sales_channel,
    'NAO SE APLICA' as sales_subchannel,
    'NAO SE APLICA' as card_brand,
    'NAO SE APLICA' as product,
    'NAO SE APLICA' as installments,
    'NAO SE APLICA' as acquirer,
    'NAO SE APLICA' as rav_type,
    sum(pix_in_dynamic_account_tpv) kpi_value
from `dataplatform-prd.conta_stone_analytics.daily_account_economics` dae
inner join accounts_summary_partner asp on asp.account_id = dae.account_id
where asp.client_group in ('KeyAccount', 'PicPay','StoneCo')
	AND date_trunc(reference_date, month) <= date_trunc('{{ ds }}',month)-1
group by reference_date
UNION ALL
select
    '{{ ds }}' as execution_date,
    '4574.1' as kpi_index,
    'TPV PIX Dinâmico - Pagarme Merchants' as kpi_name,
    date_trunc(reference_date, month) as reference_date,
	'STONE' as company,
    'PAGARME - GRANDES CONTAS' as sales_channel,
    'NAO SE APLICA' as sales_subchannel,
    'NAO SE APLICA' as card_brand,
    'NAO SE APLICA' as product,
    'NAO SE APLICA' as installments,
    'NAO SE APLICA' as acquirer,
    'NAO SE APLICA' as rav_type,
    sum(pix_in_dynamic_account_tpv) kpi_value
from `dataplatform-prd.conta_stone_analytics.daily_account_economics` dae
inner join accounts_summary_partner asp on asp.account_id = dae.account_id
where asp.client_group in ('StoneCo')
	AND date_trunc(reference_date, month) <= date_trunc('{{ ds }}',month)-1
group by reference_date
UNION ALL
select
    '{{ ds }}' as execution_date,
    '4620.1' as kpi_index,
    'TPV PIX Dinâmico - PAGARME Partnerships' as kpi_name,
    date_trunc(reference_date, month) as reference_date,
	'STONE' as company,
    'PAGARME - PARCEIROS' as sales_channel,
    'NAO SE APLICA' as sales_subchannel,
    'NAO SE APLICA' as card_brand,
    'NAO SE APLICA' as product,
    'NAO SE APLICA' as installments,
    'NAO SE APLICA' as acquirer,
    'NAO SE APLICA' as rav_type,
    sum(pix_in_dynamic_account_tpv) kpi_value
from `dataplatform-prd.conta_stone_analytics.daily_account_economics` dae
inner join accounts_summary_partner asp on asp.account_id = dae.account_id
where asp.client_group in ('KeyAccount', 'PicPay')
	AND date_trunc(reference_date, month) <= date_trunc('{{ ds }}',month)-1
group by reference_date
order by reference_date
