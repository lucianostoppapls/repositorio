-- QUERY DE ACOMPANHAMENTO DE CHURN

DECLARE @DTi date
DECLARE @DTf date
DECLARE @Roll int = 30
DECLARE @Roll2 int = 60
DECLARE @Roll3 int = 90
DECLARE @MinDate date = '2020-01-31'
DECLARE @MaxDate date = EOMONTH('{{ ds }}',-1)

----------------------------------------------
-- BLOCO DE PREPARAÇÃO: BASE ATIVA PAYMENTS --
----------------------------------------------
DROP TABLE IF EXISTS #DataReferencia;

SELECT CAST(EOMONTH(fulldate)AS DATE) AS DataFim
INTO #DataReferencia
FROM StoneDWv0.dbo.dimdate
WHERE EOMONTH(fulldate)>= '2019-12-31'
	AND EOMONTH(fulldate)<= EOMONTH('{{ ds }}',-1)
GROUP BY CAST(eomonth(fulldate)AS DATE);

DROP TABLE IF EXISTS #BaseAtivaAdquirencia;

SELECT
	EOMONTH(dt.DataFim,1) AS reference_date	
	, COUNT(DISTINCT RTrim(ClientCNPJorCPF)) AS kpi_value

INTO #BaseAtivaAdquirencia
FROM [Stonedwv0].[dbo].[FactTPV] AS A
	JOIN [Stonedwv0].[dbo].[DimAffiliation]	AS B ON A.AffiliationKey = B.AffiliationKey
	JOIN [Stonedwv0].[dbo].[DimSalesStructure] AS C ON B.SalesStructureKey = C.SalesStructureKey
	JOIN [Stonedwv0].[dbo].[DimDate] AS D ON A.TransactionDate = D.DateKey
	JOIN #DataReferencia AS dt ON D.FullDate >= dateadd(day, -29, dt.DataFim) AND D.FullDate <= dt.DataFim
	JOIN [Stonedwv0].[dbo].[DimCompany]		AS DC ON A.CompanyKey = DC.CompanyKey
WHERE  A.TypeKey = 1
	AND A.Transactions >= 1
	AND SalesStructureNameLevel1 IN ('POLOS', 'PAGARME - SMB', 'PAGARME -  SMB', 'PAGARME SMB')
	AND B.CompanyKey in (1,2)
	AND A.TransactionDate <= CONVERT(VARCHAR, EOMONTH('{{ ds }}', -1), 112)
GROUP BY  dt.DataFim;

-----------------------------------------
-- FIM PREPARAÇÃO: BASE ATIVA PAYMENTS --
-----------------------------------------

--------------------------------------------------------------------
-- BLOCO DE PREPARAÇÃO PARA O LOOP DO CÁLCULO DO CHURN 0-6m E 6m+ --
--------------------------------------------------------------------
DROP TABLE IF EXISTS #MainChurn;
CREATE TABLE #MainChurn
(
	ReferenceDate DATE
	,
	Onb INT
	,
	BaseAtivaDm30 INT
	,
	BaseAtivaDm30Ref INT
	,
	Churn INT
);
-------------------------------
--------- TPV DIÁRIO ---------- 
------------------------------- 

DROP TABLE IF EXISTS #TPVFULL;

SELECT
	C.ClientKey
, DT.FullDate TransactionDate
, SUM(ISNULL(T.TPV,0)) TPV
INTO #TPVFULL
FROM StoneDWv0.dbo.FactTPV T
	JOIN StoneDWv0..DimDate DT ON DT.DateKey = T.TransactionDate
	JOIN StoneDWv0..DimAffiliation A ON A.AffiliationKey = T.AffiliationKey
	JOIN StoneDwv0.kpi.ClientListHubs C ON C.ClientKey = A.ClientKey
WHERE (DT.FullDate between DATEADD(day,-2*@Roll3+1,@MinDate) and @MaxDate )
GROUP BY
C.ClientKey
,DT.FullDate;
-------------------------------------------------------------
-- FIM BLOCO DE PREPARAÇÃO PARA O LOOP DO CÁLCULO DO CHURN --
-------------------------------------------------------------

--------------------------------------------------------------
-- BLOCO DE PREPARAÇÃO PARA O LOOP DO CÁLCULO DE REATIVAÇÃO --
--------------------------------------------------------------
DROP TABLE IF EXISTS #MainReativaction;

CREATE TABLE #MainReativaction
(
	ReferenceDate DATE
		,
	Onb INT
		,
	ReactivatedR30 INT
);

DROP TABLE IF EXISTS #AUX;

SELECT
	H.ClientKey,
	H.SalesStructureNameLevel3,
	CASE  WHEN max([TpvPotencial]) <= 10000 THEN 'P'
		WHEN max([TpvPotencial]) <= 50000 THEN 'M'
		WHEN max([TpvPotencial]) > 50000 THEN 'G'
		ELSE 'Erro' END [Tier]
INTO #AUX
FROM StoneDwv0.kpi.ClientListHubs H
	LEFT JOIN [StoneDWv0].kpi.VwAffiliationPersonasReport P on P.ClientKey = H.ClientKey
group by h.ClientKey, H.SalesStructureNameLevel3;

DROP TABLE IF EXISTS #DailyTpvCKFULL;

SELECT
	AFF.ClientKey,
	D.FullDate TransactionDate,
	SUM(ISNULL(T.Tpv,0)) Tpv
INTO #DailyTpvCKFULL
FROM StoneDwv0.kpi.ClientListHubs X
	JOIN [StonedWv0]..[DimAffiliation]  AFF ON AFF.ClientKey = X.ClientKey
	JOIN [StonedWv0]..[FactTPV]  T ON T.AffiliationKey = AFF.AffiliationKey
	JOIN [StonedWv0]..[DimDate]  D ON D.DateKey = T.TransactionDate --AND (D.FullDate between DATEADD(day,-59,@MinDate) and @MaxDate)
	JOIN [StoneDWv0].[dbo].[DimSalesStructure]  SS ON SS.SalesStructureKey = AFF.SalesStructureKey AND SS.SalesStructureNameLevel1 = 'POLOS'
	JOIN [StoneDWv0].[dbo].[DimVendor]  V ON V.VendorKey = AFF.VendorKey AND V.VendorName <> 'Link ABC'
WHERE (D.FullDate between DATEADD(day,-59,@MinDate) and @MaxDate)
GROUP BY 
		AFF.ClientKey, 
		D.FullDate;

------------------------------------------------------------------
-- FIM BLOCO DE PREPARAÇÃO PARA O LOOP DO CÁLCULO DE REATIVAÇÃO --
------------------------------------------------------------------

--------------------------------------
-- CURSOR PARA EXECUTAR O LOOP UMA  --
-- VEZ PARA CADA DATA DE REFERÊNCIA --
--------------------------------------
DECLARE dateCursor CURSOR FOR
SELECT CAST(EOMONTH(fulldate)AS DATE) AS DataIni
	  , CAST(EOMONTH(fulldate)AS DATE) AS DataFim
FROM StoneDWv0.dbo.dimdate
WHERE EOMONTH(fulldate)>= @MinDate
	AND EOMONTH(fulldate)<= @MaxDate
GROUP BY CAST(eomonth(fulldate)AS DATE)
;

OPEN dateCursor

FETCH NEXT FROM dateCursor INTO @DTi,@DTf

WHILE @@FETCH_STATUS = 0

BEGIN
	-------- INÍCIO CHURN ---------
	-------------------------------
	--------- TPV DIÁRIO ---------- 
	------------------------------- 
	DROP TABLE IF EXISTS #TPVD;

	SELECT
		T.ClientKey
	, T.TransactionDate
	, TPV
	INTO #TPVD
	FROM #TPVFULL T
	WHERE T.TransactionDate BETWEEN DATEADD(day,-2*@Roll3+1,@DTi) AND @DTf

	-------------------------------
	--------- TPV ROLL 30 --------- 
	-------------------------------
	DROP TABLE IF EXISTS #TPVR30;

	SELECT
		C.ClientKey
	, D.ReferenceDate
	, SUM(ISNULL(T.TPV,0)) TPVR30
	INTO #TPVR30
	FROM StoneDwv0.kpi.ClientListHubs C
	CROSS JOIN (SELECT FullDate ReferenceDate
		FROM [StonedWv0]..[DimDate]
		WHERE FullDate between @DTi and @DTf OR FullDate between DATEADD(day,-@Roll,@DTi) and DATEADD(day,-@Roll,@DTf)) D
		LEFT JOIN #TPVD T ON T.ClientKey = C.ClientKey and T.TransactionDate between DATEADD(day,-29,D.ReferenceDate) and D.ReferenceDate
	GROUP BY
	C.ClientKey
	,D.ReferenceDate;

	-------------------------------
	------- BASE ONBOARDING ------- 
	-------------------------------
	DROP TABLE IF EXISTS #onbChurn;

	SELECT
		D.ReferenceDate,
		c.ClientKey,
		max(CASE WHEN C.NewActivationDate between DATEADD(day,-120,D.ReferenceDate) and D.ReferenceDate THEN 1 ELSE 0 end ) Onb
	into #onbChurn
	FROM StoneDwv0.kpi.ClientListHubs C
	CROSS JOIN (SELECT FullDate ReferenceDate
		FROM [StonedWv0]..[DimDate]
		WHERE FullDate between @DTi and @DTf) D
		LEFT JOIN StoneDWv0.dbo.DimAffiliation aff ON aff.ClientKey = C.ClientKey
		LEFT JOIN StoneDWv0.dbo.DimAffiliationData affd ON affd.AffiliationKey = aff.AffiliationKey
	group by D.ReferenceDate,
	c.ClientKey;

	--------------------------------
	------- BASE CONSOLIDADA ------- 
	--------------------------------
	INSERT INTO #MainChurn
	SELECT
		D.ReferenceDate
	, o.Onb
	, SUM(CASE WHEN ISNULL(TR30.TPVR30,0) > 1 THEN 1 ELSE 0 END) BaseAtivaDm30
	, SUM(CASE WHEN ISNULL(TR30REF.TPVR30,0) > 1 THEN 1 ELSE 0 END) BaseAtivaDm30Ref
	, SUM(CASE WHEN ISNULL(TR30REF.TPVR30,0) > 1 AND ISNULL(TR30.TPVR30,0) <= 1 THEN 1 ELSE 0 END) Churn
	--INTO #Main
	FROM StoneDwv0.kpi.ClientListHubs C
	CROSS JOIN (SELECT FullDate ReferenceDate
		FROM [StonedWv0]..[DimDate]
		WHERE FullDate between @Dti and @Dtf) D
		LEFT JOIN #TPVR30 TR30 ON TR30.ClientKey = C.ClientKey AND TR30.ReferenceDate = D.ReferenceDate
		LEFT JOIN #TPVR30 TR30REF ON TR30REF.ClientKey = C.ClientKey AND TR30REF.ReferenceDate = DATEADD(day,-30,D.ReferenceDate)
		LEFT JOIN (SELECT ClientKey, ClientCNPJorCPF, Min(ClientAlternateKey) ClientAlternateKey
		from StoneDWv0..DimAffiliation
		group by ClientKey, ClientCNPJorCPF) A on a.ClientKey = C.ClientKey
		LEFT JOIN #onbChurn o on o.ClientKey = C.ClientKey and o.ReferenceDate = D.ReferenceDate
	GROUP BY
	D.ReferenceDate
	,o.Onb;
	-------- FIM CHURN ---------

	-------- INÍCIO REATIVAÇÃO ---------
	DROP TABLE IF EXISTS #DailyTpvCK;

	SELECT
		T.ClientKey,
		T.TransactionDate,
		T.Tpv
	INTO #DailyTpvCK
	FROM #DailyTpvCKFULL T
	WHERE T.TransactionDate BETWEEN DATEADD(day,-59,@DTi) and @DTf;

	DROP TABLE IF EXISTS #Roll30TpvCK;

	SELECT
		X.ClientKey,
		D.FullDate ReferenceDate,
		SUM(ISNULL(DTPV.Tpv,0)) Roll30Tpv
	INTO 
        #Roll30TpvCK
	FROM
		StoneDwv0.kpi.ClientListHubs X
    CROSS JOIN 
        (SELECT
			FullDate
		FROM
			[StonedWv0]..[DimDate]
		WHERE 
            FullDate between DATEADD(day,-30,@DTi) and DATEADD(day,-30,@DTf)
			OR FullDate between @DTi and @DTf) D
		LEFT JOIN
		#DailyTpvCK DTPV
		ON DTPV.ClientKey = X.ClientKey
			AND DTPV.TransactionDate between DATEADD(day,-30+1,D.FullDate) and D.FullDate
	GROUP BY 
        X.ClientKey, 
        D.FullDate;

	DROP TABLE IF EXISTS #TMP;

	SELECT
		RTPV1.ClientKey,
		RTPV1.ReferenceDate,
		RTPV1.Roll30Tpv,
		RTPV2.ReferenceDate ReferenceDateDM30,
		RTPV2.Roll30Tpv Roll30TpvDM30
	INTO 
        #TMP
	FROM
		#Roll30TpvCK RTPV1
		LEFT JOIN
		#Roll30TpvCK RTPV2
		ON RTPV2.ClientKey = RTPV1.ClientKey AND RTPV2.ReferenceDate = DATEADD(day,-30,RTPV1.ReferenceDate)
	WHERE 
        RTPV1.ReferenceDate between @DTi and @DTf;

	DROP TABLE IF EXISTS #TMP2;

	SELECT
		TMP.ClientKey,
		TMP.ReferenceDate,
		CASE WHEN TMP.Roll30Tpv > 1 THEN 1 ELSE 0 END ActiveBase,
		CASE WHEN TMP.Roll30TpvDM30 > 1 THEN 1 ELSE 0 END ActiveBaseDM30,
		CASE WHEN TMP.Roll30TpvDM30 <= 1 AND TMP.Roll30Tpv > 1 AND (X.NewActivationDate between DATEADD(day,+1,TMP.ReferenceDateDM30) and TMP.ReferenceDate OR X.NewActivationDate is NULL) THEN 1 ELSE 0 END NewActive,
		CASE WHEN TMP.Roll30TpvDM30 <= 1 AND TMP.Roll30Tpv > 1 AND X.NewActivationDate NOT between DATEADD(day,+1,TMP.ReferenceDateDM30) and TMP.ReferenceDate AND X.NewActivationDate is NOT NULL THEN 1 ELSE 0 END Reactivated,
		CASE WHEN TMP.Roll30TpvDM30 > 1 AND TMP.Roll30Tpv <= 1 THEN 1 ELSE 0 END Churn,
		A.Tier,
		A.SalesStructureNameLevel3
	INTO 
        #TMP2
	FROM
		#TMP TMP
		LEFT JOIN
		StoneDwv0.kpi.ClientListHubs X
		ON X.ClientKey = TMP.ClientKey
		LEFT JOIN
		#AUX A
		ON A.ClientKey = TMP.ClientKey;

	DROP TABLE IF EXISTS #onbReactivation;

	SELECT
		D.ReferenceDate,
		c.ClientKey,
		max(CASE WHEN C.NewActivationDate between DATEADD(day,-120,D.ReferenceDate) and D.ReferenceDate  THEN 1 ELSE 0 end ) Onb
	into #onbReactivation
	FROM StoneDwv0.kpi.ClientListHubs C
	CROSS JOIN (SELECT FullDate ReferenceDate
		FROM [StonedWv0]..[DimDate]
		WHERE FullDate between @DTi and @DTf) D
		LEFT JOIN StoneDWv0.dbo.DimAffiliation aff ON aff.ClientKey = C.ClientKey
		LEFT JOIN StoneDWv0.dbo.DimAffiliationData affd ON affd.AffiliationKey = aff.AffiliationKey
	group by 	D.ReferenceDate,
	c.ClientKey;


	INSERT INTO #MainReativaction
	SELECT
		TMP2.ReferenceDate,
		o.Onb,
		SUM(Reactivated) ReactivatedR30
	FROM #TMP2 TMP2
		LEFT JOIN StoneDwv0.kpi.ClientListHubs X ON TMP2.ClientKey = X.ClientKey
		LEFT JOIN #onbReactivation o ON o.ClientKey = TMP2.ClientKey
	GROUP BY 
		  TMP2.ReferenceDate,
		  o.onb;
	-------- FIM REATIVAÇÃO ---------

	FETCH NEXT FROM dateCursor INTO @DTi,@DTf

END

CLOSE dateCursor

DROP TABLE IF EXISTS #KPIS;

SELECT
	CE.ReferenceDate
	, CAST(ROUND(((CE.Churn-RE.ReactivatedR30)/(CE.BaseAtivaDm30Ref*1.0))*100,2) as numeric(36,2)) as [4017.1]
	, CE.Churn as [4017.2]
	, RE.ReactivatedR30 as [4017.3]
	, late.[4017.4]
	, late.[4017.5]
	, late.[4017.6]
	, CAST((((CE.Churn+late.[4017.5])-(RE.ReactivatedR30+late.[4017.6]))/NULLIF(baa.kpi_value*1.0,0))*100 as numeric(36,2)) as [4017.7]
	, CE.BaseAtivaDm30Ref as [BaseAtivaDm30Ref 0-6m]
	, late.[BaseAtivaDm30Ref 6m+]
	, baa.kpi_value as BaseAtivaPayments
INTO #KPIS
FROM #MainChurn CE
	JOIN #MainReativaction RE ON CE.ReferenceDate = RE.ReferenceDate AND CE.Onb = RE.Onb AND CE.Onb = 1
	JOIN (SELECT
		CL.ReferenceDate
	, CL.BaseAtivaDm30Ref as [BaseAtivaDm30Ref 6m+]
	, CAST(ROUND(((CL.Churn-RL.ReactivatedR30)/(CL.BaseAtivaDm30Ref*1.0))*100,2) as numeric(36,2)) as [4017.4]
	, CL.Churn as [4017.5]
	, RL.ReactivatedR30 as [4017.6]
	FROM #MainChurn CL
		JOIN #MainReativaction RL ON CL.ReferenceDate = RL.ReferenceDate AND CL.Onb = RL.Onb AND CL.Onb = 0) as late ON late.ReferenceDate = CE.ReferenceDate
	JOIN #BaseAtivaAdquirencia baa ON CE.ReferenceDate = baa.reference_date;

--------------
--- 4017.1 ---
--------------
INSERT INTO StoneDWv0.kpi.ClosingMasterKpi
	(
	execution_date,
	kpi_index,
	kpi_name,
	reference_date,
	company,
	sales_channel,
	sales_subchannel,
	card_brand,
	product,
	installments,
	acquirer,
	rav_type,
	kpi_value
	)
	select '{{ ds }}'
		, '4017.1' kpi_index
		, 'Early Churn Liquido (0-6m) StoneSMB  %' kpi_name
		, ReferenceDate reference_date
		, 'Não se aplica' company
		, 'Não se aplica' sales_channel
		, 'Não se aplica' sales_subchannel
		, 'Não se aplica' card_brand
		, 'Não se aplica' product
		, 'Não se aplica' installments
		, 'Não se aplica' acquirer
		, 'Não se aplica' rav_type
		, [4017.1] as kpi_value
	from #KPIS
	--------------
	--- 4017.2 ---
	--------------
UNION ALL
	select '{{ ds }}'
		, '4017.2' kpi_index
		, '# churn bruto (0-6m)' kpi_name
		, ReferenceDate reference_date
		, 'Não se aplica' company
		, 'Não se aplica' sales_channel
		, 'Não se aplica' sales_subchannel
		, 'Não se aplica' card_brand
		, 'Não se aplica'product
		, 'Não se aplica' installments
		, 'Não se aplica' acquirer
		, 'Não se aplica' rav_type
		, [4017.2] as kpi_value
	from #KPIS
--------------
--- 4017.3 ---
--------------
UNION ALL
	select '{{ ds }}'
		, '4017.3' kpi_index
		, ' # reativados (0-6m)' kpi_name
		, ReferenceDate reference_date
		, 'Não se aplica' company
		, 'Não se aplica' sales_channel
		, 'Não se aplica' sales_subchannel
		, 'Não se aplica' card_brand
		, 'Não se aplica'product
		, 'Não se aplica' installments
		, 'Não se aplica' acquirer
		, 'Não se aplica' rav_type
		, [4017.3] as kpi_value
	from #KPIS
--------------
--- 4017.4 ---
--------------
UNION ALL
	select '{{ ds }}'
		, '4017.4' kpi_index
		, 'Churn Liquido (6m+) StoneSMB % ' kpi_name
		, ReferenceDate reference_date
		, 'Não se aplica' company
		, 'Não se aplica' sales_channel
		, 'Não se aplica' sales_subchannel
		, 'Não se aplica' card_brand
		, 'Não se aplica'product
		, 'Não se aplica' installments
		, 'Não se aplica' acquirer
		, 'Não se aplica' rav_type
		, K.[4017.4] as kpi_value
	from #KPIS K
--------------
--- 4017.5 ---
--------------
UNION ALL
	select '{{ ds }}'
		, '4017.5' kpi_index
		, '# churn bruto (6m+)' kpi_name
		, ReferenceDate reference_date
		, 'Não se aplica' company
		, 'Não se aplica' sales_channel
		, 'Não se aplica' sales_subchannel
		, 'Não se aplica' card_brand
		, 'Não se aplica'product
		, 'Não se aplica' installments
		, 'Não se aplica' acquirer
		, 'Não se aplica' rav_type
		, K.[4017.5] as kpi_value
	from #KPIS K
--------------
--- 4017.6 ---
--------------
UNION ALL
	select '{{ ds }}'
		, '4017.6' kpi_index
		, '# reativados (6m+)' kpi_name
		, ReferenceDate reference_date
		, 'Não se aplica' company
		, 'Não se aplica' sales_channel
		, 'Não se aplica' sales_subchannel
		, 'Não se aplica' card_brand
		, 'Não se aplica'product
		, 'Não se aplica' installments
		, 'Não se aplica' acquirer
		, 'Não se aplica' rav_type
		, K.[4017.6] as kpi_value
	from #KPIS K
--------------
--- 4017.7 ---
--------------
UNION ALL
	select '{{ ds }}'
		, '4017.7' kpi_index
		, 'Churn Liquido Payments %' kpi_name
		, ReferenceDate reference_date
		, 'Não se aplica' company
		, 'Não se aplica' sales_channel
		, 'Não se aplica' sales_subchannel
		, 'Não se aplica' card_brand
		, 'Não se aplica' product
		, 'Não se aplica' installments
		, 'Não se aplica' acquirer
		, 'Não se aplica' rav_type
		, K.[4017.7] as kpi_value
	from #KPIS K
