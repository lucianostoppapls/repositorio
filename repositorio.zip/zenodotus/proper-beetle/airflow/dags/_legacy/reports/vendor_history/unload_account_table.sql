SELECT Id, CNPJ_Limpo__c, Route__c, stonecode__c FROM Account
