delete from StoneDWv0.kpi.DimRavChannelTypeHistory where BaseDate = eomonth(getdate(),-1)

insert into StoneDWv0.kpi.DimRavChannelTypeHistory

select cast(nr_stonecode as varchar(50)),
	cd_rav_auto,
	eomonth(getdate(),-1)
from {{ ti.xcom_pull('create_ravfees_temp_table') }}
