select cast([NR_STONECODE] as varchar(50)) nr_stonecode
    ,cast([CD_RAV_AUTO] as float) cd_rav_auto
from [StoneCoODS].[stone].[TBSTONEF_CADASTRO_RAV]
