delete from StoneDWv0.kpi.DimUserTerritory2AssiciationHistory where BaseDate = eomonth(getdate(),-1)

insert into StoneDWv0.kpi.DimUserTerritory2AssiciationHistory

select UserTerritory2AssociationKey,
        UserKey,
        Territory2Key,
        IsActive,
        RoleInTerritory2,
        LastModifiedDate,
        LastModifiedByKey,
        SystemModstamp,
        eomonth(getdate(),-1)
from StoneDWv0.dbo.DimUserTerritory2Association
where IsActive=1
