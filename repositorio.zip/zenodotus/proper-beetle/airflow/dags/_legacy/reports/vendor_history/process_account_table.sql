delete from StoneDWv0.kpi.DimAccountHistory where eomonth(BaseDate) = eomonth(getdate(),-1);

insert into StoneDWv0.kpi.DimAccountHistory

select AccountKey,
	ClientCNPJorCPF,
        Route,
	ClientAlternateKey,
	eomonth(getdate(),-1)
from StoneDWv0.dbo.DimAccount
where IsDeleted = 0
