delete from StoneDWv0.kpi.DimTerritory2History where BaseDate = eomonth(getdate(),-1)

insert into StoneDWv0.kpi.DimTerritory2History

select Territory2Key,
        Name,
        LastModifiedDate,
        ParentTerritory2Key,
        Territory2ModelKey,
        Territory2TypeKey,
        Active,
        eomonth(getdate(),-1),
        PaymentActive
from StoneDWv0.dbo.DimTerritory2
