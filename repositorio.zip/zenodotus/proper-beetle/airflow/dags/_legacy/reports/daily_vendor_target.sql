SELECT [Id]
      ,cast([ALFA__c]*100 as int) ALFA__c
      ,[Data__c]
      ,[CRED_ATI_APURADO__C]
      ,[CRED_AUTO_APURADO__C]
      ,[REC_ALU_APURADO__C]
      ,[REC_MDR_APURADO__C]
      ,[TPV_APURADO__C]
FROM [StoneDWv0].[kpi].[VwHubVendorsTargetDailyReport] 
