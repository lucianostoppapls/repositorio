from datetime import datetime, timedelta
from airflow import DAG
from _legacy.airflow_utils import make_backfill_dags
from _legacy.pagarminho import default_args, inject_tasks
from functools import partial


revenues_task = partial(
    inject_tasks,
    etl_name="revenues",
    gcs_file="airflow-files/_legacy/pagarminho/{{ ds }}-revenues.csv",
    dest_database="StoneCoODS",
    dest_schema="pagarme",
    dest_table="revenues",
    date_column="date",
    window_days=20,
)

recents, backfill = make_backfill_dags(
    task_id="_legacy__pagarminho_revenues",
    version=6,
    recents_start_date=datetime(2021, 7, 8, 6, 0),
    backfill_expected_start_date=datetime(2014, 1, 1, 10, 0),
    recents_schedule_interval=timedelta(days=1),
    backfill_schedule_interval=timedelta(days=40),
    dag_factory=lambda **kwargs: DAG(**kwargs),
    default_args=default_args,
    max_active_runs=1,
    backfill_enabled=True,
)


revenues_task(dag=recents, looker_tables=[], source_sql="pagarminho/revenues_16.sql")

revenues_task(
    dag=backfill,
    looker_tables=["revenues_table"],
    source_sql="pagarminho/revenues_looker.sql",
)
