from datetime import datetime, timedelta
from airflow import DAG
from mssql_utils import MsSqlOperatorPYODBC
from mssql_utils import GCSToMssqlExtractOperator
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts
from airflow import configuration as conf
from plugins.gcp_utils import BigqueryToGCSOperator

default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "retries": 4,
    "retry_delay": timedelta(minutes=15),
    "autocommit": True,
    "google_cloud_storage_conn_id": "gcp_mis",
    "mssql_conn_id": "bw_azure",
    "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
    "on_failure_callback": PagerDutyAlerts.failure_incident,
    "on_success_callback": PagerDutyAlerts.resolve_incident,
}

dag = DAG(
    dag_id="_legacy__mundi_ods_revenues",
    default_args=default_args,
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 8, 20),
)

with dag:
    extract = BigqueryToGCSOperator(
        task_id="extract_mundi_revenues",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/mundi_ods/revenues_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        sql="""
            WITH billingdb_invoice AS (
                SELECT 
                    Invoice.*,
                    cteInvoice.maxPaymentDate as maxPaymentDate
                FROM dataplatform-prd.mundi_billingdb.invoice invoice
                LEFT JOIN (
                    SELECT DISTINCT
                        i.invoiceId,
                        MAX(paymentdate) over(partition by i.invoiceId) as maxPaymentDate
                    FROM dataplatform-prd.mundi_billingdb.invoice i
                    LEFT JOIN dataplatform-prd.mundi_billingdb.invoice childinv ON
                        childinv.parentinvoiceid = i.invoiceid
                        AND i.invoicestatus IN (3,9,10)
                    LEFT JOIN dataplatform-prd.mundi_billingdb.order o ON
                        i.invoiceid = o.invoiceid
                        OR childinv.invoiceid = o.invoiceid
                    WHERE o.totalamount >= 0
                ) cteInvoice ON invoice.invoiceId = cteInvoice.invoiceId
            )
            ,billingdb_customer AS (
                SELECT 
                    customer.*, 
                    nfse.competencedate as firstnfsecompetencedate, 
                    tb.has_stone as acquirerstone
                FROM dataplatform-prd.mundi_billingdb.customer customer
                LEFT JOIN (
                    SELECT DISTINCT
                        customer.customerId as customerid,
                        MIN(nfse.nfseid) over(partition by customer.customerId) as firstnfseid
                    FROM dataplatform-prd.mundi_billingdb.nfse nfse
                    LEFT JOIN dataplatform-prd.mundi_billingdb.invoice invoice ON invoice.invoiceid = nfse.invoiceid
                    LEFT JOIN (
                        SELECT DISTINCT
                            cust.customerid as customerid,
                            MIN(cont.contractid) over (partition by cust.customerId) as firstcontractid
                        FROM dataplatform-prd.mundi_billingdb.customer cust
                        LEFT JOIN dataplatform-prd.mundi_billingdb.contract cont ON cust.customerid = cont.customerid
                        LEFT JOIN dataplatform-prd.mundi_billingdb.servicedelivery sd on sd.contractid = cont.contractid
                        WHERE sd.typeserviceid IN (1, 3, 5, 6, 11, 15, 16)
                    ) contract ON contract.firstcontractid = invoice.contractid
                    LEFT JOIN dataplatform-prd.mundi_billingdb.customer customer ON customer.customerid = contract.customerid
                    LEFT JOIN dataplatform-prd.mundi_billingdb.invoiceofservicedelivery iosd on iosd.invoiceid = invoice.invoiceid
                    LEFT JOIN dataplatform-prd.mundi_billingdb.servicedelivery sd on sd.servicedeliveryid = iosd.servicedeliveryid
                    WHERE
                        nfse.nfsestatusenum IN (0, 2)
                        AND sd.typeserviceid IN (1, 3, 5, 6, 11, 15, 16)
                ) firstnfse on customer.customerid = firstnfse.customerid
                LEFT JOIN dataplatform-prd.mundi_billingdb.nfse nfse ON nfse.nfseid = firstnfse.firstnfseid
                LEFT JOIN (
                    SELECT DISTINCT
                        c.customerkey as customerkey,
                        CASE
                            WHEN mmaa.acquirerid=8 THEN true
                        END as has_stone
                    FROM dataplatform-prd.mundi_mundipaggdb.vw_customer as c
                    LEFT JOIN dataplatform-prd.mundi_mundipaggdb.merchant as mm on mm.customerid = c.customerid
                    LEFT JOIN dataplatform-prd.mundi_mundipaggdb.merchantacquireragreement mmaa on mmaa.MERCHANTID = mm.MERCHANTID
                    WHERE
                        mm.isenabled=true
                        AND mmaa.isenabled=true
                        AND (CASE WHEN mmaa.acquirerid=8 THEN true END)=true
                ) as tb on tb.customerkey = customer.customerkey
            )
            ,_billinggrossrevenue AS (
                WITH final AS (
                    SELECT
                        nf.number,
                        isd.INVOICEOFSERVICEDELIVERYID,
                        ii.isminimumvalue,
                        CASE WHEN count(nf.number) OVER (PARTITION BY nf.number,ii.invoiceid,isd.invoiceofservicedeliveryid,ts.name)>1 THEN nf.nfseamount
                                ELSE CASE WHEN ts.name in ('Setup','Projetos','Criação de Loja','B2W','Wallet','Criptomoedas') THEN nf.nfseamount
                                                    ELSE (nf.nfseamount)*(ii.totalamount/nullif(sum(ii.totalamount) OVER(partition by ii.invoiceid,nf.number),0))
                                            END
                        END as newInvoiceTotalAmount
                    FROM  dataplatform-prd.mundi_billingdb.nfse nf
                    FULL OUTER JOIN dataplatform-prd.mundi_billingdb.invoice i on nf.invoiceid=i.invoiceid
                    LEFT JOIN dataplatform-prd.mundi_billingdb.invoiceofservicedelivery isd on isd.invoiceid=i.invoiceid
                    LEFT JOIN dataplatform-prd.mundi_billingdb.servicedelivery sd on sd.servicedeliveryid=isd.servicedeliveryid
                    LEFT JOIN dataplatform-prd.mundi_billingdb.typeservice ts on ts.typeserviceid=sd.typeserviceid
                    LEFT JOIN dataplatform-prd.mundi_billingdb.invoiceitem ii on ii.invoiceid=i.invoiceid and ii.description=ts.name
                    WHERE nf.NFSESTATUSENUM in (0,2)
                    GROUP BY
                        ii.totalamount,
                        ii.isminimumvalue,
                        ii.invoiceid,
                        isd.INVOICEOFSERVICEDELIVERYID,
                        ts.name,
                        nf.nfseamount,
                        nf.number
                )
                select * from final
            )

            SELECT
                CAST(PARSE_TIMESTAMP('%FT%H:%M:%E*SZ', JSON_EXTRACT_SCALAR(billingv2_invoice.metadata, '$.nfeio_issue_date')) AS DATE) AS RevenueDate,
                --quando a migração do billingv1 pro v2 acabar, vamos usar a fórmula abaixo para pegar id do cliente.
                --COALESCE(ISNULL(NULLIF(JSON_EXTRACT_PATH_TEXT(billingv2_customer.METADATA, 'mark1_id'),' '), NULL),JSON_EXTRACT_PATH_TEXT(billingv2_customer.METADATA, 'one_id'))
                account.CustomerKey AS CustomerKey,
                'Gateway' as RevenueServiceType,
                SUM(CAST(REGEXP_EXTRACT(JSON_EXTRACT_SCALAR(billingv2_invoice.metadata, '$.nfeio_invoice_services_amount'), r"[0-9]+") AS NUMERIC))/100.0 as GrossRevenue
                FROM dataplatform-prd.mundi_mark1db.customer AS billingv2_customer
            --LEFT JOIN dataplatform-prd.mundi_mark1db.subscription  AS billingv2_subscription ON billingv2_subscription.CUSTOMERID = billingv2_customer.ID
            LEFT JOIN dataplatform-prd.mundi_mark1db.invoice  AS billingv2_invoice ON billingv2_customer.ID = billingv2_invoice.customerid
            LEFT JOIN dataplatform-prd.mundi_mark1db.account  AS billingv2_account ON billingv2_customer.ACCOUNTID = billingv2_account.ID
            LEFT JOIN dataplatform-prd.mundi_mark1db.merchant  AS billingv2_merchant ON billingv2_account.MERCHANTID = billingv2_merchant.ID
            LEFT JOIN (--alguns clientes possuem mais de uma customerkey cadastrada no SF, por isso faço o max
                select
                    upper(max(affiliationid__c)) as CustomerKey
                    ,customerservicekey__c as BillingKey
                from dataplatform-prd.sop_salesforce.account
                where customerservicekey__c is not null
                group by 2
            ) account on account.BillingKey = billingv2_customer.externalid
            WHERE
                billingv2_merchant.NAME = 'Billing Service'
                AND billingv2_account.PUBLICKEY = 'pk_PBWZ3dVHbIBbjOJL'
                AND JSON_EXTRACT_SCALAR(billingv2_invoice.METADATA, '$.nfeio_provider_legal_name') = 'PAGAR.ME PAGAMENTOS S.A.'
                AND JSON_EXTRACT_SCALAR(billingv2_invoice.METADATA, '$.nfeio_invoice_status') = 'Issued'
                AND account.customerkey is not null
                AND CAST(PARSE_TIMESTAMP('%FT%H:%M:%E*SZ', JSON_EXTRACT_SCALAR(billingv2_invoice.metadata, '$.nfeio_issue_date')) AS DATE) >= DATE_TRUNC(CAST('{{ ds }}' AS DATE), MONTH)
                AND CAST(PARSE_TIMESTAMP('%FT%H:%M:%E*SZ', JSON_EXTRACT_SCALAR(billingv2_invoice.metadata, '$.nfeio_issue_date')) AS DATE) < DATE_ADD(DATE_TRUNC(CAST('{{ ds }}' AS DATE), MONTH), INTERVAL 1 MONTH)
            GROUP BY
                RevenueDate
                , RevenueServiceType
                , CustomerKey

            UNION ALL

            SELECT
                CAST(PARSE_TIMESTAMP('%FT%H:%M:%E*SZ', JSON_EXTRACT_SCALAR(billingv2_order.metadata, '$.nfeio_issue_date')) AS DATE) AS RevenueDate,
                --quando a migração do billingv1 pro v2 acabar, vamos usar a fórmula abaixo para pegar id do cliente.
                --COALESCE(ISNULL(NULLIF(JSON_EXTRACT_SCALAR(billingv2_customer.METADATA, '$.mark1_id'),' '), NULL),JSON_EXTRACT_PATH_TEXT(billingv2_customer.METADATA, 'one_id'))
                account.CustomerKey AS CustomerKey,
                'Setup' as RevenueServiceType,
                SUM(CAST(REGEXP_EXTRACT(JSON_EXTRACT_SCALAR(billingv2_order.METADATA, '$.nfeio_invoice_services_amount'), r"[0-9]+") AS NUMERIC))/100.0 as GrossRevenue
            FROM dataplatform-prd.mundi_mark1db.customer  AS billingv2_customer
            --LEFT JOIN dataplatform-prd.mundi_mark1db.subscription  AS billingv2_subscription ON billingv2_subscription.CUSTOMERID = billingv2_customer.ID
            LEFT JOIN dataplatform-prd.mundi_mark1db.order  billingv2_order ON billingv2_order.customerid = billingv2_customer.id
            LEFT JOIN dataplatform-prd.mundi_mark1db.account  AS billingv2_account ON billingv2_customer.ACCOUNTID = billingv2_account.ID
            LEFT JOIN dataplatform-prd.mundi_mark1db.merchant  AS billingv2_merchant ON billingv2_account.MERCHANTID = billingv2_merchant.ID
            LEFT JOIN (--alguns clientes possuem mais de uma customerkey cadastrada no SF, por isso faço o max
                select
                    upper(max(affiliationid__c)) as CustomerKey
                    ,customerservicekey__c as BillingKey
                from dataplatform-prd.sop_salesforce.account
                where customerservicekey__c is not null
                group by 2
            ) account on account.BillingKey = billingv2_customer.externalid
            WHERE
                billingv2_merchant.NAME = 'Billing Service'
                AND billingv2_account.PUBLICKEY = 'pk_PBWZ3dVHbIBbjOJL'
                AND JSON_EXTRACT_SCALAR(billingv2_order.metadata, '$.nfeio_provider_legal_name') = 'PAGAR.ME PAGAMENTOS S.A.'
                AND JSON_EXTRACT_SCALAR(billingv2_order.metadata, '$.nfeio_invoice_status') = 'Issued'
                AND account.CustomerKey is not null
                AND CAST(PARSE_TIMESTAMP('%FT%H:%M:%E*SZ', JSON_EXTRACT_SCALAR(billingv2_order.metadata, '$.nfeio_issue_date')) AS DATE) >= DATE_TRUNC(CAST('{{ ds }}' AS DATE), MONTH)
                AND CAST(PARSE_TIMESTAMP('%FT%H:%M:%E*SZ', JSON_EXTRACT_SCALAR(billingv2_order.metadata, '$.nfeio_issue_date')) AS DATE) < DATE_ADD(DATE_TRUNC(CAST('{{ ds }}' AS DATE), MONTH), INTERVAL 1 MONTH)
            GROUP BY
                RevenueDate
                ,RevenueServiceType
                ,CustomerKey

            UNION ALL

            SELECT
                DATE_TRUNC(DATE(billingdb_nfse.EMISSIONDATE), DAY) AS RevenueDate,
                billingdb_customer.CUSTOMERKEY  AS CustomerKey,
                CASE
                    WHEN billingdb_typeservice.NAME like 'Conciliação%' THEN 'Conciliação'
                    WHEN billingdb_typeservice.NAME like 'Gateway%' THEN 'Gateway'
                    ELSE billingdb_typeservice.NAME
                END AS RevenueServiceType,
                COALESCE(ROUND(COALESCE(CAST( ( SUM(DISTINCT (CAST(ROUND(COALESCE(_billinggrossrevenue.newInvoiceTotalAmount ,0)*(1/1000*1.0), 9) AS NUMERIC) + (cast(cast(concat('0x', substr(to_hex(md5(CAST(_billinggrossrevenue.INVOICEOFSERVICEDELIVERYID || _billinggrossrevenue.number  AS STRING))), 1, 15)) as int64) as numeric) * 4294967296 + cast(cast(concat('0x', substr(to_hex(md5(CAST(_billinggrossrevenue.INVOICEOFSERVICEDELIVERYID || _billinggrossrevenue.number  AS STRING))), 16, 8)) as int64) as numeric)) * 0.000000001 )) - SUM(DISTINCT (cast(cast(concat('0x', substr(to_hex(md5(CAST(_billinggrossrevenue.INVOICEOFSERVICEDELIVERYID || _billinggrossrevenue.number  AS STRING))), 1, 15)) as int64) as numeric) * 4294967296 + cast(cast(concat('0x', substr(to_hex(md5(CAST(_billinggrossrevenue.INVOICEOFSERVICEDELIVERYID || _billinggrossrevenue.number  AS STRING))), 16, 8)) as int64) as numeric)) * 0.000000001) )  / (1/1000*1.0) AS FLOAT64), 0), 6), 0) AS GrossRevenue
            FROM mundi_billingdb.nfse  AS billingdb_nfse
            FULL OUTER JOIN dataplatform-prd.mundi_billingdb.invoice as billingdb_invoice ON billingdb_nfse.INVOICEID=billingdb_invoice.INVOICEID
            LEFT JOIN dataplatform-prd.mundi_billingdb.contract  AS billingdb_contract ON billingdb_invoice.CONTRACTID=billingdb_contract.CONTRACTID
            FULL OUTER JOIN billingdb_customer ON billingdb_contract.CUSTOMERID=billingdb_customer.CUSTOMERID
            LEFT JOIN dataplatform-prd.mundi_billingdb.invoiceofservicedelivery  AS billingdb_invoiceofservicedelivery ON billingdb_invoiceofservicedelivery.INVOICEID = billingdb_invoice.INVOICEID
            LEFT JOIN _billinggrossrevenue ON (_billinggrossrevenue.INVOICEOFSERVICEDELIVERYID || _billinggrossrevenue.number)=billingdb_invoiceofservicedelivery.INVOICEOFSERVICEDELIVERYID || billingdb_nfse.NUMBER
            LEFT JOIN dataplatform-prd.mundi_billingdb.servicedelivery  AS billingdb_servicedelivery ON billingdb_invoiceofservicedelivery.SERVICEDELIVERYID=billingdb_servicedelivery.SERVICEDELIVERYID
            LEFT JOIN dataplatform-prd.mundi_billingdb.typeservice  AS billingdb_typeservice ON billingdb_servicedelivery.TYPESERVICEID=billingdb_typeservice.TYPESERVICEID
            WHERE
                billingdb_nfse.EMISSIONDATE IS NOT NULL
                AND CustomerKey IS NOT NULL
                AND DATE(billingdb_nfse.EMISSIONDATE) >= DATE_TRUNC(CAST('{{ ds }}' AS DATE), MONTH)
                AND DATE(billingdb_nfse.EMISSIONDATE) < DATE_ADD(DATE_TRUNC(CAST('{{ ds }}' AS DATE), MONTH),INTERVAL 1 MONTH)
            GROUP BY
                RevenueDate,
                CustomerKey,
                RevenueServiceType
        """,
    )

    clean = MsSqlOperatorPYODBC(
        task_id="clean_mundi_revenues",
        mssql_conn_id="bw_azure",
        database="StoneCoODS",
        sql="""
            DELETE FROM mundi.tbmundif_revenue
            WHERE
                revenuedate >= dateadd(month, datediff(month, 0, '{{ ds }}'), 0)
                and revenuedate < dateadd(day, 1, eomonth('{{ ds }}'))
        """,
    )

    load = GCSToMssqlExtractOperator(
        task_id="load_mundi_revenues",
        database="StoneCoODS",
        dest_schema="mundi",
        table_name="tbmundif_revenue",
        source_file=f"airflow-files/_legacy/mundi_ods/revenues_{{{{ts_nodash.replace('+0000','')}}}}.csv",
        truncate=False,
        gcs_data_delete=False,
    )

extract >> clean >> load
