from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args, transfer_tasks


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_vendor_target_v2",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 6, 0),
    default_args=default_args,
)

transfer_tasks(
    dag=dag,
    repo_name="salesforce",
    table="DimVendorTarget",
    database="StoneDWv0",
    column_types={
        "[VendorTargetKey]": "[nvarchar](18) NOT NULL",
        "[OwnerKey]": "[nvarchar](18) NULL",
        "[OwnerEmail]": "[nvarchar](1300) NULL",
        "[OwnerName]": "[nvarchar](1300) NULL",
        "[PoloName]": "[nvarchar](1300) NULL",
        "[DistrictName]": "[nvarchar](1300) NULL",
        "[TargetATIAccreditations]": "[numeric](16, 0) NOT NULL",
        "[TargetAutoAccreditations]": "[real] NOT NULL",
        "[ReferenceDate]": "[varchar](8) NULL",
        "[TargetRent]": "[numeric](18, 2) NOT NULL",
        "[TargetDIA]": "[numeric](18, 2) NOT NULL",
        "[TargetTPV]": "[numeric](18, 2) NOT NULL",
        "[IsDeleted]": "[bit] NULL",
        "[LastModifiedDate]": "[varchar](8) NULL",
    },
    prod_schema="dbo",
    date_column="LastUpdatedAt",
    external_dag_id="_legacy__salesforce_dim_user_v2",
)
