from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args
from airflow.operators.dummy import DummyOperator
from mssql_utils import (
    CreatePrefixTableMsSqlOperator,
    DropPrefixTableMsSqlOperator,
)
from mssql_utils import MsSqlOperatorPYODBC
from plugins.mssql_utils import GCSToMssqlExtractOperator
from plugins.gcp_utils import BigqueryToGCSOperator


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_sales_structure_v4",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 6, 0),
    default_args=default_args,
)

ds = "{{ ds }}"
with dag:

    check_completion = DummyOperator(task_id="dag_init")

    unload_task = BigqueryToGCSOperator(
        task_id=f"unload_DimSalesStructure",
        source_conn_id="gcp_mis_datalake",
        dest_conn_id="gcp_mis",
        gcs_file=f"airflow-files/_legacy/salesforce/DimSalesStructure-{ds}.csv",
        sql=f"etldw/salesforce/source_DimSalesStructure.sql",
    )

    create_temp_table_task = CreatePrefixTableMsSqlOperator(
        task_id="create_table",
        schema="airflow_staging",
        database="StoneDWv0",
        table_prefix="DimSalesStructure",
        column_types={
            "[SalesStructureNameLevel1]": "[varchar](50) NOT NULL",
            "[SalesStructureNameLevel2]": "[varchar](50) NOT NULL",
            "[SalesStructureNameLevel3]": "[varchar](50) NOT NULL",
            "[SalesStructureNameLevel4]": "[varchar](50) NOT NULL",
            "[SalesStructureNameLevel5]": "[varchar](50) NULL",
            "[SalesStructureNameLevel6]": "[varchar](300) NULL",
        },
        pool="bw_azure",
        mssql_conn_id="bw_azure",
    )

    transfer_task = GCSToMssqlExtractOperator(
        task_id=f"load_DimSalesStructure",
        database="StoneDWv0",
        dest_schema="{{ ti.xcom_pull('create_table').split('.')[0] }}",
        table_name="{{ ti.xcom_pull('create_table').split('.')[1] }}",
        source_file=f"airflow-files/_legacy/salesforce/DimSalesStructure-{ds}.csv",
        truncate=False,
        gcs_data_delete=False,
        pool="bw_azure",
        mssql_conn_id="bw_azure",
    )

    write_task = MsSqlOperatorPYODBC(
        task_id=f"write_DimSalesStructure",
        database="StoneDWv0",
        sql=f"etldw/salesforce/dest_DimSalesStructure.sql",
        pool="bw_azure",
        mssql_conn_id="bw_azure",
    )

    drop_temp_table_task = DropPrefixTableMsSqlOperator(
        task_id="drop_table",
        database="StoneDWv0",
        schema="airflow_staging",
        table_prefix="DimSalesStructure",
        pool="bw_azure",
        mssql_conn_id="bw_azure",
    )

    complete_task = DummyOperator(task_id="dag_complete")

    (
        check_completion
        >> unload_task
        >> create_temp_table_task
        >> transfer_task
        >> write_task
        >> drop_temp_table_task
        >> complete_task
    )
