from datetime import datetime, timedelta
from airflow import DAG
from _legacy.etldw import default_args, transfer_tasks


dag = DAG(
    dag_id=f"_legacy__salesforce_dim_territory2_v2",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 6, 0),
    default_args=default_args,
)

transfer_tasks(
    dag=dag,
    repo_name="salesforce",
    table="DimTerritory2",
    database="StoneDWv0",
    column_types={
        "[Territory2Key]": "[nvarchar](18) NOT NULL",
        "[Name]": "[nvarchar](80) NULL",
        "[LastModifiedDate]": "[varchar](8) NULL",
        "[ParentTerritory2Key]": "[nvarchar](18) NULL",
        "[Territory2ModelKey]": "[nvarchar](18) NULL",
        "[Territory2TypeKey]": "[nvarchar](18) NULL",
        "[Active]": "[int] NULL",
        "[PaymentActive]": "[int] NULL",
    },
    prod_schema="dbo",
    date_column="LastUpdatedAt",
)
