from airflow import DAG
from salesforce_utils import (
    SalesforceToGCSOperator,
    GCSToSalesforceOperator,
)
from mssql_utils import (
    GCSToMssqlExtractOperator,
    CreatePrefixTableMsSqlOperator,
    DropPrefixTableMsSqlOperator,
    MssqlToGCSExtractOperator,
)
from datetime import datetime, timedelta
from mssql_utils import MsSqlOperatorPYODBC
from airflow.operators.latest_only import LatestOnlyOperator
from airflow import configuration as conf
from dags.utils.pagerduty.pagerduty import PagerDutyAlerts


dag = DAG(
    dag_id="_legacy__reports_account_carteira",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2020, 4, 26, 17, 0),
    default_args={
        "autocommit": True,
        "retries": 4,
        "retry_delay": timedelta(minutes=15),
        "google_cloud_storage_conn_id": "gcp_mis",
        "source_conn_id": "gcp_mis",
        "salesforce_conn_id": "datalake_from_sop_salesforce",
        "gcs_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
        "source_bucket": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
        "gcs_bucket_name": conf.get("custom", "MIS_GCS_EXTRACTED_FILES_BUCKET"),
        "mssql_conn_id": "bw_azure",
        "on_failure_callback": PagerDutyAlerts.failure_incident,
        "on_success_callback": PagerDutyAlerts.resolve_incident,
    },
)

ds = "{{ds}}"
with dag:
    check_differential_load = LatestOnlyOperator(task_id="only_latest")

    unload_account_carteira = SalesforceToGCSOperator(
        task_id="unload_account_carteira",
        sql="reports/account_carteira/unload_account_carteira.sql",
        gcs_file=f"airflow-files/_legacy/reports/unload_account_carteira_{{{{ ds }}}}.csv",
        include_deleted=False,
    )

    create_account_carteira_table = CreatePrefixTableMsSqlOperator(
        task_id="create_account_carteira_table",
        schema="airflow_staging",
        database="StoneDwv0",
        table_prefix="account_carteira",
        column_types={
            "id": "nvarchar(500)",
            "account__c": "nvarchar(500)",
            "name": "nvarchar(500)",
            "affiliation_id__c": "nvarchar(500)",
            "canal__c": "nvarchar(500)",
            "createdbyid": "nvarchar(500)",
            "createddate": "nvarchar(500)",
            "customer_id__c": "nvarchar(500)",
            "isdeleted": "nvarchar(500)",
            "email_owner_carteira__c": "nvarchar(500)",
            "farol__c": "nvarchar(500)",
            "grupo1__c": "nvarchar(500)",
            "grupo2__c": "nvarchar(500)",
            "grupo3__c": "nvarchar(500)",
            "lastmodifiedbyid": "nvarchar(500)",
            "lastmodifieddate": "nvarchar(500)",
            "nome__c": "nvarchar(500)",
            "ownerid": "nvarchar(500)",
            "parceiro__c": "nvarchar(500)",
            "stonecode__c": "nvarchar(500)",
            "subcanal__c": "nvarchar(500)",
            "systemmodstamp": "nvarchar(500)",
        },
        mssql_conn_id="bw_azure",
    )

    load_account_carteira_table = GCSToMssqlExtractOperator(
        task_id="load_account_carteira_table",
        database="StoneDwv0",
        dest_schema="{{ ti.xcom_pull('create_account_carteira_table').split('.')[0] }}",
        table_name="{{ ti.xcom_pull('create_account_carteira_table').split('.')[1] }}",
        source_file=f"airflow-files/_legacy/reports/unload_account_carteira_{ ds }",
        truncate=False,
        gcs_data_delete=False,
    )

    process_account_carteira = MsSqlOperatorPYODBC(
        task_id="process_account_carteira",
        database="StoneDwv0",
        sql="reports/account_carteira/process_account_carteira.sql",
        pool="bw_azure",
        mssql_conn_id="bw_azure",
    )

    unload_insert_account_carteira = MssqlToGCSExtractOperator(
        task_id="unload_insert_account_carteira",
        mssql_database="StoneDwv0",
        sql_query="reports/account_carteira/unload_insert_account_carteira.sql",
        mssql_conn_id="bw_azure",
        gcs_file_name=f"airflow-files/_legacy/reports/unload_insert_account_carteira_{ds}.csv",
        pool="bw_azure",
    )

    unload_update_account_carteira = MssqlToGCSExtractOperator(
        task_id="unload_update_account_carteira",
        mssql_database="StoneDwv0",
        sql_query="reports/account_carteira/unload_update_account_carteira.sql",
        mssql_conn_id="bw_azure",
        gcs_file_name=f"airflow-files/_legacy/reports/unload_update_account_carteira_{ds}.csv",
        pool="bw_azure",
    )

    insert_account_carteira = GCSToSalesforceOperator(
        task_id="insert_account_carteira",
        gcs_file=f"airflow-files/_legacy/reports/unload_insert_account_carteira_{ds}.csv",
        salesforce_object="Account_Carteira__c",
        api_action="insert",
        batch_size=300,
    )

    update_account_carteira = GCSToSalesforceOperator(
        task_id="update_account_carteira",
        gcs_file=f"airflow-files/_legacy/reports/unload_update_account_carteira_{ds}.csv",
        salesforce_object="Account_Carteira__c",
        api_action="update",
        batch_size=300,
    )

    drop_account_carteira_temp_table = DropPrefixTableMsSqlOperator(
        task_id="drop_account_carteira_temp_table",
        pool="bw_azure",
        database="StoneDwv0",
        schema="airflow_staging",
        table_prefix="account_carteira",
    )

    (
        check_differential_load
        >> unload_account_carteira
        >> create_account_carteira_table
        >> load_account_carteira_table
        >> process_account_carteira
        >> unload_insert_account_carteira
        >> unload_update_account_carteira
        >> insert_account_carteira
        >> update_account_carteira
        >> drop_account_carteira_temp_table
    )
