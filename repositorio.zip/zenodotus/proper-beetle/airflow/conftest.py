# This is a configuration file for pytest It's empty because there is no
# configuration necessary for pytest at this moment.
#
# It exists the root directory so pytest includes the root directory in the
# sys.path so that modules can be imported.
