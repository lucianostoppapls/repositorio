```
.                                                  -- zenodotus root
├── proper-beetle                                  -- Proper Beetle repository - ETL
│   ├── airflow                                    -- Airflow code
│   |   ├── Dockerfile                             -- Dockerfile
│   |   ├── dags                                   -- DAGs folder
|   |   |   ├── helpers                            -- Helper modules - implementation of business rules used by DAGs
|   |   |   |   ├── datalake
|   |   |   |   |   ├── __init__.py
|   |   |   |   |   └── data-source-systems
|   |   |   |   |       ├── salesforce.py
|   |   |   |   |       ├── mssql.py
|   |   |   |   |       └── ...
|   |   |   |   ├── another-helper
|   |   |   |   |   ├── __init__.py
|   |   |   |   |   └── helper-submodules
|   |   |   |   |       ├── other_helper_files.py
|   |   |   |   |       └── ...
|   |   |   |   └── ...
|   |   |   ├── first_dag.py
|   |   |   ├── second_dag.py
|   |   |   └── ...
│   |   ├── utils                                 -- Utilities functions used across Airflow
|   |   |   ├── file1.py
|   |   |   └── ...
│   |   └── plugins                               -- Airflow Plugins
|   |       ├── first_plugin.py
|   |       └── ...
│   ├── helm                                      -- Helm charts
│   |   └── ...
|   └── infrastructrure                           -- Infrastructure as a Code
|       └── terraform                             -- Terraform code that defines Proper Beetle's infrastructure resources
|           └── ...
│
└── stoneco-dw                                    -- Data Warehouse
|   ├── database-objects                          -- Python Alembic database objects (tables, views...) code declaration
|   |   └── ...
|   └── infrastructure                            -- Terraform code that defines databases, warehouses, roles, users and permissions
|
└── hipparchus                                    -- Monitoring stack
    ├── helm                                      -- Helm charts
    |   └── ...
    └── pipelines                                 -- Definitions for CI/CD pipeline

```
