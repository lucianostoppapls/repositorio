﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ExtensionMethods;
using Newtonsoft.Json;
using StoneCo.MIS.SQLJobMonitor.Lib.Business;
using StoneCo.MIS.SQLJobMonitor.Lib.DataAccess;
using StoneCo.MIS.SQLJobMonitor.Lib.Model;
using static StoneCo.MIS.SQLJobMonitor.Lib.Configuration.JobMonitorConfigurationManager;
using static StoneCo.MIS.SQLJobMonitor.Lib.Logger.JobMonitorLogger;

namespace StoneCo.MIS.SQLJobMonitor
{
    class Program
    {
        private static void Main(string[] args)
        {
            //Set assembly path for app.config load.
            string location = Assembly.GetAssembly(typeof(Program)).Location;
            AssemblyLocation = location;

            //Reload forces reload the settings from app.conif file into registry
            bool reload = args.Contains("-reload");

            //Instantiate Job Monitor Business Class
            JobMonitorBusiness jobMonitor = new JobMonitorBusiness();
            WriteToConsole($"Initializing SQL Job Monitor...", DateTime.Now, null, LogLevelOption.Information);
            jobMonitor.Initialize(reload);


            while (true)
            {
                //Reloading Managed and Agent Jobs to be monitored.
                jobMonitor.LoadMonitoredJobs(true);

                //Get Current Job Status                
                jobMonitor.LoadJobStatus();

                //Get List of Currently Running Jobs                
                jobMonitor.LoadJobActivity(null, Guid.Empty, true, false);

                //Merge msdb jobs into monitor table
                jobMonitor.MergeJobActivity();

                //Check if jobs are executing es expected. Otherwise take actions (restart)
                jobMonitor.ProcessJobs();

                //jobMonitor.Logger.Info($"Waiting timer to trigger in {jobMonitor.Parameters.VerificationInterval} seconds.");
                WriteToConsole($"Waiting timer to trigger in {30} seconds.", DateTime.Now, null, LogLevelOption.Information);

                //Thread.Sleep(jobMonitor.Parameters.VerificationInterval * 1000);
                Thread.Sleep(30 * 1000);
            }
        }

    }
}
