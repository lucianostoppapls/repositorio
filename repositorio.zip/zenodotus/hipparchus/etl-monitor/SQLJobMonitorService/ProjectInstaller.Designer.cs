﻿using System.ServiceProcess;

namespace StoneCo.MIS.SQLJobMonitor.Service
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SQLServerJobMonitorServiceProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.SQLServerJobMonitorServiceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // SQLServerJobMonitorServiceProcessInstaller
            // 
            this.SQLServerJobMonitorServiceProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalSystem;
            this.SQLServerJobMonitorServiceProcessInstaller.Password = null;
            this.SQLServerJobMonitorServiceProcessInstaller.Username = null;
            this.SQLServerJobMonitorServiceProcessInstaller.AfterInstall += new System.Configuration.Install.InstallEventHandler(this.SQLServerJobMonitorServiceProcessInstaller_AfterInstall);
            // 
            // SQLServerJobMonitorServiceInstaller
            // 
            this.SQLServerJobMonitorServiceInstaller.Description = "Monitors SQL Server Agent Job execution to take self-healing actions.";
            this.SQLServerJobMonitorServiceInstaller.DisplayName = "SQL Server Job Monitor Service (Stone.co MIS)";
            this.SQLServerJobMonitorServiceInstaller.ServiceName = "SQLServerJobMonitor";
            this.SQLServerJobMonitorServiceInstaller.AfterInstall += new System.Configuration.Install.InstallEventHandler(this.SQLServerJobMonitorServiceInstaller_AfterInstall);
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.SQLServerJobMonitorServiceProcessInstaller,
            this.SQLServerJobMonitorServiceInstaller});

        }

        #endregion

        private ServiceProcessInstaller SQLServerJobMonitorServiceProcessInstaller;
        private ServiceInstaller SQLServerJobMonitorServiceInstaller;
    }
}