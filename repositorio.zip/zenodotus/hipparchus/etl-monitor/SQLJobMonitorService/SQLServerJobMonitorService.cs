﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Tracing;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Runtime.InteropServices;
using System.Reflection;
using StoneCo.MIS.SQLJobMonitor.Lib.DataAccess;
using static StoneCo.MIS.SQLJobMonitor.Lib.Configuration.JobMonitorConfigurationManager;
using StoneCo.MIS.SQLJobMonitor.Lib.Business;

namespace StoneCo.MIS.SQLJobMonitor.Service
{
    public partial class SQLServerJobMonitorService : ServiceBase
    {
        JobMonitorBusiness jobMonitor;
        private Timer timer = new Timer();

        public SQLServerJobMonitorService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            //Set assembly path for app.config load.
            AssemblyLocation = Assembly.GetAssembly(typeof(ProjectInstaller)).Location;

            //Reload forces reload the settings from app.conif file into registry
            bool reload = args.Contains("-reload");

            //Instantiate Job Monitor Business Class
            jobMonitor = new JobMonitorBusiness();
            jobMonitor.Initialize(reload);

            //set timer (verification interval)
            SetTimer();
        }

        private void SetTimer(bool enabled = true)
        {
            if (enabled)
            {
                timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);
                timer.Interval = jobMonitor.Parameters.VerificationInterval * 1000;
                timer.Enabled = true;
                timer.Start();
            }
            else
            {
                timer.Stop();
                timer.Enabled = false;
            }
        }

        protected override void OnStop()
        {
            SetTimer(false);
        }

        private void OnElapsedTime(object source, ElapsedEventArgs e)
        {
            //Reloading Managed and Agent Jobs to be monitored.
            jobMonitor.LoadMonitoredJobs(true);

            //Get Current Job Status            
            jobMonitor.LoadJobStatus();

            //Get List of Currently Running Jobs            
            jobMonitor.LoadJobActivity(null, Guid.Empty, true, false);

            //Merge msdb jobs into monitor table            
            jobMonitor.MergeJobActivity();

            //Check if jobs are executing es expected. Otherwise take actions (restart)
            jobMonitor.ProcessJobs();
        }
    }
}
