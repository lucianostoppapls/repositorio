﻿using Newtonsoft.Json;
using StoneCo.MIS.SQLJobMonitor.Lib.Configuration;
using StoneCo.MIS.SQLJobMonitor.Lib.DataAccess;
using StoneCo.MIS.SQLJobMonitor.Lib.Logger;
using StoneCo.MIS.SQLJobMonitor.Lib.Model;
using StoneCo.MIS.SQLJobMonitor.Lib.Model.Collection;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using static StoneCo.MIS.SQLJobMonitor.Lib.Logger.JobMonitorLogger;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Business
{
    public class JobMonitorBusiness
    {
        #region PROPERTIES

        private JobMonitorLogger _logger;
        public JobMonitorLogger Logger
        {
            get
            {
                if (_logger == null)
                {
                    RegisterLogProviders();
                }
                return _logger;
            }
        }

        private ServiceParameters _parameters;
        public ServiceParameters Parameters
        {
            get
            {
                if (_parameters == null)
                {
                    LoadParameters();
                }
                return _parameters;
            }
        }

        private JobMonitorDataAccess _monitorDatabase;
        public JobMonitorDataAccess MonitorDatabase
        {
            get
            {
                if (_monitorDatabase == null)
                {
                    ConnectToMonitorDatabase();
                }
                return _monitorDatabase;
            }
        }

        private JobMonitorDataAccess _monitoredInstance;
        public JobMonitorDataAccess MonitoredInstance
        {
            get
            {
                if (_monitoredInstance == null)
                {
                    ConnectToMonitoredInstance();
                }
                return _monitoredInstance;
            }
        }

        public ManagedJobCollection _managedJobs;
        public ManagedJobCollection ManagedJobs
        {
            get
            {
                if (_managedJobs == null)
                {
                    LoadManagedJobs();
                }
                return _managedJobs;
            }
        }

        public AgentJobCollection _agentJobs;
        public AgentJobCollection AgentJobs
        {
            get
            {
                if (_agentJobs == null)
                {
                    LoadAgentJobs();
                }
                return _agentJobs;
            }
        }

        public MonitoredJobCollection _monitoredJobs;
        public MonitoredJobCollection MonitoredJobs
        {
            get
            {
                if (_monitoredJobs == null)
                {
                    LoadMonitoredJobs();
                }
                return _monitoredJobs;
            }
        }

        public JobActivityCollection _jobActivities;
        public JobActivityCollection JobActivities
        {
            get
            {
                if (_jobActivities == null)
                {
                    LoadJobActivity(null, Guid.Empty);
                }
                return _jobActivities;
            }
        }

        public JobStatusCollection _lastJobStatus;
        public JobStatusCollection LastJobStatus
        {
            get
            {
                if (_lastJobStatus == null)
                {
                    LoadJobStatus();
                }
                return _lastJobStatus;
            }
        }

        #endregion

        #region FILTER JOB STATUS PROPERTY

        public JobStatusCollection _lastIdleJobs;
        public JobStatusCollection LastIdleJobs
        {
            get
            {
                if (_lastIdleJobs == null)
                {
                    _lastIdleJobs = GetLastIdleJobs();
                }
                return _lastIdleJobs;
            }

        }

        public JobStatusCollection _lastOnScheduleJobs;
        public JobStatusCollection LastOnScheduleJobs
        {
            get
            {
                if (_lastOnScheduleJobs == null)
                {
                    _lastOnScheduleJobs = GetLastOnScheduleJobs();
                }
                return _lastOnScheduleJobs;
            }
        }

        public JobStatusCollection _lastDelayedJobs;
        public JobStatusCollection LastDelayedJobs
        {
            get
            {
                if (_lastDelayedJobs == null)
                {
                    _lastDelayedJobs = GetLastDelayedJobs();
                }
                return _lastDelayedJobs;
            }
        }

        public MonitoredJobActivityCollection Jobs
        {
            get
            {
                //Join current activity with monitored jobs
                var jobs = from monitored in MonitoredJobs
                           join activity in JobActivities
                            on monitored.JobId equals activity.JobId
                           select new MonitoredJobActivity()
                           {
                               JobId = activity.JobId,
                               JobName = activity.JobName,
                               IsRunning = activity.IsRunning,
                               StartedAt = activity.StartedAt,
                               EndedAt = activity.EndedAt,
                               DurationInMinutes = activity.DurationInMinutes,
                               RequestedSource = activity.RequestedSource,
                               LastRunstatus = activity.LastRunstatus,
                               InstanceId = activity.InstanceId,
                               PreviousInstanceId = activity.PreviousInstanceId,
                               ExpectationInMinutes = monitored.ExpectationInMinutes,
                               ToleranceInPercent = monitored.ToleranceInPercent,
                               NumberOfRetries = monitored.NumberOfRetries,
                               TimeoutInSeconds = monitored.TimeoutInSeconds,
                               PollingInSeconds = monitored.PollingInSeconds,
                               RunningState = JobState.UNKNOWN,
                               IsManaged = monitored.IsManaged
                           };
                return new MonitoredJobActivityCollection(jobs.ToList());
            }
        }

        public MonitoredJobActivityStateCollection CurrentJobs
        {
            get
            {
                //Left join with previous status
                var currentJobs = from current in Jobs
                                  join previous in LastJobStatus
                                  on current.JobId equals previous.JobId into status
                                  from previous in status.DefaultIfEmpty()
                                  select new MonitoredJobActivityState()
                                  {
                                      JobId = current.JobId,
                                      JobName = current.JobName,
                                      IsRunning = current.IsRunning,
                                      StartedAt = current.StartedAt,
                                      EndedAt = current.EndedAt,
                                      DurationInMinutes = current.DurationInMinutes,
                                      RequestedSource = current.RequestedSource,
                                      LastRunstatus = current.LastRunstatus,
                                      InstanceId = current.InstanceId,
                                      PreviousInstanceId = current.PreviousInstanceId,
                                      ExpectationInMinutes = current.ExpectationInMinutes,
                                      ToleranceInPercent = current.ToleranceInPercent,
                                      NumberOfRetries = current.NumberOfRetries,
                                      IsManaged = current.IsManaged,
                                      TimeoutInSeconds = current.TimeoutInSeconds,
                                      PollingInSeconds = current.PollingInSeconds,
                                      RunningState = current.RunningState,
                                      IsRestarting = previous?.IsRestarting != null && previous.IsRestarting,
                                      RetriesAttempted = previous?.RetriesAttempted != null ? previous.RetriesAttempted : 0,
                                      OriginalInstanceId = previous?.OriginalInstanceId != null ? previous.OriginalInstanceId : 0,
                                      OnAttempts = previous?.RetriesAttempted != null && previous.RetriesAttempted > 0 && previous.RetriesAttempted < current.NumberOfRetries,
                                      //Custom properties to help the state management
                                      Sucess = previous?.IsRestarting != null && !previous.IsRestarting && !current.IsRunning && current.LastRunstatus == RunStatus.SUCCEEDED,
                                      Failure = previous?.IsRestarting != null && !previous.IsRestarting && !current.IsRunning && current.LastRunstatus != RunStatus.SUCCEEDED,
                                      Aborted = !current.IsRunning && current.IsManaged && previous?.PreviousInstanceId != null
                                        && (
                                            (current.PreviousInstanceId > previous.PreviousInstanceId && !(current.LastRunstatus == RunStatus.SUCCEEDED))
                                            || (current.RequestedSource == RunRequestedSource.USER && !(current.LastRunstatus == RunStatus.SUCCEEDED))
                                            ),
                                      Exausted = previous?.RetriesAttempted != null && previous.RetriesAttempted >= current.NumberOfRetries,
                                      OnSchedule = current.DurationInMinutes <= Math.Round(current.ExpectationInMinutes * (1 + current.ToleranceInPercent), 0),
                                      Delayed = (current.DurationInMinutes > Math.Round(current.ExpectationInMinutes * (1 + current.ToleranceInPercent), 0)),
                                  };
                return new MonitoredJobActivityStateCollection(currentJobs.ToList());
            }
        }

        #endregion

        #region CONSTRUCTOR AND INITALIZATOR

        public JobMonitorBusiness()
        {

        }

        public void Initialize(bool reloadAppConfig = false)
        {
            //Register Default log provider
            RegisterLogProviders();

            //Load configuration from registry or app.config                        
            LoadParameters(reloadAppConfig);

            //Connect to monitor Database            
            ConnectToMonitorDatabase();

            //Connect to monitor Instance (msdb)            
            ConnectToMonitoredInstance();

            //Check local agent status, and start if needed.
            CheckAgentStatus(MonitoredInstance);

            //Get list of managed jobs form monitoring DB
            LoadManagedJobs(true);

            //Get list of server agent jobs from msdb
            LoadAgentJobs(true);

            //Merge msdb jobs into monitor table
            MergeAgentJobs();

            //Match list of Managed Jobs with List of Agent Jobs (combine objects)
            LoadMonitoredJobs(false); //set to false

            #region MOVED TO TIMER LOOP

            //Get Current Job Status
            //LoadJobStatus();

            ////Get List of Currently Running Jobs
            //LoadJobActivity(null, true, false);

            ////Merge msdb jobs into monitor table
            //MergeJobActivity();

            #endregion
        }

        #endregion

        #region REGISTER DEFAULT LOG PROVIDERS

        public void RegisterLogProviders()
        {
            try
            {
                //TODO: FROM CONFIG? DEFAULT PROVIDER
                _logger = new JobMonitorLogger(LogProviderType.TextFile | LogProviderType.ConsoleOutput | LogProviderType.EventViewer, LogLevelOption.Verbose);
                Logger.Audit($"Registering Default LogProviders...");
            }
            catch (Exception ex)
            {
                string provider = JsonConvert.SerializeObject(JsonConvert.DeserializeObject($"{{\"LogProviderType\":\"{LogProviderType.TextFile | LogProviderType.ConsoleOutput | LogProviderType.EventViewer}\", \"LogLevelOption\":{(byte)LogLevelOption.Verbose}}}"), Formatting.Indented);
                WriteEntry($"Could NOT default register the default log providers.\n{provider}", ex, DateTime.Now, LogProviderType.TextFile | LogProviderType.ConsoleOutput, LogLevelOption.Verbose);

                throw;
            }
        }

        #endregion

        #region LOAD PARAMETERS

        public void LoadParameters(bool reload = false)
        {
            string formmattedMessage = reload ? $"Configuration Reloaded successfully form configuration file:\n{JobMonitorConfigurationManager.AssemblyLocation}" : $"Configuration Loaded successfully from Registry:\n{JobMonitorConfigurationManager.KEYNAME}";
            try
            {
                _parameters = JobMonitorConfigurationManager.GetConfigurations(reload);

                Logger.ProviderType = (LogProviderType)_parameters.LogProviderType;
                Logger.LevelOption = (LogLevelOption)_parameters.LogLevelOption;
                Logger.LogFilePath = _parameters.LogFilePath;

                Logger.Audit(formmattedMessage, DateTime.Now, additionalData: $"{ _parameters}");
            }
            catch (Exception ex)
            {
                Logger.Error("Could not load configuration.", ex, DateTime.Now, LogProviderType.TextFile | LogProviderType.ConsoleOutput | LogProviderType.EventViewer, additionalData: $"{_parameters}");
                throw;
            }
        }

        #endregion

        #region TEST CONNECTION TO DATABASE INSTANCE AND AGENT SERVICES

        public void ConnectToMonitoredInstance()
        {
            try
            {
                _monitoredInstance = new JobMonitorDataAccess(Parameters.MonitoredInstance);
                _monitoredInstance.TestConnection();

                if (_monitoredInstance.Instance.CanConnect)
                {
                    Logger.Audit($"Connection to Monitored Instance successfull.", additionalData: $"{_monitoredInstance.Instance}");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Could not connect to Monitored Instance.", ex, additionalData: $"{_monitoredInstance.Instance}");
                throw ex;
            }
        }

        public void ConnectToMonitorDatabase()
        {
            try
            {
                _monitorDatabase = new JobMonitorDataAccess(Parameters.MonitoringDB);
                _monitorDatabase.TestConnection();

                if (_monitorDatabase.Instance.CanConnect)
                {
                    Logger.Audit($"Connection to Monitor Database successfull (Service).", additionalData: $"{_monitorDatabase?.Instance}");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Could not connect to Monitor Database.", ex, additionalData: $"{_monitorDatabase?.Instance}");
                throw ex;
            }
        }

        #endregion

        #region CHECK AGENT STATUS

        public void CheckAgentStatus(JobMonitorDataAccess instance)
        {
            try
            {
                bool agent_running = instance.CheckAgentStatus(out int pid, false);

                if (agent_running)
                {
                    string processId = JsonConvert.SerializeObject(JsonConvert.DeserializeObject($"{{\"ProcessId\":{pid}}}"), Formatting.Indented);
                    Logger.Audit($"SQL Server Agent is running.\n{processId}");
                }
                else
                {
                    Logger.Warn($"SQL Server Agent is NOT running. Trying to start SQL Server Agent.");
                    agent_running = instance.TryStartAgentService();

                    if (agent_running)
                    {
                        Logger.Audit($"SQL Server Agent started Successfully");
                    }
                    else
                    {
                        Logger.Error($"Could not start SQL Server Agent in proper time. Check SQL Error Log for Details.");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error trying to check SQL Agent status", ex);
            }
        }

        #endregion

        #region LOAD PROPERTIES       

        public void LoadManagedJobs(bool isManaged = true)
        {
            _managedJobs = GetManagedJobs(isManaged);
        }

        public void LoadAgentJobs(bool isEnabled = true)
        {
            _agentJobs = GetAgentJobs(isEnabled);
        }

        public void LoadMonitoredJobs(bool reload = false)
        {
            if (reload)
            {
                LoadManagedJobs();
                LoadAgentJobs();
            }

            //check if agent job has been renamed (in msdb)
            MergeManagedJobs();

            _monitoredJobs = GetMonitoredJobs(ManagedJobs, AgentJobs);
        }

        public void LoadJobActivity(string jobName, Guid jobId, bool isEnabled = true, bool runningStateOnly = false)
        {
            _jobActivities = GetJobActivity(jobName, jobId, isEnabled, runningStateOnly);
        }

        public void LoadJobStatus()
        {
            _lastJobStatus = GetJobStatus();
        }


        #endregion

        #region FILTER PROPERTIES

        public JobStatusCollection GetLastIdleJobs()
        {
            return new JobStatusCollection(CurrentJobs
                .Where(j => !j.IsRunning && !j.IsRestarting && j.RunningState != JobState.ERROR)
                .Select(j => new JobStatus()
                {
                    JobId = j.JobId,
                    JobName = j.JobName,
                    IsRunning = j.IsRunning,
                    IsRestarting = j.IsRestarting,
                    OnAttempts = !j.Sucess && j.OnAttempts,
                    RunningState = j.Aborted || (j.Failure && j.RequestedSource == RunRequestedSource.USER) ? JobState.ERROR : JobState.IDLE,
                    NumberOfRetries = j.NumberOfRetries,
                    RetriesAttempted = j.Sucess ? 0 : j.OnAttempts ? j.RetriesAttempted : 0,
                    InstanceId = j.InstanceId,
                    OriginalInstanceId = j.Sucess ? 0 : j.OriginalInstanceId,
                    PreviousInstanceId = j.PreviousInstanceId,
                }).ToList());
        }

        public JobStatusCollection GetLastOnScheduleJobs()
        {
            return new JobStatusCollection(CurrentJobs
                    .Where(j => j.IsRunning && !j.IsRestarting && j.OnSchedule && j.RunningState != JobState.ERROR)
                    .Select(j => new JobStatus()
                    {
                        JobId = j.JobId,
                        JobName = j.JobName,
                        IsRunning = j.IsRunning,
                        IsRestarting = j.IsRestarting,
                        OnAttempts = j.OnAttempts,
                        RunningState = JobState.ON_SCHEDULE,
                        NumberOfRetries = j.NumberOfRetries,
                        RetriesAttempted = j.RetriesAttempted,
                        InstanceId = j.InstanceId,
                        OriginalInstanceId = j.OriginalInstanceId,
                        PreviousInstanceId = j.PreviousInstanceId,
                    }).ToList());
        }

        public JobStatusCollection GetLastDelayedJobs()
        {
            return new JobStatusCollection(CurrentJobs
                .Where(j => j.IsRunning && !j.IsRestarting && j.Delayed && j.RunningState != JobState.ERROR)
                .Select(j => new JobStatus()
                {
                    JobId = j.JobId,
                    JobName = j.JobName,
                    IsRunning = j.IsRunning,
                    IsRestarting = j.IsRestarting,
                    OnAttempts = j.OnAttempts,
                    RunningState = JobState.DELAYED,
                    NumberOfRetries = j.NumberOfRetries,
                    RetriesAttempted = j.RetriesAttempted,
                    InstanceId = j.InstanceId,
                    OriginalInstanceId = j.OriginalInstanceId,
                    PreviousInstanceId = j.PreviousInstanceId,
                }).ToList());
        }

        #endregion

        #region GET COLLECTION FROM DATABASE

        public ManagedJobCollection GetManagedJobs(bool isManaged = true)
        {
            ManagedJobCollection managedJobs;
            try
            {
                managedJobs = MonitorDatabase.GetManagedJobs(isManaged);

                //log only if previous count is greater than zero or property is first loaded
                if (managedJobs.Items.Count == 0 && (_managedJobs == null || _managedJobs.Items.Count > 0))
                {
                    Logger.Warn("No active managed jobs found.");
                }
                //log only if collections differs in values (from previous load)
                else if (managedJobs.Items.Count > 0 && (_managedJobs == null || !managedJobs.Equals(_managedJobs)))
                {
                    Logger.Info($"Number of managed jobs found: {managedJobs.Items.Count}", additionalData: $"{managedJobs}");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error trying to get list of managed jobs", ex);
                managedJobs = new ManagedJobCollection();
            }

            return managedJobs;
        }

        public AgentJobCollection GetAgentJobs(bool isEnabled = true)
        {

            AgentJobCollection agentJobs;

            try
            {
                agentJobs = MonitoredInstance.GetAgentJobs(isEnabled);

                //log only if previous count is greater than zero or property is first loaded
                if (agentJobs.Items.Count == 0 && (_agentJobs == null || _agentJobs.Items.Count > 0))
                {
                    Logger.Warn("No enabled agent jobs found.");
                }
                //log only if collections differs in values (from previous load)
                else if (agentJobs.Items.Count > 0 && (_agentJobs == null || !agentJobs.Equals(_agentJobs)))
                {
                    Logger.Info($"Number of agent jobs found: {agentJobs.Items.Count}", additionalData: $"{agentJobs}");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error trying to get list of agent jobs", ex);
                agentJobs = new AgentJobCollection();
            }

            return agentJobs;

        }

        public MonitoredJobCollection GetMonitoredJobs(ManagedJobCollection managedJobs, AgentJobCollection agentJobs)
        {
            MonitoredJobCollection monitoredJobs;

            var jobs = from managed in managedJobs
                       join agent in agentJobs
                         on managed.JobId equals agent.JobId
                       select new MonitoredJob()
                       {
                           JobId = managed.JobId,
                           JobName = agent.JobName,
                           IsEnabled = agent.IsEnabled,
                           DateCreated = agent.DateCreated,
                           DateModified = agent.DateModified,
                           VersionNumber = agent.VersionNumber,
                           IsManaged = managed.IsManaged,
                           ExpectationInMinutes = managed.ExpectationInMinutes,
                           ToleranceInPercent = managed.ToleranceInPercent,
                           NumberOfRetries = managed.NumberOfRetries,
                           TimeoutInSeconds = managed.TimeoutInSeconds,
                           PollingInSeconds = managed.PollingInSeconds,
                           StartWindow = managed.StartWindow,
                           EndWindow = managed.EndWindow,
                       };

            monitoredJobs = new MonitoredJobCollection(jobs.ToList());

            //log only if previous count is greater than zero or property is first loaded
            if (monitoredJobs.Items.Count == 0 && (_monitoredJobs == null || _monitoredJobs.Items.Count > 0))
            {
                Logger.Warn($"No matched jobs to be monitored. Review ManagedJobs table to match the job_id from msdb database.");
            }
            //log only if collections differs in values (from previous load)
            else if (monitoredJobs.Items.Count() > 0 && (_monitoredJobs == null || !monitoredJobs.Equals(_monitoredJobs)))
            {
                Logger.Info($"Number of matched jobs to be monitored: {monitoredJobs.Count()}", additionalData: $"{ JsonConvert.SerializeObject(monitoredJobs, Formatting.Indented)}");
            }

            return monitoredJobs;
        }

        public JobActivityCollection GetJobActivity(string jobName, Guid jobId, bool isEnabled = true, bool runningStateOnly = false)
        {
            JobActivityCollection jobActivity;

            try
            {
                jobActivity = MonitoredInstance.GetJobActivity(jobName, jobId, isEnabled, runningStateOnly);
                JobActivityCollection runningJobs = new JobActivityCollection(jobActivity.Where(j => j.IsRunning).ToList());

                //log only if previous count is greater than zero or property is first loaded
                if (runningJobs.Items.Count == 0 && (_jobActivities == null || _jobActivities.Items.Where(j => j.IsRunning).Count() > 0))
                {
                    Logger.Info("No running jobs found.");
                }
                //log only if collections differs in values (from previous load)
                else if (runningJobs.Items.Count > 0 &&
                    (_jobActivities == null || !runningJobs.Equals(new JobActivityCollection(_jobActivities.Items.Where(j => j.IsRunning).ToList()))))
                {
                    Logger.Info($"Number of running jobs found: {runningJobs.Items.Count}", additionalData: $"{runningJobs}");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error trying to get list of agent jobs activity", ex);
                jobActivity = new JobActivityCollection();
            }

            return jobActivity;
        }

        public JobStatusCollection GetJobStatus()
        {
            JobStatusCollection jobStatus;

            try
            {
                jobStatus = MonitorDatabase.GetJobStatus();

                //log only if previous count is greater than zero or property is first loaded
                if (jobStatus.Count == 0 && (_lastJobStatus == null || _lastJobStatus.Items.Count > 0))
                {
                    Logger.Info("No job status found.");
                }
                //log only if collections differs in values (from previous load)
                else if (jobStatus.Count > 0 && (_lastJobStatus == null || !jobStatus.Equals(_lastJobStatus)))
                {
                    Logger.Info($"Number of job status found: {jobStatus.Items.Count}", additionalData: $"{jobStatus}");
                }
            }
            catch (Exception ex)
            {
                Logger.Error($"Error trying to get list of job status", ex);
                jobStatus = new JobStatusCollection();
            }

            return jobStatus;
        }

        #endregion

        #region MERGE COLLECTION WITH DATABASE

        #region MANAGED JOBS

        public void MergeManagedJobs()
        {
            //updates ManagedJob Names if renamed in agent (same JobId and <> Name)
            JobCollection renamedJobs = new JobCollection(AgentJobs.Where(agent => ManagedJobs.Any(managed => managed.JobId == agent.JobId && !(managed.JobName == agent.JobName)))
                .Select(job => new Job() { JobId = job.JobId, JobName = job.JobName }).ToList());

            if (renamedJobs.Items.Count > 0)
            {
                foreach (var job in renamedJobs.Items)
                {
                    ManagedJobs[job.JobId].JobName = job.JobName;
                }

                JobCollection originalJobs = new JobCollection(ManagedJobs.Where(managed => renamedJobs.Any(agent => agent.JobId == managed.JobId))
                    .Select(job => new Job() { JobId = job.JobId, JobName = job.JobName }).ToList());

                Logger.Warn($"Number of managed jobs renamed in agent jobs (msdb): {renamedJobs.Count}", additionalData: $"{{\n\t\"inserted\": {renamedJobs},\n\t\"deleted\": {originalJobs}\n}}");
                MergeManagedJobs(renamedJobs);
            }
        }

        public void MergeManagedJobs(JobCollection jobs)
        {
            try
            {
                int ret = MonitorDatabase.MergeManagedJobs(jobs);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error trying to managed jobs into Monitor Database.", ex);
            }
        }

        #endregion

        #region AGENT JOBS

        public void MergeAgentJobs()
        {
            if (AgentJobs.Items.Count > 0)
            {
                MergeAgentJobs(AgentJobs);
            }
        }

        public void MergeAgentJobs(AgentJobCollection jobs)
        {
            try
            {
                int ret = MonitorDatabase.MergeAgentJobs(jobs);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error trying to merge (msdb) agent jobs into Monitor Database.", ex);
            }
        }

        #endregion

        #region JOB STATUS

        public void MergeJobStatus()
        {
            if (LastJobStatus.Items.Count > 0)
            {
                MergeJobStatus(LastJobStatus);
            }
        }

        public void MergeJobStatus(JobStatus job)
        {
            MergeJobStatus(new JobStatusCollection(job));
        }

        public void MergeJobStatus(JobStatusCollection jobs)
        {
            try
            {
                int ret = MonitorDatabase.MergeJobStatus(jobs);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error trying to merge (msdb) jobs status into Monitor Database.", ex);
            }
        }

        #endregion

        #region JOB ACTIVITY

        public void MergeJobActivity()
        {
            if (JobActivities.Items.Count > 0)
            {
                MergeJobActivity(JobActivities);
            }
        }

        public void MergeJobActivity(JobActivityCollection jobs)
        {
            try
            {
                int ret = MonitorDatabase.MergeJobActivity(jobs);
            }
            catch (Exception ex)
            {
                Logger.Error($"Error trying to merge (msdb) jobs activity into Monitor Database.", ex);
            }
        }

        #endregion

        #endregion

        #region CHECK JOB EXECUTION STATUS

        public JobStatusCollection ProcessJobStatus()
        {
            #region PROCESS IDLE JOBS

            JobStatusCollection idleJobs = GetLastIdleJobs();

            if (idleJobs.Count > 0)
            {
                if (_lastJobStatus == null || _lastIdleJobs == null || idleJobs.Count != _lastIdleJobs.Count ||
                    !new JobStatusCollection(idleJobs.Where(job => job.RunningState == JobState.IDLE).ToList()).Equals(_lastIdleJobs))
                {
                    //log only if collections differs in values (from previous load) or first load
                    Logger.Info($"Number of idle jobs (not running): {idleJobs.Count}", additionalData: $"{idleJobs}");
                }
                foreach (JobStatus item in idleJobs)
                {
                    LastJobStatus[item.JobName] = item;
                }

                MergeJobStatus();
            }
            _lastIdleJobs = idleJobs;

            #endregion

            #region PROCESS ON SCHEDULE

            var onScheduledJobs = GetLastOnScheduleJobs();

            if (onScheduledJobs.Count > 0)
            {
                if (_lastJobStatus == null || _lastOnScheduleJobs == null || onScheduledJobs.Count != _lastOnScheduleJobs.Count || !onScheduledJobs.Equals(_lastOnScheduleJobs))
                {
                    //log only if collections differs in values (from previous load) or first load
                    Logger.Info($"Number of running jobs as expected (on schedule): {onScheduledJobs.Count}", additionalData: $"{onScheduledJobs}");
                }

                foreach (JobStatus item in onScheduledJobs)
                {
                    LastJobStatus[item.JobName] = item;
                }

                MergeJobStatus();
            }
            _lastOnScheduleJobs = onScheduledJobs;

            #endregion

            #region PROCESS DELAYED

            var delayedJobs = GetLastDelayedJobs();

            if (delayedJobs.Count > 0)
            {
                if (_lastJobStatus == null || _lastDelayedJobs == null || delayedJobs.Count != _lastDelayedJobs.Count || !delayedJobs.Equals(_lastDelayedJobs))
                {
                    //log only if collections differs in values (from previous load) or first load
                    Logger.Warn($"Number of running jobs at retries attempts (delayed): {delayedJobs.Count}", additionalData: $"{delayedJobs}");
                }

                foreach (JobStatus item in delayedJobs)
                {
                    LastJobStatus[item.JobName] = item;
                }

                MergeJobStatus();
            }
            _lastDelayedJobs = delayedJobs;

            #endregion

            return (delayedJobs.Count > 0) ? delayedJobs : new JobStatusCollection();
        }

        public void ProcessJobs()
        {
            JobStatusCollection irresponsiveJobs = new JobStatusCollection(ProcessJobStatus()
                .Where(j => j.RunningState == JobState.DELAYED && j.IsRunning && !j.IsRestarting).ToList());

            if (irresponsiveJobs.Count > 0)
            {
                PerformActions(irresponsiveJobs);
            }

        }

        #endregion

        #region PERFORM CORRECTIVE ACTIONS

        public async void PerformActions(JobStatusCollection jobs)
        {
            await PerformActionsAsync(jobs);
        }

        public async Task PerformActionsAsync(JobStatusCollection jobs)
        {
            List<Task<JobStatus>> restartTasks = new List<Task<JobStatus>>();

            foreach (JobStatus item in jobs)
            {
                item.RetriesAttempted++;

                if (item.RetriesAttempted > item.NumberOfRetries)
                {
                    item.RunningState = JobState.ERROR;
                    item.OnAttempts = false;
                    item.IsRestarting = false;
                    Logger.Error($"Number of retart attempts for job has been exausted. Stopping the job.", additionalData: $"{item}");
                    try
                    {
                        MergeJobStatus(item);
                        MonitoredInstance.StopJob(item.JobId);
                    }
                    catch (Exception ex)
                    {
                        Logger.Error($"Could not stop job {item.JobName}", ex, additionalData: $"{JsonConvert.SerializeObject(item, Formatting.Indented)}");
                    }
                    //TODO: PAGER DUTY
                    //TODO: SET UNMANAGED
                    return;
                }
                else
                {
                    item.RunningState = JobState.DELAYED;
                    item.OnAttempts = true;
                    item.IsRestarting = true;
                    restartTasks.Add(RestartJobAsync(item, MonitoredJobs[item.JobId].TimeoutInSeconds, MonitoredJobs[item.JobId].PollingInSeconds));
                }

                LastJobStatus[item.JobId] = item;
            }

            MergeJobStatus();

            JobStatusCollection results = new JobStatusCollection();

            while (restartTasks.Count > 0)
            {
                Task<JobStatus> finishedTask = await Task<JobStatus>.WhenAny(restartTasks);
                results.Items.Add(finishedTask.Result);
                restartTasks.Remove(finishedTask);
            }

            MergeJobStatus(results);

        }

        public async Task<JobStatus> RestartJobAsync(JobStatus job, int timeout = 30, int pollingInterval = 5)
        {
            timeout = timeout < 10 ? 10000 : timeout * 1000;
            pollingInterval = pollingInterval < 5 ? 5000 : pollingInterval * 1000;
            bool running = true;
            int timeoutms;

            #region STOP JOB OPERATION

            timeoutms = timeout;

            try
            {
                MonitoredInstance.StopJob(job.JobId);
            }
            catch (Exception ex)
            {

                job.RunningState = JobState.ERROR;
                job.OnAttempts = false;
                job.IsRestarting = false;
                job.RetriesAttempted = 0;
                Logger.Error($"Could not stop job: {job.JobName}", ex, additionalData: $"{JsonConvert.SerializeObject(job, Formatting.Indented)}");
                //TODO: PAGER DUTY
                return job;
            }

            while (timeoutms > 0)
            {
                running = MonitoredInstance.CheckJobRunningStatus(job.JobId);
                if (!running) break;
                await Task.Delay(pollingInterval);
                timeoutms -= pollingInterval;
            }

            if (running)
            {
                job.RunningState = JobState.UNKNOWN;
                job.OnAttempts = false;
                job.IsRestarting = false;
                job.RetriesAttempted = 0;
                Logger.Error($"Could not stop job in proper time: {job.JobName}", new TimeoutException($"Operation could not complete in {timeout} ms"), additionalData: $"{JsonConvert.SerializeObject(job, Formatting.Indented)}");
                //TODO: PAGER DUTY
                return job;
            }
            else
            {
                job.OriginalInstanceId = job.RetriesAttempted == 1 && job.OriginalInstanceId == 0 ? job.PreviousInstanceId : job.OriginalInstanceId;
                MergeJobStatus(job);
            }

            #endregion

            #region START JOB OPERATION

            timeoutms = timeout;

            try
            {
                MonitoredInstance.StartJob(job.JobId);
            }
            catch (Exception ex)
            {
                job.RunningState = JobState.ERROR;
                job.OnAttempts = false;
                job.IsRestarting = false;
                job.RetriesAttempted = 0;
                Logger.Error($"Could not start job:{job.JobName}", ex, additionalData: $"{JsonConvert.SerializeObject(job, Formatting.Indented)}");
                //TODO: PAGER DUTY
                return job;
            }

            while (timeoutms > 0)
            {
                running = MonitoredInstance.CheckJobRunningStatus(job.JobId);
                if (running) break;
                await Task.Delay(pollingInterval);
                timeoutms -= pollingInterval;
            }

            if (!running)
            {
                job.RunningState = JobState.ERROR;
                job.OnAttempts = false;
                job.IsRestarting = false;
                job.RetriesAttempted = 0;
                Logger.Error($"Could not stop job in proper time:{job.JobName}", new TimeoutException($"Operation could not complete in {timeout} ms"), additionalData: $"{JsonConvert.SerializeObject(job, Formatting.Indented)}");
                //TODO: PAGER DUTY
                return job;
            }

            job.RunningState = JobState.UNKNOWN;
            job.IsRestarting = false;

            Logger.Audit($"Job successfully restarted:{job.JobName}", additionalData: $"{JsonConvert.SerializeObject(job, Formatting.Indented)}");

            return job;

            #endregion

        }

        #endregion

    }
}
