﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;
using ExtensionMethods;
using StoneCo.MIS.SQLJobMonitor.Lib.Model;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Configuration
{
    public static class JobMonitorConfigurationManager
    {

        #region REGISTRY CONSTANTS AND STRUCTS

        private const string HKLM = "HKEY_LOCAL_MACHINE";
        private const string SUBKEY = @"\SYSTEM\CurrentControlSet\Services\SQLServerJobMonitor\Parameters";
        public static readonly string KEYNAME = string.Concat(HKLM, SUBKEY);
        private static string assemblyLocation;
        private static bool reloadAppConfig = false;

        public static string AssemblyLocation
        {
            get
            {
                if (string.IsNullOrEmpty(assemblyLocation))
                {
                    assemblyLocation = Assembly.GetExecutingAssembly().Location;
                }
                return assemblyLocation;
            }
            set { assemblyLocation = value; }
        }

        private struct KeyNames
        {
            /// <summary>
            /// Indicates whether the Monitoring Service should try to start the SQL Agent if Stopped.
            /// </summary>
            internal const string START_AGENT = "StartAgent";

            /// <summary>
            /// Time interval in seconds to wait for Agent to Start.
            /// </summary>
            internal const string START_AGENT_TIMEOUT = "StartAgentTimeout";

            /// <summary>
            /// Time interval in seconds to check job execution.
            /// </summary>
            internal const string VERIFICATION_INTERVAL = "VerificationInterval";
            /// <summary>
            /// Default Number of retries for irresponsive jobs, overwritten by table configuration.
            /// </summary>
            internal const string JOB_RESTART_RETRIES = "JobRestartRetries";

            /// <summary>
            /// ConnectionString to Monitoring Database containing the JobMonitorConfiguration table should be created.
            /// </summary>
            internal const string MONITORING_DB = "MonitoringDB";

            /// <summary>
            /// ConnectionString to Monitoring Database containing the JobMonitorConfiguration table should be created.
            /// </summary>
            internal const string MONITORED_INSTANCE = "MonitoredInstance";

            /// <summary>
            /// Custom absolute path for text file logs. If Empty, will use the assembly's path.
            /// </summary>
            internal const string LOG_FILE_PATH = "LogFilePath";

            /// <summary>
            /// Options to determ the Default log provider destination.
            /// </summary>
            internal const string LOG_PROVIDER_TYPE = "LogProviderType";

            /// <summary>
            /// Options to determ the Default log level option. That is, which level of information is logged. 
            /// </summary>
            internal const string LOG_LEVEL_OPTION = "LogLevelOption";

        }

        #endregion

        #region SUBCLASS APPSETTINGS

        public static class AppSettings
        {

            private static bool _startAgent = false;
            /// <summary>
            /// Indicates whether the Monitoring Service should try to start the SQL Agent if Stopped.
            /// </summary>
            public static bool StartAgent
            {
                get
                {
                    if (RegistryKeyValueExists(KeyNames.START_AGENT) == true && !reloadAppConfig)
                    {
                        bool.TryParse(RegistryGetValue(KeyNames.START_AGENT), out _startAgent);
                    }
                    else
                    {
                        bool.TryParse(GetAppSettings(KeyNames.START_AGENT), out _startAgent);
                        RegistrySetValue(KeyNames.START_AGENT, _startAgent, RegistryValueKind.DWord);
                    }
                    return _startAgent;
                }
            }

            private static int _startAgentTimeout = 60;
            /// <summary>
            /// Default Number of retries for irresponsive jobs, overwritten by table configuration.
            /// </summary>
            public static int StartAgentTimeout
            {
                get
                {
                    if (RegistryKeyValueExists(KeyNames.START_AGENT_TIMEOUT) == true && !reloadAppConfig)
                    {
                        int.TryParse(RegistryGetValue(KeyNames.START_AGENT_TIMEOUT), out _startAgentTimeout);
                    }
                    else
                    {

                        int.TryParse(GetAppSettings(KeyNames.START_AGENT_TIMEOUT), out _startAgentTimeout);
                        RegistrySetValue(KeyNames.START_AGENT_TIMEOUT, _startAgentTimeout, RegistryValueKind.DWord);
                    }

                    return _startAgentTimeout;
                }
            }

            private static int _verificationInterval = 120;
            /// <summary>
            /// Time interval in seconds to check job execution.
            /// </summary>
            public static int VerificationInterval
            {
                get
                {
                    if (RegistryKeyValueExists(KeyNames.VERIFICATION_INTERVAL) == true && !reloadAppConfig)
                    {
                        int.TryParse(RegistryGetValue(KeyNames.VERIFICATION_INTERVAL), out _verificationInterval);
                    }
                    else
                    {

                        int.TryParse(GetAppSettings(KeyNames.VERIFICATION_INTERVAL), out _verificationInterval);
                        RegistrySetValue(KeyNames.VERIFICATION_INTERVAL, _verificationInterval, RegistryValueKind.DWord);
                    }

                    return _verificationInterval;
                }
            }


            private static int _jobRestartRetries = 3;
            /// <summary>
            /// Default Number of retries for irresponsive jobs, overwritten by table configuration.
            /// </summary>
            public static int JobRestartRetries
            {
                get
                {
                    if (RegistryKeyValueExists(KeyNames.JOB_RESTART_RETRIES) == true && !reloadAppConfig)
                    {
                        int.TryParse(RegistryGetValue(KeyNames.JOB_RESTART_RETRIES), out _jobRestartRetries);
                    }
                    else
                    {
                        int.TryParse(GetAppSettings(KeyNames.JOB_RESTART_RETRIES), out _jobRestartRetries);
                        RegistrySetValue(KeyNames.JOB_RESTART_RETRIES, _jobRestartRetries, RegistryValueKind.DWord);
                    }
                    return _jobRestartRetries;
                }
            }


            private static string _logFilePath = null;
            /// <summary>
            /// Custom absolute path for text file logs. If Empty, will use the assembly's path.
            /// </summary>
            public static string LogFilePath
            {
                get
                {
                    if (RegistryKeyValueExists(KeyNames.LOG_FILE_PATH) == true && !reloadAppConfig)
                    {
                        _logFilePath = RegistryGetValue(KeyNames.LOG_FILE_PATH).GetValueOrDefault("");
                    }
                    else
                    {
                        _logFilePath = GetAppSettings(KeyNames.LOG_FILE_PATH).GetValueOrDefault("");                        
                        RegistrySetValue(KeyNames.LOG_FILE_PATH, _logFilePath, RegistryValueKind.String);
                    }
                    return _logFilePath;
                }
            }

            private static int _logProviderType = 2;
            /// <summary>
            /// Options to determ the Default log provider destination.
            /// </summary>
            public static int LogProviderType
            {
                get
                {
                    if (RegistryKeyValueExists(KeyNames.LOG_PROVIDER_TYPE) == true && !reloadAppConfig)
                    {
                        int.TryParse(RegistryGetValue(KeyNames.LOG_PROVIDER_TYPE), out _logProviderType);
                    }
                    else
                    {
                        int.TryParse(GetAppSettings(KeyNames.LOG_PROVIDER_TYPE), out _logProviderType);
                        RegistrySetValue(KeyNames.LOG_PROVIDER_TYPE, _logProviderType, RegistryValueKind.DWord);
                    }
                    return _logProviderType;
                }
            }


            private static int _logLevelOption = 1;
            /// <summary>
            /// Options to determ the Default log level option. That is, which level of information is logged. 
            /// </summary>
            public static int LogLevelOption
            {
                get
                {
                    if (RegistryKeyValueExists(KeyNames.LOG_LEVEL_OPTION) == true && !reloadAppConfig)
                    {
                        int.TryParse(RegistryGetValue(KeyNames.LOG_LEVEL_OPTION), out _logLevelOption);
                    }
                    else
                    {
                        int.TryParse(GetAppSettings(KeyNames.LOG_LEVEL_OPTION), out _logLevelOption);
                        RegistrySetValue(KeyNames.LOG_LEVEL_OPTION, _logLevelOption, RegistryValueKind.DWord);
                    }
                    return _logLevelOption;
                }
            }

        }

        #endregion

        #region SUBCLASS CONNECTIONSTRINGS

        public static class ConnectionStrings
        {
            private static string _monitoringDB;
            /// <summary>
            /// ConnectionString to Monitoring Database containing the JobMonitorConfiguration table should be created.
            /// </summary>
            public static string MonitoringDB
            {
                get
                {
                    if (RegistryKeyValueExists(KeyNames.MONITORING_DB) == true && !reloadAppConfig)
                    {
                        _monitoringDB = RegistryGetValue(KeyNames.MONITORING_DB);
                    }
                    else
                    {
                        _monitoringDB = GetConnectionStrings(KeyNames.MONITORING_DB);
                        if (!string.IsNullOrWhiteSpace(_monitoringDB))
                        {
                            RegistrySetValue(KeyNames.MONITORING_DB, _monitoringDB, RegistryValueKind.String);
                        }
                        else
                        {
                            throw new ConfigurationErrorsException("Connection string for MonitoringDB could not be found.");
                        }
                    }
                    return _monitoringDB;
                }
            }

            private static string _monitoredInstance;
            /// <summary>
            /// ConnectionString to Monitored Instance containing Jobs to be monitored.
            /// </summary>
            public static string MonitoredInstance
            {
                get
                {
                    if (RegistryKeyValueExists(KeyNames.MONITORED_INSTANCE) == true && !reloadAppConfig)
                    {
                        _monitoredInstance = RegistryGetValue(KeyNames.MONITORED_INSTANCE);
                    }
                    else
                    {
                        _monitoredInstance = GetConnectionStrings(KeyNames.MONITORED_INSTANCE);
                        if (!string.IsNullOrWhiteSpace(_monitoredInstance))
                        {
                            RegistrySetValue(KeyNames.MONITORED_INSTANCE, _monitoredInstance, RegistryValueKind.String);
                        }
                        else
                        {
                            throw new ConfigurationErrorsException("Connection string for MonitoredInstance could not be found.");
                        }
                    }
                    return _monitoredInstance;
                }
            }

        }
        #endregion

        #region STATIC METHODS FOR MANAGING CONFIGURATION MANAGER AND REGISTRY


        private static string GetAppSettings(string configKey)
        {
            var config = ConfigurationManager.OpenExeConfiguration(assemblyLocation);
            return config.AppSettings.Settings[configKey].Value;
        }

        private static string GetConnectionStrings(string configKey)
        {
            var config = ConfigurationManager.OpenExeConfiguration(assemblyLocation);
            return config.ConnectionStrings.ConnectionStrings[configKey].ConnectionString;
        }

        private static bool RegistryKeyValueExists(string keyValueName)
        {
            return Registry.GetValue(KEYNAME, keyValueName, null) != null;
        }

        private static string RegistryGetValue(string keyValueName)
        {
            return Registry.GetValue(KEYNAME, keyValueName, null).ToString();
        }

        private static bool RegistrySetValue(string keyValueName, object value, RegistryValueKind valueKind)
        {
            Registry.SetValue(KEYNAME, keyValueName, value, valueKind);
            return RegistryKeyValueExists(keyValueName);
        }
        #endregion

        public static ServiceParameters GetConfigurations(bool reload = false)
        {
            reloadAppConfig = reload;

            ServiceParameters parameters = new ServiceParameters() {
                StartAgent = AppSettings.StartAgent,
                StartAgentTimeout = AppSettings.StartAgentTimeout,
                VerificationInterval = AppSettings.VerificationInterval,
                JobRestartRetries = AppSettings.JobRestartRetries,
                MonitoringDB = ConnectionStrings.MonitoringDB,
                MonitoredInstance = ConnectionStrings.MonitoredInstance,
                LogFilePath = AppSettings.LogFilePath,
                LogProviderType = (byte)AppSettings.LogProviderType,
                LogLevelOption = (byte)AppSettings.LogLevelOption
            };

            reloadAppConfig = false;

            return parameters;
        }

    }
}
