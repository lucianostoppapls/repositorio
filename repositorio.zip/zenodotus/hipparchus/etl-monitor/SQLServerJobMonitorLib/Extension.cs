﻿using Microsoft.SqlServer.Server;
using StoneCo.MIS.SQLJobMonitor.Lib.Model;
using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using ExtensionMethods;

namespace ExtensionMethods
{
    public static class Extensions
    {
        #region STRING EXTENSIONS

        public static string GetValueOrDefault(this string str, string defaultValue = "None")
        {
            return string.IsNullOrWhiteSpace(str) ? defaultValue : str;
        }

        #endregion

        #region DATETIME EXTENSIONS

        public static DateTime GetValueOrNow(this DateTime datetime)
        {
            return datetime.Equals(DateTime.MinValue) ? DateTime.Now : datetime;
        }

        #endregion

        #region GENERIC LIST <-> DATABASE (DATAREADER, DATATABLE, DBTYPE, SQLDBTYPE) EXTENSIONS

        public static List<T> ToList<T>(this IDataReader dr) where T : BaseModel
        {
            List<T> list = new List<T>();
            while (dr.Read())
            {
                T obj = Activator.CreateInstance<T>();
                foreach (PropertyInfo prop in obj.GetType().GetProperties())
                {
                    if (Enumerable.Range(0, dr.FieldCount).Any(i => string.Equals(dr.GetName(i), prop.Name, StringComparison.OrdinalIgnoreCase)))
                    {
                        if (!Equals(dr[prop.Name], DBNull.Value))
                        {
                            if (prop.PropertyType.BaseType == typeof(Enum) && Enum.GetUnderlyingType(prop.PropertyType).Name == dr[prop.Name].GetType().Name
                                || (prop.PropertyType.Name == dr[prop.Name].GetType().Name))
                            {
                                prop.SetValue(obj, dr[prop.Name], null);
                            }
                            else if (prop.PropertyType.IsImplicitFrom(dr[prop.Name].GetType()))
                            {
                                prop.SetValue(obj, dr[prop.Name], null);
                            }
                            else if (prop.PropertyType.IsImplicitFrom(typeof(string)))
                            {
                                prop.SetValue(obj, dr[prop.Name].ToString(), null);
                            }
                        }
                    }
                }
                list.Add(obj);
            }
            return list;
        }

        public static DataTable ToDataTable<T>(this List<T> list) where T : BaseModel
        {
            return ToDataTable<T>(list, null);
        }

        public static DataTable ToDataTable<T>(this List<T> list, string autoIncrement) where T : BaseModel
        {
            //TODO: ADD Nullability/Key decorator to classes/interfaces
            T obj = Activator.CreateInstance<T>();
            DataTable table = new DataTable(obj.GetType().Name);

            //Set the table Schema from empty object
            foreach (PropertyInfo prop in obj.GetType().GetProperties())
            {

                if (prop.PropertyType.BaseType == typeof(Enum))
                {
                    //if enum, convert to base type
                    table.Columns.Add(new DataColumn(prop.Name, Enum.GetUnderlyingType(prop.PropertyType)));
                }
                else
                {
                    table.Columns.Add(new DataColumn(prop.Name, prop.PropertyType));
                }

                //set identity or sequence property
                if (prop.Name == autoIncrement.GetValueOrDefault(string.Empty))
                {
                    table.Columns[prop.Name].AutoIncrement = true;
                }
            }

            //Add rows into table
            foreach (var item in list)
            {
                DataRow row = table.NewRow();
                foreach (PropertyInfo prop in obj.GetType().GetProperties())
                {
                    if (prop.PropertyType == typeof(Guid))
                    {
                        Guid gvalue = new Guid(prop.GetValue(item, null).ToString());
                        if (gvalue == Guid.Empty)
                        {
                            row[prop.Name] = DBNull.Value;
                        }
                        else
                        {
                            row[prop.Name] = gvalue;
                        }
                    }
                    else if (prop.PropertyType.BaseType == typeof(Enum))
                    {
                        row[prop.Name] = prop.GetValue(item, null);
                    }
                    else if (prop.PropertyType == typeof(DateTime))
                    {
                        DateTime dtvalue = (DateTime)prop.GetValue(item, null);
                        if (dtvalue == DateTime.MinValue)
                        {
                            row[prop.Name] = DBNull.Value;
                        }
                        else
                        {
                            row[prop.Name] = dtvalue;
                        }
                    }
                    else
                    {
                        row[prop.Name] = prop.GetValue(item, null);
                    }
                }
                table.Rows.Add(row);
            }
            return table;
        }

        public static DbType GetDbType(this Type type)
        {
            SqlParameter parameter = new SqlParameter();
            System.ComponentModel.TypeConverter converter = System.ComponentModel.TypeDescriptor.GetConverter(parameter.DbType);
            if (converter.CanConvertFrom(type))
            {
                return (DbType)converter.ConvertFrom(type.Name);
            }
            else
            {
                try
                {
                    //Force conversion, set to string if error.
                    return (DbType)converter.ConvertFrom(type.Name);
                }
                catch (Exception)
                {
                    //set default type as string
                    return DbType.String;
                }
            }
        }

        public static SqlDbType GetSqlDbType(this Type type)
        {
            SqlParameter parameter = new SqlParameter
            {
                DbType = type.GetDbType()
            };

            return parameter.SqlDbType;
        }

        public static bool CanConvertToDbType(this Type type, DbType dbType)
        {
            return type.GetDbType() == dbType;
        }

        public static bool CanConvertToDbType(this Type type, SqlDbType sqlDbType)
        {
            return type.GetSqlDbType() == sqlDbType;
        }

        #endregion

        #region TYPE IMPLICIT CAST EXTENSIONS

        public static readonly Dictionary<TypeCode, HashSet<TypeCode>> ImplicitNumericConversions =
            new Dictionary<TypeCode, HashSet<TypeCode>>() {
                        { TypeCode.Int16, new HashSet<TypeCode>(){ TypeCode.SByte, TypeCode.Byte } },
                        { TypeCode.UInt16, new HashSet<TypeCode>(){ TypeCode.Char, TypeCode.Byte } },
                        { TypeCode.Int32, new HashSet<TypeCode>(){ TypeCode.Char, TypeCode.SByte, TypeCode.Byte,
                            TypeCode.Int16, TypeCode.UInt16 } },
                        { TypeCode.UInt32, new HashSet<TypeCode>(){ TypeCode.Char, TypeCode.Byte, TypeCode.UInt16 } },
                        { TypeCode.Int64, new HashSet<TypeCode>(){ TypeCode.Char, TypeCode.SByte, TypeCode.Byte,
                            TypeCode.Int16, TypeCode.UInt16, TypeCode.Int32, TypeCode.UInt32 } },
                        { TypeCode.UInt64, new HashSet<TypeCode>(){ TypeCode.Char, TypeCode.Byte, TypeCode.UInt16, TypeCode.UInt32 } },
                        { TypeCode.Single, new HashSet<TypeCode>(){ TypeCode.Char, TypeCode.SByte, TypeCode.Byte,
                            TypeCode.Int16, TypeCode.UInt16, TypeCode.Int32, TypeCode.UInt32, TypeCode.Int64, TypeCode.UInt64 } },
                        { TypeCode.Double, new HashSet<TypeCode>(){ TypeCode.Char, TypeCode.SByte, TypeCode.Byte, TypeCode.Int16,
                            TypeCode.UInt16, TypeCode.Int32, TypeCode.UInt32, TypeCode.Int64, TypeCode.UInt64, TypeCode.Single } },
                        { TypeCode.Decimal, new HashSet<TypeCode>(){ TypeCode.Char, TypeCode.SByte, TypeCode.Byte,
                            TypeCode.Int16, TypeCode.UInt16, TypeCode.Int32, TypeCode.UInt32, TypeCode.Int64, TypeCode.UInt64 } },
        };

        public static bool IsImplicitFrom(this Type type, Type fromType)
        {
            if (type == null || fromType == null)
            {
                return false;
            }

            // support for reference type
            if (type.IsByRef) { type = type.GetElementType(); }
            if (fromType.IsByRef) { fromType = type.GetElementType(); }

            // could always be convert to object
            if (type.Equals(typeof(object)))
            {
                return true;
            }

            // check if it could be convert using standard implicit cast
            if (IsStandardImplicitFrom(type, fromType))
            {
                return true;
            }

            // determine implicit convert for non-nullable types
            if (IsNullableType(type, out Type nonNullalbeType) &&
                IsNullableType(fromType, out Type nonNullableFromType))
            {
                type = nonNullalbeType;
                fromType = nonNullableFromType;
            }

            // check if it could be convert using standard implicit cast
            if (!fromType.IsNullableType() && !type.IsNullableType())
            {
                return IsStandardImplicitFrom(fromType, type);
            }

            return false;
        }

        public static bool IsStandardImplicitFrom(this Type type, Type fromType)
        {
            // support for Nullable<T>
            if (!type.IsValueType || IsNullableType(ref type))
            {
                fromType = GetNonNullableType(fromType);
            }

            // determine implicit value type convert
            if (!type.IsEnum &&
                ImplicitNumericConversions.TryGetValue(Type.GetTypeCode(type), out HashSet<TypeCode> typeSet))
            {
                if (!fromType.IsEnum && typeSet.Contains(Type.GetTypeCode(fromType)))
                {
                    return true;
                }
            }

            // determine implicit reference type convert and boxing convert
            return type.IsAssignableFrom(fromType);
        }

        public static bool IsNullableType(this Type type)
        {
            return (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>));
        }

        public static bool IsNullableType(this Type type, out Type nonNullalbeType)
        {
            if (IsNullableType(type))
            {
                nonNullalbeType = type.GetGenericArguments()[0];
                return true;
            }
            else
            {
                nonNullalbeType = type;
                return false;
            }
        }

        public static bool IsNullableType(ref Type type)
        {
            if (IsNullableType(type))
            {
                type = type.GetGenericArguments()[0];
                return true;
            }
            else
            {
                return false;
            }
        }

        public static Type GetNonNullableType(this Type type)
        {
            if (IsNullableType(type))
            {
                return type.GetGenericArguments()[0];
            }
            return type;
        }
        
        #endregion
    }
}