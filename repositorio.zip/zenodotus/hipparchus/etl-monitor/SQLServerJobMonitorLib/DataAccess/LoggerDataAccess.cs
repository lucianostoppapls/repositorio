﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExtensionMethods;
using Microsoft.SqlServer.Server;
using StoneCo.MIS.SQLJobMonitor.Lib.Model;

namespace StoneCo.MIS.SQLJobMonitor.Lib.DataAccess
{
    public class LoggerDataAccess : BaseDataAccess
    {
        #region PRIVATE FIELDS

        private const string SELECT_COMMAND = @"SELECT [EventLogId]
                                      ,[EventMessage]
                                      ,[EventTime]
                                      ,[LogLevel]
                                      ,[ExceptionSource]
                                      ,[ExceptionMessage]
                                      ,[StackTrace]
                                      ,[AdditionalData]
                                  FROM [jobmonitor].[JobEventLog]";

        #endregion

        #region CONSTRUCTOR

        public LoggerDataAccess(string connString) : base(connString)
        {

        }

        #endregion

        public void AppendEventLog(JobEventLog log)
        {
            DataTable table = (new List<JobEventLog>() { log }).ToDataTable<JobEventLog>();

            _ = AdapterUpdate(table, SELECT_COMMAND);
        }
    }
}
