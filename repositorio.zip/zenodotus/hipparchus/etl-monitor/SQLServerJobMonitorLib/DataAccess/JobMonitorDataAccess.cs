﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices.WindowsRuntime;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ExtensionMethods;
using Microsoft.SqlServer.Server;
using StoneCo.MIS.SQLJobMonitor.Lib.Model;

namespace StoneCo.MIS.SQLJobMonitor.Lib.DataAccess
{
    public class JobMonitorDataAccess : BaseDataAccess
    {
        #region CONSTRUCTOR

        public JobMonitorDataAccess(string connString) : base(connString)
        {

        }

        #endregion

        #region AGENT JOBS METHODS

        public AgentJobCollection GetAgentJobs(bool IsEnabled = true)
        {
            AgentJobCollection agentJobs;

            string command_text = @"SELECT     sj.job_id as JobId
                                              ,cast(sj.name as nvarchar(128)) as JobName
                                              ,cast(sj.enabled as bit) as IsEnabled  
                                              ,sj.date_created as DateCreated
                                              ,sj.date_modified as DateModified
                                              ,sj.version_number as VersionNumber  
                                            FROM msdb.dbo.sysjobs sj
                                            WHERE sj.enabled = @IsEnabled";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("IsEnabled", SqlDbType.Bit)
                {
                    Value = IsEnabled
                }
            };

            agentJobs = ExecuteReader<AgentJobCollection, AgentJob>(command_text, sqlParameters);
            return agentJobs;
        }

        public AgentJobCollection GetAgentJobById(Guid jobId)
        {
            AgentJobCollection agentJobs;

            string command_text = @"SELECT     sj.job_id as JobId
                                              ,cast(sj.name as nvarchar(128)) as JobName
                                              ,cast(sj.enabled as bit) as IsEnabled  
                                              ,sj.date_created as DateCreated
                                              ,sj.date_modified as DateModified
                                              ,sj.version_number as VersionNumber  
                                            FROM msdb.dbo.sysjobs sj
                                            WHERE sj.job_id = @job_id";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("job_id", SqlDbType.UniqueIdentifier)
                {
                    Value = jobId
                }
            };

            agentJobs = ExecuteReader<AgentJobCollection, AgentJob>(command_text, sqlParameters);
            return agentJobs;
        }

        public void MergeAgentJobs(AgentJob job)
        {
            MergeAgentJobs(new AgentJobCollection(job));
        }

        public int MergeAgentJobs(AgentJobCollection jobs)
        {
            const string ProcedureName = "jobmonitor.usp_merge_agent_jobs";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("AgentJobs", SqlDbType.Structured)
                {
                    Value = jobs.Items.ToDataTable<AgentJob>(),
                    TypeName = "jobmonitor.AgentJobType"
                }
            };
            return ExecuteProcedure(ProcedureName, sqlParameters);
        }

        #endregion

        #region MANAGED JOBS METHODS

        public ManagedJobCollection GetManagedJobs(bool IsManaged = true)
        {
            ManagedJobCollection managedJobs;

            string command_text = @"SELECT   JobId
                                                ,JobName
                                                ,IsManaged
                                                ,ExpectationInMinutes
                                                ,ToleranceInPercent
                                                ,NumberOfRetries
                                                ,TimeoutInSeconds
                                                ,PollingInSeconds
                                                ,StartWindow
                                                ,EndWindow
                                          FROM jobmonitor.ManagedJobs
                                          WHERE IsManaged = @IsManaged";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("IsManaged", SqlDbType.Bit)
                {
                    Value = IsManaged
                }
            };

            managedJobs = ExecuteReader<ManagedJobCollection, ManagedJob>(command_text, sqlParameters);
            return managedJobs;
        }

        public void MergeManagedJobs(Job job)
        {
            MergeManagedJobs(new JobCollection(job));
        }

        public int MergeManagedJobs(JobCollection jobs)
        {
            const string ProcedureName = "jobmonitor.usp_merge_managed_jobs";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("ManagedJobs", SqlDbType.Structured)
                {
                    Value = jobs.Items.ToDataTable<Job>(),
                    TypeName = "jobmonitor.JobType"
                }
            };
            return ExecuteProcedure(ProcedureName, sqlParameters);
        }
        #endregion

        #region JOB ACTIVITY METHODS

        public JobActivityCollection GetJobActivity(string JobName, Guid JobId, bool IsEnabled = true, bool RunningStateOnly = false)
        {
            JobActivityCollection agentJobs;

            string stateFilter = RunningStateOnly ? "\nAND sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NULL" : string.Empty;
            string jobFilter = (JobId != null && JobId != Guid.Empty) ?
                    $"\nAND sj.job_id = N'{JobId}'" :    
                string.IsNullOrEmpty(JobName) ? 
                    string.Empty : $"\nAND sj.name = N'{JobName}'";

            string command_text = string.Format(@"SELECT sj.job_id as JobId
                                              ,CAST(sj.name as nvarchar(128)) as JobName     
                                              ,CAST(sj.enabled as bit) as IsEnabled
	                                          ,sj.date_created as DateCreated
	                                          ,sj.date_modified as DateModified
	                                          ,sj.version_number as VersionNumber
	                                          ,sja.start_execution_date as StartedAt
	                                          ,sja.stop_execution_date as EndedAt
	                                          ,CAST(CASE WHEN sja.start_execution_date IS NULL THEN NULL
		                                                 WHEN sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NULL THEN DATEDIFF(SECOND, sja.start_execution_date, SYSDATETIME())/60.0  
		                                                 WHEN sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NOT NULL THEN  DATEDIFF(SECOND, sja.start_execution_date, sja.stop_execution_date)/60.0  
	                                                END as numeric(9,4)) AS DurationInMinutes	
	                                          ,CAST(CASE WHEN sja.start_execution_date IS NULL THEN 0
		                                                 WHEN sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NULL THEN 1
		                                                 WHEN sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NOT NULL THEN 0
	                                                END AS BIT) AS 'IsRunning'
                                              ,CAST(sja.run_requested_source as int) as RequestedSource
	                                          ,CASE WHEN sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NULL  THEN 4 ELSE sh.run_status END as LastRunStatus	                                          
	                                          ,cast(cast(sh.run_date as varchar) as date) as LastRunDate
	                                          ,CAST(STUFF(STUFF(RIGHT(REPLICATE('0', 6) +  CAST(sh.run_time as varchar(6)), 6), 3, 0, ':'), 6, 0, ':') as time(0)) as LastRunTime
	                                          ,sh.instance_id as InstanceId	                                          
                                              ,(SELECT top 1 lead(instance_id, 1, instance_id) over(order by instance_id desc) FROM msdb.dbo.sysjobhistory b WHERE b.job_id = sj.job_id) as PreviousInstanceId
                                          FROM msdb.dbo.sysjobs sj 
                                          JOIN msdb.dbo.sysjobactivity sja  
	                                        ON sj.job_id = sja.job_id 
                                          LEFT JOIN msdb.dbo.sysjobhistory sh
	                                        ON sh.instance_id = sja.job_history_id
                                        WHERE session_id = (SELECT MAX(session_id) FROM msdb.dbo.sysjobactivity a WHERE a.job_id = sj.job_id) {0} {1}
                                        AND sj.enabled = @IsEnabled", stateFilter, jobFilter);

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("IsEnabled", SqlDbType.Bit)
                {
                    Value = IsEnabled
                }
            };

            agentJobs = ExecuteReader<JobActivityCollection, JobActivity>(command_text, sqlParameters);
            return agentJobs;
        }

        public void MergeJobActivity(JobActivity job)
        {
            MergeJobActivity(new JobActivityCollection(job));
        }

        public int MergeJobActivity(JobActivityCollection jobs)
        {
            const string ProcedureName = "jobmonitor.usp_merge_job_activity";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("JobActivity", SqlDbType.Structured)
                {
                    Value = jobs.Items.ToDataTable<JobActivity>(),
                    TypeName = "jobmonitor.JobActivityType"
                }
            };
            return ExecuteProcedure(ProcedureName, sqlParameters);
        }

        #endregion

        #region JOB STATUS METHODS

        public JobStatusCollection GetJobStatus()
        {
            JobStatusCollection agentJobs;

            string command_text = @"SELECT   
                                         JobId
                                        ,JobName
                                        ,IsRunning
                                        ,IsRestarting
                                        ,OnAttempts
                                        ,RunningState
                                        ,NumberOfRetries
                                        ,RetriesAttempted
                                        ,InstanceId
                                        ,OriginalInstanceId
                                        ,PreviousInstanceId
                                   FROM jobmonitor.JobStatus";

            agentJobs = ExecuteReader<JobStatusCollection, JobStatus>(command_text, new List<SqlParameter>());
            return agentJobs;
        }

        public void MergeJobStatus(JobStatus job) 
        {
            MergeJobStatus(new JobStatusCollection(job));
        }

        public int MergeJobStatus(JobStatusCollection jobs)
        {
            const string ProcedureName = "jobmonitor.usp_merge_job_status";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("JobStatus", SqlDbType.Structured)
                {
                    Value = jobs.Items.ToDataTable<JobStatus>(),
                    TypeName = "jobmonitor.JobStatusType"
                }
            };
            return ExecuteProcedure(ProcedureName, sqlParameters);
        }

        #endregion

        #region JOB STATUS MANAGEMENT (START-STOP-CHECK)

        public int StopJob(string jobName)
        {
            const string ProcedureName = "msdb.dbo.sp_stop_job";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("job_name", SqlDbType.NVarChar)
                {
                    Value = jobName
                }
            };
            return ExecuteProcedure(ProcedureName, sqlParameters);
        }

        public int StopJob(Guid jobId)
        {
            const string ProcedureName = "msdb.dbo.sp_stop_job";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("job_id", SqlDbType.UniqueIdentifier)
                {
                    Value = jobId
                }
            };
            return ExecuteProcedure(ProcedureName, sqlParameters);
        }

        public int StartJob(string jobName)
        {
            const string ProcedureName = "msdb.dbo.sp_start_job";
            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("job_name", SqlDbType.NVarChar)
                {
                    Value = jobName
                }
            };
            return ExecuteProcedure(ProcedureName, sqlParameters);
        }

        public int StartJob(Guid jobId)
        {
            const string ProcedureName = "msdb.dbo.sp_start_job";
            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("job_id", SqlDbType.UniqueIdentifier)
                {
                    Value = jobId
                }
            };
            return ExecuteProcedure(ProcedureName, sqlParameters);
        }

        public bool CheckJobRunningStatus(string jobName)
        {
            string command_text = @"SELECT TOP 1 
                                            CAST(CASE WHEN sja.start_execution_date IS NULL THEN 0
                                                      WHEN sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NULL THEN 1
                                                      WHEN sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NOT NULL THEN 0
                                                  END AS BIT
                                                 ) AS 'IsRunning'
                                         FROM msdb.dbo.sysjobs sj 
                                            JOIN msdb.dbo.sysjobactivity sja
                                                ON sj.job_id = sja.job_id
                                         WHERE sj.name = @job_name
                                            AND sja.session_id = (SELECT MAX(session_id) FROM msdb.dbo.sysjobactivity a WHERE a.job_id = sja.job_id)";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("job_name", SqlDbType.NVarChar)
                {
                    Value = jobName
                }
            };

            bool.TryParse(ExecuteScalar(command_text, sqlParameters).ToString(), out bool isRunning);
            return isRunning;
        }

        public bool CheckJobRunningStatus(Guid jobId)
        {
            string command_text = @"SELECT TOP 1 
                                            CAST(CASE WHEN sja.start_execution_date IS NULL THEN 0
                                                      WHEN sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NULL THEN 1
                                                      WHEN sja.start_execution_date IS NOT NULL AND sja.stop_execution_date IS NOT NULL THEN 0
                                                  END AS BIT
                                                 ) AS 'IsRunning'
                                         FROM msdb.dbo.sysjobs sj 
                                            JOIN msdb.dbo.sysjobactivity sja
                                                ON sj.job_id = sja.job_id
                                         WHERE sj.job_id = @job_id
                                            AND sja.session_id = (SELECT MAX(session_id) FROM msdb.dbo.sysjobactivity a WHERE a.job_id = sja.job_id)";

            List<SqlParameter> sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("job_id", SqlDbType.UniqueIdentifier)
                {
                    Value = jobId
                }
            };

            bool.TryParse(ExecuteScalar(command_text, sqlParameters).ToString(), out bool isRunning);
            return isRunning;
        }

        #endregion
    }
}
