﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.DataAccess
{
    public class LogDataAccess : BaseDataAccess
    {
        #region CONSTRUCTOR

        public LogDataAccess(string connString) : base(connString)
        {

        }

        #endregion
    }
}
