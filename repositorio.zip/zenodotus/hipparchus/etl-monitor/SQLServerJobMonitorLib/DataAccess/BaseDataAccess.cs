﻿using ExtensionMethods;
using StoneCo.MIS.SQLJobMonitor.Lib.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.DataAccess
{
    public abstract class BaseDataAccess
    {
        #region PROPERTIES

        public DatabaseInstance Instance { get; private set; }

        #endregion

        #region CONSTRUCTOR

        public BaseDataAccess(string connString)
        {
            Instance = new DatabaseInstance() { ConnectionString = connString };
        }

        #endregion

        #region TEST CONNECTION

        public bool TestConnection()
        {
            using (SqlConnection connection = new SqlConnection(Instance.ConnectionString))
            {
                try
                {
                    connection.Open();
                    Instance.CanConnect = connection.ServerVersion != null;
                    Instance.Database = connection.Database;
                    Instance.DataSource = connection.DataSource;
                    Instance.ServerVersion = connection.ServerVersion;
                }
                catch (Exception)
                {
                    Instance.CanConnect = false;
                    throw;
                }

                Instance.IsAgentRunning = CheckAgentServiceStatus();
                return Instance.CanConnect;
            }
        }

        #endregion

        #region AGENT STATUS CHECKING

        public bool CheckAgentStatus(out int pid, bool fromServices = false)
        {
            pid = 0;

            if (fromServices)
            {
                return CheckAgentServiceStatus();
            }

            if (!Instance.CanConnect)
            {
                return false;
            }

            string command_text = "select hostprocess from sysprocesses WHERE program_name = N'SQLAgent - Generic Refresher';";

            string ret = ExecuteScalar(command_text, new List<SqlParameter>()) as string;
            int.TryParse(ret.GetValueOrDefault("0"), out pid);
            Instance.IsAgentRunning = pid > 0;

            return Instance.IsAgentRunning;
        }

        public bool CheckAgentServiceStatus()
        {
            ServiceController service = new ServiceController("SQLSERVERAGENT");
            try
            {
                Instance.IsAgentRunning = service.Status == ServiceControllerStatus.Running;
            }
            catch (Exception)
            {
                Instance.IsAgentRunning = false;
            }
            return Instance.IsAgentRunning;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="timeout">Timeout in seconds</param>
        /// <returns></returns>
        public bool TryStartAgentService(int timeout = 30)
        {
            timeout = timeout < 10 ? 10000 : timeout * 1000;

            ServiceController service = new ServiceController("SQLSERVERAGENT");

            try
            {
                ServiceControllerStatus status = service.Status;

                TimeSpan timeOutSpan = TimeSpan.FromMilliseconds(timeout);
                Stopwatch watch = new Stopwatch();

                watch.Start();
                service.Start();
                service.WaitForStatus(ServiceControllerStatus.Running, timeOutSpan);

                //TODO: agent start retries count and timeout
                while (service.Status != ServiceControllerStatus.Running)
                {
                    if (watch.Elapsed.TotalMilliseconds >= timeout) break;
                    Thread.Sleep(1000);
                }
                watch.Stop();

                CheckAgentStatus(out int pid, true);
            }
            catch (Exception)
            {
                //TODO: LOG
                Instance.IsAgentRunning = false;
            }
            return Instance.IsAgentRunning;
        }

        #endregion

        #region GENERIC EXECUTORS

        protected T ExecuteReader<T, U>(string commandText, List<SqlParameter> sqlParameters) where T : BaseCollection<U> where U : BaseModel
        {
            T collection;

            using (SqlConnection connection = new SqlConnection(Instance.ConnectionString))
            {
                connection.Open();

                using (SqlCommand sql_command = new SqlCommand(commandText, connection))
                {
                    sql_command.CommandType = CommandType.Text;

                    foreach (var parameter in sqlParameters)
                    {
                        sql_command.Parameters.Add(parameter);
                    }

                    SqlDataReader reader = sql_command.ExecuteReader();

                    List<U> items = reader.ToList<U>();                    

                    collection = Activator.CreateInstance<T>();
                    collection.Items.AddRange(items);

                    return collection;
                }
            }
        }

        protected int ExecuteProcedure(string procedureName, List<SqlParameter> sqlParameters)
        {

            using (SqlConnection connection = new SqlConnection(Instance.ConnectionString))
            {
                connection.Open();

                using (SqlCommand sql_command = new SqlCommand(procedureName, connection))
                {
                    sql_command.CommandType = CommandType.StoredProcedure;
                    foreach (var parameter in sqlParameters)
                    {
                        sql_command.Parameters.Add(parameter);
                    }

                    int ret = sql_command.ExecuteNonQuery();
                    return ret;
                }
            }
        }

        protected object ExecuteScalar(string command_text, List<SqlParameter> sqlParameters)
        {
            using (SqlConnection connection = new SqlConnection(Instance.ConnectionString))
            {
                connection.Open();

                using (SqlCommand sql_command = new SqlCommand(command_text, connection))
                {
                    sql_command.CommandType = CommandType.Text;
                    foreach (var parameter in sqlParameters)
                    {
                        sql_command.Parameters.Add(parameter);
                    }

                    return sql_command.ExecuteScalar();
                }
            }
        }

        protected int ExecuteNonQuery(string command_text, List<SqlParameter> sqlParameters)
        {
            using (SqlConnection connection = new SqlConnection(Instance.ConnectionString))
            {
                connection.Open();

                using (SqlCommand sql_command = new SqlCommand(command_text, connection))
                {
                    sql_command.CommandType = CommandType.Text;
                    foreach (var parameter in sqlParameters)
                    {
                        sql_command.Parameters.Add(parameter);
                    }

                    return sql_command.ExecuteNonQuery();
                }
            }
        }

        protected int AdapterUpdate(DataTable table, string selectCommandText)
        {
            using (SqlConnection connection = new SqlConnection(Instance.ConnectionString))
            {
                connection.Open();
                using (SqlDataAdapter adapter = new SqlDataAdapter(selectCommandText, connection))
                {
                    SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
                    SqlCommand command = builder.GetInsertCommand(true);
                    return adapter.Update(table);
                }
            }
        }

        #endregion

    }
}
