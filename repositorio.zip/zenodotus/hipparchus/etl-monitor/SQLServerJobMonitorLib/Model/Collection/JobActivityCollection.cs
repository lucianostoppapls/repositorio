﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{

    public class JobActivityCollection : BaseJobCollection<JobActivity>
    {
        public JobActivityCollection() : base()
        {

        }

        public JobActivityCollection(JobActivity job) : base(job)
        {

        }

        public JobActivityCollection(List<JobActivity> jobs) : base(jobs)
        {

        }
    }
}
