﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model.Collection
{
    public class MonitoredJobActivityStateCollection : BaseJobCollection<MonitoredJobActivityState>
    {
        public MonitoredJobActivityStateCollection() : base()
        {

        }

        public MonitoredJobActivityStateCollection(MonitoredJobActivityState job) : base(job)
        {

        }

        public MonitoredJobActivityStateCollection(List<MonitoredJobActivityState> jobs) : base(jobs)
        {

        }
    }
}
