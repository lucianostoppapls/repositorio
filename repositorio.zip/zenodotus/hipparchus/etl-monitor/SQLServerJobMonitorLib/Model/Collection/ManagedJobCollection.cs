﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class ManagedJobCollection : BaseJobCollection<ManagedJob>
    {

        #region NON DEFAULT CONSTRUCTORS

        public ManagedJobCollection() : base()
        {

        }

        public ManagedJobCollection(ManagedJob job) : base(job)
        {

        }

        public ManagedJobCollection(List<ManagedJob> jobs) : base(jobs)
        {

        }

        #endregion
    }
}
