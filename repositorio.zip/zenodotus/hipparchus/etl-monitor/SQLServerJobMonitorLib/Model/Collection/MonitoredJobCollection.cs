﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class MonitoredJobCollection : BaseJobCollection<MonitoredJob>
    {
        public MonitoredJobCollection() : base()
        {

        }

        public MonitoredJobCollection(MonitoredJob job) : base(job)
        {

        }

        public MonitoredJobCollection(List<MonitoredJob> jobs) : base(jobs)
        {

        }
    }
}