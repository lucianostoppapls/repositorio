﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model.Collection
{
    public class MonitoredJobActivityCollection : BaseJobCollection<MonitoredJobActivity>
    {
        public MonitoredJobActivityCollection() : base()
        {

        }

        public MonitoredJobActivityCollection(MonitoredJobActivity job) : base(job)
        {

        }

        public MonitoredJobActivityCollection(List<MonitoredJobActivity> jobs) : base(jobs)
        {

        }
    }
}
