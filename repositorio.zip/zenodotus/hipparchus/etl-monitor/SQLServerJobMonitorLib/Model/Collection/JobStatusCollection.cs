﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class JobStatusCollection : BaseJobCollection<JobStatus>
    {
        public JobStatusCollection() : base()
        {

        }

        public JobStatusCollection(JobStatus job) : base(job)
        {

        }

        public JobStatusCollection(List<JobStatus> jobs) : base(jobs)
        {

        }
    }
}
