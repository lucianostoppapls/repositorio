﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class AgentJobCollection : BaseJobCollection<AgentJob>
    {
        public AgentJobCollection() : base()
        {

        }

        public AgentJobCollection(AgentJob job) : base(job)
        {

        }

        public AgentJobCollection(List<AgentJob> jobs) : base(jobs)
        {

        }
    }
}
