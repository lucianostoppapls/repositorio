﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class JobCollection : BaseJobCollection<Job>
    {
        public JobCollection() : base()
        {

        }

        public JobCollection(Job job) : base(job)
        {

        }

        public JobCollection(List<Job> jobs) : base(jobs)
        {

        }
    }
}
