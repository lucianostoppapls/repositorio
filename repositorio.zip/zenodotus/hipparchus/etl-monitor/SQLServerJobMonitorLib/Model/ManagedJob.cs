﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class ManagedJob : BaseModel, IManagedJob
    {
        public Guid JobId { get; set; }
        public string JobName { get; set; }
        public decimal ExpectationInMinutes { get; set; }
        public decimal ToleranceInPercent { get; set; }
        public byte NumberOfRetries { get; set; }
        public bool IsManaged { get; set; }
        public int TimeoutInSeconds { get; set; }
        public int PollingInSeconds { get; set; }
        public TimeSpan StartWindow { get; set; }
        public TimeSpan EndWindow { get; set; }

    }
}
