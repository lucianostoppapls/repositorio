﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class JobEventLog : BaseModel
    {
        public int EventLogId { get; set; }
        public string EventMessage { get; set; }
        public DateTime EventTime { get; set; }
        public byte LogLevel { get; set; }     
        public string ExceptionSource { get; set; }
        public string ExceptionMessage { get; set; }
        public string StackTrace { get; set; }
        public string AdditionalData { get; set; }
    }
}
