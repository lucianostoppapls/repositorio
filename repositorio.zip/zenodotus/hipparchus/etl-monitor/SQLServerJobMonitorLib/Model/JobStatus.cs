﻿using StoneCo.MIS.SQLJobMonitor.Lib.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class JobStatus : BaseModel, IJobStatus
    {
        public Guid JobId { get; set; }
        public string JobName { get; set; }
        public bool IsRunning { get; set; }
        public bool IsRestarting { get; set; }
        public bool OnAttempts { get; set; }
        public JobState RunningState { get; set; }
        public byte NumberOfRetries { get; set; }
        public int RetriesAttempted { get; set; }
        public int InstanceId { get; set; }
        public int OriginalInstanceId { get; set; }
        public int PreviousInstanceId { get; set; }
    }
}
