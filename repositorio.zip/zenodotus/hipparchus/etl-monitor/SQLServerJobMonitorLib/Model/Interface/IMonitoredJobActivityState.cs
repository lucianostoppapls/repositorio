﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model.Interface
{
    public interface IMonitoredJobActivityState : IMonitoredJobActivity
    {
        bool Sucess { get; set; }
        bool Failure { get; set; }
        bool Aborted { get; set; }
        bool Exausted { get; set; }        
        bool OnSchedule { get; set; }
        bool Delayed { get; set; }
    }
}
