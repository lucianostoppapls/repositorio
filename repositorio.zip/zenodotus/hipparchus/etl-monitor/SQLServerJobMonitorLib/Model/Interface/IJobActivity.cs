﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public enum RunRequestedSource : int
    {
        UNKNOWN = 0,
        SCHEDULER = 1,
        ALERTER = 2,
        BOOT = 3,
        USER = 4,
        ON_IDLE_SCHEDULE = 6
    }

    public enum RunStatus : int
    {
        FAILED = 0,
        SUCCEEDED = 1,
        RETRY = 2,
        CANCELED = 3,
        IN_PROGRESS = 4
    }

    public interface IJobActivity : IAgentJob
    {
        bool IsRunning { get; set; }        
        DateTime StartedAt { get; set; }
        DateTime EndedAt { get; set; }
        decimal DurationInMinutes { get; set; }        
        RunRequestedSource RequestedSource { get; set; }
        RunStatus LastRunstatus { get; set; }
        DateTime LastRunDate { get; set; }
        TimeSpan LastRunTime { get; set; }
        int InstanceId { get; set; }
        int PreviousInstanceId { get; set; }
    }
}