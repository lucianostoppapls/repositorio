﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public enum JobState : int
    {
        UNKNOWN = -1,
        IDLE = 0,
        ON_SCHEDULE = 1,
        DELAYED = 2,
        ERROR = 3,
    }

    public interface IJobStatus : IJob
    {
        bool IsRunning { get; set; }
        bool IsRestarting { get; set; }
        bool OnAttempts { get; set; }
        JobState RunningState { get; set; }
        byte NumberOfRetries { get; set; }
        int RetriesAttempted { get; set; }
        int InstanceId { get; set; }
        int OriginalInstanceId { get; set; }
        int PreviousInstanceId { get; set; }
    }
}
