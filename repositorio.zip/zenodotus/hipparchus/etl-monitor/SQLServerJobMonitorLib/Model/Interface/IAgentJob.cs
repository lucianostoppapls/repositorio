﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public interface IAgentJob : IJob
    {
        bool IsEnabled { get; set; }
        DateTime DateCreated { get; set; }
        DateTime DateModified { get; set; }
        int VersionNumber { get; set; }
    }
}
