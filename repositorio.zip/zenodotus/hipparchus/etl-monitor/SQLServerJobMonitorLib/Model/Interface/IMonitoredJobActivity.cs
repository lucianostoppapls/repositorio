﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model.Interface
{
    public interface IMonitoredJobActivity : IJobStatus, IManagedJob, IJobActivity
    {

    }
}
