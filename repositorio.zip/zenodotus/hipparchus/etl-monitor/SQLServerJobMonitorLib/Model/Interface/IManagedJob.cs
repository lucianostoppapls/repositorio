﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public interface IManagedJob : IJob
    {
        bool IsManaged { get; set; }
        decimal ExpectationInMinutes { get; set; }
        decimal ToleranceInPercent { get; set; }
        byte NumberOfRetries { get; set; }        
        int TimeoutInSeconds { get; set; }
        int PollingInSeconds { get; set; }
        TimeSpan StartWindow { get; set; }
        TimeSpan EndWindow { get; set; }
    }
}
