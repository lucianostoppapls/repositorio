﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public interface IJob
    {
        Guid JobId { get; set; }
        string JobName { get; set; }
    }
}
