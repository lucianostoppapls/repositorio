﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class AgentJob : BaseModel, IAgentJob
    {
        public Guid JobId { get; set; }
        public string JobName { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }
        public int VersionNumber { get; set; }
    }
}
