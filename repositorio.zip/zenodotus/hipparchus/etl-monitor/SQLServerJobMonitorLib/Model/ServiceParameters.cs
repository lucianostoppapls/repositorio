﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class ServiceParameters : BaseModel
    {
        /// <summary>
        /// Indicates whether the Monitoring Service should try to start the SQL Agent if Stopped.
        /// </summary>
        public bool StartAgent { get; set; }

        /// <summary>
        /// Time interval in seconds to wait for Agent to Start.
        /// </summary>
        public int StartAgentTimeout { get; set; }

        /// <summary>
        /// Time interval in seconds to check job execution.
        /// </summary>
        public int VerificationInterval { get; set; }
        /// <summary>
        /// JobRestartRetries: Number of retries for irresponsive jobs.
        /// </summary>
        public int JobRestartRetries { get; set; }

        /// <summary>
        /// ConnectionString to Monitoring Database containing the JobMonitorConfiguration table should be created.
        /// </summary>
        [JsonIgnore]
        public string MonitoringDB { get; set; }

        /// <summary>
        /// ConnectionString to Monitoring Database containing the JobMonitorConfiguration table should be created.
        /// </summary>
        [JsonIgnore]
        public string MonitoredInstance { get; set; }

        /// <summary>
        /// LogFilePath: Custom absolute path for text file logs. If Empty, will use the assembly's path
        /// </summary>
        public string LogFilePath { get; set; }

        /// <summary>
        /// LogProviderType: Options to determ the Default log provider destination.
        /// </summary>
        public byte LogProviderType { get; set; }

        /// <summary>
        /// LogLevelOption: Options to determ the Default log level option. That is, which level of information is logged. 
        /// </summary>
        public byte LogLevelOption { get; set; }
    }
}
