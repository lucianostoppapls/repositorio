﻿using StoneCo.MIS.SQLJobMonitor.Lib.Model.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class MonitoredJobActivityState : BaseModel, IMonitoredJobActivityState
    {
        public Guid JobId { get; set; }
        public string JobName { get; set; }
        public bool IsRunning { get; set; }
        public DateTime StartedAt { get; set; }
        public DateTime EndedAt { get; set; }
        public decimal DurationInMinutes { get; set; }
        public RunRequestedSource RequestedSource { get; set; }
        public RunStatus LastRunstatus { get; set; }
        public int InstanceId { get; set; }
        public int PreviousInstanceId { get; set; }
        public decimal ExpectationInMinutes { get; set; }
        public decimal ToleranceInPercent { get; set; }
        public byte NumberOfRetries { get; set; }
        public bool IsManaged { get; set; }
        public int TimeoutInSeconds { get; set; }
        public int PollingInSeconds { get; set; }
        public JobState RunningState { get; set; }
        public bool IsRestarting { get; set; }
        public int RetriesAttempted { get; set; }
        public int OriginalInstanceId { get; set; }
        public TimeSpan StartWindow { get; set; }
        public TimeSpan EndWindow { get; set; }
        public DateTime LastRunDate { get; set; }
        public TimeSpan LastRunTime { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }
        public int VersionNumber { get; set; }
        public bool Sucess { get; set; }
        public bool Failure { get; set; }
        public bool Aborted { get; set; }
        public bool Exausted { get; set; }
        public bool OnAttempts { get; set; }
        public bool OnSchedule { get; set; }
        public bool Delayed { get; set; }
    }
}
