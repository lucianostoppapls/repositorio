﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class MonitoredJob : BaseModel, IMonitoredtJob
    {
        public Guid JobId { get; set; }
        public string JobName { get; set; }
        public decimal ExpectationInMinutes { get; set; }
        public decimal ToleranceInPercent { get; set; }
        public byte NumberOfRetries { get; set; }
        public bool IsManaged { get; set; }
        public int TimeoutInSeconds { get; set; }
        public int PollingInSeconds { get; set; }
        public TimeSpan StartWindow { get; set; }
        public TimeSpan EndWindow { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }
        public int VersionNumber { get; set; }

        #region CUSTOM CONSTRUCTORS

        public MonitoredJob() : base()
        {

        }

        public MonitoredJob(ManagedJob managedJob, AgentJob agentJob) : base()
        {
            #region JOB PROPERTIES

            JobId = managedJob.JobId;
            JobName = managedJob.JobName;

            #endregion

            #region MANAGED JOB PROPERTIES

            ExpectationInMinutes = managedJob.ExpectationInMinutes;
            ToleranceInPercent = managedJob.ToleranceInPercent;
            NumberOfRetries = managedJob.NumberOfRetries;
            IsManaged = managedJob.IsManaged;
            TimeoutInSeconds = managedJob.TimeoutInSeconds;
            PollingInSeconds = managedJob.PollingInSeconds;
            StartWindow = managedJob.StartWindow;
            EndWindow = managedJob.EndWindow;

            #endregion

            #region AGENT JOB PROPERTIES

            IsEnabled = agentJob.IsEnabled;
            DateCreated = agentJob.DateCreated;
            DateModified = agentJob.DateModified;
            VersionNumber = agentJob.VersionNumber;

            #endregion
        }

        #endregion
    }
}
