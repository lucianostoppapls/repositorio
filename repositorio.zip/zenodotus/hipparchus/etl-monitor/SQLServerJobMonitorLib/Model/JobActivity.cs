﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class JobActivity : BaseModel, IJobActivity
    {
        public Guid JobId { get; set; }
        public string JobName { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }
        public int VersionNumber { get; set; }
        public bool IsRunning { get; set; }        
        public DateTime StartedAt { get; set; }
        public DateTime EndedAt { get; set; }
        public decimal DurationInMinutes { get; set; }        
        public RunRequestedSource RequestedSource { get; set; }        
        public RunStatus LastRunstatus { get; set; }
        public DateTime LastRunDate { get; set; }
        public TimeSpan LastRunTime { get; set; }
        public int InstanceId { get; set; }
        public int PreviousInstanceId { get; set; }
    }
}
