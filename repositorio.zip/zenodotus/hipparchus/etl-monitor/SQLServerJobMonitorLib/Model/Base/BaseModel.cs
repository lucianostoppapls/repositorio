﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public abstract class BaseModel : IEqualityComparer<BaseModel>
    {
        public override string ToString()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }

        public override bool Equals(object obj)
        {
            return Equals(this, obj as BaseModel); 
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();  
        }

        public bool Equals(BaseModel x, BaseModel y)
        {
            //return false if any is null or non-matching type
            if (x == null || y == null || !x.GetType().Equals(y.GetType()))
            {
                return false;
            }

            //returns true if objects have the same address
            if (ReferenceEquals(x, y))
            {
                return true;
            }

            var x_prop = x.GetType().GetProperties().ToList();
            var y_prop = y.GetType().GetProperties().ToList();

            //get list of properties with same name and different values
            var diff = x_prop.Where(px => !y_prop.Any(py => px.Name == py.Name && !(px.GetValue(x, null) == (py.GetValue(y, null)))));            
            return diff.Count() > 0;
        }

        public int GetHashCode(BaseModel obj)
        {
            return obj.GetHashCode();
        }

        public BaseModel()
        {

        }
    }
}
