﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public abstract class BaseJobCollection<T> : BaseCollection<T> where T : BaseModel, IJob
    {
        #region NON DEFAULT CONSTRUCTORS

        public BaseJobCollection() : base()
        {

        }

        public BaseJobCollection(T item) : base(item)
        {

        }

        public BaseJobCollection(List<T> items) : base(items)
        {

        }
        #endregion

        #region CUSTOM INDEXES FOR DERIVED CLASS

        public T this[string name]
        {
            get { return Items.Where(job => job.JobName == name).FirstOrDefault(); }
            set
            {
                if (Items.Exists(job => job.JobName == name))
                {
                    Items[Items.FindIndex(job => job.JobName == name)] = value;
                }
                else
                {
                    Items.Add(value);
                }
            }
        }

        public T this[Guid id]
        {
            get { return Items.Where(job => job.JobId == id).FirstOrDefault(); }
            set
            {
                if (Items.Exists(job => job.JobId == id))
                {
                    Items[Items.FindIndex(job => job.JobId == id)] = value;
                }
                else
                {
                    Items.Add(value);
                }
            }
        }

        #endregion
    }
}
