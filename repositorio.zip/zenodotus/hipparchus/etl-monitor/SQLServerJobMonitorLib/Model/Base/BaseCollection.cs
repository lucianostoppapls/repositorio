﻿using ExtensionMethods;
using Microsoft.SqlServer.Server;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public abstract class BaseCollection<T> : IEnumerable<T>, IEqualityComparer<BaseCollection<T>> where T : BaseModel
    {
        public List<T> Items { get; set; }

        public BaseCollection()
        {
            Items = new List<T>();
        }

        public BaseCollection(T item)
        {
            Items = new List<T>
            {
                item
            };
        }

        public BaseCollection(List<T> items)
        {
            Items = new List<T>();
            Items.AddRange(items);
        }

        public IEnumerator<T> GetEnumerator()
        {
            return Items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public List<T> ToList()
        {
            return Items.ToList<T>();
        }

        public int Count
        {
            get { return Items.Count(); }
        }


        public T this[int index]
        {
            get {
                if (index <= Items.Count - 1)
                {
                    return Items[index];
                }
                return this.GetEnumerator().Current;
            }
            set { Items[index] = value; }
        }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(Items, Formatting.Indented);
        }

        public override bool Equals(object obj)
        {
            return Equals(this, obj as BaseCollection<T>);    
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();  
        }

        public bool Equals(BaseCollection<T> x, BaseCollection<T> y)
        {
            //return false if any is null or non-matching type
            if (x == null || y == null || !x.GetType().Equals(y.GetType()))
            {
                return false;
            }

            //returns true if objects have the same address
            if (ReferenceEquals(x, y))
            {
                return true;
            }
                        
            var x_prop = x.Items;
            var y_prop = y.Items;

            //get list of items with different values
            var diff = x_prop.Where(px => !y_prop.Any(py => !px.Equals(px, py)));            
            return diff.Count() == 0;

        }

        public int GetHashCode(BaseCollection<T> obj)
        {
            return obj.GetHashCode();
        }
    }
}
