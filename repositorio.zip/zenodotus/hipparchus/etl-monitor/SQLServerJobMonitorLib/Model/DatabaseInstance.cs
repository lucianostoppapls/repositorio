﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class DatabaseInstance : BaseModel
    {   
        public string DataSource { get; set; }
        public string Database { get; set; }
        public string ServerVersion { get; set; }
        public bool CanConnect { get; set; }
        public bool IsAgentRunning { get; set; }
        [JsonIgnore]
        public string ConnectionString { get; set; }
    }
}
