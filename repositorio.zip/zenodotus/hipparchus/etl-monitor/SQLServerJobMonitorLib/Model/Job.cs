﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Model
{
    public class Job : BaseModel, IJob
    {
        public Guid JobId { get; set; }
        public string JobName { get; set; }
    }
}
