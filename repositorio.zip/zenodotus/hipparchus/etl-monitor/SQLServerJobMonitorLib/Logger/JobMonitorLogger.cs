﻿using ExtensionMethods;
using StoneCo.MIS.SQLJobMonitor.Lib.Configuration;
using StoneCo.MIS.SQLJobMonitor.Lib.DataAccess;
using StoneCo.MIS.SQLJobMonitor.Lib.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StoneCo.MIS.SQLJobMonitor.Lib.Logger
{
    public class JobMonitorLogger
    {

        #region PUBLIC ENUMERATORS

        /// <summary>
        /// <br/>Options to determ the Default log provider destination.<br/><br/>
        /// For multi-selection, concatenate with | (bitwise OR):<code>LogProviderType.EventViewer | LogProviderType.DatabaseTable</code>
        /// </summary>
        /// <remarks>This example code logs both to Event Viewer on Application source and to the Monitoring DB Table.</remarks>
        public enum LogProviderType : byte
        {
            /// <summary>
            /// Log entries to EventView on Application Source.
            /// </summary>
            EventViewer = 1,

            /// <summary>
            /// Log entries to text file in custom user defined path or in assembly's folder if path is not provided.
            /// </summary>
            TextFile = 2,

            /// <summary>
            /// Log entries on Monitoring database table defined in ConnectionStrings name.
            /// </summary>
            DatabaseTable = 4,

            /// <summary>
            /// Log entries to Debug Console output
            /// </summary>
            ConsoleOutput = 8,

            /// <summary>
            /// Used for bitwise operations
            /// </summary>
            FullMask = 15
        }

        /// <summary>
        /// <br/>Options to determ the Default log level option. That is, which level of information is logged.<br/><br/>
        /// For multi-selection, concatenate with | (bitwise OR):<code>LogLevelOption.Error | LogLevelOption.Warning</code><br/>
        /// This example code logs both Errors and Warning to the providers.
        /// </summary>                
        public enum LogLevelOption : byte
        {
            /// <summary>
            ///An error event. This indicates a significant problem the user should know about;<br/>
            ///usually a loss of functionality or data.
            /// </summary>
            Error = 1,

            /// <summary>
            /// A warning event. This indicates a problem that is not immediately significant, but that may signify conditions that could cause future problems.
            /// </summary>
            Warning = 2,

            /// <summary>
            /// An information event. This indicates a significant, successful operation.
            /// </summary>
            Information = 4,

            /// <summary>
            /// Verbose Option has the same effect as selecting:<br/><br/><c>LogLevelOption.Error | LogLevelOption.Warning | LogLevelOption.Information</c>
            /// </summary>
            Verbose = 7,

            /// <summary>
            /// Audit of a Success event. This indicates a success event occurred and must be audited.
            /// </summary>
            SuccessAudit = 8,

            /// <summary>
            /// Audit of a Failure event. This indicates a failure event occurred and must be audited.
            /// </summary>
            FailureAudit = 16,

            /// <summary>
            /// An audit event. This indicates an event occurred and must be audited.
            /// </summary>
            Audit = 24
        }

        #endregion

        #region PRIVATE CLASS ATTRIBUTES

        private static EventLog monitorEventLog;
        private const string EVENT_SOURCE_NAME = "SQLServerJobMonitor";
        private const string EVENT_LOG_NAME = "Application";
        private static LoggerDataAccess monitorDatabase;

        #endregion

        #region PUBLIC PROPERTIES

        private LogProviderType _providerType;
        /// <summary>
        /// 
        /// </summary>
        public LogProviderType ProviderType
        {
            get
            {
                return _providerType;
            }
            set
            {
                _providerType = value;
                if ((_providerType & LogProviderType.DatabaseTable) == LogProviderType.DatabaseTable)
                {
                    RegisterMonitorDatabase();
                }
            }
        }


        /// <summary>
        /// 
        /// </summary>
        public LogLevelOption LevelOption { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string LogFilePath { get; set; }

        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// 
        /// </summary>
        public JobMonitorLogger() : this(default, default, default)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="providerType"></param>
        /// <param name="logLevel"></param>
        /// <param name="logFilePath"></param>
        public JobMonitorLogger(LogProviderType providerType = LogProviderType.TextFile, LogLevelOption logLevel = LogLevelOption.Error, string logFilePath = null)
        {
            LevelOption = logLevel;
            ProviderType = providerType;
            LogFilePath = logFilePath;

            RegisterEventViewer();


        }

        #endregion

        #region INITIALIZERS

        private void RegisterMonitorDatabase()
        {
            try
            {
                monitorDatabase = new LoggerDataAccess(JobMonitorConfigurationManager.GetConfigurations().MonitoringDB);
                monitorDatabase.TestConnection();

                if (monitorDatabase.Instance.CanConnect)
                {
                    Audit($"Connection to Monitor Database successfull (Logger).", additionalData: $"{monitorDatabase.Instance}");
                }
            }
            catch (Exception ex)
            {
                monitorDatabase = null;
                string formmattedMessage = $"Could not register Monitor Database.";
                WriteEntry(formmattedMessage, ex, DateTime.Now, LogProviderType.EventViewer | LogProviderType.TextFile, LogLevelOption.Error, additionalData: $"{monitorDatabase.Instance}");
                throw ex;
            }

        }

        private void RegisterEventViewer()
        {
            monitorEventLog = new EventLog();

            try
            {
                if (!EventLog.SourceExists(EVENT_SOURCE_NAME))
                {
                    EventLog.CreateEventSource(EVENT_SOURCE_NAME, EVENT_LOG_NAME);
                }
                monitorEventLog.Source = EVENT_SOURCE_NAME;
                monitorEventLog.Log = EVENT_LOG_NAME;

            }
            catch (Exception ex)
            {
                monitorEventLog = null;
                string formmattedMessage = $"Could not register Event Viewer Source.";
                WriteEntry(formmattedMessage, ex, DateTime.Now, LogProviderType.EventViewer | LogProviderType.TextFile, LogLevelOption.Error, additionalData: $"{EVENT_SOURCE_NAME}");

                throw;
            }
        }

        #endregion

        #region LOG INFO


        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public void Info(string message, string additionalData = null)
        {
            Info(message, null, DateTime.Now, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        public void Info(string message, DateTime eventTime, string additionalData = null)
        {
            Info(message, null, eventTime, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void Info(string message, Exception exception, string additionalData = null)
        {
            Info(message, exception, DateTime.Now, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="eventTime"></param>
        public void Info(string message, Exception exception, DateTime eventTime, string additionalData = null)
        {
            Info(message, exception, eventTime, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        /// <param name="providerType"></param>
        public void Info(string message, DateTime eventTime, LogProviderType providerType, string additionalData = null)
        {
            Info(message, null, eventTime, providerType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="eventTime"></param>
        /// <param name="providerType"></param>
        public void Info(string message, Exception exception, DateTime eventTime, LogProviderType providerType, string additionalData = null)
        {
            if ((LevelOption & LogLevelOption.Information) == LogLevelOption.Information)
            {
                WriteEntry(message, exception, eventTime, providerType, LogLevelOption.Information, additionalData, LogFilePath);
            }
        }

        #endregion

        #region LOG WARNING

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public void Warn(string message, string additionalData = null)
        {
            Warn(message, null, DateTime.Now, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        public void Warn(string message, DateTime eventTime, string additionalData = null)
        {
            Warn(message, null, eventTime, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void Warn(string message, Exception exception, string additionalData = null)
        {
            Warn(message, exception, DateTime.Now, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="eventTime"></param>
        public void Warn(string message, Exception exception, DateTime eventTime, string additionalData = null)
        {
            Warn(message, exception, eventTime, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        /// <param name="providerType"></param>
        public void Warn(string message, DateTime eventTime, LogProviderType providerType, string additionalData = null)
        {
            Warn(message, null, eventTime, providerType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="eventTime"></param>
        /// <param name="providerType"></param>
        public void Warn(string message, Exception exception, DateTime eventTime, LogProviderType providerType, string additionalData = null)
        {
            if ((LevelOption & LogLevelOption.Warning) == LogLevelOption.Warning)
            {
                WriteEntry(message, exception, eventTime, providerType, LogLevelOption.Warning, additionalData, LogFilePath);
            }
        }

        #endregion

        #region LOG ERROR
        /// <summary>
        /// 
        /// </summary>
        public void Error(string message, string additionalData = null)
        {
            Error(message, null, DateTime.Now, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        public void Error(string message, DateTime eventTime, string additionalData = null)
        {
            Error(message, null, eventTime, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void Error(string message, Exception exception, string additionalData = null)
        {
            Error(message, exception, DateTime.Now, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="eventTime"></param>
        public void Error(string message, Exception exception, DateTime eventTime, string additionalData = null)
        {
            Error(message, exception, eventTime, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        /// <param name="providerType"></param>
        public void Error(string message, DateTime eventTime, LogProviderType providerType, string additionalData = null)
        {
            Error(message, null, eventTime, providerType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="eventTime"></param>
        /// <param name="providerType"></param>
        public void Error(string message, Exception exception, DateTime eventTime, LogProviderType providerType, string additionalData = null)
        {
            if ((LevelOption & LogLevelOption.Error) == LogLevelOption.Error)
            {
                WriteEntry(message, exception, eventTime, providerType, LogLevelOption.Error, additionalData, LogFilePath);
            }
        }

        #endregion

        #region AUDIT


        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public void Audit(string message, string additionalData = null)
        {
            Audit(message, null, DateTime.Now, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        public void Audit(string message, DateTime eventTime, string additionalData = null)
        {
            Audit(message, null, eventTime, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        public void Audit(string message, Exception exception, string additionalData = null)
        {
            Audit(message, exception, DateTime.Now, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="eventTime"></param>
        public void Audit(string message, Exception exception, DateTime eventTime, string additionalData = null)
        {
            Audit(message, exception, eventTime, ProviderType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        /// <param name="providerType"></param>
        public void Audit(string message, DateTime eventTime, LogProviderType providerType, string additionalData = null)
        {
            Audit(message, null, eventTime, providerType, additionalData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="eventTime"></param>
        /// <param name="providerType"></param>
        public void Audit(string message, Exception exception, DateTime eventTime, LogProviderType providerType, string additionalData = null)
        {
            WriteEntry(message, exception, eventTime, providerType, LogLevelOption.SuccessAudit, additionalData, LogFilePath);
        }

        #endregion

        #region LOG WRITE STATIC METHODS

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="eventTime"></param>
        /// <param name="providerType"></param>
        /// <param name="logLevel"></param>
        public static void WriteEntry(string message, Exception exception, DateTime eventTime, LogProviderType providerType, LogLevelOption logLevel, string additionalData = null, string logPath = null)
        {
            if ((providerType & LogProviderType.EventViewer) == LogProviderType.EventViewer)
            {
                WriteEventViewer(message, exception, logLevel, additionalData);
            }

            if ((providerType & LogProviderType.TextFile) == LogProviderType.TextFile)
            {
                WriteToLogFile(message, eventTime, exception, logLevel, additionalData, logPath);
            }

            if ((providerType & LogProviderType.ConsoleOutput) == LogProviderType.ConsoleOutput)
            {
                WriteToConsole(message, eventTime, exception, logLevel, additionalData);
            }

            if ((providerType & LogProviderType.DatabaseTable) == LogProviderType.DatabaseTable)
            {
                WriteToTable(message, eventTime, exception, logLevel, additionalData);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <param name="logLevel"></param>
        public static void WriteEventViewer(string message, Exception exception, LogLevelOption logLevel, string additionalData = null)
        {
            string formattedException = (exception == null) ? string.Empty : $"\nSource: {exception?.Source}\n{ exception?.Message}\n{ exception?.StackTrace}";
            string formattedAdditional = string.IsNullOrWhiteSpace(additionalData) ? string.Empty : $"\n{additionalData}";
            string formattedMessage = $"{message}{formattedAdditional}{formattedException}";

            if (monitorEventLog == null)
            {
                EventLog.WriteEntry("Application", formattedMessage, (EventLogEntryType)logLevel);
            }
            else
            {
                monitorEventLog?.WriteEntry(formattedMessage, (EventLogEntryType)logLevel);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        /// <param name="exception"></param>
        /// <param name="logLevel"></param>
        /// <param name="logPath"></param>
        public static void WriteToLogFile(string message, DateTime eventTime, Exception exception, LogLevelOption logLevel, string additionalData, string logPath = null)
        {

            string formattedException = (exception == null) ? string.Empty : $"\nSource: {exception?.Source}\n{exception?.Message}\n{exception?.StackTrace}";
            string formattedAdditional = string.IsNullOrWhiteSpace(additionalData) ? string.Empty : $"\n{additionalData}";
            string formattedMessage = $"{eventTime.ToUniversalTime():yyyy-MM-dd HH:mm:ss tt}, {Enum.GetName(typeof(LogLevelOption), logLevel)}, {message}\n{formattedAdditional}{formattedException}";

            string path = logPath.GetValueOrDefault(AppDomain.CurrentDomain.BaseDirectory) + "\\Logs";
            string filepath = path + "\\ServiceLog_" + DateTime.Now.Date.ToShortDateString().Replace('/', '_') + ".txt";

            try
            {
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
            }
            catch (Exception ex)
            {
                WriteEventViewer($"Could create the logging directory: {path}\nError: {ex.Message}", ex, LogLevelOption.Error, null);
                throw ex;
            }

            try
            {
                if (!File.Exists(filepath))
                {
                    // Create a file to write to.   
                    using (StreamWriter sw = File.CreateText(filepath))
                    {
                        lock (sw)
                        {
                            sw.WriteLine(formattedMessage);
                        }
                    }
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(filepath))
                    {
                        lock (sw)
                        {
                            sw.WriteLine(formattedMessage);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                WriteEventViewer($"Could write to log file: {filepath}\nMessage: {formattedMessage}", ex, LogLevelOption.Error, null);
                throw ex;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        /// <param name="exception"></param>
        /// <param name="logLevel"></param>
        public static void WriteToConsole(string message, DateTime eventTime, Exception exception, LogLevelOption logLevel, string additionalData = null)
        {
            string formattedException = (exception == null) ? string.Empty : $"\nSource: {exception?.Source}, {exception?.Message}\n{exception?.StackTrace}";
            string formattedAdditional = string.IsNullOrWhiteSpace(additionalData) ? string.Empty : $"\n{additionalData}";
            string formattedMessage = $"{eventTime.ToUniversalTime():yyyy-MM-dd HH:mm:ss tt}, {Enum.GetName(typeof(LogLevelOption), logLevel)}, {message}\n{formattedAdditional}{formattedException}";

            Console.ResetColor();

            switch (logLevel)
            {
                case LogLevelOption.Error:
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    break;
                case LogLevelOption.Warning:
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    break;
                case LogLevelOption.SuccessAudit:
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    break;
                case LogLevelOption.FailureAudit:
                    Console.ForegroundColor = ConsoleColor.DarkMagenta;
                    break;
                default:
                    Console.ResetColor();
                    break;
            }

            Console.WriteLine(formattedMessage);

            Console.ResetColor();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="eventTime"></param>
        /// <param name="exception"></param>
        /// <param name="logLevel"></param>
        public static void WriteToTable(string message, DateTime eventTime, Exception exception, LogLevelOption logLevel, string additionalData = null)
        {
            JobEventLog log = new JobEventLog()
            {
                EventMessage = message,
                EventTime = eventTime.GetValueOrNow(),
                LogLevel = (byte)logLevel,
                ExceptionSource = exception?.Source,
                ExceptionMessage = exception?.Message,
                StackTrace = exception?.StackTrace,
                AdditionalData = additionalData,
            };

            try
            {
                monitorDatabase?.AppendEventLog(log);
            }
            catch (Exception ex)
            {
                WriteEventViewer($"Could write to job event log table.\n{message}", ex, LogLevelOption.Error, $"{log}");
                throw ex;
            }

        }

        #endregion
    }
}
