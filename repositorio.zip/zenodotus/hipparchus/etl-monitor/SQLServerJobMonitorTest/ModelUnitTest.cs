﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using StoneCo.MIS.SQLJobMonitor.Lib.Model;

namespace StoneCo.MIS.SQLJobMonitorTest
{
    [TestClass]
    public class ModelUnitTest
    {
        private readonly Guid job1_id = new Guid("1A3425FF-91C7-4D68-81E5-1AFF04DC3017");
        private readonly Guid job3_id = new Guid("538A2F71-67B1-4A9F-9C8F-9B2F21CC2D2C");
        private readonly string job1_name = "20 MINUTES JOB";
        private readonly string job3_name = "30 MINUTES JOB";

        private Job job1;
        private Job job2;
        private Job job3;
        private Job job4;
        private object job5;

        private JobCollection joblist1;
        private JobCollection joblist2;
        private JobCollection joblist3;
        private JobCollection joblist4;

        [TestInitialize]
        public void Setup()
        {       
            job1 = new Job() { JobId = job1_id, JobName = job1_name };
            job2 = new Job() { JobId = job1_id, JobName = job1_name };
            job3 = new Job() { JobId = job3_id, JobName = job3_name };
            job4 = new Job();
            job5 = new object();

            joblist1 = new JobCollection()
            {
                Items = new List<Job>() { job1, job2 }
            };

            joblist2 = new JobCollection()
            {
                Items = new List<Job>() { job1, job3 }
            };
            
            joblist3 = new JobCollection()
            {
                Items = new List<Job>() { job1, job4 }
            };

            joblist4 = new JobCollection()
            {
                Items = new List<Job>() { job1, job5 as Job }
            };
        }

        [TestMethod]
        public void TestEqualsObject()
        {
            Assert.IsTrue(job1.Equals(job1));
            Assert.IsTrue(job2.Equals(job2));
            Assert.IsTrue(job3.Equals(job3));
            Assert.IsTrue(job4.Equals(job4));
            Assert.IsTrue(job1.Equals(job2));

            Assert.IsFalse(job1.Equals(job3));
            Assert.IsFalse(job2.Equals(job3));
            Assert.IsFalse(job1.Equals(job4));
            Assert.IsFalse(job2.Equals(job4));
            Assert.IsFalse(job3.Equals(job4));

            Assert.IsFalse(job1.Equals(job5 as Job));
            Assert.IsFalse(job1.Equals(null));

            Assert.IsTrue(joblist1.Equals(joblist1));
            Assert.IsTrue(joblist2.Equals(joblist2));
            Assert.IsTrue(joblist3.Equals(joblist3));
            Assert.IsTrue(joblist4.Equals(joblist4));

            Assert.IsFalse(joblist1.Equals(joblist2));
            Assert.IsFalse(joblist1.Equals(joblist3));
            Assert.IsFalse(joblist1.Equals(joblist4));

            Assert.IsFalse(joblist1.Equals(null));
        }

        [TestMethod]
        public void TestEqualsBaseModel()
        {
            Assert.IsTrue(job1.Equals(job1, job1));
            Assert.IsTrue(job2.Equals(job2, job2));
            Assert.IsTrue(job3.Equals(job3, job3));
            Assert.IsTrue(job4.Equals(job4, job4));
            Assert.IsTrue(job1.Equals(job1, job2));

            Assert.IsFalse(job1.Equals(job1, job3));
            Assert.IsFalse(job2.Equals(job2, job3));
            Assert.IsFalse(job1.Equals(job1, job4));
            Assert.IsFalse(job2.Equals(job2, job4));
            Assert.IsFalse(job3.Equals(job3, job4));

            Assert.IsFalse(job1.Equals(job1, job5 as Job));
            Assert.IsFalse(job1.Equals(job1, null));

            Assert.IsTrue(joblist1.Equals(joblist1, joblist1));
            Assert.IsTrue(joblist2.Equals(joblist2, joblist2));
            Assert.IsTrue(joblist3.Equals(joblist3, joblist3));
            Assert.IsTrue(joblist4.Equals(joblist4, joblist4));

            Assert.IsFalse(joblist1.Equals(joblist1, joblist2));
            Assert.IsFalse(joblist1.Equals(joblist1, joblist3));
            Assert.IsFalse(joblist1.Equals(joblist1, joblist4));

            Assert.IsFalse(joblist1.Equals(joblist1, null));
        }

        [TestMethod]
        public void TestIndexes()
        {
            Assert.IsTrue(joblist1[job1_id].Equals(job1));
            Assert.IsTrue(joblist1[job1_name].Equals(job1));
            Assert.IsTrue(joblist1[0].Equals(job1));

            Assert.IsTrue(joblist2[job1_id].Equals(job1));
            Assert.IsTrue(joblist2[job1_name].Equals(job1));
            Assert.IsTrue(joblist2[0].Equals(job1));

            Assert.IsTrue(joblist2[job3_id].Equals(job3));
            Assert.IsTrue(joblist2[job3_name].Equals(job3));
            Assert.IsTrue(joblist2[1].Equals(job3));
        }
    }
}
