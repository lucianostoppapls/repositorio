# Hipparchus
![Image](./hipparchus.jpg?raw=true)

Our monitoring stack uses [Grafana](https://grafana.com/) on top of [Prometheus](https://prometheus.io/), deployed as a helm chart on Google [Kubernetes](https://kubernetes.io/docs/home/) Engine ([GKE](https://cloud.google.com/kubernetes-engine/docs)). It provides visibility to GKE infrastructure and the applications deployed there.
[Azure DevOps Pipelines](https://docs.microsoft.com/en-us/azure/devops/pipelines/?view=azure-devops) serves as the CI/CD platform.

Below we have a chart displaying how the components interact on GKE.
![Image](./prometheus-grafana-architecture.png?raw=true)
