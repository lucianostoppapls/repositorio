# import pyodbc
from decimal import Decimal
import json
import jsonlines
import pymssql
import datetime
import math
import os
import argparse
from google.cloud import storage

my_args = argparse.ArgumentParser(description="List of arguments for datasets")

my_args.add_argument("-t", "--table", type=str, help="source table")
my_args.add_argument(
    "-l", "--limit", type=int, default=50000, help="line limit - default 50000"
)
my_args.add_argument("-c", "--columns", type=str, help="columns to sort in the query")
my_args.add_argument(
    "-m",
    "--method",
    type=str,
    default="Both",
    help="Method to be called in the service: Extract, Upload or Both. - default Both",
)
my_args.add_argument(
    "-f",
    "--frequency",
    type=int,
    default=1,
    help="Frequency for extraction in days: Current date - frequency. - default 1",
)
my_args.add_argument("-d", "--database", type=str, help="Database for connection")
args = my_args.parse_args()


class HandleError(json.JSONEncoder):
    """
    Classe para corrigir problema com campos datetime e decimal na geração do json
    """

    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, datetime.datetime):
            return obj.__str__()
        return json.JSONEncoder.default(self, obj)


server = os.getenv("PYMSSQL_SERVER")
user = os.getenv("PYMSSQL_USERNAME")
pwd = os.getenv("PYMSSQL_PASSWORD")
port = int(os.getenv("PYMSSQL_PORT"))

database = args.database
limit = args.limit
columns = args.columns

bucket_name = "datalake_stg_software_sponte.stone.com.br"

days = datetime.timedelta(args.frequency)
start_date = (datetime.datetime.now() - days).date()
# end_date = datetime.datetime.combine(
#     (datetime.datetime.now() - datetime.timedelta(1)).date(), datetime.time(23, 59, 59)
# )


tables = [
    {
        "sponte_name": "ClientesSituacoes",
        "gcp_name": "clientes_clientessituacoes",
    },
    {
        "sponte_name": "ContasReceber2",
        "gcp_name": "clientes_contasreceber2",
    },
    {
        "sponte_name": "ContasReceberCorpo2",
        "gcp_name": "clientes_contasrecebercorpo2",
    },
    {
        "sponte_name": "Franquias",
        "gcp_name": "clientes_franquias",
    },
    {
        "sponte_name": "SPWProdutos",
        "gcp_name": "clientes_spwprodutos",
    },
    {
        "sponte_name": "HistoricosCorpo",
        "gcp_name": "clientes_historicocorpo",
    },
    {
        "sponte_name": "Situacao",
        "gcp_name": "clientes_situacao",
    },
    {
        "sponte_name": "Cidades",
        "gcp_name": "clientes_cidades",
    },
    {
        "sponte_name": "Clientes",
        "gcp_name": "clientes_clientes",
    },
    {
        "sponte_name": "ClientesAreasAtuacao",
        "gcp_name": "clientes_clientesareaatuacao",
    },
    {
        "sponte_name": "ClientesContrAlteracoes",
        "gcp_name": "clientes_clientescontralteracoes",
    },
    {
        "sponte_name": "ClientesContr",
        "gcp_name": "clientes_clientescontr",
    },
    {
        "sponte_name": "ClientesContrProdutos",
        "gcp_name": "clientes_clientescontrprodutos",
    },
    {
        "sponte_name": "DeletedRows",
        "gcp_name": "clientes_deletedrows",
    },
]

# args.table = Será tabela dos parms
table = [x for x in tables if str.lower(args.table) == str.lower(x["sponte_name"])]
print("Connecting to {} server, {} database..".format(server, database))
cnxn = pymssql.connect(
    host=server, port=port, user=user, password=pwd, database=f"{database}"
)
cur = cnxn.cursor(as_dict=True)


def execute_query(query):
    cur.execute(query)
    dados = cur.fetchall()

    return dados


def count_pages(table):
    count = execute_query(f"SELECT COUNT(*) as count FROM {table} (NOLOCK) ")
    pages = 1
    if count != None and count[0]["count"] > limit:
        pages = math.ceil(count[0]["count"] / limit)
    return pages


def paginated_query(table):
    pages = count_pages(table)
    i = 0
    query = []
    while i < pages:
        query.append(
            f"""
                SELECT 
                    *, 
                    Getdate() AS 'ExtractedAt' 
                FROM {table} (NOLOCK)
                WHERE 
                    LastModifiedAt >= '{start_date}' 
                ORDER BY {columns} 
                OFFSET {i * limit} ROWS 
                FETCH NEXT {limit} ROWS ONLY;
            """
        )
        i += 1
    return query


def dir_path(name_dir, mkdir=False):
    dir_path = os.path.dirname(os.path.realpath(__file__))
    dir_path += f"\\{name_dir}"
    if mkdir and os.path.exists(dir_path) == False:
        os.mkdir(dir_path)
    return dir_path


def remove_file(file):
    if os.path.exists(file) == True:
        os.remove(file)


def extract(table):
    path = dir_path(table, True)
    queries = paginated_query(table)
    page = 1
    path += f"\\{table}_{datetime.datetime.today().strftime('%Y%m%d')}"
    for query in queries:
        full_name = path + f"_page_{page}.json"
        remove_file(full_name)
        records = execute_query(query)
        if records != None:
            # Json padrão com [] com lista gera erros na importação. Ex: [{a: 1}, {a: 2}]
            # JsonL para a importação ex:
            # {a: 1}
            # {a: 2}
            print(f"writing data - page: {page}")
            with jsonlines.open(full_name, "w") as f:
                f.write_all([json.loads(HandleError().encode(x)) for x in records])
        page += 1


def upload(name_dir, table):
    path = dir_path(name_dir)
    files = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]
    storage_client = storage.Client.from_service_account_json(
        "software_sponte_nonprd_service_account_keys.json"
    )
    bucket = storage_client.bucket(bucket_name)
    for file in files:
        print(f"Processing file: {file}")
        blob = bucket.blob(f"{table}/{file}")
        if blob.exists():
            blob.delete()
        blob.upload_from_filename(path + "\\" + file)
        print(f"Uploaded file {table}/{file}")
        remove_file(path + "\\" + file)


if __name__ == "__main__":
    try:
        if str.lower(args.method) == "extract" or str.lower(args.method) == "both":
            extract(args.table)

        if str.lower(args.method) == "upload" or str.lower(args.method) == "both":
            upload(args.table, table[0]["gcp_name"])

    except Exception as e:
        print("Error: \n", e)
        pass
    finally:
        cnxn.close()
